#!/usr/bin/env python3
"""Read-only statement snapshot/metadata checker. It never invokes Lean, Lake or Comparator."""
from pathlib import Path
import json,hashlib,re,sys
import jsonschema
D=Path(__file__).resolve().parent; W=D.parent
m=json.loads((D/'STATEMENT-DRAFT.json').read_text()); checks=0
outer=json.loads((D/'MANIFEST.json').read_text()); expected=set()
for row in outer['files']:
 q=D/row['path']; b=q.read_bytes()
 assert len(b)==row['bytes'];assert hashlib.sha256(b).hexdigest()==row['sha256'];checks+=2
 expected.add(row['path'])
actual={str(q.relative_to(D)) for q in D.rglob('*') if q.is_file()}
assert actual-{'MANIFEST.json','STATIC-CHECK.json'}==expected;checks+=1
if '--live' in sys.argv:
 assert (W/'STATEMENT-DRAFT.json').read_bytes()==(D/'STATEMENT-DRAFT.json').read_bytes();checks+=1
payload={}
for r in m['files']:
 b=(D/r['snapshot_path']).read_bytes()
 assert len(b)==r['bytes']; assert hashlib.sha256(b).hexdigest()==r['sha256']; checks+=2
 payload[r['live_path']]=b.decode()
 if '--live' in sys.argv:
  assert (W/r['live_path']).read_bytes()==b; checks+=1
assert hashlib.sha256((W/'precode-01/MANIFEST.json').read_bytes()).hexdigest()==m['precode_manifest_sha256']; checks+=1
pre=json.loads((W/'precode-01/MANIFEST.json').read_text())
for r in pre['files']:
 b=(W/'precode-01'/r['path']).read_bytes()
 assert len(b)==r['bytes'];assert hashlib.sha256(b).hexdigest()==r['sha256'];checks+=2
cfg=json.loads(payload['comparator.json']); headers=json.loads(payload['STATEMENT-HEADERS.json'])
source=payload['Challenge.lean'];defs=payload['NLA/NM04/Definitions.lean']
found=re.findall(r'^theorem\s+(\w+)\b',source,re.M)
assert len(found)==35; assert ['NLA.NM04.'+x for x in found]==cfg['theorem_names']; checks+=2
assert cfg['definition_names']==[];assert cfg['permitted_axioms']==['propext','Quot.sound','Classical.choice'];checks+=2
assert len(re.findall(r'^  sorry$',source,re.M))==35;assert not re.search(r'\bsorry\b|\baxiom\b|\bunsafe\b|\bnative_decide\b',defs);checks+=2
assert re.findall(r'^import (\S+)',source,re.M)==['NLA.NM04.Definitions'];checks+=1
assert all(x.startswith('Mathlib.') for x in re.findall(r'^import (\S+)',defs,re.M));checks+=1
assert hashlib.sha256(source.encode()).hexdigest()==headers['source_sha256'];checks+=1
for h in headers['headers']:
 assert hashlib.sha256(h['header'].encode()).hexdigest()==h['header_sha256'];assert h['header'] in source;checks+=2
assert len(headers['headers'])==35;checks+=1
assert cfg['theorem_names'][-1]=='NLA.NM04.rowland_wu_identity';checks+=1
assert '((m : ℝ)⁻¹ • (HReal m n).submatrix' in source; checks+=1
lm=json.loads(payload['lake-manifest.json'])
for n,pin in [('leancert','621a43d7cf21f87872392a01e874f2f1dbddc926'),('mathlib','0df444a360eaa60ab8c11dca51a86af692955474')]:
 assert any(r['name']==n and r['rev']==pin for r in lm['packages']);checks+=1
assert payload['lean-toolchain']=='leanprover/lean4:v4.33.1\n';checks+=1
assert 'defaultTargets = ["Challenge"]' in payload['lakefile.toml'];checks+=1
schema=json.loads((W/'precode-01/sources/standards/mathlib-initiative/formalization.yaml/schema/v0.4.schema.json').read_text())
meta=json.loads(payload['formalization.yaml']);jsonschema.Draft202012Validator(schema).validate(meta);checks+=1
assert meta['status']['main_results']==[];checks+=1
assert meta['project']['affiliations']['George Stepaniants']=='Department of Computing and Mathematical Sciences, California Institute of Technology';checks+=1
assert all(not re.search(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',text) for text in payload.values());checks+=1
assert not m['actual_lean_run'] and not m['actual_leancert_run'] and not m['actual_comparator_run'];checks+=1
print(json.dumps({'status':'PASS_STATIC_STATEMENT_SNAPSHOT_ONLY','mode':'snapshot_and_live' if '--live' in sys.argv else 'snapshot','checks':checks,'contracts':35,'definitions_holes':0,'challenge_intentional_holes':35,'schema':'v0.4','actual_lean_run':False,'actual_leancert_run':False,'actual_comparator_run':False,'independent_approvals_claimed':0,'mathematical_correctness_certified':False},indent=2))
