/-
Copyright (c) 2026 George Stepaniants. Released under Apache 2.0 license.
Department of Computing and Mathematical Sciences, California Institute of Technology.
Substantial OpenAI Codex assistance. Mathematical source: Matthew J. Colbrook's
NM-04 manuscript, Section 3. Only the distinguished scalar pivot is inverted;
selected tail minors may be singular or empty.
-/
import NLA.NM04.Definitions
import Mathlib.Logic.Equiv.Fin.Basic
import Mathlib.Tactic
import LeanCert.Tactic

set_option autoImplicit false
set_option leancert.trust "kernel"

namespace NLA.NM04
noncomputable section
open scoped BigOperators Matrix

theorem schur_bordered_minor {m n : ℕ} (hm : 1 ≤ m) (hn : 1 ≤ n)
    (S : Rect m n) (hx : S (firstIndex hm) (firstIndex hn) ≠ 0) (I : Index m n) :
    delta S hm hn I = S (firstIndex hm) (firstIndex hn) * minor (schurTail S hm hn) I := by
  let k := I.1.1.card
  let rows : Fin k → Fin m := fun i => (I.1.1.orderEmbOfFin rfl i).val
  let cols : Fin k → Fin n := fun j => (I.1.2.orderEmbOfFin I.property.symm j).val
  let x := S (firstIndex hm) (firstIndex hn)
  let P : Matrix (Fin 1) (Fin 1) ℝ := fun _ _ => x
  let B : Matrix (Fin 1) (Fin k) ℝ := fun _ j => S (firstIndex hm) (cols j)
  let C : Matrix (Fin k) (Fin 1) ℝ := fun i _ => S (rows i) (firstIndex hn)
  let D : Matrix (Fin k) (Fin k) ℝ := fun i j => S (rows i) (cols j)
  let pinv : Matrix (Fin 1) (Fin 1) ℝ := fun _ _ => x⁻¹
  let : Invertible P := {
    invOf := pinv
    invOf_mul_self := by
      ext i j
      have hij : i = j := Subsingleton.elim _ _
      change (∑ l : Fin 1, pinv i l * P l j) = if i = j then 1 else 0
      simp [P, pinv, hij, x, hx]
    mul_invOf_self := by
      ext i j
      have hij : i = j := Subsingleton.elim _ _
      change (∑ l : Fin 1, P i l * pinv l j) = if i = j then 1 else 0
      simp [P, pinv, hij, x, hx] }
  let e : Fin 1 ⊕ Fin k ≃ Fin (k + 1) :=
    finSumFinEquiv.trans (finCongr (Nat.add_comm 1 k))
  have he0 (i : Fin 1) : e (Sum.inl i) = 0 := by
    have hi : i = 0 := Subsingleton.elim _ _
    subst i
    rfl
  have hes (i : Fin k) : e (Sum.inr i) = i.succ := by
    apply Fin.ext
    change 1 + i.val = i.val + 1
    omega
  let A := S.submatrix (Fin.cons (firstIndex hm) rows) (Fin.cons (firstIndex hn) cols)
  have hblocks : A.submatrix e e = Matrix.fromBlocks P B C D := by
    ext i j
    rcases i with i | i <;> rcases j with j | j
    · simp only [Matrix.submatrix_apply, he0]
      rfl
    · simp only [Matrix.submatrix_apply, he0, hes]
      rfl
    · simp only [Matrix.submatrix_apply, he0, hes]
      rfl
    · simp only [Matrix.submatrix_apply, hes]
      rfl
  have hschur : D - C * ⅟P * B = minorMatrix (schurTail S hm hn) I := by
    ext i j
    change S (rows i) (cols j) -
      (∑ l : Fin 1, (∑ t : Fin 1, C i t * pinv t l) * B l j) =
      S (rows i) (cols j) - S (rows i) (firstIndex hn) *
        S (firstIndex hm) (cols j) / x
    simp only [Fin.sum_univ_one, C, B, pinv]
    simp only [div_eq_mul_inv]
    ring
  have hdetP : P.det = x := by
    exact Matrix.det_fin_one P
  change A.det = x * (minorMatrix (schurTail S hm hn) I).det
  calc
    A.det = (A.submatrix e e).det := (Matrix.det_submatrix_equiv_self e A).symm
    _ = (Matrix.fromBlocks P B C D).det := congrArg Matrix.det hblocks
    _ = P.det * (D - C * ⅟P * B).det := Matrix.det_fromBlocks₁₁ P B C D
    _ = _ := by rw [hdetP, hschur]

#print axioms schur_bordered_minor
#assert_trust kernel schur_bordered_minor

end
end NLA.NM04
