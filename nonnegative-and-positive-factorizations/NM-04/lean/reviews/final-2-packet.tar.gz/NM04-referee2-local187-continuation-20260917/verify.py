#!/usr/bin/env python3
"""Read-only verification of this sealed continuation; invokes no other tools."""
from pathlib import Path
import hashlib, json, re, sys
R = Path(__file__).resolve().parent
B = Path('/private/tmp/nla-lean-next-20260915')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
count = 0
def check(ok, label):
    global count
    count += 1
    if not ok: raise AssertionError(label)
m = json.loads((R / 'MANIFEST.json').read_text())
excluded = {'MANIFEST.json', 'VERIFICATION.json'}
actual = {p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file()
          and p.relative_to(R).as_posix() not in excluded}
check(actual == set(m['files']), 'exact payload inventory')
for p, h in m['files'].items(): check(sha(R / p) == h, 'payload ' + p)
v = json.loads((R / 'VERDICT.json').read_text())
old = json.loads((R / 'prior-review/VERDICT.json').read_text())
changes = json.loads((R / 'COMMENT-IDENTITY.json').read_text())
check(sha(R / 'prior-review/MANIFEST.json') == v['prior_manifest_sha256'], 'prior manifest')
check(sha(R / 'prior-review/VERDICT.json') == v['prior_verdict_sha256'], 'prior verdict')
check(len(v['source_sha256']) == 38, '38 sources')
for p, h in v['source_sha256'].items():
    check(sha(R / 'snapshot' / p) == h, 'source ' + p)
    if p not in changes: check(h == old['source_sha256'][p], 'unchanged source ' + p)
    if '--check-current' in sys.argv:
        check(sha(B / 'NM04-local187-source-snapshot' / p) == h, 'current immutable ' + p)
        check(sha(B / 'next-proofs/NM-04' / p) == h, 'current active ' + p)
for p in changes:
    strip = lambda t: ''.join(l for l in t.splitlines(True) if not l.lstrip().startswith('--'))
    check(strip((R / 'before' / Path(p).name).read_text()) ==
          strip((R / 'snapshot' / p).read_text()), 'non-comment identity ' + p)
cfg = json.loads((R / 'frozen/comparator.json').read_text())
r = json.loads((R / 'coordinator/development-187/RECEIPT.json').read_text())
b = json.loads((R / 'coordinator/development-184/RECEIPT.json').read_text())
check(sha(R / 'coordinator/development-184/RECEIPT.json') == old['local_receipt_sha256'], 'approved base receipt')
check(r['source_inputs'] == v['source_sha256'], 'complete exact187 source inventory')
check(r['completed_modules'] == 38 and r['failed_modules'] == [] and r['blocked_modules'] == [], 'complete187 success')
fresh, reused = 0, 0
for c in r['commands']:
    check(c['source_sha256'] == v['source_sha256'][c['module'].replace('.', '/') + '.lean'], 'command source')
    if c.get('status') == 'reused_exact_successful_local_output':
        reused += 1
        check(c['prior_receipt_sha256'] == old['local_receipt_sha256'], 'reuse bound184')
        bc = next(x for x in b['commands'] if x['module'] == c['module'])
        check(c['output_sha256'] == bc['output_sha256'], 'reuse output')
        for p, h in c['transitive_source_hashes'].items():
            check(h == v['source_sha256'][p] == old['source_sha256'][p], 'reuse transitive')
    else:
        fresh += 1
        check(c['exit_code'] == 0, 'fresh success')
        check('--threads=1' in c['argv'] and '--memory=4096' in c['argv'], 'fresh limits')
        log = R / 'coordinator/development-187' / (c['module'] + '.log')
        check(sha(log) == c['log_sha256'], 'fresh actual log')
        check(not re.search(r'\berror:|sorryAx|unrecognized axioms', log.read_text()), 'fresh log success')
check((fresh, reused) == (7, 31), 'seven fresh and31 reused')
exports = re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",
    (R / 'coordinator/development-187/Solution.log').read_text())
check([n for n, _ in exports] == cfg['theorem_names'], 'all35 exact exports')
for n, a in exports: check(set(a.split(', ')) <= set(cfg['permitted_axioms']), 'allowed axioms ' + n)
check(v['reviewer_Lean_Lake_Comparator_runs'] == 0, 'truthful scope')
print(json.dumps({'pass': True, 'checks': count, 'source_modules': 38, 'contracts': 35,
                  'fresh_root_commands': 7, 'reused_root_outputs': 31,
                  'reviewer_Lean_Lake_Comparator_runs': 0,
                  'scope': 'Read-only sealed continuation verification'}))
