#!/usr/bin/env python3
"""Read-only packet verifier; never invokes Lean, Lake, Comparator or Git.

Run with --check-current to also compare the immutable snapshot and current
proof sources. Historical packaging is not treated as current approved data.
"""
from pathlib import Path
import hashlib, json, re, sys

R = Path(__file__).resolve().parent
B = Path('/private/tmp/nla-lean-next-20260915')
checks = 0

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def check(ok, label):
    global checks
    checks += 1
    if not ok:
        raise AssertionError(label)

manifest = json.loads((R / 'MANIFEST.json').read_text())
excluded = {'MANIFEST.json', 'VERIFICATION.json', 'VERIFICATION-current.json'}
actual = {p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file()
          and p.relative_to(R).as_posix() not in excluded}
check(actual == set(manifest['files']), 'exact payload inventory')
for rel, record in manifest['files'].items():
    check(sha(R / rel) == record['sha256'], 'payload digest ' + rel)
    check((R / rel).stat().st_size == record['bytes'], 'payload bytes ' + rel)

bindings = json.loads((R / 'BINDINGS.json').read_text())
sources = bindings['source_sha256']
check(len(sources) == 38, '38 complete sources')
for rel, h in sources.items():
    check(sha(R / 'snapshot' / rel) == h, 'reviewed source ' + rel)
    if '--check-current' in sys.argv:
        check(sha(Path(bindings['source_snapshot']) / rel) == h, 'immutable source ' + rel)
        check(sha(B / 'next-proofs/NM-04' / rel) == h, 'active proof source ' + rel)

freeze = json.loads((R / 'frozen/STATEMENT-FREEZE.json').read_text())
for rel, h in freeze['source_sha256'].items():
    path = R / ('snapshot/' if rel.startswith('NLA/') else 'frozen/') / rel
    check(sha(path) == h, 'freeze binding ' + rel)
headers = json.loads((R / 'frozen/STATEMENT-HEADERS.json').read_text())['headers']
config = json.loads((R / 'frozen/comparator.json').read_text())
check(len(headers) == 35 and [h['name'] for h in headers] == config['theorem_names'],
      '35 contracts in exact order')
check(config['definition_names'] == [], 'no definition holes')
check(set(config['permitted_axioms']) == {'propext', 'Classical.choice', 'Quot.sound'},
      'three permitted axioms')
norm = lambda t: ' '.join(t.split())
for h in headers:
    name = h['name'].split('.')[-1]
    pattern = re.compile(r'^theorem\s+' + re.escape(name) + r'\b(.*?)\s*:=', re.M | re.S)
    found = []
    for rel in sources:
        found += [m.group(0).rsplit(':=', 1)[0].rstrip()
                  for m in pattern.finditer((R / 'snapshot' / rel).read_text())]
    check(len(found) == 1 and norm(found[0]) == norm(h['header']), 'exact header ' + name)

for rel in sources:
    text = (R / 'snapshot' / rel).read_text()
    code = re.sub(r'/\-.*?\-/', '', text, flags=re.S)
    code = re.sub(r'--[^\n]*', '', code)
    check(not re.search(r'\b(?:sorry|admit|sorryAx|axiom|opaque|unsafe|native_decide|run_tac|run_elab|implemented_by|extern)\b|#eval|debug\.skipKernelTC', code),
          'conservative proof-source screen ' + rel)
    check(not re.search(r'^import\s+Challenge\b', text, re.M), 'no Challenge import ' + rel)

receipt_path = R / 'coordinator/runs/development-184/RECEIPT.json'
j = json.loads(receipt_path.read_text())
check(j.get('end') and j['completed_modules'] == 38 and
      j['failed_modules'] == [] and j['blocked_modules'] == [], 'terminal successful root receipt')
check(j['source_inputs'] == sources, 'root receipt exact source closure')
check(sha(R / 'coordinator/ASSEMBLY-184.json') == j['assembly_sha256'], 'bound assembly')
check(sha(R / 'coordinator/serial_compile_v3.py.txt') == j['runner_sha256'], 'bound actual runner')

def replay(module, p, expected=None):
    receipt = json.loads(p.read_text())
    check(receipt['compiler_sha256'] == j['compiler_sha256'], 'same pinned compiler ' + str(p))
    c = next(x for x in receipt['commands'] if x['module'] == module)
    rel = module.replace('.', '/') + '.lean'
    check(c['source_sha256'] == sources[rel], 'source in receipt ' + module)
    if expected is not None:
        check(c['output_sha256'] == expected, 'output chain ' + module)
    for q, h in c.get('transitive_source_hashes', {}).items():
        check(sources[q] == h, 'transitive source ' + module + ' ' + q)
    if c.get('status') == 'reused_exact_successful_local_output':
        prior = R / 'coordinator/runs' / Path(c['prior_receipt']).parent.name / 'RECEIPT.json'
        check(sha(prior) == c['prior_receipt_sha256'], 'prior receipt hash ' + module)
        return replay(module, prior, c['output_sha256'])
    check(c.get('exit_code') == 0 and bool(c.get('output_sha256')), 'successful origin ' + module)
    check('--threads=1' in c['argv'] and '--memory=4096' in c['argv'], 'compiler limits ' + module)
    log = p.parent / (module + '.log')
    check(sha(log) == c['log_sha256'], 'actual origin log hash ' + module)
    check(not re.search(r'\berror:|sorryAx|unrecognized axioms', log.read_text()), 'origin log success ' + module)

for rel in sorted(sources):
    replay(rel[:-5].replace('/', '.'), receipt_path)
log = (R / 'coordinator/runs/development-184/Solution.log').read_text()
exports = re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", log)
check([n for n, _ in exports] == config['theorem_names'], 'all 35 final exports')
for n, a in exports:
    check(set(a.split(', ')) <= set(config['permitted_axioms']), 'axiom export ' + n)
check(re.findall(r'^#assert_trust kernel (\S+)',
                 (R / 'snapshot/Solution.lean').read_text(), re.M) == config['theorem_names'],
      'all 35 kernel assertions')
verdict = json.loads((R / 'VERDICT.json').read_text())
check(verdict['source_sha256'] == sources, 'verdict source binding')
check(verdict['reviewer_lean_runs'] == 0 and verdict['reviewer_comparator_runs'] == 0,
      'truthful reviewer scope')
print(json.dumps({'pass': True, 'checks': checks, 'source_modules': len(sources),
                  'contracts': len(headers), 'check_current': '--check-current' in sys.argv,
                  'reviewer_lean_runs': 0, 'reviewer_comparator_runs': 0,
                  'scope': 'Read-only packet/source/root-evidence verification, not Lean execution'}))
