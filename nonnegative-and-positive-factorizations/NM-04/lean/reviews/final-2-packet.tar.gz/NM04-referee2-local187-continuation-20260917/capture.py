#!/usr/bin/env python3
"""Read-only source/local-evidence continuation; writes only this review packet."""
from pathlib import Path
import datetime, difflib, hashlib, json, re, subprocess
R = Path(__file__).resolve().parent
B = Path('/private/tmp/nla-lean-next-20260915')
L = Path('/private/tmp/nla-lean-local-shared-20260916')
OLD = B / 'reviews/NM04-full-referee2-20260917'
S = B / 'NM04-local187-source-snapshot'
P = B / 'next-proofs/NM-04'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks = []
def check(label, value):
    checks.append({'check': label, 'pass': bool(value)})
    if not value: raise AssertionError(label)
def put(rel, data):
    p = R / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data if isinstance(data, bytes) else data.encode())
def copy(p, rel):
    put(rel, Path(p).read_bytes())
def jout(rel, data):
    put(rel, json.dumps(data, indent=2, ensure_ascii=False) + '\n')

check('prior seal unchanged', sha(OLD / 'MANIFEST.json') == '87dcb82e29e7ee4a4a01caec34787f968099ba8b25fbb76b0c19cf5b6b0f0fd5')
for rel in ['MANIFEST.json', 'VERDICT.json', 'REVIEW.md', 'verify_review.py']:
    copy(OLD / rel, 'prior-review/' + rel)
old_verdict = json.loads((OLD / 'VERDICT.json').read_text())
check('prior exact approval unchanged', sha(OLD / 'VERDICT.json') == '44e3b5bd1295f885d2fdd683bfef2b0f6cdca08ee9e536caca0b6803543b2fa6')
argv = ['python3', str(OLD / 'verify_review.py')]
z = subprocess.run(argv, capture_output=True, text=True)
jout('prior-review/ACTUAL-READONLY-VERIFICATION.json', {'argv': argv,
     'exit_code': z.returncode, 'stdout': z.stdout, 'stderr': z.stderr})
check('prior sealed packet readonly verifier', z.returncode == 0)

source_hashes = {}
changed = []
for p in sorted(S.rglob('*.lean')):
    rel = p.relative_to(S).as_posix()
    source_hashes[rel] = sha(p)
    copy(p, 'snapshot/' + rel)
    check('current active exact source ' + rel, sha(P / rel) == sha(p))
    if old_verdict['source_sha256'][rel] != sha(p): changed.append(rel)
check('exactly the two comment files changed', changed == [
    'NLA/NM04/RankOneBordered.lean', 'NLA/NM04/SchurBordered.lean'])
token_identity = {}
for rel in changed:
    before = (OLD / 'snapshot' / rel).read_text()
    after = (S / rel).read_text()
    copy(OLD / 'snapshot' / rel, 'before/' + Path(rel).name)
    edits = []
    for tag, a, b, c, d in difflib.SequenceMatcher(None, before.splitlines(True), after.splitlines(True)).get_opcodes():
        if tag != 'equal':
            lines = after.splitlines(True)[c:d]
            check('only new standalone comments in ' + rel,
                  tag == 'insert' and all(line.lstrip().startswith('--') for line in lines))
            edits.append({'kind': tag, 'old_lines': [a+1, b], 'new_lines': [c+1, d], 'added': lines})
    # Stronger than whitespace-token matching for these exact insertions:
    # remove whole standalone line-comments, retaining all remaining bytes.
    strip = lambda t: ''.join(line for line in t.splitlines(True) if not line.lstrip().startswith('--'))
    check('exact non-comment bytes unchanged ' + rel, strip(before) == strip(after))
    token_identity[rel] = {'before': old_verdict['source_sha256'][rel],
        'after': sha(S / rel), 'non_line_comment_sha256': hashlib.sha256(strip(after).encode()).hexdigest(),
        'edits': edits}
    put('diffs/' + Path(rel).name + '.diff', ''.join(difflib.unified_diff(
        before.splitlines(True), after.splitlines(True), fromfile='local184/' + rel, tofile='local187/' + rel)))
jout('COMMENT-IDENTITY.json', token_identity)
for rel in ['Challenge.lean', 'STATEMENT-FREEZE.json', 'STATEMENT-HEADERS.json',
            'comparator.json', 'NUMERICAL_TARGETS.md', 'SourceCorrespondence.md']:
    copy(OLD / 'frozen' / rel, 'frozen/' + rel)
    check('unchanged frozen boundary ' + rel, sha(P / rel) == sha(OLD / 'frozen' / rel))
copy(B / 'NM04-COMMENT187.json', 'coordinator/NM04-COMMENT187.json')
copy(B / 'NM04-LOCAL-COMPLETE-187.json', 'coordinator/NM04-LOCAL-COMPLETE-187.json')
copy(L / 'ASSEMBLY-187.json', 'coordinator/ASSEMBLY-187.json')
copy(L / 'serial_compile_v3.py', 'coordinator/serial_compile_v3.py.txt')
for k in [184, 187]:
    copy(L / f'runs/development-{k}/RECEIPT.json', f'coordinator/development-{k}/RECEIPT.json')
base = json.loads((R / 'coordinator/development-184/RECEIPT.json').read_text())
final = json.loads((R / 'coordinator/development-187/RECEIPT.json').read_text())
check('base receipt exactly previously approved', sha(R / 'coordinator/development-184/RECEIPT.json') == old_verdict['local_receipt_sha256'])
check('terminal success 187', final.get('end') and final['completed_modules'] == 38
      and final['failed_modules'] == [] and final['blocked_modules'] == [])
check('all38 exact sources in local187', final['source_inputs'] == source_hashes and len(source_hashes) == 38)
check('same compiler as approved184', final['compiler_sha256'] == base['compiler_sha256'])
check('actual runner matches', sha(R / 'coordinator/serial_compile_v3.py.txt') == final['runner_sha256'])
check('actual assembly matches', sha(R / 'coordinator/ASSEMBLY-187.json') == final['assembly_sha256'])
check('bounded serial compiler', final['threads'] == 1 and final['memory_cap_mib'] == 4096
      and final['max_compiler_processes'] == 1)
fresh, reused = [], []
for c in final['commands']:
    module = c['module']; rel = module.replace('.', '/') + '.lean'
    check('command source ' + module, c['source_sha256'] == source_hashes[rel])
    output = L / '.lake/build/lib/lean' / (module.replace('.', '/') + '.olean')
    check('actual current output ' + module, sha(output) == c['output_sha256'])
    if c.get('status') == 'reused_exact_successful_local_output':
        reused.append(module)
        check('reuse from approved184 ' + module,
              Path(c['prior_receipt']).parent.name == 'development-184' and
              c['prior_receipt_sha256'] == old_verdict['local_receipt_sha256'])
        bc = next(x for x in base['commands'] if x['module'] == module)
        check('same successful output as184 ' + module, bc['output_sha256'] == c['output_sha256'])
        for p, h in c['transitive_source_hashes'].items():
            check('unchanged transitive source ' + module + ' ' + p,
                  source_hashes[p] == h == old_verdict['source_sha256'][p])
    else:
        fresh.append(module)
        check('fresh successful command ' + module, c['exit_code'] == 0)
        check('fresh bounded command ' + module, '--threads=1' in c['argv'] and '--memory=4096' in c['argv'])
        log = L / 'runs/development-187' / (module + '.log')
        copy(log, 'coordinator/development-187/' + log.name)
        check('actual fresh log hash ' + module, sha(log) == c['log_sha256'])
        check('actual fresh log clean ' + module, not re.search(r'\berror:|sorryAx|unrecognized axioms', log.read_text()))
        for dep, oh in c['dependency_olean_sha256'].items():
            check('actual fresh dependency output ' + module + ' ' + dep,
                  sha(L / '.lake/build/lib/lean' / (dep.replace('.', '/') + '.olean')) == oh)
check('7fresh31reused', len(fresh) == 7 and len(reused) == 31)
cfg = json.loads((R / 'frozen/comparator.json').read_text())
logs = (R / 'coordinator/development-187/Solution.log').read_text()
axioms = re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", logs)
check('35 exact theorem exports', [n for n, _ in axioms] == cfg['theorem_names'])
for n, a in axioms: check('permitted axioms ' + n, set(a.split(', ')) <= set(cfg['permitted_axioms']))
summary = json.loads((R / 'coordinator/NM04-LOCAL-COMPLETE-187.json').read_text())
check('root summary original hash', sha(R / 'coordinator/NM04-LOCAL-COMPLETE-187.json') == 'd32daefe49cde06358205c59a897a439f3af49aa8d017b31a68f8265893efa4d')
check('summary exact receipt', summary['receipt_sha256'] == sha(R / 'coordinator/development-187/RECEIPT.json'))
check('summary exact sources', summary['sources'] == source_hashes)
jout('CHECKS.json', {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
     'pass': True, 'checks': checks, 'fresh_modules': fresh, 'reused_modules': reused,
     'source_sha256': source_hashes, 'reviewer_Lean_Lake_Comparator_runs': 0})
print(json.dumps({'pass': True, 'checks': len(checks), 'fresh': len(fresh), 'reused': len(reused),
                  'source_modules': len(source_hashes), 'contracts': len(axioms)}))
