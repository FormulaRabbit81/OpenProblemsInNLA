#!/usr/bin/env python3
"""Read-only packet replay. No Lean, network, or filesystem mutations."""
from pathlib import Path
import hashlib,json,re,sys
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
checks=0
def ck(label,b):
 global checks
 checks+=1
 if not b:raise AssertionError(label)
if '--unsealed' not in sys.argv:
 m=load(R/'MANIFEST.json');files=m['files']
 ck('exact packet inventory',{str(p.relative_to(R)) for p in R.rglob('*') if p.is_file() and p.name!='MANIFEST.json'}==set(files))
 for rel,h in files.items():ck('payload '+rel,sha(R/rel)==h)
s=load(R/'SOURCE-BINDINGS.json');q=load(R/'local/NM04-LOCAL-COMPLETE-204.json')
ck('38proof sources',len(s['sources'])==38 and s['sources']==q['sources'])
for rel,h in s['sources'].items():ck('source '+rel,sha(R/'snapshot'/rel)==h)
for rel,h in s['frozen'].items():ck('frozen '+rel,sha(R/'frozen'/rel)==h)
for folder,h in s['prior_seals'].items():ck('prior '+folder,sha(R/'prior'/folder/'MANIFEST.json')==h)
ck('only one changed file',s['changed']==['NLA/NM04/AnalyticBasics.lean'])
after=(R/'snapshot/NLA/NM04/AnalyticBasics.lean').read_text();before=(R/'before/AnalyticBasics.lean').read_text()
insert='''section FrozenDerivativeInstance

-- Match the frozen specification's scalar-continuity witness. Additional
-- analytic imports supply another proof of this same property, while
-- Comparator compares the elaborated statements structurally.
attribute [local instance] ContinuousMul.to_continuousSMul
attribute [-instance] IsModuleTopology.toContinuousSMul

'''
ck('exact scope-only edit',after.count(insert)==1 and after.count('end FrozenDerivativeInstance\n\n')==1 and after.replace(insert,'',1).replace('end FrozenDerivativeInstance\n\n','',1)==before)
root='/private/tmp/nla-lean-local-shared-20260916/'
for p,h in q['retained_original_evidence'].items():ck('retained '+p,sha(R/'local'/p.removeprefix(root))==h)
r=load(R/'local/runs/development-204/RECEIPT.json');by={c['module']:c for c in r['commands']}
ck('terminal204',r.get('end') and r['completed_modules']==38 and not r['failed_modules'] and not r['blocked_modules'])
ck('sourceinputs',r['source_inputs']==s['sources'])
origins=load(R/'ACTUAL-LOCAL-ORIGINS.json')
for mod,orig in origins.items():
 p=R/'local'/orig['receipt'].removeprefix(root);rr=load(p);c=next(x for x in rr['commands'] if x['module']==mod)
 ck('origin receipt '+mod,sha(p)==orig['receipt_sha256'])
 ck('origin exact successful command '+mod,c==orig['command'] and c['exit_code']==0)
 ck('origin final identity '+mod,c['source_sha256']==by[mod]['source_sha256'] and c['output_sha256']==by[mod]['output_sha256'])
 ck('origin log '+mod,sha(p.parent/(mod+'.log'))==c['log_sha256'])
 for dep,h in c['dependency_olean_sha256'].items():ck('dependency '+mod+' '+dep,by[dep]['output_sha256']==h)
names=load(R/'frozen/comparator.json')['theorem_names'];head=load(R/'frozen/STATEMENT-HEADERS.json')['headers']
text='\n'.join((R/'snapshot'/p).read_text() for p in s['sources'])
for entry in head:ck('header '+entry['name'],entry['header'] in text)
a=load(R/'diagnostics/challenge-types.json');z=load(R/'diagnostics/solution-types.json')
ck('exact35 names',[x['name'] for x in a]==[x['name'] for x in z]==names and len(names)==35)
for x,y in zip(a,z):ck('type '+x['name'],x['levelParams']==y['levelParams'] and x['binderNormalizedType']==y['binderNormalizedType'])
c=load(R/'diagnostics/ROOT-COMPARISON.json')
ck('205 actualdump bindings',c['challenge_dump_sha256']==sha(R/'diagnostics/challenge-types.json') and c['solution_dump_sha256']==sha(R/'diagnostics/solution-types.json'))
ck('205 receipt binding',c['receipt_sha256']==sha(R/'local/runs/development-205/RECEIPT.json'))
r205=load(R/'local/runs/development-205/RECEIPT.json')
ck('205 terminal',r205.get('end') and r205['completed_modules']==39 and not r205['failed_modules'] and not r205['blocked_modules'])
for label in ['Challenge','Solution']:
 mod=f'NLA.NM04Diagnostics.{label}Types205';d=next(x for x in r205['commands'] if x['module']==mod)
 ck('205 command '+label,d['exit_code']==0 and sha(R/'diagnostics'/(mod.replace('.','/')+'.lean'))==d['source_sha256'])
 ck('205 log '+label,sha(R/'local/runs/development-205'/(mod+'.log'))==d['log_sha256'])
for rel,h in s['sources'].items():
 if rel!='Solution.lean':ck('205 dependency '+rel,r205['source_inputs'][rel]==h)
ck('actual reviewer checks passed',load(R/'CHECKS.json')['pass'] and all(x['pass'] for x in load(R/'CHECKS.json')['checks']))
v=load(R/'VERDICT.json');ck('scope',v['reviewer_Lean_Lake_Comparator_runs']==0 and v['count_change']==0 and not v['new_Linux_Comparator_success'] and not v['publication_package_approved'])
print(json.dumps({'pass':True,'checks':checks,'sealed':'--unsealed' not in sys.argv,'source_modules':38,'contracts':35,'reviewer_Lean_Lake_Comparator_runs':0}))
