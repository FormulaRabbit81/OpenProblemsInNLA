#!/usr/bin/env python3
"""Independent read-only capture; writes only this review directory. Never runs Lean."""
from pathlib import Path
import datetime, difflib, hashlib, json, re
R=Path(__file__).resolve().parent
B=Path('/private/tmp/nla-lean-next-20260915')
L=Path('/private/tmp/nla-lean-local-shared-20260916')
P=B/'next-proofs/NM-04'
S=B/'NM04-local204-source-snapshot'
OLD=B/'reviews/NM04-referee2-local187-continuation-20260917'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
checks=[]
def check(label,ok):
 checks.append({'check':label,'pass':bool(ok)})
 if not ok: raise AssertionError(label)
def put(rel,data):
 p=R/rel;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_bytes(data if isinstance(data,bytes) else data.encode())
def cp(p,rel):put(rel,Path(p).read_bytes())
def jout(rel,v):put(rel,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
priors={
 'NM04-full-referee2-20260917':'87dcb82e29e7ee4a4a01caec34787f968099ba8b25fbb76b0c19cf5b6b0f0fd5',
 'NM04-referee2-local187-continuation-20260917':'e172447317cc71f5e90f693505f109799b1d5f7a151750a2d5a6c4082db67d01',
 'NM04-runtime-failure-referee2-20260917':'416b981ee0dc64485a8134d857eed169cb244c6a3e7ff5bfbb0939e7d1b84a13',
 'NM04-referee2-local201-held-20260917':'adcc128169e6ddf699fcd8efb1a938d8fc00e0d5310a19b5b8d5123baa3293da'}
for folder,h in priors.items():
 base=B/'reviews'/folder
 check('unchanged prior seal '+folder,sha(base/'MANIFEST.json')==h)
 for rel in ['MANIFEST.json','VERDICT.json','REVIEW.md']:cp(base/rel,'prior/'+folder+'/'+rel)
old=load(OLD/'VERDICT.json')['source_sha256']
sources={str(p.relative_to(S)):sha(p) for p in sorted(S.rglob('*.lean'))}
check('same38module inventory',set(sources)==set(old) and len(sources)==38)
changed=[p for p in sources if sources[p]!=old[p]]
check('only AnalyticBasics changed',changed==['NLA/NM04/AnalyticBasics.lean'])
for rel,h in sources.items():
 cp(S/rel,'snapshot/'+rel)
 check('exact active source '+rel,sha(P/rel)==h)
rel=changed[0];before=(OLD/'snapshot'/rel).read_text();after=(S/rel).read_text()
insert='''section FrozenDerivativeInstance

-- Match the frozen specification's scalar-continuity witness. Additional
-- analytic imports supply another proof of this same property, while
-- Comparator compares the elaborated statements structurally.
attribute [local instance] ContinuousMul.to_continuousSMul
attribute [-instance] IsModuleTopology.toContinuousSMul

'''
check('exact inserted section once',after.count(insert)==1)
check('exact matching end once',after.count('end FrozenDerivativeInstance\n\n')==1)
check('remove only elaboration scope gives exact old bytes',after.replace(insert,'',1).replace('end FrozenDerivativeInstance\n\n','',1)==before)
cp(OLD/'snapshot'/rel,'before/AnalyticBasics.lean')
put('SOURCE-DELTA.patch',''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='approved187/'+rel,tofile='reviewed204/'+rel)))
frozen={}
for rel in ['Challenge.lean','STATEMENT-FREEZE.json','STATEMENT-HEADERS.json','comparator.json','NUMERICAL_TARGETS.md','SourceCorrespondence.md']:
 frozen[rel]=sha(P/rel);check('unchanged frozen '+rel,frozen[rel]==sha(OLD/'frozen'/rel));cp(P/rel,'frozen/'+rel)
cfg=load(P/'comparator.json');names=cfg['theorem_names'];check('35unique contracts',len(names)==len(set(names))==35)
headers=load(P/'STATEMENT-HEADERS.json')['headers']
text='\n'.join((S/rel).read_text() for rel in sources)
for entry in headers:check('exact original header '+entry['name'],entry['header'] in text)
complete=B/'NM04-LOCAL-COMPLETE-204.json';q=load(complete)
check('expected complete204 hash',sha(complete)=='4063492a265402d4c9cf50d6019911f00d939d294d44702f966975119a7c3e6d')
cp(complete,'local/NM04-LOCAL-COMPLETE-204.json')
check('summary exact38source hashes',q['sources']==sources)
# Preserve and independently authenticate every retained original chain record.
for path,h in q['retained_original_evidence'].items():
 p=Path(path);check('retained original '+path,sha(p)==h);cp(p,'local/'+str(p.relative_to(L)))
r204=load(L/'runs/development-204/RECEIPT.json')
check('204 summary receipt',sha(L/'runs/development-204/RECEIPT.json')==q['receipt_sha256'])
check('terminal204 fullclosure',r204.get('end') and r204['completed_modules']==38 and not r204['failed_modules'] and not r204['blocked_modules'])
check('204 sourceinputs exact',r204['source_inputs']==sources)
for k in [204,205]:
 rp=L/f'runs/development-{k}/RECEIPT.json';ap=L/f'ASSEMBLY-{k}.json';r=load(rp)
 cp(rp,f'local/runs/development-{k}/RECEIPT.json');cp(ap,f'local/ASSEMBLY-{k}.json')
 check(f'assembly{k}',sha(ap)==r['assembly_sha256'])
 check(f'bounded{k}',r['threads']==1 and r['memory_cap_mib']==4096 and r['max_compiler_processes']==1)
 check(f'terminal{k}',r.get('end') and not r['failed_modules'] and not r['blocked_modules'])
check('compiler same as approved187',r204['compiler_sha256']==load(OLD/'coordinator/development-187/RECEIPT.json')['compiler_sha256'])
cp(L/'serial_compile_v3.py','local/serial_compile_v3.py.txt')
check('same actual runner',sha(L/'serial_compile_v3.py')==r204['runner_sha256'])
by={c['module']:c for c in r204['commands']}
fresh=[];reuse=[];originmap={}
for mod,c in by.items():
 rel=mod.replace('.','/')+'.lean'
 check('204 command source '+mod,c['source_sha256']==sources[rel])
 op=L/'.lake/build/lib/lean'/(mod.replace('.','/')+'.olean')
 check('204 actual output '+mod,sha(op)==c['output_sha256'])
 if 'argv' in c:fresh.append(mod)
 else:reuse.append(mod)
 hop=c;rp=L/'runs/development-204/RECEIPT.json';seen=set()
 while 'argv' not in hop:
  check('no reuse cycle '+mod,str(rp) not in seen);seen.add(str(rp))
  for path,h in hop['transitive_source_hashes'].items():check('reuse exact transitive '+mod+' '+path,sources[path]==h)
  pp=Path(hop['prior_receipt']);check('reuse receipt '+mod+' '+str(pp),sha(pp)==hop['prior_receipt_sha256'])
  prior=load(pp);pc=next(x for x in prior['commands'] if x['module']==mod)
  check('reuse identity '+mod+' '+str(pp),pc['source_sha256']==hop['source_sha256'] and pc['output_sha256']==hop['output_sha256'])
  hop=pc;rp=pp
 check('origin successful '+mod,hop.get('exit_code')==0 and hop.get('end'))
 check('origin bounded '+mod,'--threads=1' in hop['argv'] and '--memory=4096' in hop['argv'])
 check('origin compiler unchanged '+mod,load(rp)['compiler_sha256']==r204['compiler_sha256'])
 log=rp.parent/(mod+'.log');check('origin actual log '+mod,sha(log)==hop['log_sha256'])
 check('origin log clean '+mod,not re.search(r'\berror:|sorryAx|unrecognized axioms',log.read_text()))
 for dep,h in hop['dependency_olean_sha256'].items():check('origin dependency '+mod+' '+dep,by[dep]['output_sha256']==h)
 originmap[mod]={'receipt':str(rp),'receipt_sha256':sha(rp),'command':hop,'reuse_hops':len(seen)}
check('8fresh30reuse',len(fresh)==8 and len(reuse)==30)
solutionlog=(L/'runs/development-204/Solution.log').read_text()
axioms=re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",solutionlog)
check('all35 exact exported axioms names',[n for n,a in axioms]==names)
for n,a in axioms:check('allowed axioms '+n,set(a.split(', '))==set(cfg['permitted_axioms']))
# Diagnostics are observational modules, not altered challenge/proof or a Comparator run.
r205=load(L/'runs/development-205/RECEIPT.json');a205=load(L/'ASSEMBLY-205.json');d=B/'NM04-type-diagnostics-205'
check('205 39closure',r205['completed_modules']==39)
check('205 same compiler',r205['compiler_sha256']==r204['compiler_sha256'])
for rel,h in sources.items():
 if rel!='Solution.lean':
  check('205 imported exact proof '+rel,a205['sources'][rel]['sha256']==h==r205['source_inputs'][rel])
for label in ['Challenge','Solution']:
 mod=f'NLA.NM04Diagnostics.{label}Types205';rel=mod.replace('.','/')+'.lean'
 source=Path(a205['sources'][rel]['source']);c=next(x for x in r205['commands'] if x['module']==mod)
 check('205 successful diagnostic '+label,c.get('exit_code')==0)
 check('205 exact diagnostic '+label,sha(source)==a205['sources'][rel]['sha256']==c['source_sha256'])
 cp(source,'diagnostics/'+rel)
 log=L/'runs/development-205'/(mod+'.log');check('205 actual log '+label,sha(log)==c['log_sha256']);cp(log,'local/runs/development-205/'+log.name)
 for dep,h in c['dependency_olean_sha256'].items():check('205 exact dependency '+label+' '+dep,by[dep]['output_sha256']==h)
 cp(d/(label.lower()+'-types.json'),'diagnostics/'+label.lower()+'-types.json')
challenge=(R/'diagnostics/NLA/NM04Diagnostics/ChallengeTypes205.lean').read_text()
check('diagnostic preserves exact Challenge text',challenge.split('\nprivate def diagnosticEraseBinderNames')[0].replace('import Lean\n','').rstrip() == (P/'Challenge.lean').read_text().rstrip())
sol=(R/'diagnostics/NLA/NM04Diagnostics/SolutionTypes205.lean').read_text()
check('solution diagnostic exact same proof imports',re.findall(r'^import (NLA\..*)$',sol,re.M)==re.findall(r'^import (NLA\..*)$',(S/'Solution.lean').read_text(),re.M))
a=load(d/'challenge-types.json');z=load(d/'solution-types.json')
check('35 diagnostic exact names',[x['name'] for x in a]==[x['name'] for x in z]==names)
rows=[]
for x,y in zip(a,z):
 row={'name':x['name'],'same_universes':x['levelParams']==y['levelParams'],'same_binder_normalized_type':x['binderNormalizedType']==y['binderNormalizedType'],'same_raw_repr':x['type']==y['type']}
 check('205 same universes '+x['name'],row['same_universes']);check('205 same normalized type '+x['name'],row['same_binder_normalized_type']);rows.append(row)
 if x['name']=='NLA.NM04.potential_line_derivative':
  check('C04 restored frozen witness',all('ContinuousMul.to_continuousSMul' in t and 'IsModuleTopology.toContinuousSMul' not in t for t in [x['type'],y['type']]))
cp(d/'COMPARISON.json','diagnostics/ROOT-COMPARISON.json');comp=load(d/'COMPARISON.json')
check('expected205 comparison hash',sha(d/'COMPARISON.json')=='220012b2101b1167db78d3bb0e07ae90ede3b3f2021d1b57535e5ce3ceb4fa2f')
check('comparison binds actual dumps',comp['challenge_dump_sha256']==sha(d/'challenge-types.json') and comp['solution_dump_sha256']==sha(d/'solution-types.json'))
check('comparison binds actual receipt',comp['receipt_sha256']==sha(L/'runs/development-205/RECEIPT.json'))
cp(B/'compare_nm04_diagnostics.py','diagnostics/root_compare.py.txt')
check('comparison script retained',comp['comparison_script_sha256']==sha(B/'compare_nm04_diagnostics.py'))
jout('INDEPENDENT-TYPE-COMPARISON.json',{'scope':'Read-only comparison of actual root205 emitted expressions, not a Lean or Comparator run by this referee','all35_match':True,'results':rows})
# Pinned evidence for exact matching, proposition witness, and section restoration.
failure=B/'reviews/NM04-runtime-failure-referee2-20260917'
for sub in ['pinned-mathlib','pinned-comparator']:
 for p in (failure/sub).rglob('*'):
  if p.is_file():cp(p,sub+'/'+str(p.relative_to(failure/sub)))
lean=Path('/Users/georgestepaniants/.elan/toolchains/leanprover--lean4---v4.33.1/src/lean')
for rel in ['Lean/Meta/Instances.lean','Lean/ScopedEnvExtension.lean','Lean/Elab/BuiltinCommand.lean','Lean/Expr.lean']:
 cp(lean/rel,'pinned-lean-4.33.1/'+rel)
cp(L/'.lake/packages/mathlib/Mathlib/Analysis/Calculus/Deriv/Basic.lean','pinned-mathlib/Mathlib/Analysis/Calculus/Deriv/Basic.lean')
jout('SOURCE-BINDINGS.json',{'sources':sources,'frozen':frozen,'changed':changed,'prior_seals':priors})
jout('ACTUAL-LOCAL-ORIGINS.json',originmap)
jout('CHECKS.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pass':True,'checks':checks,'fresh':fresh,'reused':reuse,'reviewer_compiler_or_Comparator_runs':0})
print(json.dumps({'pass':True,'checks':len(checks),'sources':len(sources),'fresh204':len(fresh),'reused204':len(reuse),'types205_match':len(rows),'reviewer_compiler_or_Comparator_runs':0}))
