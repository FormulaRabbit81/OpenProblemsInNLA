#!/usr/bin/env python3
"""Read-only package preflight; no compiler, network, Git mutation or publication.

Checks the exact external candidate package plus this small sealed report. Reads
archives in memory without extraction. Optional Git checks use read-only commands.
Python schema validation is not a Lean/Comparator run or mathematical acceptance.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import importlib.util
import io
import json
import posixpath
import re
import subprocess
import sys
import tarfile
import urllib.parse
sys.dont_write_bytecode = True

HERE = Path(__file__).resolve().parent
EXPECTED_PACKAGE = '9119212bd10f5d2f80895f75ff9598767868c431ea71e33ae1a30e9d6a4e6b8a'
EXPECTED_PREVIOUS = '34a8bc2dd1330f2c51e496329341804eb5859d67'
REL = 'nonnegative-and-positive-factorizations/NM-04/lean'
checks = 0

def check(value, why):
    global checks
    if not value:
        raise AssertionError(why)
    checks += 1

def digest(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    return digest(path.read_bytes())

def unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate key ' + key)
        result[key] = value
    return result

def decode(data):
    return json.loads(data, object_pairs_hook=unique)

def read(path):
    return decode(path.read_text())

def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def entries(manifest):
    data = manifest['files']
    if isinstance(data, list):
        return {x['path']: x['sha256'] for x in data}
    return {path: value['sha256'] if isinstance(value, dict) else value for path, value in data.items()}

def audit(package, worktree):
    check(sha(package / 'PACKAGE-MANIFEST.json') == EXPECTED_PACKAGE, 'exact379-payload candidate manifest')
    inventory = read(package / 'PACKAGE-MANIFEST.json')['files']
    actual = {str(p.relative_to(package)) for p in package.rglob('*') if p.is_file()}
    check(actual == set(inventory) | {'PACKAGE-MANIFEST.json'} and len(inventory) == 379, 'exact package inventory')
    for path in package.rglob('*'):
        check(not path.is_symlink(), 'no package symlinks')
    for rel, expected in inventory.items():
        check(sha(package / rel) == expected, 'sealed package file ' + rel)
        check('.lake' not in PurePosixPath(rel).parts and Path(rel).suffix not in {'.olean', '.ilean', '.o', '.so', '.a'},
              'no compiled build artifacts')
    for capture in (HERE / 'inputs/package').rglob('*'):
        if capture.is_file():
            check(sha(capture) == sha(package / capture.relative_to(HERE / 'inputs/package')),
                  'reviewed metadata snapshot exact')
    local = read(package / 'verification/LOCAL-COMPLETE.json')
    check(sha(package / 'verification/LOCAL-COMPLETE.json') ==
          '4063492a265402d4c9cf50d6019911f00d939d294d44702f966975119a7c3e6d', 'exact actual204 local record')
    check(sha(package / 'verification/LOCAL-COMPLETE-204.json') == sha(package / 'verification/LOCAL-COMPLETE.json'),
          'current local record aliases exact')
    source = local['sources']
    check(len(source) == local['actual_local_closure_modules'] == 38 and local['exact_contracts'] == 35, 'full38/35 local scope')
    for rel, expected in source.items():
        check(sha(package / rel) == expected, 'approved204 source')
    frozen = read(package / 'STATEMENT-FREEZE.json')
    check(sha(package / 'STATEMENT-FREEZE.json') == '9f81c6ce7f27cf17bcc12df5715928fd2e5220fbfad94b1867e4bb1fe84d73f2',
          'original statement freeze')
    for rel, expected in frozen['source_sha256'].items():
        check(sha(package / rel) == expected, 'original frozen boundary')
    active = read(package / 'ACTIVE-SOURCE-MANIFEST.json')
    check(active['source_sha256'] == source and active['local_run'] == 204, 'active source map')
    cfg = read(package / 'comparator.json')
    check(len(cfg['theorem_names']) == len(set(cfg['theorem_names'])) == 35 and cfg['definition_names'] == [],
          '35 exact targets and no replaceable definition holes')
    check(set(cfg['permitted_axioms']) == {'propext', 'Classical.choice', 'Quot.sound'}, 'standard permitted axioms only')
    metadata = read(package / 'formalization.yaml')
    schema = read(HERE / 'inputs/worktree/docs/lean/schema/v0.4.schema.json')
    validator = module(HERE / 'inputs/worktree/tools/lean/validate_manifest.py', 'nm04_preflight_schema')
    # This reviewed function only parses and validates files; it runs no compiler.
    validator.validate(package, schema)
    check(sha(package / 'sources/standards/mathlib-initiative/formalization.yaml/schema/v0.4.schema.json') ==
          sha(HERE / 'inputs/worktree/docs/lean/schema/v0.4.schema.json'), 'pinned schema copies agree')
    results = metadata['status']['main_results']
    check(results == read(package / 'IMPLEMENTATION-MAP.json')['results'], 'implementation map exact')
    check([r['declaration'] for r in results] == cfg['theorem_names'], '35 results exact order and names')
    for row in results:
        path = package / row['file']
        check(sha(path) == row['file_sha256'] == source[row['file']], 'metadata exact source file hash')
        line = path.read_text().splitlines()[row['line'] - 1]
        check(re.match(r'\s*theorem\s+' + re.escape(row['declaration'].split('.')[-1]) + r'\b', line), 'metadata declaration line')
        check(row['axioms'] == local['observed_axioms'][row['declaration']], 'metadata actual local axiom list')
        check('local Lean204' in row['verification_status'] and 'Linux Comparator pending' in row['verification_status'],
              'result status distinguishes local and future Linux')
    state = read(package / 'STATE.json')
    check(state['local_run'] == 204 and state['local_Lean_passed'] and state['contracts'] == 35 and
          state['local_type_diagnostic_run'] == 205 and state['all35_local_types_match'], 'truthful local status')
    check(state['current_source_review_continuations'] == 2 and state['count_change'] == 0 and
          not state['GitHub_Comparator_run_for_current_source'], 'no premature Linux or count claim')
    check(metadata['status']['whole_problem_verified'] is False and
          metadata['verification']['GitHub_Comparator']['status'] == 'pending for repaired source', 'live metadata pending')
    failed = read(package / 'verification/FAILED-LINUX-35269165327.json')
    check(failed == metadata['verification']['GitHub_Comparator']['previous_failed_run'] and
          failed['run_id'] == 35269165327 and failed['commit'] == EXPECTED_PREVIOUS and
          failed['conclusion'] == 'failure' and not failed['current_repaired_source_accepted'], 'failure history truthful')
    check('candidate kernel replay not reached' in failed['failure'], 'failure phase retained')
    check('historical local187 package only' in metadata['verification']['package_preflight']['scope'],
          'old package approval not misrepresented as current repair approval')
    diag = read(package / 'verification/type-diagnostics-205/COMPARISON.json')
    check(sha(package / 'verification/type-diagnostics-205/COMPARISON.json') ==
          '220012b2101b1167db78d3bb0e07ae90ede3b3f2021d1b57535e5ce3ceb4fa2f' and
          diag['all35_match'] and diag['source_complete_record_sha256'] == sha(package / 'verification/LOCAL-COMPLETE.json'),
          'actual205 diagnostic record retained')
    lake = read(package / 'lake-manifest.json')
    check(lake['name'] == 'NLANM04' and lake['packagesDir'] == '.lake/packages', 'contained Lake dependency directory and project name')
    pins = {x['name']: x['rev'] for x in lake['packages']}
    check(pins['leancert'] == '621a43d7cf21f87872392a01e874f2f1dbddc926' and
          pins['mathlib'] == '0df444a360eaa60ab8c11dca51a86af692955474', 'reviewed LeanCert and Mathlib pins')
    for dependency in lake['packages']:
        url = urllib.parse.urlsplit(dependency['url'])
        check(dependency['type'] == 'git' and re.fullmatch('[0-9a-f]{40}', dependency['rev']) and
              url.scheme == 'https' and url.netloc == 'github.com' and not url.query and not url.fragment,
              'immutable public dependency revision')
    check((package / 'lean-toolchain').read_text().strip() == 'leanprover/lean4:v4.33.1', 'pinned toolchain')
    toml = (package / 'lakefile.toml').read_text()
    check('defaultTargets = ["Solution"]' in toml and 'name = "NLA"' in toml and
          'name = "Challenge"' in toml and 'name = "Solution"' in toml, 'plain lake build targets actual proof')
    readme = (package / 'README.md').read_text()
    check('`lake build`' in readme and 'pending' in readme and 'first unsuccessful local adjustment' in readme,
          'reproduction and retained failure explanations')
    check(metadata['project']['authors'] == ['George Stepaniants'] and
          metadata['project']['affiliations']['George Stepaniants'] ==
          'Department of Computing and Mathematical Sciences, California Institute of Technology', 'authorized attribution')
    for name in ['Matthew J. Colbrook', 'Eric Rowland', 'Jason Wu', 'OpenAI Codex']:
        check(name in readme, 'prior authorship and automation disclosed')
    # Check only live documentation links, not historical source snapshots with original relative paths.
    link_checks = []
    for rel in ['README.md', 'reviews/README.md']:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', (package / rel).read_text()):
            if target.startswith(('https://', 'http://', '#', 'mailto:')):
                continue
            target = urllib.parse.unquote(target.split('#')[0])
            target_repo = posixpath.normpath(posixpath.join(REL, posixpath.dirname(rel), target))
            if target_repo.startswith(REL + '/'):
                check((package / target_repo[len(REL) + 1:]).exists(), 'live package file or directory link resolves')
            else:
                check((worktree / target_repo).is_file(), 'live shared harness link resolves')
            link_checks.append(target_repo)
    for key, value in metadata['alignment'].items():
        if key != 'status':
            check((package / value).is_file(), 'metadata alignment path exists')
    # Read every regular file and all archive members without extracting or executing them.
    counts = {'regular_files': 0, 'archives': 0, 'archive_members': 0, 'bytes_scanned': 0}
    archives = {}
    mail = re.compile(rb'[A-Za-z0-9.!#$%&\x27*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,}')
    def privacy(data, name, depth=0):
        counts['bytes_scanned'] += len(data)
        check(counts['bytes_scanned'] < 500_000_000, 'bounded complete archive scan')
        for match in mail.finditer(data):
            part = match.group().lower().split(b'@')[0]
            check(b'george' not in part and b'stepan' not in part, 'no George email candidate')
        if name.endswith(('.tar.gz', '.tgz', '.tar')):
            check(depth < 10, 'bounded archive nesting')
            counts['archives'] += 1
            contents = {}
            with tarfile.open(fileobj=io.BytesIO(data), mode='r:*') as stream:
                for member in stream.getmembers():
                    path = PurePosixPath(member.name)
                    check(not path.is_absolute() and '..' not in path.parts, 'safe relative archive member')
                    if member.isdir():
                        continue
                    check(member.isfile() and member.name not in contents, 'ordinary unique archive member')
                    payload = stream.extractfile(member).read()
                    contents[member.name] = payload
                    counts['archive_members'] += 1
                    privacy(payload, name + '!' + member.name, depth + 1)
            archives[name] = contents
    for rel in sorted(actual):
        counts['regular_files'] += 1
        privacy((package / rel).read_bytes(), rel)
    check(counts['regular_files'] == 380 and counts['archives'] == 11 and counts['archive_members'] == 1357,
          'complete observed privacy scan inventory')
    index = read(package / 'reviews/INDEX.json')
    final_reviewers = []
    archive_rows = []
    for row in index:
        archive_path = 'reviews/' + row['archive']
        check(sha(package / archive_path) == row['archive_sha256'], 'indexed archive digest')
        contents = archives[archive_path]
        root = row['original_packet'] + '/'
        manifest_bytes = contents[root + 'MANIFEST.json']
        check(digest(manifest_bytes) == row['manifest_sha256'] == sha(package / 'reviews' / row['manifest']),
              'indexed and archived review manifest identical')
        manifest = decode(manifest_bytes)
        for rel, expected in entries(manifest).items():
            check(root + rel in contents and digest(contents[root + rel]) == expected, 'review sealed payload retained')
        # Some earlier packets append execution receipts or separately hash-bound prior manifests.
        # Every such byte is still bound by the public archive SHA and outer package manifest.
        extras = sorted(set(contents) - {root + rel for rel in entries(manifest)} - {root + 'MANIFEST.json'})
        for key in ['report', 'verdict']:
            visible = (package / 'reviews' / row[key]).read_bytes()
            check(any(data == visible for data in contents.values()), 'readable review copy occurs byte-for-byte in archive')
        archive_rows.append({'label': row['label'], 'regular_members': len(contents), 'manifest_payloads': len(entries(manifest)),
                             'additional_outer_hash_bound_members': extras})
        if row['label'].endswith('-local204'):
            verdict = read(package / 'reviews' / row['verdict'])
            check(verdict.get('source_hashes', verdict.get('source_sha256')) == source, 'final continuation covers exact full38 sources')
            final_reviewers.append(verdict['reviewer'])
            number = int(row['label'].split('-')[1])
            acceptance = read(package / f'verification/ROOT-REFEREE{number}-ACCEPTANCE204.json')
            check(acceptance['actual_integrity_exit_code'] == 0 and
                  acceptance['manifest_sha256'] == row['manifest_sha256'] and
                  acceptance['verdict_sha256'] == sha(package / 'reviews' / row['verdict']) and
                  acceptance['current_source_complete_record_sha256'] == sha(package / 'verification/LOCAL-COMPLETE.json'),
                  'root actual source-review replay bound to integrated continuation')
    check(len(final_reviewers) == len(set(final_reviewers)) == 2, 'two distinct final continuation reviewers')
    check({'statement-1', 'statement-2', 'failed-runtime-diagnosis', 'unsuccessful-local201'} <= {r['label'] for r in index},
          'statement-first and failed history preserved')
    for name, contents in archives.items():
        roots = {key.split('/')[0] for key in contents}
        check(len(roots) == 1, 'single archive root')
        prefix = next(iter(roots)) + '/'
        manifest = decode(contents[prefix + 'MANIFEST.json'])
        for rel, expected in entries(manifest).items():
            check(prefix + rel in contents and digest(contents[prefix + rel]) == expected, 'all archive root manifest payloads match')
    # Actual read-only Git inspection of the intended publication worktree.
    git_records = []
    def git(*argv):
        command = ['git', *argv]
        result = subprocess.run(command, cwd=worktree, capture_output=True, text=True)
        check(result.returncode == 0, 'read-only Git query succeeded')
        git_records.append({'argv': command, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
        return result.stdout
    check(git('rev-parse', 'HEAD').strip() == EXPECTED_PREVIOUS and not git('status', '--porcelain').strip(),
          'clean expected previous publication commit')
    protected = ['tools/lean', '.github/workflows/lean-verification.yml', 'docs/lean/schema/v0.4.schema.json']
    check(git('diff', 'ff6abf718126ceb23f933cf4f627f95104461fe8', 'HEAD', '--', *protected) == '',
          'checker, workflow and schema invariant against trusted prior base')
    for capture in (HERE / 'inputs/worktree').rglob('*'):
        if capture.is_file():
            check(sha(capture) == sha(worktree / capture.relative_to(HERE / 'inputs/worktree')), 'reviewed checker/instruction source unchanged')
    existing = {str(p.relative_to(worktree / REL)): sha(p) for p in (worktree / REL).rglob('*') if p.is_file()}
    check(set(existing) <= actual, 'copytree overlay leaves no stale removed file')
    prospective = sorted(REL + '/' + rel for rel in actual if rel not in existing or sha(package / rel) != existing[rel])
    check(prospective and [path for path in prospective if path.endswith('.lean')] ==
          [REL + '/NLA/NM04/AnalyticBasics.lean'], 'anticipated sole active Lean source change')
    selector = module(HERE / 'inputs/worktree/tools/lean/projects.py', 'nm04_preflight_selection')
    projects = selector.discover_at_ref(worktree, EXPECTED_PREVIOUS)
    selected = selector.select(projects, prospective)
    check(selected == [{'id': 'NM-04', 'project': REL}], 'anticipated workflow selects exactly NM-04')
    check(not any(path.startswith(('tools/lean/', 'docs/lean/ci-toolchain/')) or
                  path == '.github/workflows/lean-verification.yml' for path in prospective), 'shared checker job not spuriously selected')
    script = (HERE / 'inputs/push_nm04_repaired_source.py').read_text()
    check(script == (package.parent / 'push_nm04_repaired_source.py').read_text(), 'reviewed pending push script exact')
    for required in ["'GitHub_Comparator']['status'] == 'pending for repaired source'", "GIT_AUTHOR_EMAIL=''",
                     "GIT_COMMITTER_EMAIL=''", "assert selected == [{'id': 'NM-04', 'project': REL}]",
                     "HEAD:refs/heads/codex/lean-nm04-verification", "assert actual_sources == [REL + '/NLA/NM04/AnalyticBasics.lean']",
                     "'problem_ids.json', 'RESOLVED.md'", "'canonical_status': 'Solved'", "'count_change': 0"]:
        check(required in script, 'reviewed push invariant retained')
    check("'--force'" not in script.split("run(['git', 'push'")[1], 'no force push requested')
    canonical = worktree / 'nonnegative-and-positive-factorizations/NM-04/README.md'
    check('**Status:** Solved' in canonical.read_text(), 'canonical status remains Solved')
    return {'result': 'PASS_PREPUBLICATION_PACKAGE', 'checks': checks, 'package_manifest_sha256': EXPECTED_PACKAGE,
            'package_payloads': 379, 'proof_sources': 38, 'original_contracts': 35,
            'privacy_scan': counts, 'George_email_candidates': 0,
            'archive_review_inventory': archive_rows, 'live_documentation_links': link_checks,
            'anticipated_changed_files': prospective, 'anticipated_selection': selected,
            'read_only_Git_queries': git_records, 'schema_checked': True,
            'reviewer_Lean_execution': False, 'reviewer_Comparator_execution': False,
            'push_script_executed': False, 'new_Linux_pending': True, 'count_change': 0}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--package', type=Path, default=Path('/private/tmp/nla-lean-next-20260915/NM04-canonical-package-local204'))
    parser.add_argument('--worktree', type=Path, default=Path('/private/tmp/nla-lean-next-nm04-worktree'))
    parser.add_argument('--record', type=Path, help='Optional audit record inside this review directory only.')
    args = parser.parse_args()
    if (HERE / 'MANIFEST.json').is_file():
        manifest = read(HERE / 'MANIFEST.json')
        actual = {str(p.relative_to(HERE)) for p in HERE.rglob('*') if p.is_file() and p != HERE / 'MANIFEST.json'}
        check(actual == set(manifest['files']), 'small review packet exact inventory')
        for rel, expected in manifest['files'].items():
            check(sha(HERE / rel) == expected, 'small review packet sealed bytes')
    result = audit(args.package, args.worktree)
    if args.record:
        check(args.record.resolve().is_relative_to(HERE) and not args.record.exists(), 'new record inside owned review only')
        args.record.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: value for k, value in result.items() if k not in
                      {'archive_review_inventory', 'live_documentation_links', 'anticipated_changed_files', 'read_only_Git_queries'}}, indent=2))

if __name__ == '__main__':
    main()
