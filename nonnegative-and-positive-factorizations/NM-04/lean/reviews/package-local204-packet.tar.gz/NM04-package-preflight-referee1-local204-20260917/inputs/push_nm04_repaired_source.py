"""Publish the reviewed local204 repair for the required real Linux check.

Keeps the canonical target Solved and preserves the first failed run.
"""
from pathlib import Path
import datetime, hashlib, importlib.util, json, os, re, shutil, subprocess

B = Path('/private/tmp/nla-lean-next-20260915')
W = Path('/private/tmp/nla-lean-next-nm04-worktree')
P = B / 'NM04-canonical-package-local204'
REL = 'nonnegative-and-positive-factorizations/NM-04/lean'
D = W / REL
PREVIOUS = '34a8bc2dd1330f2c51e496329341804eb5859d67'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
git = lambda *a: subprocess.check_output(['git', *a], cwd=W)
assert git('rev-parse', 'HEAD').decode().strip() == PREVIOUS
assert not git('status', '--porcelain').strip()
state = load(P / 'STATE.json')
assert state['current_source_review_continuations'] == 2 and state['count_change'] == 0
assert state['local_run'] == 204 and state['all35_local_types_match']
metadata = load(P / 'formalization.yaml')
assert metadata['status']['whole_problem_verified'] is False
assert metadata['verification']['independent_reviews']['final'] == 2
assert metadata['verification']['GitHub_Comparator']['status'] == 'pending for repaired source'
index = load(P / 'reviews/INDEX.json')
for number in [1, 2]:
    accepted = load(B / f'NM04-ROOT-REFEREE{number}-ACCEPTANCE204.json')
    assert accepted['actual_integrity_exit_code'] == 0
    row = next(r for r in index if r['label'] == f'final-{number}-local204')
    assert sha(P / 'reviews' / row['manifest']) == accepted['manifest_sha256']
    assert sha(P / 'reviews' / row['verdict']) == accepted['verdict_sha256']
    assert sha(P / 'reviews' / row['archive']) == row['archive_sha256']
local = load(B / 'NM04-LOCAL-COMPLETE-204.json')
for rel, h in local['sources'].items():
    assert sha(P / rel) == h, rel
for rel, h in load(P / 'STATEMENT-FREEZE.json')['source_sha256'].items():
    assert sha(P / rel) == sha(D / rel) == h, rel
manifest = load(P / 'PACKAGE-MANIFEST.json')
assert set(manifest['files']) | {'PACKAGE-MANIFEST.json'} == {str(f.relative_to(P)) for f in P.rglob('*') if f.is_file()}
for rel, h in manifest['files'].items():
    assert sha(P / rel) == h, rel
    text = (P / rel).read_bytes().decode('utf-8', errors='ignore')
    assert not re.search(r'(?i)(?:george|g?stepaniants|sgstepaniants)[^\s@<>]{0,40}@[\w.-]+\.[A-Za-z]{2,}', text), rel
shutil.copytree(P, D, dirs_exist_ok=True)
assert {str(f.relative_to(P)) for f in P.rglob('*') if f.is_file()} == {str(f.relative_to(D)) for f in D.rglob('*') if f.is_file()}
for f in P.rglob('*'):
    if f.is_file():
        assert sha(f) == sha(D / f.relative_to(P))
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONPATH='/tmp/nla-publication-python-20260917',
           GIT_AUTHOR_NAME='George Stepaniants', GIT_AUTHOR_EMAIL='',
           GIT_COMMITTER_NAME='George Stepaniants', GIT_COMMITTER_EMAIL='')
record = {'time': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'previous_commit': PREVIOUS,
          'project': REL, 'local_source_run': 204, 'local_type_diagnostic_run': 205,
          'two_exact_source_continuations': True, 'new_Linux_Comparator_run': False,
          'canonical_status': 'Solved', 'count_change': 0, 'commands': []}
record_path = B / 'NM04-REPAIRED-PROOF-PUSH-20260917.json'
assert not record_path.exists()
def save():
    record_path.write_text(json.dumps(record, indent=2) + '\n')
def run(argv):
    r = subprocess.run(argv, cwd=W, env=env, capture_output=True, text=True)
    record['commands'].append({'argv': argv, 'exit_code': r.returncode, 'stdout': r.stdout, 'stderr': r.stderr})
    save()
    assert r.returncode == 0, (r.stdout, r.stderr)
    return r
run(['/Users/georgestepaniants/miniforge3/bin/python', 'tools/lean/validate_manifest.py', REL])
run(['git', 'add', '--force', '--', REL])
run(['git', '-c', 'commit.gpgsign=false', 'commit', '-m', 'Match NM-04 derivative elaboration to frozen Comparator contract'])
commit = git('rev-parse', 'HEAD').decode().strip()
assert git('show', '-s', '--format=%ae|%ce', 'HEAD') == b'|\n'
changed = git('diff', '--name-only', '--no-renames', PREVIOUS, commit).decode().splitlines()
assert changed and all(p.startswith(REL + '/') for p in changed)
actual_sources = git('diff', '--name-only', PREVIOUS, commit, '--', '*.lean').decode().splitlines()
assert actual_sources == [REL + '/NLA/NM04/AnalyticBasics.lean'], actual_sources
assert git('diff', PREVIOUS, commit, '--', 'problem_ids.json', 'RESOLVED.md',
           'nonnegative-and-positive-factorizations/NM-04/README.md') == b''
spec = importlib.util.spec_from_file_location('selection', W / 'tools/lean/projects.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
projects = module.discover_at_ref(W, commit)
module.require_retained_projects(projects, module.discover_at_ref(W, PREVIOUS))
selected = module.select(projects, changed)
assert selected == [{'id': 'NM-04', 'project': REL}], selected
assert git('diff', 'ff6abf718126ceb23f933cf4f627f95104461fe8', commit, '--',
           'tools/lean', '.github/workflows/lean-verification.yml') == b''
tracked = git('ls-tree', '-r', '--name-only', commit, '--', REL).decode().splitlines()
assert set(tracked) == {REL + '/' + str(f.relative_to(P)) for f in P.rglob('*') if f.is_file()}
record.update(proof_commit=commit, tracked_project_files=len(tracked), changed_files=len(changed),
              selection=selected, package_manifest_sha256=sha(P / 'PACKAGE-MANIFEST.json'),
              source_complete_record_sha256=sha(B / 'NM04-LOCAL-COMPLETE-204.json'))
save()
run(['git', 'push', 'origin', 'HEAD:refs/heads/codex/lean-nm04-verification'])
record['pushed'] = True
save()
print(json.dumps({k: record[k] for k in ['proof_commit', 'tracked_project_files', 'changed_files', 'selection', 'pushed', 'count_change']}, indent=2))
