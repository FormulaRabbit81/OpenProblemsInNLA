#!/usr/bin/env python3
"""Read-only continuation verifier. Never invokes Lean, Lake, Comparator or subprocess.

Replays SHA bindings, source-scope comparisons, root-run receipt/log consistency,
and raw type-dump comparisons. This is neither an independent compiler rerun nor
an unforgeable attestation. The real repaired-source Linux run remains a separate gate.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re

BASE = Path(__file__).resolve().parent
LOCAL = Path('/private/tmp/nla-lean-local-shared-20260916')
checks = 0

def check(value, why):
    global checks
    if not value:
        raise AssertionError(why)
    checks += 1

def read(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def local(path):
    return BASE / 'evidence/local' / Path(path).relative_to(LOCAL)

def seal(directory, expected=None):
    manifest = directory / 'MANIFEST.json'
    if expected:
        check(sha(manifest) == expected, 'original manifest binding')
    files = read(manifest)['files']
    actual = {str(p.relative_to(directory)) for p in directory.rglob('*')
              if p.is_file() and p != manifest}
    check(actual == set(files), 'complete sealed payload inventory')
    for rel, digest in files.items():
        check(sha(directory / rel) == digest, 'sealed bytes: ' + rel)

def erased_repr(text):
    """Erase only the first Name argument of Expr binders in retained repr text.

    This independent Python check is restricted to the captured repr grammar;
    it does not elaborate Lean, erase constants/types, or invoke a compiler.
    """
    spans = []
    for match in re.finditer(r'Lean\.Expr\.(?:forallE|lam|letE)\s+', text):
        start = match.end()
        if text[start] == '(':
            depth = 0
            end = start
            for end in range(start, len(text)):
                if text[end] == '(':
                    depth += 1
                elif text[end] == ')':
                    depth -= 1
                    if depth == 0:
                        break
            end += 1
            check(depth == 0 and text[start + 1:end].lstrip().startswith('Lean.Name.'),
                  'binder repr first argument is a Name constructor')
        else:
            end = start
            while end < len(text) and not text[end].isspace() and text[end] not in '()':
                end += 1
            check(text[start:end].startswith(('`', 'Lean.Name.anonymous')),
                  'binder repr first argument is a Name literal')
        spans.append((start, end))
    for start, end in reversed(spans):
        text = text[:start] + 'Lean.Name.anonymous' + text[end:]
    return text

def tokens(text):
    # Repr line wrapping changes with name length; preserve strings and all other tokens.
    return re.findall(r'"(?:\\.|[^"\\])*"|`«[^»]*»|[()\[\],]|[^\s()\[\],]+', text)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check-current', type=Path)
    args = parser.parse_args()
    seal(BASE)
    baseline = BASE / 'baseline187'
    seal(baseline, 'afc66176571c99fc2cbac88c6dd691a60b5fa0123402d247407eb35485598e87')
    previous = read(baseline / 'VERDICT.json')
    check(previous['verdict'] == 'APPROVE_EXACT_SOURCE187' and previous['nonauthor'],
          'previous independent whole-target approval')
    record_path = BASE / 'evidence/local/NM04-LOCAL-COMPLETE-204.json'
    check(sha(record_path) == '4063492a265402d4c9cf50d6019911f00d939d294d44702f966975119a7c3e6d',
          'root actual local204 result')
    record = read(record_path)
    sources = record['sources']
    check(len(sources) == record['actual_local_closure_modules'] == 38 and
          record['exact_contracts'] == 35, 'full source/contract scope')
    check(set(sources) == set(previous['source_hashes']), 'unchanged closure inventory')
    changed = {p for p in sources if sources[p] != previous['source_hashes'][p]}
    check(changed == {'NLA/NM04/AnalyticBasics.lean'}, 'one active source changed')
    texts = {}
    for rel, digest in sources.items():
        path = BASE / 'evidence/source204' / (rel + '.txt')
        check(sha(path) == digest, 'exact reviewed source204')
        if args.check_current:
            check(sha(args.check_current / rel) == digest, 'current source still reviewed204')
        texts[rel[:-5].replace('/', '.')] = path.read_text()
    before = (baseline / 'evidence/source187/NLA/NM04/AnalyticBasics.lean.txt').read_text()
    after = texts['NLA.NM04.AnalyticBasics']
    insertion = '''section FrozenDerivativeInstance

-- Match the frozen specification's scalar-continuity witness. Additional
-- analytic imports supply another proof of this same property, while
-- Comparator compares the elaborated statements structurally.
attribute [local instance] ContinuousMul.to_continuousSMul
attribute [-instance] IsModuleTopology.toContinuousSMul

'''
    closing = 'end FrozenDerivativeInstance\n\n'
    check(after.count(insertion) == 1 and after.count(closing) == 1, 'only reviewed scope syntax')
    check(after.replace(insertion, '', 1).replace(closing, '', 1) == before,
          'every original header, proof body and other byte unchanged')
    wrapped = after.split(insertion)[1].split(closing)[0]
    check(re.findall(r'^theorem\s+(\w+)', wrapped, re.M) == ['potential_line_derivative'],
          'section encloses only C04')
    check(after.index(closing) < after.index('#print axioms row_partition_positive'),
          'instance scope closed before axiom/trust reports')
    imports = {m: re.findall(r'^import\s+(\S+)', s, re.M) for m, s in texts.items()}
    closures = {}
    def closure(module):
        if module not in closures:
            closures[module] = {module}
            for dep in imports[module]:
                check(dep != 'Challenge' and not dep.startswith('NLA.NM04Diagnostics'),
                      'specification/diagnostic outside proof imports')
                if dep.startswith('NLA.'):
                    check(dep in texts, 'retained proof dependency')
                    closures[module] |= closure(dep)
        return closures[module]
    check(closure('Solution') == set(texts), 'full38 source closure retained')
    frozen = BASE / 'evidence/frozen'
    freeze = read(frozen / 'STATEMENT-FREEZE.json')
    check(sha(frozen / 'STATEMENT-FREEZE.json') == previous['statement_freeze_sha256'],
          'original statement freeze retained')
    for rel, digest in freeze['source_sha256'].items():
        p = frozen / (rel + '.txt' if rel.endswith('.lean') else rel)
        check(sha(p) == digest, 'frozen boundary unchanged')
        if args.check_current:
            check(sha(args.check_current / rel) == digest, 'current frozen boundary unchanged')
    cfg = read(frozen / 'comparator.json')
    names = cfg['theorem_names']
    headers = read(frozen / 'STATEMENT-HEADERS.json')['headers']
    challenge = (frozen / 'Challenge.lean.txt').read_text()
    check(len(names) == len(headers) == 35 and cfg['definition_names'] == [], '35 unchanged exact contracts')
    allowed = {'propext', 'Classical.choice', 'Quot.sound'}
    check(set(cfg['permitted_axioms']) == allowed, 'no extra permitted axioms')
    for header in headers:
        pattern = r'^theorem\s+' + re.escape(header['name'].split('.')[-1]) + r'\b[\s\S]*?(?=\s*:=\s*by)'
        expected = re.search(pattern, challenge, re.M).group().strip()
        matches = [m.group().strip() for s in texts.values() if (m := re.search(pattern, s, re.M))]
        check(matches == [expected] == [header['header']], 'literal original theorem header')
    for path, digest in record['retained_original_evidence'].items():
        check(sha(local(path)) == digest, 'retained original local evidence')
    receipt = read(local(record['receipt']))
    check(sha(local(record['receipt'])) == record['receipt_sha256'], 'local204 receipt binding')
    check(receipt.get('end') and receipt['completed_modules'] == 38 and
          not receipt['failed_modules'] and not receipt['blocked_modules'], 'terminal local204 success')
    check(sha(BASE / 'evidence/local/ASSEMBLY-204.json') == record['assembly_sha256'] ==
          receipt['assembly_sha256'], 'source assembly binding')
    check(sha(BASE / 'evidence/local/serial_compile_v3.py') == receipt['runner_sha256'],
          'actual serial driver binding')
    check(sum(c.get('exit_code') == 0 for c in receipt['commands']) == 8 and
          sum(c.get('status') == 'reused_exact_successful_local_output' for c in receipt['commands']) == 30,
          '8 fresh successes and 30 exact successful reuses')
    origins = record['commands_and_successful_origins']
    check({x['module'] for x in origins} == set(texts), 'all modules have successful origin evidence')
    outputs = {x['module']: x['command']['output_sha256'] for x in origins}
    for origin in origins:
        module = origin['module']
        original = origin['command']
        for index, hop in enumerate(origin['reuse_chain']):
            path = local(hop['receipt'])
            check(sha(path) == hop['sha256'], 'reuse receipt hash')
            node = read(path)
            check(node.get('end') and node['platform'] == 'darwin' and node['threads'] == 1 and
                  node['memory_cap_mib'] == 4096 and node['max_compiler_processes'] == 1,
                  'local one-process resource limits')
            matching = [c for c in node['commands'] if c['module'] == module]
            check(len(matching) == 1, 'unique module command')
            command = matching[0]
            check(command['source_sha256'] == sources[module.replace('.', '/') + '.lean'] and
                  command['output_sha256'] == original['output_sha256'], 'reuse source/output binding')
            for dependency in closure(module):
                rel = dependency.replace('.', '/') + '.lean'
                check(node['source_inputs'][rel] == sources[rel], 'transitive exact-source reuse')
            if index + 1 < len(origin['reuse_chain']):
                nxt = origin['reuse_chain'][index + 1]
                check(command['status'] == 'reused_exact_successful_local_output', 'reuse status')
                if 'prior_receipt' in command:
                    check(command['prior_receipt'] == nxt['receipt'] and
                          command['prior_receipt_sha256'] == nxt['sha256'], 'prior receipt link')
                else:
                    check(command['prior_command'] in read(local(nxt['receipt']))['commands'], 'legacy prior link')
            else:
                check(command == original and command['exit_code'] == 0, 'actual successful origin')
                check('--threads=1' in command['argv'] and '--memory=4096' in command['argv'], 'bounded argv')
                log = path.parent / (module + '.log')
                check(sha(log) == command['log_sha256'] and 'error:' not in log.read_text(), 'original successful log')
                for dep, digest in command['dependency_olean_sha256'].items():
                    check(outputs[dep] == digest, 'successful direct dependency output')
    final_log = (local(record['receipt']).parent / 'Solution.log').read_text()
    observed = re.findall(r"^'([^']+)' depends on axioms: \[([^]]*)\]$", final_log, re.M)
    check([name for name, _ in observed] == names, 'all35 exports reported')
    for name, axiom_list in observed:
        axioms = [a.strip() for a in axiom_list.split(',')]
        check(set(axioms) <= allowed and record['observed_axioms'][name] == axioms, 'allowed transitive axioms')
    check(re.findall(r'^#assert_trust kernel (\S+)$', texts['Solution'], re.M) == names,
          'all35 kernel trust assertions actually in successful Solution')
    diag = BASE / 'evidence/diagnostic205'
    compare = read(diag / 'COMPARISON.json')
    check(sha(diag / 'COMPARISON.json') == '220012b2101b1167db78d3bb0e07ae90ede3b3f2021d1b57535e5ce3ceb4fa2f',
          'root actual205 comparison binding')
    check(compare['source_complete_record_sha256'] == sha(record_path), 'diagnostic tied to exact204')
    dr = read(local(compare['receipt']))
    check(sha(local(compare['receipt'])) == compare['receipt_sha256'] and dr.get('end') and
          not dr['failed_modules'] and not dr['blocked_modules'] and dr['completed_modules'] == 39,
          'actual205 successful diagnostic execution')
    for command in dr['commands']:
        if command['module'].startswith('NLA.NM04.'):
            module = command['module']
            check(command['status'] == 'reused_exact_successful_local_output' and
                  command['prior_receipt'] == record['receipt'] and
                  command['prior_receipt_sha256'] == record['receipt_sha256'] and
                  command['output_sha256'] == outputs[module], 'diagnostic exact204 reuse')
    assembly = read(BASE / 'evidence/local/ASSEMBLY-205.json')
    check(sha(BASE / 'evidence/local/ASSEMBLY-205.json') == dr['assembly_sha256'], 'diagnostic assembly binding')
    check(assembly['frozen_Challenge_sha256'] == previous['challenge_sha256'], 'diagnostic original Challenge')
    for rel, digest in sources.items():
        if rel != 'Solution.lean':
            check(assembly['sources'][rel]['sha256'] == digest and dr['source_inputs'][rel] == digest,
                  'diagnostic uses exact repaired proof closure')
    diag_source = {}
    for label in ['Challenge', 'Solution']:
        module = 'NLA.NM04Diagnostics.' + label + 'Types205'
        rel = module.replace('.', '/') + '.lean'
        source = diag / (rel + '.txt')
        cmd = next(c for c in dr['commands'] if c['module'] == module)
        check(cmd.get('exit_code') == 0 and sha(source) == cmd['source_sha256'] ==
              assembly['sources'][rel]['sha256'], 'fresh diagnostic source execution')
        check('--threads=1' in cmd['argv'] and '--memory=4096' in cmd['argv'], 'bounded diagnostic argv')
        log = local(compare['receipt']).parent / (module + '.log')
        check(sha(log) == cmd['log_sha256'] and 'error:' not in log.read_text(), 'actual diagnostic log')
        diag_source[label] = source.read_text()
    prefix = challenge.replace('import NLA.NM04.Definitions', 'import NLA.NM04.Definitions\nimport Lean', 1)
    check(diag_source['Challenge'].startswith(prefix + '\nprivate def diagnosticEraseBinderNames'),
          'diagnostic Challenge is unchanged frozen source plus Lean import and observer suffix')
    check(diag_source['Solution'].startswith('import NLA.NM04.Canonical\nimport NLA.NM04.TransitionEntries\nimport Lean\n'),
          'solution diagnostic imports exact proof entrypoint dependencies')
    for label, source in diag_source.items():
        suffix = source[source.index('private def diagnosticEraseBinderNames'):]
        check(re.findall(r'`(NLA\.NM04\.[A-Za-z0-9_]+)', suffix) == names, 'exact35 diagnostic name order')
        check('let ci ← getConstInfo name' in suffix and '(reprStr ci.type)' in suffix,
              'diagnostic observes elaborated types')
    left = read(diag / 'challenge-types.json')
    right = read(diag / 'solution-types.json')
    check(sha(diag / 'challenge-types.json') == compare['challenge_dump_sha256'] and
          sha(diag / 'solution-types.json') == compare['solution_dump_sha256'], 'captured raw dump bindings')
    check([x['name'] for x in left] == [x['name'] for x in right] == names, 'all35 raw dump targets')
    actual_results = []
    for x, y in zip(left, right):
        for row in [x, y]:
            check(tokens(erased_repr(row['type'])) == tokens(row['binderNormalizedType']),
                  'independent erasure only of raw Expr binder names')
        actual_results.append({'name': x['name'], 'same_universes': x['levelParams'] == y['levelParams'],
                               'same_binder_normalized_type': x['binderNormalizedType'] == y['binderNormalizedType']})
    check(actual_results == compare['results'] and all(x['same_universes'] and x['same_binder_normalized_type']
          for x in actual_results) and compare['all35_match'], 'all35 equality independently recomputed')
    c04 = next(x for x in left if x['name'].endswith('.potential_line_derivative'))
    check('ContinuousMul.to_continuousSMul' in c04['type'] and
          'IsModuleTopology.toContinuousSMul' not in c04['type'], 'original selected C04 witness')
    olddiag = BASE / 'evidence/diagnostic202'
    oldleft, oldright = read(olddiag / 'challenge-types.json'), read(olddiag / 'solution-types.json')
    check([x['name'] for x in oldleft] == [x['name'] for x in oldright] == names, 'historical failed diagnostic targets')
    differences = [x['name'] for x, y in zip(oldleft, oldright)
                   if x['levelParams'] != y['levelParams'] or x['binderNormalizedType'] != y['binderNormalizedType']]
    check(differences == ['NLA.NM04.potential_line_derivative'], 'unsuccessful local202 C04 remains failure evidence')
    fail = BASE / 'evidence/failed-linux-35269165327'
    run = read(fail / 'run.json')
    log = (fail / 'comparator.log').read_text()
    check(run['id'] == 35269165327 and run['conclusion'] == 'failure' and
          run['head_sha'] == '34a8bc2dd1330f2c51e496329341804eb5859d67', 'earlier exact published run failed')
    check("Challenge and solution theorem statement do not match: 'NLA.NM04.potential_line_derivative'" in log and
          'EXIT_STATUS=1' in log and 'Running Lean default kernel on solution.' not in log and
          'Your solution is okay!' not in log, 'earlier Linux failure before candidate kernel replay')
    for pin in read(BASE / 'evidence/primary/PINS.json'):
        check(sha(BASE / 'evidence/primary' / pin['source']) == pin['sha256'], 'primary source scope audit binding')
    verdict = read(BASE / 'VERDICT.json')
    check(verdict['verdict'] == 'APPROVE_EXACT_SOURCE204_CONTINUATION' and verdict['nonauthor'], 'independent approval')
    check(verdict['source_hashes'] == sources and verdict['full_target_review_preserved'] and
          verdict['reviewed_original_contracts'] == 35, 'approval exact full unchanged target')
    check(not verdict['reviewer_Lean_execution'] and not verdict['reviewer_Comparator_execution'] and
          not verdict['new_Linux_Comparator_success_verified'] and verdict['completed_target_count_change'] == 0,
          'no unrun checks or completion claimed')
    print(json.dumps({'result': 'PASS', 'checks': checks, 'scope': 'Read-only source204 continuation evidence consistency',
                      'proof_modules': 38, 'frozen_contracts': 35, 'actual_root_local_run': 204,
                      'actual_root_type_diagnostic': 205, 'reviewer_Lean_execution': False,
                      'reviewer_Comparator_execution': False, 'new_Linux_pending': True,
                      'completed_target_count_change': 0}, indent=2))

if __name__ == '__main__':
    main()
