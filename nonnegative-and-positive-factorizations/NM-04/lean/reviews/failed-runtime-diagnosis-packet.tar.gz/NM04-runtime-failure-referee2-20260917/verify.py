#!/usr/bin/env python3
"""Read-only sealed failure-evidence integrity, not a compiler or Comparator."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();n=0
def ck(label,ok):
 global n
 n+=1
 if not ok:raise SystemExit('FAIL: '+label)
m=json.loads((R/'MANIFEST.json').read_text())['files']
a={p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file()}
ck('exact packet inventory',a==set(m)|{'MANIFEST.json'} or a==set(m)|{'MANIFEST.json','VERIFICATION.json'})
for rel,h in m.items():ck('sealed '+rel,sha((R/rel).read_bytes())==h)
v=json.loads((R/'VERDICT.json').read_text());c=json.loads((R/'CHECKS.json').read_text());run=json.loads((R/'AUDIT-RUN.json').read_text())
ck('bounded failure verdict',v['verdict']=='CONFIRM_FAILURE_AND_EXACT_INSTANCE_MISMATCH_DIAGNOSIS')
ck('report hash',sha((R/'REVIEW.md').read_bytes())==v['report_sha256'])
ck('actual audit success',run['exit_code']==0 and json.loads(run['stdout'])['pass'])
ck('actual89 audit checks',c['pass'] and len(c['checks'])==89 and all(x['pass'] for x in c['checks']))
ck('candidate not accepted',not v['candidate_Comparator_accepted'] and not v['candidate_default_kernel_replayed'] and not v['repaired_source_approval'] and v['count_change']==0)
a=json.loads((R/'observed/artifacts.json').read_text())['artifacts'][0]
ck('advertised artifact binding',a['digest']=='sha256:'+v['artifact_sha256'])
r=json.loads((R/'observed/run.json').read_text())
ck('run failed at exact head',r['id']==v['run_id'] and r['head_sha']==v['commit'] and r['conclusion']=='failure')
log=next((R/'observed/artifact-logs').glob('verify-*/comparator.log')).read_text()
ck('actual failure marker',"Challenge and solution theorem statement do not match: 'NLA.NM04.potential_line_derivative'" in log and 'EXIT_STATUS=1' in log)
ck('no candidate replay marker','Running Lean default kernel on solution.' not in log and 'Your solution is okay!' not in log)
t=json.loads((R/'INDEPENDENT-TYPE-COMPARISON.json').read_text())
ck('all35 type comparisons',len(t)==35 and all(x['level_parameters_equal'] for x in t))
ck('onlyC04 nonbinder mismatch',[x['name'] for x in t if not x['binder_name_normalized_repr_equal']]==['NLA.NM04.potential_line_derivative'])
print(json.dumps({'pass':True,'checks':n,'scope':'Read-only failure-evidence integrity; no runtime acceptance'}))
