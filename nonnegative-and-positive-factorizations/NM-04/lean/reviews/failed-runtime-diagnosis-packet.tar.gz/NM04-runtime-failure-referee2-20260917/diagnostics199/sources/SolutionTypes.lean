import NLA.NM04.Canonical
import NLA.NM04.TransitionEntries
import Lean

open Lean in
run_cmd do
  let mut rows : Array Json := #[]
  for name in #[`NLA.NM04.coercivity_half_certificate, `NLA.NM04.row_partition_positive, `NLA.NM04.potential_continuous, `NLA.NM04.potential_line_derivative, `NLA.NM04.zero_mean_coercivity, `NLA.NM04.potential_attains_minimum, `NLA.NM04.potential_minimum_has_margins, `NLA.NM04.positive_balanced_scaling_exists, `NLA.NM04.positive_balanced_scaling_unique, `NLA.NM04.sinkhorn_semantics, `NLA.NM04.position_sorted_semantics, `NLA.NM04.empty_minor_values, `NLA.NM04.H_diagonal, `NLA.NM04.H_raising, `NLA.NM04.H_lowering, `NLA.NM04.H_column_exchange, `NLA.NM04.H_row_exchange, `NLA.NM04.H_other, `NLA.NM04.weighted_principal_minor_expansion, `NLA.NM04.cofactor_signed_minor_formula, `NLA.NM04.universal_rank_one_update, `NLA.NM04.universal_bordered_determinant, `NLA.NM04.minor_lowering_identity, `NLA.NM04.minor_column_exchange_identity, `NLA.NM04.minor_row_exchange_identity, `NLA.NM04.minor_raising_identity, `NLA.NM04.schur_margin_identities, `NLA.NM04.schur_bordered_minor, `NLA.NM04.balanced_minor_relation, `NLA.NM04.weighted_transition_action, `NLA.NM04.balanced_null_vector, `NLA.NM04.diagonal_minor_covariance, `NLA.NM04.diagonal_pencil_covariance, `NLA.NM04.sinkhorn_pencil_singular, `NLA.NM04.rowland_wu_identity] do
    let ci ← getConstInfo name
    rows := rows.push <| Json.mkObj [
      ("name", toJson name.toString),
      ("levelParams", toJson (ci.levelParams.map Name.toString)),
      ("type", toJson (reprStr ci.type))]
  IO.FS.writeFile "/private/tmp/nla-lean-next-20260915/NM04-type-diagnostics-199/solution-types.json" (Json.compress (toJson rows))
