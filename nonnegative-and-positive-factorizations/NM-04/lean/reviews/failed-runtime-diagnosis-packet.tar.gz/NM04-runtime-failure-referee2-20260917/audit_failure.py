#!/usr/bin/env python3
"""Independent read-only failure/type audit; not a Lean or Comparator invocation."""
from pathlib import Path
import datetime,difflib,hashlib,json,re,subprocess,zipfile
R=Path(__file__).resolve().parent;B=Path('/private/tmp/nla-lean-next-20260915')
G=B/'NM04-canonical-run-35269165327';D=B/'NM04-type-diagnostics-199'
L=Path('/private/tmp/nla-lean-local-shared-20260916')
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
def check(label,ok):
 checks.append({'check':label,'pass':bool(ok)})
 if not ok:raise AssertionError(label)
def put(rel,b):
 p=R/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else b.encode())
def jout(rel,j):put(rel,json.dumps(j,indent=2)+'\n')
run=json.loads((G/'run.json').read_text());art=json.loads((G/'artifacts.json').read_text())['artifacts'][0]
check('actual terminal failed run',run['id']==35269165327 and run['conclusion']=='failure' and run['status']=='completed')
check('actual reviewed proof commit',run['head_sha']=='34a8bc2dd1330f2c51e496329341804eb5859d67')
check('authenticated artifact digest',art['digest']=='sha256:'+sha((G/'lean-NM-04.zip').read_bytes())=='sha256:f4d41f070642d1c3a69e1b46e221eed5176671c819722cf5330b93d4e462ae52')
check('artifact run/head identity',art['workflow_run']['id']==run['id'] and art['workflow_run']['head_sha']==run['head_sha'])
with zipfile.ZipFile(G/'lean-NM-04.zip') as z:
 for name in z.namelist():
  if name.endswith('/'):continue
  check('exact extracted artifact '+name,(G/'artifacts/lean-NM-04'/name).read_bytes()==z.read(name))
logs=next((G/'artifacts/lean-NM-04').glob('verify-*'))
text=(logs/'comparator.log').read_text()
check('actual C04 statement mismatch',"uncaught exception: Challenge and solution theorem statement do not match: 'NLA.NM04.potential_line_derivative'" in text and 'EXIT_STATUS=1' in text)
check('candidate kernel replay not reached','Running Lean default kernel on solution.' not in text and 'Your solution is okay!' not in text)
check('Challenge build completed', 'Build completed successfully (2336 jobs).' in text)
check('Solution build completed','Build completed successfully (3667 jobs).' in text)
soltext=text.split('Built Solution',1)[1].split('Build completed successfully',1)[0]
exports=re.findall(r"'([^']+)' depends on axioms: \[([^\]]+)\]",soltext)
config=json.loads((B/'NM04-canonical-package-local187/comparator.json').read_text())
check('all35 exact Linux axiom exports',[n for n,_ in exports]==config['theorem_names'])
check('all printed exports foundation-only',all(set(a.split(', '))=={'propext','Classical.choice','Quot.sound'} for _,a in exports))
check('no terminal result file',not list(G.rglob('result.json')))
for name in ['job-105364154708.log','job-105363832661.log']:put('observed/'+name,(G/name).read_bytes())
raw=(G/'job-105364154708.log').read_text()
check('raw log confirms actual checkout',run['head_sha'] in raw)
check('raw log confirms C04 failure',"Challenge and solution theorem statement do not match: 'NLA.NM04.potential_line_derivative'" in raw)
check('raw harness exits2','Process completed with exit code 2.' in raw)
select=(G/'job-105363832661.log').read_text()
check('actual selection NM04 only','{"include":[{"id":"NM-04","project":"nonnegative-and-positive-factorizations/NM-04/lean"}]}' in select)
for name,marker,status in [('comparator-controls.log','PASS: all five Comparator regressions',0),('kernel-controls.log','PASS: all three actual Comparator.runBuiltinKernel cases behaved as required',0),('sandbox.log','Outer and export fixture contents unchanged; only designated build fixture written.',0),('negative-sorry.log',"Illegal axiom detected: 'sorryAx'",1),('negative-native.log',"Illegal axiom detected: 'checked._native.native_decide.ax_1_1'",1)]:
 s=(logs/name).read_text();check('observed control '+name,marker in s and 'EXIT_STATUS='+str(status) in s)
receipt=json.loads((L/'runs/development-199/RECEIPT.json').read_text())
check('actual199 terminal diagnostic completion',receipt['end'] and not receipt['failed_modules'] and not receipt['blocked_modules'])
fresh=[c for c in receipt['commands'] if 'argv' in c]
check('actual199 two diagnostic commands',len(fresh)==2 and all(c['exit_code']==0 for c in fresh))
check('actual199 compiler limits',receipt['max_compiler_processes']==1 and receipt['threads']==1 and receipt['memory_cap_mib']==4096)
for rel,h in receipt['source_inputs'].items():check('199 exact retained source '+rel,sha((D/'sources'/rel).read_bytes())==h)
for c in fresh:
 p=L/'runs/development-199'/(c['module']+'.log')
 check('199 actual diagnostic log '+c['module'],sha(p.read_bytes())==c['log_sha256'])
 put('diagnostics199/'+p.name,p.read_bytes())
put('diagnostics199/RECEIPT.json',(L/'runs/development-199/RECEIPT.json').read_bytes())
for name in ['challenge-types.json','solution-types.json','RAW-TYPE-COMPARISON.json']:put('diagnostics199/'+name,(D/name).read_bytes())
for f in (D/'sources/NLA/NM04Diagnostics').glob('*.lean'):put('diagnostics199/sources/'+f.name,f.read_bytes())
challenge=json.loads((D/'challenge-types.json').read_text());solution=json.loads((D/'solution-types.json').read_text())
check('all35 names from exact configuration',[x['name'] for x in challenge]==[x['name'] for x in solution]==config['theorem_names'])
check('all35 universe parameter lists identical',all(x['levelParams']==y['levelParams'] for x,y in zip(challenge,solution)))
# This removes only expression binder names. It is a diagnostic reflecting
# Lean's documented alpha-equivalence, not an implementation of Comparator.
def normalize_binders(s):
 pattern=re.compile(r'(Lean\.Expr\.(?:forallE|lam|letE)\s+)')
 out=[];pos=0
 for m in pattern.finditer(s):
  if m.start()<pos:continue
  out.append(s[pos:m.end()]);i=m.end()
  if s[i]=='`':
   e=i+1
   while e<len(s) and not s[e].isspace():e+=1
  elif s[i]=='(':
   depth=0;quoted=False;escape=False;e=i
   while e<len(s):
    c=s[e]
    if quoted:
     if escape:escape=False
     elif c=='\\':escape=True
     elif c=='"':quoted=False
    elif c=='"':quoted=True
    elif c=='(':depth+=1
    elif c==')':
     depth-=1
     if depth==0:e+=1;break
    e+=1
  else:raise AssertionError('unexpected binder-name representation')
  out.append('BINDER');pos=e
 out.append(s[pos:]);return ' '.join(''.join(out).split())
comparison=[]
for x,y in zip(challenge,solution):
 comparison.append({'name':x['name'],'raw_repr_equal':x['type']==y['type'],'binder_name_normalized_repr_equal':normalize_binders(x['type'])==normalize_binders(y['type']),'level_parameters_equal':x['levelParams']==y['levelParams']})
check('exactlyC04 nonbinder mismatch',[x['name'] for x in comparison if not x['binder_name_normalized_repr_equal']]==['NLA.NM04.potential_line_derivative'])
check('24 exact raw types',sum(x['raw_repr_equal'] for x in comparison)==24)
check('ten harmless binder-name differences',sum(not x['raw_repr_equal'] and x['binder_name_normalized_repr_equal'] for x in comparison)==10)
witness=json.loads((R/'DIFFERING-CONTINUITY-WITNESS.json').read_text())
x=next(x for x in challenge if x['name'].endswith('potential_line_derivative'))['type'];y=next(x for x in solution if x['name'].endswith('potential_line_derivative'))['type']
check('actual Challenge continuity witness present',witness['challenge_witness'] in x and 'ContinuousMul.to_continuousSMul' in witness['challenge_witness'])
check('actual Solution continuity witness present',witness['solution_witness'] in y and 'IsModuleTopology.toContinuousSMul' in witness['solution_witness'])
check('only differing fully applied continuity witness',' '.join(x.replace(witness['challenge_witness'],'WITNESS').split())==' '.join(y.replace(witness['solution_witness'],'WITNESS').split()))
jout('INDEPENDENT-TYPE-COMPARISON.json',comparison)
for name in ['Topology/Algebra/MulAction.lean','Topology/Algebra/Monoid.lean','Topology/Algebra/Module/ModuleTopology.lean']:
 rel='Mathlib/'+name
 p=subprocess.run(['git','show','0df444a360eaa60ab8c11dca51a86af692955474:'+rel],cwd=L/'.lake/packages/mathlib',capture_output=True,check=False)
 check('pinned Mathlib read '+rel,p.returncode==0 and p.stdout==(L/'.lake/packages/mathlib'/rel).read_bytes())
 put('pinned-mathlib/'+rel,p.stdout)
expr=Path('/Users/georgestepaniants/.elan/toolchains/leanprover--lean4---v4.33.1/src/lean/Lean/Expr.lean').read_bytes()
put('pinned-lean-4.33.1/Expr.lean',expr)
check('Lean BEq Expr is alpha-equivalence',b'Return true iff `a` and `b` are alpha equivalent.' in expr and b'instance : BEq Expr where\n  beq := Expr.eqv' in expr)
check('ContinuousSMul is proposition',b'Prop where' in (R/'pinned-mathlib/Mathlib/Topology/Algebra/MulAction.lean').read_bytes())
# Capture the proposed repair only; approval of repaired code awaits actual
# completed full201 and new type diagnostics and belongs in a new packet.
old=B/'NM04-local187-source-snapshot/NLA/NM04/AnalyticBasics.lean';new=B/'next-proofs/NM-04/NLA/NM04/AnalyticBasics.lean'
put('proposed-repair/AnalyticBasics-before.lean.txt',old.read_bytes());put('proposed-repair/AnalyticBasics-after.lean.txt',new.read_bytes())
put('proposed-repair/diff.patch',''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile='approved187',tofile='proposed201')))
jout('CHECKS.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pass':True,'checks':checks,'scope':'Failure evidence and independent local199 type-dump diagnosis; no accepted Linux result or repaired-source approval','reviewer_Lean_Lake_Comparator_runs':0})
print(json.dumps({'pass':True,'checks':len(checks),'actual_Linux_result':'failure','cause':'C04 implicit ContinuousSMul proof expression differs','other34_binder_normalized_types_match':True,'reviewer_compiler_runs':0}))
