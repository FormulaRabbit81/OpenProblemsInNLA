#!/usr/bin/env python3
"""Read-only evidence consistency checks; never runs Lean or Comparator.

This checks the scope and bytes of the independent review packet. A pass is
not a mathematical proof or a compiler/kernel/sandbox verification result.
"""
from pathlib import Path
import hashlib
import json
import re


BASE = Path(__file__).resolve().parent
checks = 0


def check(predicate, description):
    global checks
    if not predicate:
        raise AssertionError(description)
    checks += 1


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def main():
    manifest = read_json(BASE / "MANIFEST.json")
    for relative, expected in manifest["files"].items():
        file = BASE / relative
        check(file.is_file(), f"present: {relative}")
        check(digest(file) == expected, f"hash: {relative}")
    check(set(manifest["files"]) == {
        str(file.relative_to(BASE)) for file in BASE.rglob("*")
        if file.is_file() and file.name != "MANIFEST.json"
    } | {
        str(file.relative_to(BASE)) for file in BASE.rglob("MANIFEST.json")
        if file != BASE / "MANIFEST.json"
    }, "all payload files are sealed")
    snapshot = BASE / "evidence/baseline178"
    check(digest(snapshot / "MANIFEST.json") ==
          "937e72f3e814fd95461e59c9bd45d2a99008ffe0f70e7cb28cbb84d267b63209",
          "original review handoff manifest")
    original = read_json(snapshot / "MANIFEST.json")
    check(len(original["files"]) == 52, "all original payloads")
    for relative, expected in original["files"].items():
        check(digest(snapshot / relative) == expected, f"original {relative}")
    configuration = read_json(snapshot / "comparator.json")
    headers = read_json(snapshot / "STATEMENT-HEADERS.json")["headers"]
    reviews = read_json(BASE / "CONTRACT-REVIEW.json")
    check(len(headers) == len(reviews) == 35, "35 independently reviewed contracts")
    check(configuration["theorem_names"] == [h["name"] for h in headers],
          "configured contracts exactly match statement list")
    check(configuration["definition_names"] == [], "no definition holes")
    check(set(configuration["permitted_axioms"]) ==
          {"propext", "Quot.sound", "Classical.choice"}, "permitted standard axioms")
    for header, review in zip(headers, reviews):
        check(header["name"] == review["name"], "contract-review correspondence")
        check(hashlib.sha256(header["header"].encode()).hexdigest() ==
              header["header_sha256"], "frozen statement-header hash")
        module = snapshot / (review["proof_module"].replace(".", "/") + ".lean")
        check(digest(module) == review["source178_proof_sha256"], "reviewed module bytes")
        short_name = header["name"].split(".")[-1]
        actual = re.search(r"^theorem " + re.escape(short_name) +
                           r"\b[\s\S]*?(?= := by)", module.read_text(), re.M)
        check(actual is not None and actual.group(0).strip() == header["header"],
              "literal implementation header matches independent frozen statement")
        check(bool(review["reasoning"]), "substantive per-contract reasoning retained")
    modules = {str(p.relative_to(snapshot))[:-5].replace("/", "."): p
               for p in snapshot.rglob("*.lean")}
    closure = set()

    def visit(module):
        if module in closure:
            return
        closure.add(module)
        for imported in re.findall(r"^import\s+(\S+)", modules[module].read_text(), re.M):
            if imported in modules:
                visit(imported)

    visit("Solution")
    check(len(closure) == 36, "observed incomplete baseline178 import closure")
    check("NLA.NM04.TransitionEntries" not in closure, "F01 is genuine in baseline178")
    check("Challenge" not in closure, "Challenge placeholders are outside proof closure")
    for name, module in modules.items():
        if name != "Challenge":
            check(not re.search(r"\b(sorry|admit|axiom|unsafe|native_decide|implemented_by|extern)\b",
                                module.read_text()), f"source safety scan: {name}")
    local = read_json(BASE / "evidence/root-local178-incomplete/RECEIPT.json")
    check(local["threads"] == 1 and local["memory_cap_mib"] == 4096 and
          local["max_compiler_processes"] == 1, "observed root local178 resource limits")
    failed = [c for c in local["commands"] if c.get("exit_code", 0) != 0]
    check(any(c["module"] == "NLA.NM04.MinorRaising" for c in failed),
          "incomplete actual178 explicitly retained as failed, never approved")
    for command in local["commands"]:
        if "log_sha256" in command:
            path = BASE / "evidence/root-local178-incomplete" / (command["module"] + ".log")
            check(digest(path) == command["log_sha256"], "retained original root log hash")
    exact = read_json(BASE / "evidence/exact-checks.stdout.json")
    actual = read_json(BASE / "evidence/EXACT-CHECK-RUN.json")
    check(exact["total_cases"] == 27 and exact["principal_subsets_checked"] == 282,
          "finite rational scope is exact")
    check(exact["all_passed"] and not exact["Lean_run"] and not exact["Comparator_run"],
          "finite checks are not reported as Lean or Comparator")
    check(actual["exit_code"] == 0, "actual bounded Python check exit")
    check(digest(BASE / "independent_exact_checks.py") == actual["script_sha256"],
          "actual bounded Python checker bytes")
    check(digest(BASE / "evidence/exact-checks.stdout.json") == actual["stdout_sha256"],
          "actual bounded Python output bytes")
    check(digest(BASE / "evidence/exact-checks.stderr.txt") == actual["stderr_sha256"],
          "actual bounded Python stderr bytes")
    verdict = read_json(BASE / "VERDICT.json")
    check(verdict["verdict"] == "request_changes_pending_final_source_and_local_success",
          "no premature approval")
    check(verdict["reviewer"] == "/root/nm04_full_referee1" and verdict["nonauthor"],
          "reviewer scope recorded")
    check(not verdict["reviewer_executed_Lean"] and not verdict["reviewer_executed_Comparator"]
          and not verdict["full_target_accepted"] and verdict["completed_target_count_change"] == 0,
          "verification and count claims stay within actual evidence")
    print(json.dumps({"result": "PASS", "checks": checks,
                      "scope": "read-only packet consistency; provisional nonauthor review",
                      "Lean_run": False, "Comparator_run": False,
                      "full_target_accepted": False}, indent=2))


if __name__ == "__main__":
    main()
