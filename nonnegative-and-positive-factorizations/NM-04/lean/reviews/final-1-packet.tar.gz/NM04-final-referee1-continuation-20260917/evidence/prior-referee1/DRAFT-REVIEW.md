# NM-04 independent full review — provisional source178 findings

Reviewer: `/root/nm04_full_referee1`, an independent Codex agent. I did not
author any NM-04 mathematical proof, statement, Lean proof body, helper,
source repair, or compiler harness. Suggested changes below are review
findings, not authored implementation. This is an agent review, not external
human peer review or a formal verification result.

The reviewed immutable snapshot is `NM04-full-review-source178`, manifest
SHA256 `937e72f3e814fd95461e59c9bd45d2a99008ffe0f70e7cb28cbb84d267b63209`.
I checked all 52 manifest payload hashes, retained a byte-for-byte copy in
`evidence/baseline178`, and read the canonical README, the full Colbrook TeX
manuscript, all 36 local NLA modules, Solution, all 35 Challenge statements,
the definition boundary, Comparator configuration and six pinned Tau Ceti
guidance files. Statements and sources were read substantively, not approved
solely from hashes or grep output.

**Current verdict: not yet approved.** The mathematics appears faithful and
complete, but final source changes and successful full local compilation
must be inspected before sealing final approval. No Lean, Lake, Comparator,
kernel-export or GitHub check was run by this reviewer. Root's local178 was
still incomplete at the review handoff; none of its partial successes is
being counted as a complete target.

## Findings requiring continuation

1. **F01 — incomplete export closure.** Solution imports only Canonical.
   Following every local import recursively reaches 36 local modules, but
   not TransitionEntries. Thus the six C13–C18 theorem names printed and
   asserted in Solution are absent from that environment. Import
   TransitionEntries explicitly or add another justified dependency edge.
   Root has been notified; this is an actual source/export blocker, not a
   flaw in the six theorem proofs.
2. **F02 — duplicate decision transport.** TransitionEntries contains
   `support_decision_transport`, `column_coefficient_all_decisions` and
   `row_coefficient_all_decisions`. ColumnExchangeIndices duplicates the
   first two as `columnSupport_all_decisions` and
   `columnCoefficient_all_decisions`. WeightedTransition duplicates the
   same support transport as `support_cast` and zero-specializes the two
   coefficient transports as `column_all_decisions`/`row_all_decisions`.
   Consolidate these exact subsingleton transports in a shared module;
   retain the literal finite enumerations and frozen public statements.
3. **F03 — duplicate ordered transports.** CofactorSigned's private
   `minor_eq_ordered_det` and MinorTranspose's public `minor_ordered_det`
   have the same proposition and `subst n; rfl` proof. BorderOrder's
   `position_ordered_card` and CofactorSigned's `position_ordered` are
   likewise identical extensions of C11 to a named cardinality. Put one
   canonical version of each in MinorBasics and reuse it.
4. **F04 — document wrapper changes.** WeightedExpansion, RankOneBordered,
   SchurBordered and several minor-index modules use `change` across
   matrix/function, `Fin.cons`/`Fin.snoc`, subtype or finite-sum wrappers.
   The mathematics is valid, but precise local comments should explain
   the intended bridge where a named rewrite is unavailable. This applies
   the Tau Ceti proof-quality rubric, not a blanket ban on automation.
5. **F05 — retained frozen hypothesis.** WeightedTransition's C30 retains
   `hn : 1 ≤ n` from the frozen contract even though the algebraic proof
   needs only `hm`. Explain this scope choice and remove the pointless
   `clear hn`; do not suppress linting or silently alter the frozen type.

## Mathematical assessment

The final target is exactly the original Rowland–Wu coefficient identity for
every strictly positive real m-by-n matrix, with m,n≥1. It is not replaced by
an algebraic-degree bound, a generic-input result, a fixed-size calculation,
or a theorem assuming a Sinkhorn oracle. `sinkhorn` is a total choice whose
zero fallback is excluded by an actual internally proved scaling-existence
theorem. Actual matrix uniqueness proves fidelity to the README's explicit
equivalent definition. Alternating-normalization convergence is not claimed.

The analytic proof minimizes the explicit log-partition potential on the
mean-zero hyperplane. Its derivative is proved from exp/log chain rules and
positive row partitions. A maximal coordinate and positivity give coercivity;
compact sublevels give an attained global minimum. The actual column
imbalance sums to zero, so using it as a permitted direction makes its sum
of squares vanish at the minimum. Exponential column factors and reciprocal
positive row partitions produce the required row sums 1 and column sums m/n.
The uniqueness proof compares maximal column factors and forces equality in
positive weighted row/column sums; it leaves the genuine scalar factor gauge
unrestricted. All these prerequisites are proved rather than fields of a
structure supplied by the caller.

Minor indices are equal-cardinality actual finite subsets, sorted by the
existing order embedding. Tail indices are exactly original labels 2,…,m
and 2,…,n in zero-based Fin notation. One-based position counts are checked
against that enumeration. The H matrix uses integer subtraction, the four
literal disjoint singleton-support cases, and weights m,−n,m,n. Unsupported
entries vanish. Signs agree with the canonical page, including lowering's
extra minus sign, exchanged-column positions and exchanged-row positions.

The cofactor form is an explicit polynomial sum of actual adjugate entries.
Cramer's identity, sorted deletion and universal alternating multilinearity
give the four minor identities. The rank-one update and bordered determinant
formula are proved over arbitrary commutative rings without dividing by a
minor. The raising case orders an appended row and column through explicit
finite permutations, cancels their common constant sign, and discards only
borders with repeated selected rows or columns. The empty-minor raising case
therefore remains the identity 0 = sum(T) − sum(T), not an omitted case.

Only the positive distinguished entry is inverted in the Schur argument.
The exact Schur margins yield the master minor relation. Cardinality weights
change the raising coefficient m to n and the lowering coefficient −n to −m.
The empty coordinate of the null vector is 1. Diagonal covariance gives a
null vector for the original unbalanced input with strictly positive empty
coordinate, preventing a vacuous zero witness. The general weighted
principal-minor expansion is valid for zero diagonal factors and an empty
index type. Its final specialization has det(m⁻¹ H_E), both specified minor
products, and precisely x^|E|.

For m=1 or n=1 the tail minor index contains only the empty pair; H is the
single value −mn, Δ=Γ=a11, and x=1/n. The identity is a11(1−nx)=0. For m=n=1
this becomes a11(1−1)=0. Positive rank-one inputs and other singular minors
are covered universally because no determinant cancellation is used.

LeanCert is used in kernel mode for 0<1/2<1, and both bounds are actually
consumed by coercivity/minimization. The remaining argument is symbolic;
there is no interval subdivision by matrix dimension, no numerical Sinkhorn
iteration, and no numerical determinant enumeration inside the Lean proof.

## Reuse, generality and attribution

Pinned Mathlib inspected at commit
`0df444a360eaa60ab8c11dca51a86af692955474`. Retained search commands and raw
outputs cover scaling/Sinkhorn names and descriptions, sorted finite-set
enumerations, alternating/multilinear expansion, adjugates/Cramer,
determinant updates, principal minors, determinant scaling, minima and
Fermat's theorem. In particular SchurComplement's
`det_add_replicateCol_mul_replicateRow` requires `IsUnit A.det` and explicitly
lists the universal adjugate form as a TODO. It does not replace this proof's
universal singular/empty-minor identity. Existing APIs genuinely reused
include `adjugate_fin_succ_eq_det_submatrix`, `cramer_eq_adjugate_mulVec`,
`det_piecewise_one_eq_submatrix_det`, `map_add_eq_map_add_linearDeriv_add`,
`det_fromBlocks_one₂₂`, `det_fromBlocks₁₁`, `det_updateCol_eq_zero`,
`det_mul_row`, `det_mul_column`, `orderEmbOfFin_unique`, finite permutation
signs, `IsCompact.exists_isMinOn` and `IsLocalMin.hasDerivAt_eq_zero`.

The core algebra is at the natural arbitrary commutative-ring level; real
positivity is used only for analytic scaling and the distinguished pivot.
The row-exchange proof properly reuses column exchange via transposition.
The exceptions to clean reuse are the exact duplicates F02–F03 above.

Code consistently credits George Stepaniants's formalization contribution,
Department of Computing and Mathematical Sciences, California Institute of
Technology; Rowland and Wu's question; and Matthew J. Colbrook's solution.
The original source attribution is preserved. The author's mathematics is
not reassigned to the formalizer. No George Stepaniants email occurs in the
reviewed Lean code. Colbrook's existing source contains his own original
contact information; that is not the user's email and was not edited here.

## Supplementary independent finite checks

I actually ran `python3 independent_exact_checks.py`, using only standard
Python rational arithmetic. Its literal H definition was transcribed from
the catalog, and determinants use elimination rather than the Lean
cofactor/Schur route. All 27 cases over 1≤m,n≤3 passed, including positive
rank-one matrices, vanishing minors, nontrivial balanced perturbations and
nontrivial diagonal unscalings. All 282 principal subsets were evaluated.
The exact commands, timestamps, script hash and raw output are retained.
These bounded checks are counterexample searches only; they neither prove
the universal theorem nor certify a Lean or Comparator run.

This draft must be continued against the final compiled source before a
final approval or target-count change is justified. Public packaging,
formalization.yaml, exact published commits, GitHub Comparator runs and PR
status are outside this provisional source review and require separate
evidence.
