#!/usr/bin/env python3
"""Read-only verification of this independent NM-04 source-review evidence.

No Lean, Lake, Comparator, shell, network, subprocess, or mathematical
counterexample search is executed here. This checks retained file hashes,
the reviewed import closure and exact contract text, original root compiler
receipts/logs, reuse provenance, and the stated scope of this review. Logs
are evidence of the coordinator's runs; consistency cannot make them an
independent compiler rerun or an unforgeable attestation.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re

BASE = Path(__file__).resolve().parent
LOCAL_ROOT = Path('/private/tmp/nla-lean-local-shared-20260916')
checks = 0


def check(condition, message):
    global checks
    if not condition:
        raise AssertionError(message)
    checks += 1


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def local_copy(path):
    return BASE / 'evidence/local' / Path(path).relative_to(LOCAL_ROOT)


def lean_text_without_comments(text):
    """Remove nested block/line comments, preserving strings and newlines.

    Used only for a conservative source scan, never as a Lean parser or a
    substitute for kernel checking. Comment187 equality is checked by the
    stronger exact line comparison that removes line-comments only.
    """
    result = []
    i = 0
    depth = 0
    quoted = False
    while i < len(text):
        if depth:
            if text.startswith('/-', i):
                depth += 1
                i += 2
            elif text.startswith('-/', i):
                depth -= 1
                i += 2
            else:
                result.append('\n' if text[i] == '\n' else ' ')
                i += 1
        elif quoted:
            result.append(text[i])
            if text[i] == '\\' and i + 1 < len(text):
                result.append(text[i + 1])
                i += 2
            else:
                if text[i] == '"':
                    quoted = False
                i += 1
        elif text.startswith('/-', i):
            result.append(' ')
            depth = 1
            i += 2
        elif text.startswith('--', i):
            i = text.find('\n', i)
            if i == -1:
                break
        else:
            quoted = text[i] == '"'
            result.append(text[i])
            i += 1
    check(depth == 0 and not quoted, 'closed comments and string literals')
    return ''.join(result)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check-current', type=Path,
                        help='Optionally compare approved source hashes with this project directory.')
    args = parser.parse_args()
    manifest = read(BASE / 'MANIFEST.json')
    actual_files = {str(p.relative_to(BASE)) for p in BASE.rglob('*')
                    if p.is_file() and p != BASE / 'MANIFEST.json'}
    check(actual_files == set(manifest['files']), 'every payload is sealed, with no extra files')
    for rel, digest in manifest['files'].items():
        check(sha(BASE / rel) == digest, 'sealed payload ' + rel)

    record = read(BASE / 'evidence/local/NM04-LOCAL-COMPLETE-187.json')
    check(sha(BASE / 'evidence/local/NM04-LOCAL-COMPLETE-187.json') ==
          'd32daefe49cde06358205c59a897a439f3af49aa8d017b31a68f8265893efa4d',
          'original coordinator local187 record')
    check(record['actual_local_closure_modules'] == 38 and record['exact_contracts'] == 35,
          'whole original target scope')
    source_hashes = record['sources']
    source_root = BASE / 'evidence/source187'
    text_by_module = {}
    for rel, digest in source_hashes.items():
        f = source_root / (rel + '.txt')
        check(sha(f) == digest, 'reviewed exact187 source ' + rel)
        if args.check_current:
            check(sha(args.check_current / rel) == digest, 'current exact187 source ' + rel)
        text_by_module[rel[:-5].replace('/', '.')] = f.read_text()
    imports = {m: re.findall(r'^import\s+(\S+)', text, re.M)
               for m, text in text_by_module.items()}
    closures = {}

    def closure(module):
        if module not in closures:
            closures[module] = {module}
            for dep in imports[module]:
                check(dep != 'Challenge', 'Challenge is outside every proof import')
                if dep.startswith('NLA.'):
                    check(dep in text_by_module, 'local dependency is retained')
                    closures[module] |= closure(dep)
        return closures[module]

    check(closure('Solution') == set(text_by_module), 'complete 38-module Solution closure')
    check('NLA.NM04.TransitionEntries' in closure('Solution'), 'F01 explicit export closure fixed')
    for module, text in text_by_module.items():
        cleaned = lean_text_without_comments(text)
        check(not re.search(r'\b(sorry|admit|axiom|unsafe|native_decide|implemented_by|extern)\b',
                            cleaned), 'no proof escape or hole ' + module)

    frozen = read(BASE / 'evidence/package184/STATEMENT-FREEZE.json')
    cfg = read(BASE / 'evidence/package184/comparator.json')
    headers = read(BASE / 'evidence/package184/STATEMENT-HEADERS.json')['headers']
    reviews = read(BASE / 'CONTRACT-REVIEW.json')
    challenge = (BASE / 'evidence/package184/Challenge.lean.txt').read_text()
    check(len(headers) == len(reviews) == 35, 'all contracts independently reviewed')
    check(cfg['theorem_names'] == [h['name'] for h in headers], 'exact Comparator contract list')
    permitted = {'propext', 'Classical.choice', 'Quot.sound'}
    check(cfg['definition_names'] == [] and set(cfg['permitted_axioms']) == permitted,
          'no definition holes or extra permitted axioms')
    for rel, digest in frozen['source_sha256'].items():
        file = (source_root / (rel + '.txt') if rel in source_hashes else
                BASE / 'evidence/package184' / (rel + '.txt' if rel.endswith('.lean') else rel))
        check(sha(file) == digest, 'frozen boundary unchanged: ' + rel)
    for h, review in zip(headers, reviews):
        name = h['name'].split('.')[-1]
        pattern = r'^theorem\s+' + re.escape(name) + r'\b[\s\S]*?(?=\s*:=\s*by)'
        expected = re.search(pattern, challenge, re.M)
        actual = [match.group().strip() for text in text_by_module.values()
                  if (match := re.search(pattern, text, re.M))]
        check(expected is not None and actual == [expected.group().strip()] == [h['header']],
              'literal frozen Challenge and implementation type: ' + name)
        check(hashlib.sha256(h['header'].encode()).hexdigest() == h['header_sha256'],
              'frozen header digest ' + name)
        check(review['name'] == h['name'] and review['header_sha256'] == h['header_sha256']
              and review['source_sha256'] == source_hashes[review['source']]
              and len(review['reasoning']) > 90, 'substantive exact-source review ' + name)
    proof_export = text_by_module['Solution']
    check(re.findall(r'^#print axioms (\S+)$', proof_export, re.M) == cfg['theorem_names'],
          'all original exports have axiom reports')
    check(re.findall(r'^#assert_trust kernel (\S+)$', proof_export, re.M) == cfg['theorem_names'],
          'all original exports assert kernel trust')

    for original_path, digest in record['retained_original_evidence'].items():
        check(sha(local_copy(original_path)) == digest, 'original retained receipt or log')
    receipt = read(local_copy(record['receipt']))
    check(sha(local_copy(record['receipt'])) == record['receipt_sha256'], 'final receipt hash')
    check(receipt.get('end') and not receipt['failed_modules'] and not receipt['blocked_modules']
          and receipt['completed_modules'] == 38, 'actual final187 root result is terminal success')
    check(sha(BASE / 'evidence/local/ASSEMBLY-187.json') == receipt['assembly_sha256']
          == record['assembly_sha256'], 'actual assembled source set bound to root run')
    check(sha(BASE / 'evidence/local/serial_compile_v3.py') == receipt['runner_sha256'],
          'reviewed serial compiler driver matches run')
    environment = read(BASE / 'evidence/local/LOCAL-ENVIRONMENT.json')
    packages = {p['package']: p['commit'] for p in environment['dependencies']}
    check(packages['mathlib'] == '0df444a360eaa60ab8c11dca51a86af692955474' and
          packages['leancert'] == '621a43d7cf21f87872392a01e874f2f1dbddc926', 'pinned primary dependencies')
    check(sum(c.get('exit_code') == 0 for c in receipt['commands']) == 7 and
          sum(c.get('status') == 'reused_exact_successful_local_output' for c in receipt['commands']) == 31,
          'seven fresh successes distinguished from 31 exact reused outputs')

    originals = record['commands_and_successful_origins']
    check({c['module'] for c in originals} == set(text_by_module), 'every module has successful provenance')
    for origin in originals:
        module = origin['module']
        rel = module.replace('.', '/') + '.lean'
        origin_command = origin['command']
        for index, hop in enumerate(origin['reuse_chain']):
            file = local_copy(hop['receipt'])
            check(sha(file) == hop['sha256'], 'reuse receipt authenticated')
            node = read(file)
            check(node.get('end') and node['platform'] == 'darwin' and node['threads'] == 1
                  and node['memory_cap_mib'] == 4096 and node['max_compiler_processes'] == 1,
                  'actual local receipt records required resource limits')
            commands = [c for c in node['commands'] if c['module'] == module]
            check(len(commands) == 1, 'unique command for module in receipt')
            command = commands[0]
            check(command['source_sha256'] == source_hashes[rel]
                  and command['output_sha256'] == origin_command['output_sha256'],
                  'source and output binding through reuse chain')
            for dep in closure(module):
                dep_rel = dep.replace('.', '/') + '.lean'
                check(node['source_inputs'][dep_rel] == source_hashes[dep_rel],
                      'transitive local source binding through reuse chain')
            if index + 1 < len(origin['reuse_chain']):
                check(command['status'] == 'reused_exact_successful_local_output', 'reuse hop status')
                next_hop = origin['reuse_chain'][index + 1]
                if 'prior_receipt' in command:
                    check(command['prior_receipt'] == next_hop['receipt']
                          and command['prior_receipt_sha256'] == next_hop['sha256'],
                          'actual prior receipt link')
                else:
                    next_node = read(local_copy(next_hop['receipt']))
                    check(command['prior_command'] in next_node['commands'], 'legacy embedded prior command')
            else:
                check(command == origin_command and command['exit_code'] == 0,
                      'chain ends at actual retained successful command')
                check('--threads=1' in command['argv'] and '--memory=4096' in command['argv']
                      and command['argv'][0] == environment['compiler'], 'actual bounded Lean argv')
                log = file.parent / (module + '.log')
                check(sha(log) == command['log_sha256'] and 'error:' not in log.read_text(),
                      'successful original log binding')

    final_log = local_copy(record['receipt']).parent / 'Solution.log'
    observations = re.findall(r"^'([^']+)' depends on axioms: \[([^]]*)\]$",
                              final_log.read_text(), re.M)
    check([name for name, _ in observations] == cfg['theorem_names'], 'final log covers every original contract')
    for name, axiom_text in observations:
        axioms = [a.strip() for a in axiom_text.split(',')]
        check(set(axioms) <= permitted and axioms == record['observed_axioms'][name],
              'no disallowed transitive axiom: ' + name)

    old = read(BASE / 'evidence/local/NM04-LOCAL-COMPLETE-184.json')
    changed = {rel for rel in source_hashes if source_hashes[rel] != old['sources'][rel]}
    check(changed == {'NLA/NM04/RankOneBordered.lean', 'NLA/NM04/SchurBordered.lean'},
          'only two comment187 source deltas')
    for rel in changed:
        before = (BASE / 'evidence/source184' / (rel + '.txt')).read_text().splitlines()
        after = (source_root / (rel + '.txt')).read_text().splitlines()
        check([x for x in before if not x.lstrip().startswith('--')] ==
              [x for x in after if not x.lstrip().startswith('--')],
              'exact non-line-comment content unchanged: ' + rel)
    for pin in read(BASE / 'evidence/reuse-search/PRIMARY-PINS.json'):
        check(sha(BASE / 'evidence/reuse-search/primary' / (pin['source_path'] + '.txt')) == pin['sha256']
              and pin['git_show_exact_match'], 'retained primary Mathlib API source')
    for pin in read(BASE / 'evidence/sources/primary/GIT-MATCHES.json'):
        check(sha(BASE / 'evidence/sources/primary' / pin['retained_file']) == pin['sha256']
              and pin['git_show_exact_match'], 'retained original canonical primary source')
    verdict = read(BASE / 'VERDICT.json')
    check(verdict['verdict'] == 'APPROVE_EXACT_SOURCE187' and verdict['nonauthor'], 'independent source approval scope')
    check(verdict['source_hashes'] == source_hashes and verdict['reviewed_contracts'] == 35,
          'approval binds complete exact source and original statement boundary')
    check(not verdict['reviewer_Lean_execution'] and not verdict['reviewer_Comparator_execution']
          and not verdict['GitHub_Comparator_for_published_commit_verified']
          and verdict['completed_target_count_change'] == 0, 'no compiler, CI or count overclaim')
    print(json.dumps({'result': 'PASS', 'checks': checks,
                      'scope': 'read-only exact-source review and retained evidence consistency',
                      'reviewed_source': 'local187', 'proof_modules': 38,
                      'original_contracts': 35, 'Lean_run_by_reviewer': False,
                      'Comparator_run_by_reviewer': False,
                      'whole_campaign_target_accepted': False}, indent=2))


if __name__ == '__main__':
    main()
