"""Read-only source/run binding and structural checks; never invokes Lean or writes candidates."""
from pathlib import Path
import json, hashlib, re, subprocess, datetime
R=Path(__file__).resolve().parent
W=Path('/private/tmp/nla-lean-next-20260915/next-proofs/NM-04')
S=W/'statement-draft-01';P=W/'precode-01'
def sha(b):return hashlib.sha256(b).hexdigest()
def record(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def checked(p,r):
 b=p.read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'],str(p)
 return record(p)
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/formal_review_standards',
 'scope':'Independent static review and read-only source/run evidence audit. No Lean process, candidate edit, Git mutation, or proof verification.',
 'author_role':'Reviewer did not author the NM-04 statements or mathematical source.'}
manifest=record(S/'MANIFEST.json')
assert manifest['sha256']=='1797fd8dc2d61041d86d231a8361fe89ac82fb7ab55b2fba5bf45f82451f2c56'
out['statement_manifest']=manifest
out['snapshot_files']=[checked(S/f['path'],f) for f in json.loads((S/'MANIFEST.json').read_text())['files']]
out['live_candidate_files']=[checked(W/f['live_path'],f) for f in json.loads((S/'STATEMENT-DRAFT.json').read_text())['files']]
out['precode_manifest']=record(P/'MANIFEST.json')
out['precode_files']=[checked(P/f['path'],f) for f in json.loads((P/'MANIFEST.json').read_text())['files']]
out['source_bindings']=record(P/'SOURCE-BINDINGS.json')
out['source_records']=[]
for r in json.loads((P/'SOURCE-BINDINGS.json').read_text())['records']:
 q=checked(P/r['path'],r)
 if 'git_commit' in r:
  got=subprocess.run(['git','show',r['git_commit']+':'+r['git_path']],cwd=r['source'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  assert got.returncode==0, got.stderr.decode()
  blob=hashlib.sha1(b'blob '+str(len(got.stdout)).encode()+b'\x00'+got.stdout).hexdigest()
  assert blob==r['git_blob'] and sha(got.stdout)==r['sha256']
  q.update({'actual_git_source_sha256':sha(got.stdout),'git_commit':r['git_commit'],'git_path':r['git_path'],'git_blob':blob})
 else:
  actual=Path(r['source'])
  if actual.is_file():
   assert sha(actual.read_bytes())==r['sha256'],str(actual)
   q['actual_source_file_sha256']=r['sha256']
  else:q['actual_source_file_available']=False
 out['source_records'].append(q)
# Drop nested block and line comments for a limited lexical structural check.
def code_only(s):
 out=[];i=0;depth=0
 while i<len(s):
  if depth:
   if s.startswith('/-',i):depth+=1;i+=2
   elif s.startswith('-/',i):depth-=1;i+=2
   else:i+=1
  elif s.startswith('/-',i):depth=1;i+=2
  elif s.startswith('--',i):
   j=s.find('\n',i);i=len(s) if j<0 else j
  else:out.append(s[i]);i+=1
 assert depth==0
 return ''.join(out)
d=code_only((S/'inputs/NLA/NM04/Definitions.lean.txt').read_text())
c=code_only((S/'inputs/Challenge.lean.txt').read_text())
prohibited=r'\b(?:axiom|unsafe|implemented_by|extern|native_decide|admit|sorryAx|ofReduceBool)\b'
assert not re.search(prohibited,d+'\n'+c)
assert len(re.findall(r'\bsorry\b',d))==0 and len(re.findall(r'\bsorry\b',c))==35
names=re.findall(r'^theorem\s+(\w+)',c,re.M)
co=json.loads((S/'inputs/comparator.json').read_text())
assert len(names)==35 and len(set(names))==35
assert ['NLA.NM04.'+n for n in names]==co['theorem_names']
assert co['definition_names']==[]
assert co['permitted_axioms']==['propext','Quot.sound','Classical.choice']
assert not list(W.glob('Solution.lean')) and not list(W.glob('NLA/NM04/Proof.lean'))
out['structure']={'theorems':names,'comparator_exact_order_match':True,'definition_exceptions':[],
 'allowed_axioms':co['permitted_axioms'],'definitions_holes':0,'challenge_holes':35,
 'prohibited_tokens_in_comment_stripped_sources':[],
 'scope':'Lexical checks are supplemental; complete mathematical definitions/contracts were read. This is not an elaborated dependency or kernel-axiom audit.'}
# Retain root's small original run receipt/logs, with explicit attribution.
root=Path('/private/tmp/nla-lean-next-20260915/NM04-STATEMENT-ELABORATION-124.json')
rr=json.loads(root.read_text())
assert sha(root.read_bytes())=='7741eeafc06310f2909ee73879137c32377fa572715e098dc0b9226e792b6c04'
receipt=Path(rr['receipt']);rb=receipt.read_bytes();assert sha(rb)==rr['receipt_sha256']
rc=json.loads(rb)
assert rc['max_compiler_processes']==1 and rc['threads']==1 and rc['memory_cap_mib']==4096
run=receipt.parent
(R/'coordinator-run124').mkdir(exist_ok=True)
(R/'coordinator-run124/ROOT-STATEMENT-ELABORATION.json').write_bytes(root.read_bytes())
(R/'coordinator-run124/RECEIPT.json').write_bytes(rb)
out['coordinator_run']={'scope':'Root executed these local macOS statement checks. Reviewer independently read and hash-checked the retained receipt and complete raw logs but did not execute Lean.',
 'receipt':record(receipt),'root_record':record(root),'checks':[]}
for x in rr['command']:
 lp=run/(x['module']+'.log');lb=lp.read_bytes()
 assert sha(lb)==x['log_sha256'] and x['exit_code']==0
 expected='8f55d605dcd56160feede340a7cb03734be0e04085b4d4bfd30f4d36cede7c6a' if x['module']=='NLA.NM04.Definitions' else '2e47866aef26d75e14fecc6f569f8c1c7a2812f2bfbd0e47b0c8277ecffc81cc'
 assert x['source_sha256']==expected
 warnings=len(re.findall(r'warning:',lb.decode()))
 assert warnings==(0 if x['module']=='NLA.NM04.Definitions' else 35)
 (R/'coordinator-run124'/lp.name).write_bytes(lb)
 out['coordinator_run']['checks'].append({'module':x['module'],'source_sha256':expected,'log':record(lp),'warnings':warnings,'exit_code':0,'argv':x['argv'],'elapsed_seconds':x['elapsed_seconds']})
out['verdict']='PASS'
(R/'BINDINGS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'verdict':'PASS','snapshot_files':len(out['snapshot_files']),'live_files':len(out['live_candidate_files']),
 'precode_files':len(out['precode_files']),'source_records':len(out['source_records']),
 'actual_git_blobs':sum('git_blob' in x for x in out['source_records']),'theorems':len(names),
 'root_run_receipt_and_raw_logs_checked':True,'reviewer_lean_execution':False},sort_keys=True))
