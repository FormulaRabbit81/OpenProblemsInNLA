"""Independent finite rational convention checks; not a Lean proof or universal certificate."""
from fractions import Fraction as Q
from itertools import combinations, product
from collections import Counter
import json, time
from pathlib import Path

checks = Counter()
start = time.monotonic()
def check(label, lhs, rhs=True):
    checks[label] += 1
    assert lhs == rhs, (label, lhs, rhs)
def det(A):
    n = len(A)
    assert all(len(r) == n for r in A)
    B = [[Q(x) for x in r] for r in A]
    out = Q(1)
    for j in range(n):
        p = next((i for i in range(j,n) if B[i][j]), None)
        if p is None:
            return Q(0)
        if p != j:
            B[p], B[j] = B[j], B[p]
            out = -out
        v = B[j][j]
        out *= v
        for i in range(j+1,n):
            f = B[i][j]/v
            for k in range(j+1,n): B[i][k] -= f*B[j][k]
    return out

def sub(A,R,C): return [[A[i][j] for j in C] for i in R]
def minor(A,I): return det(sub(A,*I))
def ids(r,c):
    return [(R,C) for k in range(min(r,c)+1)
            for R in combinations(range(r),k) for C in combinations(range(c),k)]
def pos(i,R): return 1 + sum(j < i for j in R)
def cf(T,I,Z):
    R,C = I
    return sum(((-1)**(pos(i,R)+pos(j,C)) * Z[i][j]
                * minor(T,(tuple(x for x in R if x!=i),tuple(y for y in C if y!=j)))
                for i in R for j in C), Q(0))
def coeff(I,J):
    R,C = map(set,I); P,D = map(set,J)
    rm,ra,cm,ca = R-P,P-R,C-D,D-C
    nonzero=[]
    if not rm and len(ra)==1 and not cm and len(ca)==1:
        s,t=next(iter(ra)),next(iter(ca)); nonzero.append((0,(-1)**(pos(s,J[0])+pos(t,J[1]))))
    if len(rm)==1 and not ra and len(cm)==1 and not ca:
        s,t=next(iter(rm)),next(iter(cm)); nonzero.append((1,(-1)**(pos(s,I[0])+pos(t,I[1]))))
    if not rm and not ra and len(cm)==1 and len(ca)==1:
        s,t=next(iter(cm)),next(iter(ca)); nonzero.append((2,(-1)**(pos(s,I[1])+pos(t,J[1]))))
    if len(rm)==1 and len(ra)==1 and not cm and not ca:
        s,t=next(iter(rm)),next(iter(ra)); nonzero.append((3,(-1)**(pos(s,I[0])+pos(t,J[0]))))
    check('support_cases_disjoint',len(nonzero)<=1)
    out=[0]*4
    for k,v in nonzero: out[k]=v
    return out

def ops(D,f,I):
    return [sum((coeff(I,J)[a]*f[J] for J in D),Q(0)) for a in range(4)]
def H(m,n,D):
    return [[len(I[0])*(m+n)-m*n if I==J else
             sum(a*b for a,b in zip([m,-n,m,n],coeff(I,J)))
             for J in D] for I in D]
def mv(A,v): return [sum((a*b for a,b in zip(r,v)),Q(0)) for r in A]
def pencil(m,n,D,A,z):
    tail=[r[1:] for r in A[1:]]
    delta={I:minor(A,((0,)+tuple(i+1 for i in I[0]),(0,)+tuple(j+1 for j in I[1]))) for I in D}
    gamma={I:A[0][0]*minor(tail,I) for I in D}
    K=[[int(i==j)*gamma[I]+Q(z,m)*H(m,n,D)[i][j]*delta[J]
        for j,J in enumerate(D)] for i,I in enumerate(D)]
    return delta,gamma,K

generic_shapes=[]
for r,c in [(0,0),(0,2),(2,0),(1,1),(1,3),(3,1),(2,2),(2,3),(3,2),(3,3)]:
    D=ids(r,c)
    families=[[[Q(0) for j in range(c)] for i in range(r)],
              [[Q((i+1)*(j+2)) for j in range(c)] for i in range(r)],
              [[Q(((i+1)*7+(j+1)*3+i*j*5)%11-5) for j in range(c)] for i in range(r)]]
    generic_shapes.append({'rows':r,'columns':c,'minor_indices':len(D),'matrices':len(families)})
    for T in families:
        f={I:minor(T,I) for I in D}
        rs=[sum(row,Q(0)) for row in T]
        cs=[sum((T[i][j] for i in range(r)),Q(0)) for j in range(c)]
        u=[Q(2*i-1,3) for i in range(r)];v=[Q(j+2,5) for j in range(c)];z=Q(-7,4)
        Z=[[u[i]*v[j] for j in range(c)] for i in range(r)]
        updated=[[T[i][j]+z*Z[i][j] for j in range(c)] for i in range(r)]
        for I in D:
            k=len(I[0]); U,L,C,R=ops(D,f,I)
            check('rank_one_update',minor(updated,I),f[I]+z*cf(T,I,Z))
            check('lowering_identity',cf(T,I,[[Q(1) for j in range(c)] for i in range(r)]),L)
            check('column_exchange_identity',cf(T,I,[[rs[i] for j in range(c)] for i in range(r)]),k*f[I]+C)
            check('row_exchange_identity',cf(T,I,[[cs[j] for j in range(c)] for i in range(r)]),k*f[I]+R)
            check('raising_identity',cf(T,I,[[rs[i]*cs[j] for j in range(c)] for i in range(r)]),sum(rs,Q(0))*f[I]-U)
            V=sub(T,*I); a=[Q(i+2,3) for i in range(k)];b=[Q(2-i,5) for i in range(k)];d=Q(7,4)
            # Adjugate entry (i,j) is cofactor (j,i), computed directly.
            adj=[[(-1)**(i+j)*det([[V[s][t] for t in range(k) if t!=i] for s in range(k) if s!=j])
                  for j in range(k)] for i in range(k)]
            lhs=sum((a[i]*sum((adj[i][j]*b[j] for j in range(k)),Q(0)) for i in range(k)),Q(0))
            border=[V[i]+[b[i]] for i in range(k)]+[a+[d]]
            check('bordered_determinant',lhs,d*det(V)-det(border))

balanced_cases=[]
for m,n in [(1,1),(1,3),(3,1),(2,2),(2,3),(3,2),(3,3)]:
    for perturb in [False,True]:
        S=[[Q(1,n) for j in range(n)] for i in range(m)]
        if perturb and m>1 and n>1:
            for i in range(m-1):
                for j in range(n-1):
                    e=Q(1,100*m*n*(i+j+1))
                    S[i][j]+=e;S[i+1][j+1]+=e;S[i+1][j]-=e;S[i][j+1]-=e
        check('positive_balanced_entries',all(x>0 for row in S for x in row))
        check('balanced_rows',[sum(row,Q(0)) for row in S],[Q(1)]*m)
        check('balanced_columns',[sum((S[i][j] for i in range(m)),Q(0)) for j in range(n)],[Q(m,n)]*n)
        D=ids(m-1,n-1);x=S[0][0];rho=Q(m,n)
        T=[[S[i+1][j+1]-S[i+1][0]*S[0][j+1]/x for j in range(n-1)] for i in range(m-1)]
        check('schur_row_margins',[sum(row,Q(0)) for row in T],[1-S[i+1][0]/x for i in range(m-1)])
        check('schur_column_margins',[sum((T[i][j] for i in range(m-1)),Q(0)) for j in range(n-1)],
              [rho*(1-S[0][j+1]/x) for j in range(n-1)])
        check('schur_total_margin',sum((sum(row,Q(0)) for row in T),Q(0)),m-rho/x)
        delta,gamma,K=pencil(m,n,D,S,x);w=[Q(n,m)**len(I[0]) for I in D]
        h=H(m,n,D);hf=mv([[h[i][j]*delta[J] for j,J in enumerate(D)] for i in range(len(D))],w)
        for i,I in enumerate(D):
            check('schur_bordered_minor',delta[I],x*minor(T,I))
            U,L,C,R=ops(D,delta,I);diag=len(I[0])*(m+n)-m*n
            total=diag*delta[I]+n*U-m*L+m*C+n*R
            check('balanced_minor_relation',m*minor([r[1:] for r in S[1:]],I)+total,Q(0))
            check('weighted_transition_action',hf[i],w[i]*total)
        check('balanced_nonzero_null_vector',mv(K,w),[Q(0)]*len(D));check('empty_weight',w[0],Q(1))
        for scale_variant in ['positive','zeros_and_negative']:
            a=[Q(i+2,3) for i in range(m)];b=[Q(j+3,2) for j in range(n)]
            if scale_variant=='zeros_and_negative':a[0]=Q(0);b[-1]=Q(-2)
            A=[[a[i]*S[i][j]*b[j] for j in range(n)] for i in range(m)]
            da,ga,ka=pencil(m,n,D,A,Q(2,3));_,_,ks=pencil(m,n,D,S,Q(2,3))
            factors=[]
            for I in D:
                f=a[0]*b[0]
                for i in I[0]: f*=a[i+1]
                for j in I[1]: f*=b[j+1]
                factors.append(f)
                check('delta_covariance',da[I],f*delta[I]);check('gamma_covariance',ga[I],f*gamma[I])
            check('pencil_covariance',ka,[[ks[i][j]*factors[j] for j in range(len(D))] for i in range(len(D))])
        # A is a nontrivial positive inverse scaling of known balanced S.
        a=[Q(i+2,3) for i in range(m)];b=[Q(j+3,2) for j in range(n)]
        A=[[S[i][j]/a[i]/b[j] for j in range(n)] for i in range(m)]
        da,ga,ka=pencil(m,n,D,A,x)
        polynomial=Q(0)
        for size in range(len(D)+1):
            for E in combinations(range(len(D)),size):
                poly_coefficient=det([[Q(h[i][j],m) for j in E] for i in E])
                term=poly_coefficient*x**size
                for i,I in enumerate(D): term*=da[I] if i in E else ga[I]
                polynomial+=term
        check('literal_full_polynomial_on_known_scaling_orbit',polynomial,Q(0))
        check('pencil_determinant_on_known_scaling_orbit',det(ka),Q(0))
        balanced_cases.append({'m':m,'n':n,'perturbation_requested':perturb,'first_entry':str(x),'index_count':len(D)})

for d in range(5):
    M=[[Q((i+1)*3-(j+1)*2+(i==j)) for j in range(d)] for i in range(d)]
    for zero_diagonal in [False,True]:
        gamma=[Q(i+2) if not zero_diagonal or i%2 else Q(0) for i in range(d)]
        delta=[Q(2-i) for i in range(d)];z=Q(-3,5)
        K=[[int(i==j)*gamma[i]+z*M[i][j]*delta[j] for j in range(d)] for i in range(d)]
        rhs=Q(0)
        for size in range(d+1):
            for E in combinations(range(d),size):
                term=det(sub(M,E,E))*z**size
                for i in range(d):term*=delta[i] if i in E else gamma[i]
                rhs+=term
        check('weighted_principal_minor_expansion',det(K),rhs)

for n in range(1,6):
    for t in product(range(-2,3),repeat=n):
        if sum(t)==0:
            check('mean_zero_sup_norm_bound',max(map(abs,t))<=n*max(t))
            check('half_coercivity_geometric_bound',Q(1,2*n)*max(map(abs,t))<=max(t))

out={'verdict':'PASS','scope':'Independent exact-rational finite sign, normalization and edge-case diagnostics only. Not a Lean proof, real exp/log proof, real sinkhorn evaluation, or universal theorem certificate.',
     'elapsed_seconds':time.monotonic()-start,'checks':dict(sorted(checks.items())),
     'total_assertions':sum(checks.values()),'generic_matrix_families':generic_shapes,'balanced_cases':balanced_cases,
     'empty_and_singular_cases_included':True,'all_arithmetic_exact':True,'lean_executed':False,
     'positive_scaling_orbits_use_known_balanced_witness_not_classical_choice_evaluation':True}
Path('DIAGNOSTIC.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'verdict':out['verdict'],'total_assertions':out['total_assertions'],'elapsed_seconds':out['elapsed_seconds'],'check_families':len(checks)},sort_keys=True))
