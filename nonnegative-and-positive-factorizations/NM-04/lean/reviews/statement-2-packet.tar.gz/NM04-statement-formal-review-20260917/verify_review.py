"""Verify sealed reviewer files and immutable reviewed source snapshots; no Lean/Git/write actions."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
m=json.loads((R/'MANIFEST.json').read_text())
expected={x['path'] for x in m['files']}
actual={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file() and p!=R/'MANIFEST.json'}
assert actual==expected,(actual-expected,expected-actual)
for x in m['files']:
 b=(R/x['path']).read_bytes()
 assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'],x['path']
b=json.loads((R/'BINDINGS.json').read_text())
inputs=[b['statement_manifest'],b['precode_manifest'],b['source_bindings']]+b['snapshot_files']+b['precode_files']
for x in inputs:
 y=Path(x['path']).read_bytes()
 assert len(y)==x['bytes'] and hashlib.sha256(y).hexdigest()==x['sha256'],x['path']
print(json.dumps({'verdict':'PASS','review_files_bound':len(m['files']),'review_files_including_outer':len(m['files'])+1,'external_immutable_records_checked':len(inputs),'lean_executed':False},sort_keys=True))
