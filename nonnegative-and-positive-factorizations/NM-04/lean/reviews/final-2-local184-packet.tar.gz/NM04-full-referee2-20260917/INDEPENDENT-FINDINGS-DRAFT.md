# NM-04 independent whole-target findings, drafted before final referee consultation

Reviewer: `/root/mf06_statement_referee2`, a nonauthor of NM-04 mathematics and
Lean sources. This reviewer has authored no NM-04 proof, definition, contract,
or repair and has not read another final proof referee's conclusions. This
document records the independent mathematical assessment before the local
compilation gate is satisfied. It is not final proof acceptance.

I read the complete numerical sheet first, all 217 lines of Definitions, all 35
Challenge contracts, the full canonical README, the complete retained Colbrook
manuscript, all 38 Lean modules including Solution from the immutable local180
snapshot, and the single-file local182 continuation. The only 180-to-182 source
delta read here adds the documented classical decision-instance convention and
refreshes a stale comment in BalancedMinor. I have not run Lean, Lake,
Comparator, the Tau Ceti CLI/service, or an independent kernel checker.

## Original-target fidelity and adversarial checks

The original target is the literal Rowland-Wu coefficient identity for every
strictly positive real m-by-n matrix and every m,n at least one. It is not just
an algebraic-degree bound, a statement for generic matrices, or a finite test.
The final theorem's coefficients are the prescribed principal minors of H/m,
multiplied by Delta on E and Gamma on its complement and the power |E| of the
actual Sinkhorn entry. No coefficient-fitting or polynomial-oracle definition
is used.

All new definitions have literal mathematical meaning: finite real matrices;
the strictly positive tail labels excluding only the distinguished first
index; all equal-cardinality finite row/column subsets; increasing row/column
enumerations; one-based positions; ordinary determinant minors; the four exact
set-difference support cases and their signed integer coefficients; the actual
matrix H, pencil and weight; explicit exp/log scaling potential and imbalance;
ordinary adjugate/cofactor form; actual diagonal scaling and Schur tail. The
definition of sinkhorn uses classical choice from positive diagonal scalings.
The fallback zero branch is excluded by the proved existence theorem under
the final hypotheses. The unique matrix property, not unique gauge factors,
is proved independently of the final identity.

The canonical README explicitly permits the equivalent unique positive
diagonal-scaling definition. Alternating-normalization convergence is therefore
not required by this chosen target and is not claimed. The manuscript's later
arbitrary-margin, exterior-power, symmetry and degree discussions are outside
these contracts; I read them but do not count them as formalized.

I specifically tested the mathematical logic at m=1, n=1, both dimensions one,
the empty index/minor, singular selected minors, rank-one positive matrices,
full selected row/column sets with no remaining raising/exchange indices,
arbitrary commutative-ring characteristic for the universal algebra, and the
scaling gauge freedom. The empty minor remains one, the empty Delta/Gamma
remain A00, the weight has empty coordinate one, and the transported null
vector has strictly positive empty coordinate. No division by a selected minor
appears. Only positive m,n, the positive distinguished pivot, positive scaling
factors and row partitions are inverted where applicable.

## Every frozen contract

| Contract | Independent proof assessment |
|---|---|
| C01 coercivity_half_certificate | Actual kernel-mode interval_decide rational half bounds; both inequalities enter C05 and positivity also enters C06. |
| C02 row_partition_positive | At least one column and positive entries/exp give the literal finite partition's positivity. |
| C03 potential_continuous | Continuous finite exponential sums and log on strictly positive partitions. |
| C04 potential_line_derivative | Chain rule computes the derivative of the actual potential along t+s d; finite sums rearrange to d dot imbalance. |
| C05 zero_mean_coercivity | Max coordinate q is nonnegative; zero sum implies sup norm at most n q. Each log partition dominates log a+q; the half certificate gives the frozen weaker bound. |
| C06 potential_attains_minimum | A finite positive entry minimum gives a uniform lower bound; the mean-zero sublevel is closed, bounded and nonempty, hence compact in this finite real product, and a true minimum is attained. |
| C07 potential_minimum_has_margins | Imbalance sums to zero. Taking the imbalance itself as the line direction gives derivative sum of squares, which vanishes at a minimum; each imbalance is zero. This improves the initial direction plan without changing the contract. |
| C08 positive_balanced_scaling_exists | Positive factors 1/rowPartition and exp t construct row-one and column-m/n margins at the proved minimizer. |
| C09 positive_balanced_scaling_unique | A maximum column factor and equality of positive weighted totals force all products of relative row/column factors to one, hence equality of matrices, leaving the correct gauge freedom. |
| C10 sinkhorn_semantics | Actual existence excludes the fallback and actual uniqueness identifies the chosen matrix; positivity follows from concrete scaling factors. |
| C11 position_sorted_semantics | Finset increasing enumeration and the count of smaller members give exactly index+1. |
| C12 empty_minor_values | Empty determinant equals one and the bordered singleton equals A00, including one-row/one-column cases. |
| C13 H_diagonal | All off-diagonal transition supports vanish on equal indices; integer diagonal has unsaturated subtraction. |
| C14 H_raising | Literal support uniqueness selects the prescribed +m one-based sign. |
| C15 H_lowering | Literal support uniqueness selects minus n times the deletion sign, equivalently the source's exponent+1. |
| C16 H_column_exchange | Only the column-exchange coefficient survives, with +m and old/new column positions. |
| C17 H_row_exchange | Only the row-exchange coefficient survives, with +n and old/new row positions. |
| C18 H_other | All unsupported coefficients and the unequal-index diagonal vanish. |
| C19 weighted_principal_minor_expansion | Multilinearity chooses the participating rows, factors row weights, reuses Mathlib's identity-row principal-minor lemma, and transposes for literal column weights. No inverse or nonempty restriction. |
| C20 cofactor_signed_minor_formula | Ordered erasure equals skip-index enumeration; Mathlib adjugate cofactor expansion supplies actual signed deleted minors. Two one-based shifts preserve parity. |
| C21 universal_rank_one_update | Multilinearity eliminates terms with two rank-one rows by alternation and identifies the surviving first-order term with the adjugate; no determinant inverse is used. |
| C22 universal_bordered_determinant | A unit scalar border gives a Schur identity; affine dependence on that single border entry yields the universal d det(T)-v adj(T) u identity. Selected blocks may be singular or empty. |
| C23 minor_lowering_identity | Actual erasure indices biject supported lowerings, with precisely the cofactor sign and no omitted empty case. |
| C24 minor_column_exchange_identity | Column replacement determinant is the cofactor column form; selected columns give k copies of the original minor, and unselected replacements enumerate literal exchanges exactly once. |
| C25 minor_row_exchange_identity | Transposes actual ordered minors, cofactor form and the full signed exchange sum to obtain the row identity. |
| C26 minor_raising_identity | Expand actual row/column sums into all ambient borders. Borders on selected labels vanish; all remaining pairs biject actual raising indices with sorted insertion signs. |
| C27 schur_margin_identities | Removes only the distinguished label from row/column sums; positive pivot and dimensions justify all divisions. |
| C28 schur_bordered_minor | Mathlib block determinant uses just the invertible 1-by-1 distinguished pivot, not invertibility of the selected tail minor. |
| C29 balanced_minor_relation | Rank-one reconstruction plus the four universal cofactor identities and literal Schur total produce every required m,n/sign coefficient by field/ring algebra. The mathematical argument is sound; local182 still failed elaboration at an instance-transport equality. |
| C30 weighted_transition_action | Supported cardinality changes transport (n/m)^k exactly; all unsupported terms are zero. Frozen hn is unused here and documented rather than artificially consumed. |
| C31 balanced_null_vector | Applies the proved minor relation through the literal H action, with empty weight one and nonzero vector. |
| C32 diagonal_minor_covariance | Ordinary determinant row/column factorization gives the same actual positive-scaling factor for Delta and Gamma; identity itself allows zero scaling factors. |
| C33 diagonal_pencil_covariance | Entrywise covariance yields right multiplication by the scaling-factor diagonal, with no misplaced row scaling. |
| C34 sinkhorn_pencil_singular | Uses actual scaling existence/semantics and transports the balanced null vector; empty coordinate is explicitly positive. No assumed balancing oracle. |
| C35 rowland_wu_identity | Nonzero null vector forces the actual pencil determinant to zero; C19 gives the exact full coefficient sum, scaling H before each principal determinant. |

## Every module and proof-quality scope

All source bodies were read, including Definitions, Numerical, AnalyticBasics,
Coercivity, Minimum, Stationary, ScalingExistence, ScalingUniqueness,
SinkhornSemantics, MinorBasics, TransitionSupport, DecisionTransport,
TransitionEntries, TransitionCardinality, WeightedTransition,
WeightedExpansion, CofactorSigned, RankOneBordered, MinorLowering, BorderOrder,
BorderedMinors, MinorColumnForms, ColumnExchangeIndices, MinorColumnExchange,
MinorTranspose, MinorRowExchange, RaisingIndices, MinorRaising,
MinorLinearity, CofactorDirections, SchurMargins, SchurBordered,
SchurReconstruction, BalancedMinor, DiagonalCovariance, PencilConsequences,
Canonical and Solution. No source module is excused because its final theorem
looks plausible. DecisionTransport only transports equal subsingleton
instances; it supplies no mathematical assertion or new axiom. Solution
explicitly imports TransitionEntries as well as Canonical and exports all 35
trust/axiom checks.

Proofs are split into substantive analytic, indexing, determinant and assembly
lemmas with explicit mathematical commentary. Type-transport changes and the
core determinant rewrites are explained by local comments or named helper
contracts; many elementary change commands unfold a named definition. I did
not find a readability problem requiring source changes merely to satisfy a
literal comment-per-tactic rule. Ring/field arithmetic is confined to exact
algebra; no dimension enumeration or large interval computation is used. The
only interval calculation is the fixed rational half certificate.

## Reuse, attribution and preliminary evidence limits

Actual pinned Mathlib search located the existing rank-one determinant lemma
with an IsUnit A.det hypothesis and its explicit TODO for the universal
adjugate version. The project's C21/C22 supply the missing singular-safe form,
while reusing determinant multilinearity, Cramer/adjugate, Schur complements,
row/column scaling, finite reindexing and compact minimum APIs. The weighted
expansion reuses det_piecewise_one_eq_submatrix_det instead of duplicating it.
Further exact source/evidence checks will be retained in the sealed packet.

The files attribute the question to Rowland and Wu and the mathematical
solution to Matthew J. Colbrook. George Stepaniants is credited for the code
and formalization with Department of Computing and Mathematical Sciences,
California Institute of Technology, and substantial OpenAI Codex assistance.
No personal email is introduced by these reviewed sources.

No mathematical objection was found at this stage. Final source approval is
withheld until a successful source-matched local export is independently
inspected. I read the actual local182 failed BalancedMinor log; it contains an
unsolved visually identical equality and sorryAx generated by that failure.
Neither local180 nor local182 is being reported as a whole-target pass.
This draft is not a Comparator run, GitHub result, full independent Lean rerun,
or published-commit certificate, and it changes no completion count.
