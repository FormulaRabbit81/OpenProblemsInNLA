#!/usr/bin/env python3
"""Capture this referee's read-only evidence. Writes only inside this packet.

No Lean/Lake/Comparator, network access, Git mutations or source edits occur.
"""
from pathlib import Path
import datetime, difflib, hashlib, json, re, subprocess

R = Path(__file__).resolve().parent
B = Path('/private/tmp/nla-lean-next-20260915')
S = B / 'NM04-local184-source-snapshot'
F = B / 'NM04-full-review-source178'
P = B / 'next-proofs/NM-04'
L = Path('/private/tmp/nla-lean-local-shared-20260916')
ROOT = Path('/Users/georgestepaniants/Research/OpenProblemsInNLA')
M = Path('/Users/georgestepaniants/Research/project/lean-verification/.lake/packages/mathlib')
MPIN = '0df444a360eaa60ab8c11dca51a86af692955474'
checks, external = [], {}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def check(label, ok, detail=None):
    checks.append({'check': label, 'pass': bool(ok), 'detail': detail})
    if not ok:
        raise AssertionError(label + ': ' + str(detail))

def write(rel, data):
    p = R / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data if isinstance(data, bytes) else data.encode())

def retain(p, rel):
    p = Path(p)
    data = p.read_bytes()
    write(rel, data)
    external[str(p)] = {'sha256': sha(data), 'retained': rel}
    return data

def run(argv):
    z = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return {'argv': argv, 'exit_code': z.returncode,
            'stdout': z.stdout.decode(), 'stderr': z.stderr.decode()}

def jwrite(rel, obj):
    write(rel, json.dumps(obj, indent=2, ensure_ascii=False) + '\n')

source_hashes = {}
for p in sorted(S.rglob('*.lean')):
    rel = p.relative_to(S).as_posix()
    data = retain(p, 'snapshot/' + rel)
    source_hashes[rel] = sha(data)
    check('active proof bytes ' + rel, (P / rel).read_bytes() == data)
check('exact complete module count', len(source_hashes) == 38)
for rel in ['Challenge.lean', 'STATEMENT-FREEZE.json', 'STATEMENT-HEADERS.json',
            'NUMERICAL_TARGETS.md', 'SourceCorrespondence.md', 'comparator.json']:
    data = retain(F / rel, 'frozen/' + rel)
    check('unchanged frozen file ' + rel, (P / rel).read_bytes() == data)
for rel in ['README.md', 'formalization.yaml', 'lakefile.toml', 'lake-manifest.json', 'lean-toolchain']:
    retain(P / rel, 'historical-packaging/' + rel)
retain(B / 'NM04-LOCAL-COMPLETE-184.json', 'coordinator/NM04-LOCAL-COMPLETE-184.json')
retain(L / 'ASSEMBLY-184.json', 'coordinator/ASSEMBLY-184.json')

freeze = json.loads((R / 'frozen/STATEMENT-FREEZE.json').read_text())
for rel, h in freeze['source_sha256'].items():
    path = R / ('snapshot/' if rel.startswith('NLA/') else 'frozen/') / rel
    check('freeze binding ' + rel, sha(path.read_bytes()) == h)
for entry in freeze['accepted_reviews']:
    d = Path(entry['directory'])
    for name in ['MANIFEST.json', 'VERDICT.json', 'REVIEW.md']:
        data = retain(d / name, 'prior-statement-reviews/' + d.name + '/' + name)
        if name in ['MANIFEST.json', 'VERDICT.json']:
            check('accepted statement review ' + str(d / name),
                  sha(data) == entry[name.split('.')[0].lower() + '_sha256'])

for p in sorted((F / 'standards').rglob('*.md')):
    rel = p.relative_to(F).as_posix()
    data = retain(p, rel)
    old = B / 'reviews/MF06-statement-referee2-20260917/snapshot/draft/source-inputs/standards/TauCetiProject/TauCetiReview' / p.relative_to(F / 'standards')
    check('same previously read pinned rubric ' + rel, old.read_bytes() == data)

primary = [
    ('nonnegative-and-positive-factorizations/NM-04/README.md', 'README.md'),
    ('references/colbrook-factorization-2026-09-11/manuscripts/NM-04_sinkhorn_identity.tex',
     'NM-04_sinkhorn_identity.tex')]
git_evidence = []
for path, name in primary:
    data = retain(F / 'primary' / name, 'primary/' + name)
    z = run(['git', '-C', str(ROOT), 'show',
             '849003686970b372e1b2128ba072f86168f81d38:' + path])
    check('read original Git blob ' + path, z['exit_code'] == 0)
    original = z['stdout'].encode()
    write('primary/original-8490036869-' + name, original)
    if name == 'README.md':
        # The supplied review copy has only the repository's later math-markup
        # cleanup. Keep the original bytes and complete diff; permit only these
        # explicit presentation substitutions, not a general whitespace filter.
        normalized = z['stdout'].replace('$`', '$').replace('`$', '$')
        normalized = normalized.replace('```math', '$$').replace('```', '$$')
        normalized = normalized.replace(r'\mathop{\mathrm{Sink}}\nolimits', r'\operatorname{Sink}')
        normalized = normalized.replace(r'\mathop{\mathrm{adj}}\nolimits', r'\operatorname{adj}')
        check('only explicit math markup changed in target', normalized.encode() == data)
        write('primary/README-original-to-review-copy.diff', ''.join(difflib.unified_diff(
            z['stdout'].splitlines(True), data.decode().splitlines(True),
            fromfile='original-8490036869', tofile='review-copy178')))
    else:
        check('exact original manuscript bytes', original == data)
    git_evidence.append({'argv': z['argv'], 'exit_code': z['exit_code'],
                         'stdout_sha256': sha(z['stdout'].encode())})

head = run(['git', '-C', str(M), 'rev-parse', 'HEAD'])
check('actual pinned Mathlib HEAD', head['exit_code'] == 0 and head['stdout'].strip() == MPIN)
git_evidence.append(head)
api_paths = [
    'Mathlib/LinearAlgebra/Matrix/SchurComplement.lean',
    'Mathlib/LinearAlgebra/Matrix/Adjugate.lean',
    'Mathlib/LinearAlgebra/Matrix/Charpoly/Coeff.lean',
    'Mathlib/LinearAlgebra/Matrix/Determinant/Basic.lean',
    'Mathlib/LinearAlgebra/Multilinear/Basic.lean',
    'Mathlib/Data/Finset/Sort.lean',
    'Mathlib/Topology/Order/Compact.lean',
    'Mathlib/Analysis/Calculus/LocalExtr/Basic.lean']
for rel in api_paths:
    data = retain(M / rel, 'pinned-api/' + rel)
    z = run(['git', '-C', str(M), 'show', MPIN + ':' + rel])
    check('API pinned Git equality ' + rel, z['exit_code'] == 0 and z['stdout'].encode() == data)
    git_evidence.append({'argv': z['argv'], 'exit_code': z['exit_code'],
                         'stdout_sha256': sha(z['stdout'].encode())})
jwrite('checks/pinned-git-bindings.json', git_evidence)

searches = []
for pattern in [r'det_.*(vecMulVec|replicateCol|rank.?one)|Sinkhorn|sinkhorn',
                r'det_piecewise_one_eq_submatrix_det|det_add_diagonal|det_add_one',
                r'IsCompact.exists_isMinOn|IsLocalMin.hasDerivAt_eq_zero']:
    searches.append(run(['rg', '-n', pattern, str(M / 'Mathlib')]))
for z in searches:
    check('actual read-only Mathlib search ' + z['argv'][2], z['exit_code'] in [0, 1])
jwrite('checks/mathlib-reuse-searches.json', searches)

examples = P / 'precode-01/sources/examples'
for p in sorted(examples.iterdir()):
    retain(p, 'examples/' + p.name)
retain(P / 'precode-01/sources/standards/leanprover/comparator/README.md', 'standards/Comparator-README.md')
retain(P / 'precode-01/sources/standards/mathlib-initiative/formalization.yaml/schema/v0.4.schema.json',
       'standards/formalization-v0.4.schema.json')

# Whitespace-only normalization checks literal declarations, not elaborated types.
headers = json.loads((R / 'frozen/STATEMENT-HEADERS.json').read_text())['headers']
config = json.loads((R / 'frozen/comparator.json').read_text())
check('35 independent configured contracts', len(headers) == 35 and
      [x['name'] for x in headers] == config['theorem_names'] and config['definition_names'] == [])
norm = lambda t: ' '.join(t.split())
contract_evidence = []
for h in headers:
    name = h['name'].split('.')[-1]
    pattern = re.compile(r'^theorem\s+' + re.escape(name) + r'\b(?P<body>.*?)\s*:=', re.M | re.S)
    matches = []
    for rel in source_hashes:
        t = (S / rel).read_text()
        for m in pattern.finditer(t):
            matches.append((rel, m.group(0).rsplit(':=', 1)[0].rstrip()))
    check('unique proof declaration ' + name, len(matches) == 1, matches)
    check('literal frozen header ' + name, norm(matches[0][1]) == norm(h['header']))
    contract_evidence.append({'name': h['name'], 'file': matches[0][0],
                              'frozen_header_sha256': h['header_sha256']})
jwrite('checks/contract-bindings.json', contract_evidence)

imports = {rel[:-5].replace('/', '.'): re.findall(r'^import\s+(\S+)', (S / rel).read_text(), re.M)
           for rel in source_hashes}
seen = set()
def walk(module):
    if module in seen:
        return
    seen.add(module)
    check('no Challenge import ' + module, module != 'Challenge')
    for dep in imports[module]:
        if dep.startswith('NLA.NM04.'):
            check('present local dependency ' + dep, dep in imports)
            walk(dep)
        else:
            check('allowed external import ' + dep, dep.startswith(('Mathlib', 'LeanCert')))
walk('Solution')
check('Solution reaches every source', seen == set(imports))
jwrite('checks/import-closure.json', imports)

# Deliberately conservative lexical screen supplements, not replaces, full reading.
for rel in source_hashes:
    t = (S / rel).read_text()
    t = re.sub(r'/\-.*?\-/', '', t, flags=re.S)
    t = re.sub(r'--[^\n]*', '', t)
    forbidden = re.findall(r'\b(?:sorry|admit|sorryAx|axiom|opaque|unsafe|native_decide|run_tac|run_elab|implemented_by|extern)\b|#eval|debug\.skipKernelTC', t)
    check('no forbidden proof construct ' + rel, not forbidden, forbidden)

# Independently traverse actual reuse receipts to successful local command origins.
root_receipt = L / 'runs/development-184/RECEIPT.json'
receipt_seen, command_seen, origins = {}, {}, []
def receipt(p):
    p = Path(p)
    if str(p) not in receipt_seen:
        data = retain(p, 'coordinator/runs/' + p.parent.name + '/' + p.name)
        receipt_seen[str(p)] = (sha(data), json.loads(data))
    return receipt_seen[str(p)]

def command_origin(p, module, expected_output=None):
    rh, j = receipt(p)
    c = next(x for x in j['commands'] if x['module'] == module)
    rel = module.replace('.', '/') + '.lean'
    check('receipt source matches ' + str(p) + ' ' + module,
          c.get('source_sha256') == source_hashes[rel])
    if expected_output is not None:
        check('reused output binding ' + str(p) + ' ' + module,
              c.get('output_sha256') == expected_output)
    for q, h in c.get('transitive_source_hashes', {}).items():
        check('transitive source ' + str(p) + ' ' + q, source_hashes.get(q) == h)
    if c.get('status') == 'reused_exact_successful_local_output':
        prev = Path(c['prior_receipt'])
        check('prior receipt digest ' + str(prev), receipt(prev)[0] == c['prior_receipt_sha256'])
        return command_origin(prev, module, c['output_sha256'])
    check('actual successful command ' + str(p) + ' ' + module,
          c.get('exit_code') == 0 and bool(c.get('output_sha256')))
    check('serial bounded command ' + str(p) + ' ' + module,
          '--threads=1' in c['argv'] and '--memory=4096' in c['argv'])
    log = Path(p).parent / (module + '.log')
    data = retain(log, 'coordinator/runs/' + log.parent.name + '/' + log.name)
    check('raw success log digest ' + str(log), sha(data) == c['log_sha256'])
    check('raw success log clean ' + str(log), not re.search(r'\berror:|sorryAx|unrecognized axioms', data.decode()))
    out = Path(c['argv'][c['argv'].index('-o') + 1])
    check('current compiled output ' + module, sha(out.read_bytes()) == c['output_sha256'])
    for dep, oh in c.get('dependency_olean_sha256', {}).items():
        dep_rel = dep.replace('.', '/') + '.lean'
        if dep_rel in source_hashes:
            check('dependency output ' + module + ' ' + dep,
                  sha((L / '.lake/build/lib/lean' / (dep.replace('.', '/') + '.olean')).read_bytes()) == oh)
    return {'module': module, 'origin_receipt': str(p), 'origin_receipt_sha256': rh,
            'command': c, 'log_sha256': sha(data)}

_, final = receipt(root_receipt)
check('terminal complete root receipt', final.get('end') and final.get('completed_modules') == 38
      and final.get('failed_modules') == [] and final.get('blocked_modules') == [])
check('root receipt complete exact source inventory', final['source_inputs'] == source_hashes)
check('assembly receipt digest', sha((R / 'coordinator/ASSEMBLY-184.json').read_bytes()) == final['assembly_sha256'])
assembly = json.loads((R / 'coordinator/ASSEMBLY-184.json').read_text())
check('actual assembly sources', {p: x['sha256'] for p, x in assembly['sources'].items()} == source_hashes)
runner = retain(L / 'serial_compile_v3.py', 'coordinator/serial_compile_v3.py.txt')
check('actual serial runner digest', sha(runner) == final['runner_sha256'])
actual_compiler = Path(next(c['argv'][0] for c in final['commands'] if 'argv' in c))
check('actual compiler binary digest', sha(actual_compiler.read_bytes()) == final['compiler_sha256'])
for module in sorted(imports):
    origins.append(command_origin(root_receipt, module))
for rp, (rh, rj) in receipt_seen.items():
    check('same compiler in receipt ' + rp, rj['compiler_sha256'] == final['compiler_sha256'])
jwrite('checks/independent-local-evidence-audit.json', origins)
summary = json.loads((R / 'coordinator/NM04-LOCAL-COMPLETE-184.json').read_text())
check('coordinator summary exact receipt', summary['receipt_sha256'] == receipt(root_receipt)[0])
check('coordinator summary exact sources', summary['sources'] == source_hashes)
solution_log = (R / 'coordinator/runs/development-184/Solution.log').read_text()
axioms = re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", solution_log)
check('35 exact successful exported names', [n for n, _ in axioms] == config['theorem_names'])
for name, ax in axioms:
    check('allowed observed axioms ' + name,
          set(ax.split(', ')) <= set(config['permitted_axioms']))
check('35 kernel trust assertions in Solution',
      re.findall(r'^#assert_trust kernel (\S+)', (S / 'Solution.lean').read_text(), re.M) == config['theorem_names'])

for old in [180, 182]:
    t = (B / f'NM04-local{old}-source-snapshot/NLA/NM04/BalancedMinor.lean').read_text()
    retain(B / f'NM04-local{old}-source-snapshot/NLA/NM04/BalancedMinor.lean',
           f'history/BalancedMinor-local{old}.lean.txt')
    write(f'history/BalancedMinor-{old}-to-184.diff', ''.join(difflib.unified_diff(
        t.splitlines(True), (S / 'NLA/NM04/BalancedMinor.lean').read_text().splitlines(True),
        fromfile=f'local{old}', tofile='local184')))
    retain(L / f'runs/development-{old}/NLA.NM04.BalancedMinor.log',
           f'history/BalancedMinor-local{old}-FAILED.log')

jwrite('BINDINGS.json', {'reviewer': '/root/mf06_statement_referee2',
       'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'source_snapshot': str(S), 'source_sha256': source_hashes,
       'external_files': external,
       'scope': 'Independent read-only source and root-run evidence audit; not a Lean or Comparator execution'})
jwrite('CHECKS.json', {'pass': all(x['pass'] for x in checks), 'checks': checks,
       'reviewer_lean_runs': 0, 'reviewer_comparator_runs': 0,
       'root_local_run': 184, 'source_modules': len(source_hashes), 'contracts': len(headers)})
print(json.dumps({'pass': True, 'checks': len(checks), 'sources': len(source_hashes),
                  'contracts': len(headers), 'receipts': len(receipt_seen),
                  'packet': str(R)}))
