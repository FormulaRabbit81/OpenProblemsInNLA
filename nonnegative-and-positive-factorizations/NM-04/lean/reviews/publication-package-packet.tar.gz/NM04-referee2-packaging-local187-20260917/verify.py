#!/usr/bin/env python3
"""Read-only integrity verifier. Never invokes Lean, Lake or Comparator."""
from pathlib import Path
import argparse, hashlib, json
p=argparse.ArgumentParser()
p.add_argument('--check-current',action='store_true')
a=p.parse_args()
R=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
n=0
def check(label,condition):
 global n
 n+=1
 if not condition:raise SystemExit('FAIL: '+label)
m=json.loads((R/'MANIFEST.json').read_text())
actual={p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file()}
check('exact sealed packet inventory',actual==set(m['files'])|{'MANIFEST.json'} or actual==set(m['files'])|{'MANIFEST.json','VERIFICATION.json'})
for rel,h in m['files'].items():check('packet payload '+rel,sha((R/rel).read_bytes())==h)
v=json.loads((R/'VERDICT.json').read_text())
c=json.loads((R/'CHECKS.json').read_text())
run=json.loads((R/'AUDIT-RUN.json').read_text())
check('approved bounded verdict',v['verdict']=='APPROVE_EXACT_PACKAGE_FOR_FINAL_LINUX_CHECK')
check('report binding',sha((R/'REVIEW.md').read_bytes())==v['report_sha256'])
check('actual audit pass',c['pass'] and not c['findings'] and all(x['pass'] for x in c['checks']))
check('audit check count',len(c['checks'])==v['audit_checks']==2003)
check('actual audit subprocess success',run['exit_code']==0 and json.loads(run['stdout'])['pass'])
check('no runtime overclaim',v['reviewer_Lean_Lake_Comparator_runs']==0 and not v['Linux_Comparator_executed'] and not v['publication_as_verified_approved'] and v['count_change']==0)
check('package manifest binding',sha((R/'snapshot/PACKAGE-MANIFEST.json').read_bytes())==v['package_manifest_sha256'])
bind=json.loads((R/'PACKAGE-FILE-BINDINGS.json').read_text())
check('package file count',len(bind)==v['packaged_files']==281)
check('file bindings manifest',bind['PACKAGE-MANIFEST.json']==v['package_manifest_sha256'])
check('packaging manifest exact recorded inventory',json.loads((R/'snapshot/PACKAGE-MANIFEST.json').read_text())['files']=={k:h for k,h in bind.items() if k!='PACKAGE-MANIFEST.json'})
state=json.loads((R/'snapshot/STATE.json').read_text())
check('state preserves pending Linux',state['local_run']==187 and state['final_source_reviews']==2 and not state['GitHub_Comparator_run'] and state['count_change']==0)
check('all archives integrated',len(json.loads((R/'snapshot/reviews/INDEX.json').read_text()))==v['archive_count']==5)
check('no outstanding active link',all(x['exists'] for x in json.loads((R/'checks/active-links.json').read_text())))
check('privacy scope scan empty',not json.loads((R/'checks/privacy.json').read_text())['matches'])
check('tracked external harness',sha((R/'external/HARNESS.md').read_bytes())=='6e7bca698cbdce70599d59d710e5b3ad1757f796b4b05e18bcb78820e9bc0fd4')
check('observed upstream ancestry',json.loads((R/'external/ANCESTRY.json').read_text())['exit_code']==0)
for x in json.loads((R/'external/TRACKED-HARNESS.json').read_text())['commands']:check('observed read-only Git command',x['exit_code']==0)
if a.check_current:
 P=Path(v['package'])
 current={p.relative_to(P).as_posix():sha(p.read_bytes()) for p in P.rglob('*') if p.is_file()}
 check('exact current package inventory',set(current)==set(bind))
 for rel,h in bind.items():check('exact current package '+rel,current[rel]==h)
 check('exact current shared harness',sha(Path('/private/tmp/nla-lean-next-nm04-worktree/tools/lean/HARNESS.md').read_bytes())=='6e7bca698cbdce70599d59d710e5b3ad1757f796b4b05e18bcb78820e9bc0fd4')
print(json.dumps({'pass':True,'checks':n,'current_package_checked':a.check_current,'scope':'Read-only integrity; not Lean, Lake or Comparator'}))
