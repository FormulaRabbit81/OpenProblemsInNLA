#!/usr/bin/env python3
"""Independent read-only packaging preflight. Writes only its own review folder.
No source edits, archive extraction, Lean, Lake, Git, network or Comparator.
"""
from pathlib import Path, PurePosixPath
import datetime, hashlib, io, json, re, tarfile
import jsonschema, tomli
R = Path(__file__).resolve().parent
B = Path('/private/tmp/nla-lean-next-20260915')
P = B / 'NM04-canonical-package-local187'
ROOT = Path('/Users/georgestepaniants/Research/OpenProblemsInNLA')
V = B / 'reviews/NM04-referee2-local187-continuation-20260917/VERDICT.json'
sha = lambda b: hashlib.sha256(b).hexdigest()
files = {p.relative_to(P).as_posix(): p.read_bytes() for p in sorted(P.rglob('*')) if p.is_file()}
checks, findings, privacy = [], [], []
def check(label, ok, detail=None):
    checks.append({'check': label, 'pass': bool(ok), 'detail': detail})
    if not ok: findings.append({'check': label, 'detail': detail})
def put(rel, data):
    p = R / rel; p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data if isinstance(data, bytes) else data.encode())
def jout(rel, data): put(rel, json.dumps(data, indent=2, ensure_ascii=False)+'\n')

f = json.loads(files['formalization.yaml'])
schema = json.loads(files['sources/standards/v0.4.schema.json'])
errs = list(jsonschema.Draft202012Validator(schema).iter_errors(f))
check('formalization schema v0.4', not errs, [e.message for e in errs])
check('retained schema matches pinned copy',
      files['sources/standards/v0.4.schema.json'] ==
      files['sources/standards/mathlib-initiative/formalization.yaml/schema/v0.4.schema.json'])
v = json.loads(V.read_text())
for rel, h in v['source_sha256'].items(): check('approved local187 source '+rel, sha(files[rel]) == h)
check('exact active source manifest', json.loads(files['ACTIVE-SOURCE-MANIFEST.json'])['source_sha256'] == v['source_sha256'])
freeze = json.loads(files['STATEMENT-FREEZE.json'])
for rel, h in freeze['source_sha256'].items(): check('unchanged frozen '+rel, sha(files[rel]) == h)
check('toolchain pin', files['lean-toolchain'].decode().strip() == 'leanprover/lean4:v4.33.1')
lake = tomli.loads(files['lakefile.toml'].decode())
check('Solution default target', lake['defaultTargets'] == ['Solution'])
check('Solution independent library registration', {x['name'] for x in lake['lean_lib']} == {'NLA','Challenge','Solution'})
check('Lake LeanCert pin', lake['require'] == [{'name':'leancert','git':'https://github.com/alerad/leancert','rev':'621a43d7cf21f87872392a01e874f2f1dbddc926'}])
newdep = json.loads(files['lake-manifest.json'])
olddep = json.loads(files['statement-history/lake-manifest.json'])
check('only root package label changed', newdep['name'] == 'NLANM04' and
      olddep['name'] == 'NLAIE02' and {k:x for k,x in newdep.items() if k!='name'} ==
      {k:x for k,x in olddep.items() if k!='name'})
cfg = json.loads(files['comparator.json'])
results = f['status']['main_results']
check('all35 exact metadata names', [r['declaration'] for r in results] == cfg['theorem_names'] and len(results)==35)
check('exact implementation map', results == json.loads(files['IMPLEMENTATION-MAP.json'])['results'])
for r in results:
    check('metadata proof hash '+r['declaration'], sha(files[r['file']]) == r['file_sha256'])
    check('metadata declaration line '+r['declaration'],
          files[r['file']].decode().splitlines()[r['line']-1].startswith('theorem '+r['declaration'].split('.')[-1]))
    check('metadata observed permitted axioms '+r['declaration'], set(r['axioms']) <= set(cfg['permitted_axioms']))
for k, path in f['alignment'].items(): check('metadata alignment '+k, path in files)
check('actual local187 record linked', files['verification/LOCAL-COMPLETE.json'] == files['verification/LOCAL-COMPLETE-187.json'])
check('actual local187 record hash', sha(files['verification/LOCAL-COMPLETE.json']) == v['local187_complete_record_sha256'])
check('no premature whole problem verification', f['status']['whole_problem_verified'] is False)
check('no claimed GitHub check', f['verification']['GitHub_Comparator']['status'] == 'not run')
check('George name and exact authorized affiliation', f['project']['authors'] == ['George Stepaniants'] and
      f['project']['affiliations']['George Stepaniants'] ==
      'Department of Computing and Mathematical Sciences, California Institute of Technology')
check('mathematical authorship retained', any('Matthew J. Colbrook' in x.get('authors',[]) for x in f['sources']))

for entry in json.loads(files['verification/RETAINED-PATHS.json']):
    rel=entry['destination']
    check('retained path digest '+rel, rel in files and sha(files[rel])==entry['sha256'])
pm = json.loads(files['PACKAGE-MANIFEST.json'])['files']
check('complete package manifest inventory', set(pm) == set(files)-{'PACKAGE-MANIFEST.json'})
for rel,h in pm.items(): check('package manifest '+rel, rel in files and sha(files[rel])==h)
for entry in json.loads(files['precode-01/MANIFEST.json'])['files']:
    rel='precode-01/'+entry['path']
    check('precode manifest '+rel, rel in files and sha(files[rel])==entry['sha256'])

active_docs=['README.md','SourceCorrespondence.md','reviews/README.md']
links=[]
for rel in active_docs:
    for target in re.findall(r'\]\(([^)]+)\)',files[rel].decode()):
        url=target.split('#',1)[0]
        if not url or '://' in url or url.startswith('mailto:'):continue
        url=url.strip('<>')
        target_path=(P/rel).parent/url
        try: resolved=target_path.resolve().relative_to(P.resolve()).as_posix()
        except ValueError:
            # The only external active link is evaluated at the proposed
            # unchanged canonical README location, not at the temporary folder.
            virtual=ROOT/'nonnegative-and-positive-factorizations/NM-04/lean'/rel
            resolved=(virtual.parent/url).resolve()
            ok=resolved.is_file()
        else:ok=resolved in files or any(x.startswith(resolved.rstrip('/')+'/') for x in files)
        links.append({'from':rel,'target':target,'resolved':str(resolved),'exists':ok})
        check('active local link '+rel+' -> '+target,ok)
jout('checks/active-links.json',links)

archive_details=[]
def members(data,label):
    with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
        result={}
        for m in archive.getmembers():
            check('safe archive member '+label+' '+m.name,
                  not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
                  and (m.isfile() or m.isdir()))
            if m.isfile(): result[m.name]=archive.extractfile(m).read()
        return result
def normalized_manifest(j):
    f=j['files']
    if isinstance(f,list):return {x['path']:x['sha256'] for x in f}
    return {p:(x if isinstance(x,str) else x['sha256']) for p,x in f.items()}

review_index=json.loads(files['reviews/INDEX.json'])
for e in review_index:
    rel='reviews/'+e['archive']; data=files[rel]
    check('review archive hash '+e['label'],sha(data)==e['archive_sha256'])
    check('review archive bytes '+e['label'],len(data)==e['archive_bytes'])
    check('review visible manifest '+e['label'],sha(files['reviews/'+e['manifest']])==e['manifest_sha256'])
    content=members(data,e['label'])
    prefix=e['original_packet']+'/'
    check('archive original manifest '+e['label'],sha(content[prefix+'MANIFEST.json'])==e['manifest_sha256'])
    for key,name in [('report','REVIEW.md'),('verdict','VERDICT.json')]:
        check('archive visible '+key+' '+e['label'],content[prefix+name]==files['reviews/'+e[key]])
    manifest=normalized_manifest(json.loads(content[prefix+'MANIFEST.json']))
    for n,h in manifest.items():check('archive sealed member '+e['label']+' '+n,
        prefix+n in content and sha(content[prefix+n])==h)
    archive_details.append({'label':e['label'],'archive_sha256':sha(data),
        'members':len(content),'sealed_payloads':len(manifest)})
    for n,data in content.items():
        if b'@' in data:
            for email in re.findall(rb'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',data):
                if re.search(rb'george|stepan',email,re.I):privacy.append({'path':rel+'!'+n,'address_sha256':sha(email)})
for rel,data in files.items():
    if rel.endswith('.tar.gz'):
        if rel.startswith('reviews/'):continue
        content=members(data,rel)
        for n,d in content.items():
            for email in re.findall(rb'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',d):
                if re.search(rb'george|stepan',email,re.I):privacy.append({'path':rel+'!'+n,'address_sha256':sha(email)})
    else:
        for email in re.findall(rb'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',data):
            if re.search(rb'george|stepan',email,re.I):privacy.append({'path':rel,'address_sha256':sha(email)})
check('no George or Stepaniants email in text or archive members',not privacy,privacy)
jout('checks/review-archives.json',archive_details)
jout('checks/privacy.json',{'scope':'All packaged regular files and gzip-tar regular-file members, candidate addresses matching George or Stepan; no address values published','matches':privacy})
check('no concurrent package mutation during audit', all((P/rel).read_bytes()==data for rel,data in files.items()))
check('no active compiled artifacts',not any(x.endswith(('.olean','.ilean','.o')) for x in files))
readiness={'review_labels':[e['label'] for e in review_index],
    'final187_review_archives_required':['referee1 exact187 continuation','referee2 exact187 continuation'],
    'note':'Final review archives and truthful review-completion metadata must be integrated before the final Linux check. This preflight does not run Lean, Lake or Comparator.'}
for rel in ['README.md','formalization.yaml','lakefile.toml','lake-manifest.json','STATE.json',
            'reviews/README.md','reviews/INDEX.json','ACTIVE-SOURCE-MANIFEST.json',
            'PACKAGE-MANIFEST.json','verification/packaging/LAKE-MANIFEST-CHANGE.json',
            'sources/standards/v0.4.schema.json','IMPLEMENTATION-MAP.json']:
    put('snapshot/'+rel,files[rel])
put('source-approval/VERDICT.json',V.read_bytes())
jout('PACKAGE-FILE-BINDINGS.json',{p:sha(d) for p,d in files.items()})
jout('CHECKS.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'package':str(P),'checks':checks,'pass':not findings,'findings':findings,
    'integration_boundary':readiness,'reviewer_Lean_Lake_Comparator_runs':0})
print(json.dumps({'pass':not findings,'checks':len(checks),'files':len(files),
    'archives_checked':archive_details,'findings':findings,'integration_boundary':readiness}))
