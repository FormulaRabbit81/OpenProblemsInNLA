#!/usr/bin/env python3
"""Read-only exact-candidate integrity audit; never executes a proof checker.

This checks the publication candidate against an independently reviewed source
and runtime chain. It does not substitute for that review or execute Lean,
Lake, Comparator, a build, a Git mutation, or a network request. It reads local
Git objects, project files, sealed review archives, and PDF text/metadata.
"""
import ast
import hashlib
import importlib.util
import io
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tarfile
import zipfile

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parent
S = json.loads((R / 'SCOPE.json').read_text())
W = Path(S['worktree'])
P = W / S['project']
B = R.parent.parent
checks = 0
def check(condition, label):
    global checks
    checks += 1
    if not condition:
        raise AssertionError(label)
def sha(data):
    return hashlib.sha256(data).hexdigest()
def load(path):
    return json.loads(path.read_text())
def git(*args):
    return subprocess.check_output(['git', *args], cwd=W)
def hfile(path, expected):
    check(path.is_file() and not path.is_symlink(), 'ordinary file: ' + str(path))
    check(sha(path.read_bytes()) == expected, 'sha256: ' + str(path))

if (R / 'MANIFEST.json').exists():
    own = load(R / 'MANIFEST.json')['files']
    check(set(own) == {str(f.relative_to(R)) for f in R.rglob('*')
                     if f.is_file() and f.name != 'MANIFEST.json'}, 'sealed review file inventory')
    for name, expected in own.items():
        hfile(R / name, expected)

hfile(P / 'PACKAGE-MANIFEST.json', S['package_manifest_sha256'])
package = load(P / 'PACKAGE-MANIFEST.json')
actual = {str(f.relative_to(P)) for f in P.rglob('*') if f.is_file()}
check(len(actual) == 418, '418 regular project files')
check(set(package['files']) == actual - {'PACKAGE-MANIFEST.json'}, 'complete 417-payload manifest')
check(package['proof_commit'] == S['proof_commit'] and package['proof_run'] == S['proof_run'], 'immutable proof scope')
for name, expected in package['files'].items():
    hfile(P / name, expected)
for name, expected in S['protected_inputs'].items():
    hfile(P / name, expected)
    check(sha(git('show', S['proof_commit'] + ':' + S['project'] + '/' + name)) == expected,
          'proof-commit protected input: ' + name)
for name, expected in S['checker_inputs'].items():
    hfile(W / name, expected)
    check(sha(git('show', S['proof_commit'] + ':' + name)) == expected, 'unchanged shared checker/IDs: ' + name)
for name, expected in S['publication_files'].items():
    hfile(W / name, expected)

active = load(P / 'ACTIVE-SOURCE-MANIFEST.json')
local = load(P / 'verification/LOCAL-COMPLETE.json')
freeze = load(P / 'STATEMENT-FREEZE.json')
headers = load(P / 'STATEMENT-HEADERS.json')
config = load(P / 'comparator.json')
meta = load(P / 'formalization.yaml')
implementation = load(P / 'IMPLEMENTATION-MAP.json')
state = load(P / 'STATE.json')
check(len(active['source_sha256']) == active['Solution_closure_files'] == 38, '38-source closure')
check(active['source_sha256'] == local['sources'], 'local204 exact-source continuity')
check(local['actual_local_closure_modules'] == 38 and local['exact_contracts'] == 35, 'local204 full scope')
check(len(freeze['source_sha256']) == 6, 'six frozen boundary files')
for name, expected in freeze['source_sha256'].items():
    hfile(P / name, expected)
names = config['theorem_names']
check(len(names) == len(set(names)) == 35, '35 distinct original frozen exports')
check(names == [e['name'] for e in headers['headers']], 'frozen name agreement')
check(meta['status']['main_results'] == implementation['results'], 'implementation map exactly agrees')
check([e['declaration'] for e in implementation['results']] == names, 'metadata complete ordered coverage')
axioms = {'propext', 'Classical.choice', 'Quot.sound'}
check(set(config['permitted_axioms']) == axioms == set(meta['status']['axioms']), 'standard axioms only')
for entry in implementation['results']:
    hfile(P / entry['file'], entry['file_sha256'])
    line = (P / entry['file']).read_text().splitlines()[entry['line'] - 1]
    check('theorem ' + entry['declaration'].split('.')[-1] in line, 'literal declaration line: ' + entry['declaration'])
    check(entry['sorry_count'] == 0 and set(entry['axioms']) == axioms, 'per-export trust metadata')
    check(str(S['proof_run']) in entry['verification_status'] and S['proof_commit'] in entry['verification_status'],
          'per-export immutable execution scope')
verification = meta['verification']
check(verification['local_Lean']['run'] == 204 and verification['local_elaborated_type_diagnostics']['run'] == 205,
      'local development/type diagnostics distinct')
gh = verification['GitHub_Comparator']
check(gh['published_commit'] == S['proof_commit'] and gh['run'] == S['proof_run'] and gh['job'] == 105387449317,
      'actual immutable Linux revision/run/job')
check(gh['input_count'] == 380 and gh['exports'] == 35, 'runtime does not claim future 418-file execution')
check(state['count_change'] == 0 and len(state['remaining']) == 3, 'publication and count gates remain separate')
check('pending' in verification['publication_status'] and 'later publication' in active['Linux_Comparator'],
      'future checks not claimed complete')
check('ran on GitHub non-root Linux' in meta['automation']['methods'][0]['tool_setup'], 'corrected completed-runtime tense')

failure = load(P / 'verification/FAILED-LINUX-35269165327.json')
check(failure['run_id'] == 35269165327 and failure['conclusion'] == 'failure', 'failed Linux attempt retained')
check('kernel replay not reached' in failure['failure'] and failure['current_repaired_source_accepted'] is False,
      'failure history does not claim successful kernel replay')
index = load(P / 'reviews/INDEX.json')
required = {'final-1-local204': S['prior_source_manifest_sha256'],
            'package-local204': S['prior_package_manifest_sha256'],
            'runtime-35276203784': S['prior_runtime_manifest_sha256']}
for label, expected in required.items():
    entry = next(x for x in index if x['label'] == label)
    hfile(P / 'reviews' / entry['manifest'], expected)
check(any(x['label'] == 'final-2-local204' for x in index), 'second independent exact204 continuation retained')
archive_members_checked = 0
for entry in index:
    archive = P / 'reviews' / entry['archive']
    hfile(archive, entry['archive_sha256'])
    hfile(P / 'reviews' / entry['manifest'], entry['manifest_sha256'])
    with tarfile.open(archive, mode='r:gz') as bundle:
        prefix = entry['original_packet'] + '/'
        member_data = {m.name[len(prefix):]: bundle.extractfile(m).read()
                       for m in bundle.getmembers() if m.isfile() and m.name.startswith(prefix)}
    check(sha(member_data['MANIFEST.json']) == entry['manifest_sha256'], 'archive/outer review manifest')
    archived_manifest = json.loads(member_data['MANIFEST.json'])
    file_entries = archived_manifest['files']
    if isinstance(file_entries, list):
        file_entries = {x['path']: x['sha256'] for x in file_entries}
    for name, expected in file_entries.items():
        if isinstance(expected, dict):
            expected = expected['sha256']
        check(name in member_data and sha(member_data[name]) == expected, 'archived sealed payload: ' + entry['label'] + '/' + name)
        archive_members_checked += 1
    for outer_name, inner_name in [('report', 'REVIEW.md'), ('verdict', 'VERDICT.json')]:
        # Different older referee packets use alternate report basenames.
        if inner_name in member_data:
            check((P / 'reviews' / entry[outer_name]).read_bytes() == member_data[inner_name], 'review copy matches sealed packet')

runtime_dir = P / 'verification/linux-2026-09-17'
prior = load(P / 'reviews/runtime-35276203784-manifest.json')
for name, expected in prior['files'].items():
    if name.startswith('runtime/'):
        hfile(runtime_dir / name[len('runtime/'):], expected)
hfile(runtime_dir / 'lean-NM-04.zip', '33efcf4a5566999c953fac7b029c94cb9fe0264a8910c0cb8702a1d3d1d7f8d8')
result = load(runtime_dir / 'artifacts/lean-NM-04/verify-20260917T212313Z-4211/result.json')
check(result['repository_commit'] == S['proof_commit'] and result['config'] == config, 'accepted actual runtime config')
check(len(result['input_sha256']) == 380, 'accepted runtime 380-source inventory')
for name, expected in result['input_sha256'].items():
    check(sha(git('show', S['proof_commit'] + ':' + S['project'] + '/' + name)) == expected,
          'runtime input matched to immutable Git blob: ' + name)

canonical = 'nonnegative-and-positive-factorizations/NM-04/README.md'
current_target = (W / canonical).read_bytes().split(b'## Problem statement\n', 1)[1]
for base in [S['proof_commit'], '849003686970b372e1b2128ba072f86168f81d38']:
    check(current_target == git('show', base + ':' + canonical).split(b'## Problem statement\n', 1)[1],
          'entire original target/reference/history suffix unchanged: ' + base)
renderer = (W / 'tools/render_problems.py').read_text()
old_renderer = git('show', S['proof_commit'] + ':tools/render_problems.py').decode()
check(renderer.replace(', "NM-04"', '').replace('"NM-04", ', '').replace("'NM-04', ", '') == old_renderer,
      'renderer changes only three NM04-specific membership entries')
check(renderer.count('NM-04') - old_renderer.count('NM-04') == 3, 'exactly three renderer membership additions')
expected_summary = '**Resolution evidence:** 53 solved (published or independently audited); 52 solved with Lean verification.'
for name in ['README.md', 'CATALOG.md']:
    check(expected_summary in (W / name).read_text(), 'canonical counts after one promotion: ' + name)
for name in ['CATALOG.md', 'nonnegative-and-positive-factorizations/README.md']:
    old = git('show', S['proof_commit'] + ':' + name).decode().splitlines()
    new = (W / name).read_text().splitlines()
    check([x for x in old if '| [' in x and '[NM-04]' not in x] ==
          [x for x in new if '| [' in x and '[NM-04]' not in x], 'all other catalog rows unchanged')
old_resolved = git('show', S['proof_commit'] + ':RESOLVED.md').decode()
new_resolved = (W / 'RESOLVED.md').read_text()
check(old_resolved.split('**NM-04 (', 1)[0] == new_resolved.split('**NM-04 (', 1)[0] and
      old_resolved.split('**NR-04 (', 1)[1] == new_resolved.split('**NR-04 (', 1)[1], 'resolved edits bounded to NM04')

spec = importlib.util.spec_from_file_location('nla_final_review_projects', W / 'tools/lean/projects.py')
projects = importlib.util.module_from_spec(spec)
spec.loader.exec_module(projects)
selected = projects.select(projects.discover(W), list(S['publication_files']))
check(selected == [{'id': 'NM-04', 'project': S['project']}], 'only NM04 selected prospectively')
allowed = {'CATALOG.md', 'README.md', 'RESOLVED.md', 'nonnegative-and-positive-factorizations/README.md', 'tools/render_problems.py'}
check(all(n in allowed or n.startswith('nonnegative-and-positive-factorizations/NM-04/') for n in S['publication_files']),
      'all 54 publication paths within bounded scope')
check(not any(n.endswith('.lean') for n in S['publication_files']), 'no proof source changed')
push = Path(S['push_script'])
hfile(push, S['push_script_sha256'])
pushtext = push.read_text()
ast.parse(pushtext)
for text in ["review['approved_to_push'] is True", "review['protected_inputs']", "review['publication_files']",
             "GIT_AUTHOR_EMAIL=''", "GIT_COMMITTER_EMAIL=''", "git('show', '-s', '--format=%ae|%ce', head)",
             "selected == [{'id':'NM-04','project':PROJECT}]", "['git','push','origin',BRANCH]"]:
    check(text in pushtext, 'reviewed prospective normal push guard: ' + text)
check('--force' not in pushtext and 'force-with-lease' not in pushtext, 'normal push only')

readme = (P / 'README.md').read_text()
check('tools/lean/bootstrap.sh /tmp/nla-nm04-tools\ntools/lean/verify.sh ' in readme,
      'reproduction bootstraps before verification')
check('local `lake build`' in readme and 'does not replace the Linux verification' in readme, 'local/Linux distinction')
check(meta['project']['authors'] == ['George Stepaniants'], 'requested formalization contributor')
affiliation = 'Department of Computing and Mathematical Sciences, California Institute of Technology'
check(meta['project']['affiliations']['George Stepaniants'] == affiliation, 'department and university explicit')
for text in [readme, (W / canonical).read_text(), new_resolved]:
    check('George Stepaniants' in text and affiliation in text and 'Matthew J. Colbrook' in text, 'preserved attribution')
check('Eric Rowland and Jason Wu' in readme and 'not external human peer review' in readme, 'question and review attribution')

pdf = P.parent / 'problem.pdf'
pdftext = subprocess.check_output(['/opt/homebrew/bin/pdftotext', str(pdf), '-']).decode()
pdfinfo = subprocess.check_output(['/opt/homebrew/bin/pdfinfo', str(pdf)]).decode()
check(re.search(r'^Pages:\s+3$', pdfinfo, re.M) is not None, 'actual PDF page count')
check('George Stepaniants' in pdftext and 'California Institute of Technology' in pdftext and 'Matthew J. Colbrook' in pdftext,
      'PDF visible credit')
check('Metadata Stream: no' in pdfinfo and 'JavaScript:      no' in pdfinfo, 'PDF metadata/active content scope')
visual_record = load(P / 'verification/packaging/NM04-PDF-REVIEW-20260917.json')
for name, expected in visual_record['source_sha256'].items():
    hfile(W / name, expected)
for name, expected in S['pdf_images'].items():
    hfile(Path(name), expected)
check(visual_record['actual_final_render_exit'] == 0 and visual_record['pages'] == 3, 'root actual render receipt')
required_checks = load(P / 'verification/packaging/NM04-DOCUMENT-REQUIRED-CHECKS-20260917.json')
check(len(required_checks['commands']) == 4 and all(c['exit_code'] == 0 for c in required_checks['commands']),
      'retained root ID/catalog/17tests/schema receipts')

email_pattern = re.compile(rb'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}')
emails = {}
privacy = {'regular_files': 0, 'archives': 0, 'archive_regular_members': 0, 'scanned_bytes': 0}
def safe_path(name):
    pp = PurePosixPath(name)
    check(not pp.is_absolute() and '..' not in pp.parts, 'safe archive member path')
def scan(data, label, depth=0):
    check(depth <= 8, 'bounded archive nesting')
    privacy['scanned_bytes'] += len(data)
    for value in email_pattern.findall(data):
        value = value.decode().lower()
        emails[value] = emails.get(value, 0) + 1
        check('stepan' not in value and 'george' not in value, 'no George email in ' + label)
    stream = io.BytesIO(data)
    if zipfile.is_zipfile(stream):
        privacy['archives'] += 1
        with zipfile.ZipFile(stream) as archive:
            for member in archive.infolist():
                safe_path(member.filename)
                check((member.external_attr >> 16) & 0o170000 != 0o120000, 'no ZIP symlink')
                if not member.is_dir():
                    privacy['archive_regular_members'] += 1
                    scan(archive.read(member), label + ':' + member.filename, depth + 1)
    elif label.endswith(('.tar.gz', '.tgz', '.tar')):
        privacy['archives'] += 1
        with tarfile.open(fileobj=io.BytesIO(data), mode='r:*') as archive:
            for member in archive.getmembers():
                safe_path(member.name)
                check(member.isfile() or member.isdir(), 'ordinary TAR member')
                if member.isfile():
                    privacy['archive_regular_members'] += 1
                    scan(archive.extractfile(member).read(), label + ':' + member.name, depth + 1)
for name in sorted(actual):
    privacy['regular_files'] += 1
    scan((P / name).read_bytes(), name)
for name in S['outer_files']:
    scan((W / name).read_bytes(), name)
scan(pdftext.encode(), 'extracted PDF text')
scan(pdfinfo.encode(), 'extracted PDF metadata')
check(set(emails) <= {'m.colbrook@damtp.cam.ac.uk', 'townsend@cornell.edu'}, 'only unchanged prior-author email candidates')
print(json.dumps({'result': 'PASS', 'checks': checks, 'package_manifest_sha256': S['package_manifest_sha256'],
                  'project_files': len(actual), 'publication_paths': len(S['publication_files']),
                  'protected_inputs': len(S['protected_inputs']), 'checker_inputs': len(S['checker_inputs']),
                  'archive_manifest_members_checked': archive_members_checked, 'privacy': privacy,
                  'george_email_candidates': 0, 'unrelated_prior_author_email_candidates': len(emails),
                  'selected_projects': selected, 'reviewer_Lean_Comparator_runs': 0,
                  'scope': 'Exact candidate package/documents only; prior actual proof runtime retained, future commit and merge checks separate'}, indent=2))
