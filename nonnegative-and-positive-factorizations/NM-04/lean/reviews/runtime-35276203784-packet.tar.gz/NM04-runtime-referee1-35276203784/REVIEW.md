# NM-04 exact-commit runtime review

**Verdict: approve the runtime evidence for published commit `21ed3545a8b4784303e9cc0473879eb33ef4d813`.** No runtime blocker was found. This audit continues my full source187 review and exact source204 repair review; it does not substitute log inspection for those mathematical reviews.

I have never authored the NM-04 statements, proof bodies, helpers, repair, or checker. I ran no Lean, Lake, Comparator, or GitHub job in this review. Root performed the authenticated GitHub fetch; I independently inspected the fetched API records, exact Git objects, artifact, raw job output, pinned checker sources, and all substantive runtime logs. The Python audit reruns evidence checks only.

## Identity and coverage

- GitHub run **35276203784**, attempt 1, completed successfully at the exact commit above, on the fork's `codex/lean-nm04-verification` branch. It is a push run, not an upstream merge or independent human certification.
- Artifact **10521096295**, `lean-NM-04`, has SHA-256 `33efcf4a5566999c953fac7b029c94cb9fe0264a8910c0cb8702a1d3d1d7f8d8`. I matched this with the downloaded zip, API digest, and raw upload-job digest, and matched all 13 archive payloads with the extracted files.
- All **380** recorded project inputs match the published Git blobs and the exact package approved before publication (manifest `9119212bd10f5d2f80895f75ff9598767868c431ea71e33ae1a30e9d6a4e6b8a`). No project input was silently omitted or replaced.
- All **38** previously approved proof-closure module hashes match, and the six frozen statement/definition files remain unchanged. All **35** original exports appear in both Challenge and Solution export lists and in Solution's axiom output, including C04 and the final `rowland_wu_identity`.
- The selector chose only NM-04. The verify job ran on Ubuntu 24.04 as a non-root user; sandbox probes report UID 1001.

## What actually ran

The substantive Comparator log ends with all three required observations in order: Lean's default kernel is invoked; the default kernel accepts the solution; Comparator prints its final acceptance. The recorded process exit is zero. Each of the 35 Solution exports reports only `propext`, `Classical.choice`, and `Quot.sound`. The configuration permits exactly those axioms, leaves definition holes empty, and does not enable an external replacement kernel.

The frozen Challenge intentionally contains 35 theorem placeholders. Its corresponding warnings are expected and are not proof acceptance. The candidate Solution has no placeholder warning or illegal-axiom failure. There is one retained ordinary unused-variable linter warning at WeightedTransition.lean:145 for `hn`; it is not a failed proof check and does not change any statement.

The same verify job actually ran all of these controls before building the candidate:

- Build/export sandbox probes: outside-file writes, truncation, symlink writes, and creation are denied. Only the designated build `.lake` directory is writable; export `.lake` writes are denied. User, PID, mount, network, IPC, and UTS namespaces are private; host process access, loopback, AF_UNIX sockets, and nested namespace attempts fail; capabilities are absent and no-new-privileges is set.
- Four malformed sandbox-invocation cases return the expected rejection.
- The actual `Comparator.runBuiltinKernel` replay control accepts an honest inductive/quotient fixture, rejects a raw proof of False using True.intro, and rejects a forged quotient declaration during its post-check.
- All five named Comparator regression cases pass their prescribed phase checks, including honest acceptance, mismatched declarations/statements, and illegal axioms.
- Separate `sorry` and `native_decide` fixtures both return exit 1 for the expected illegal axiom; this is not merely a textual source scan.

The workflow's separate `checker-controls` job is skipped because checker files did not change. This does not mean the controls were skipped: the actual verify job invokes the same controls and retains their full logs. The raw job contains every nonempty runtime-log body line in sequence after removing timestamps; artifact command headers and EXIT_STATUS annotations are harness-generated additions to the retained logs, not separate runner output.

## Trusted checker and source-review continuity

The workflow, harness, and checker source lock at this commit are unchanged from the previously reviewed base `ff6abf718126ceb23f933cf4f627f95104461fe8`. I verified all 58 locked Forsythe source blobs at commit `8d1b0c0545a77b40245e84705aa7d273e6c81e62`, and inspected the central comparison, axiom traversal, default-kernel replay, strict sandbox adapter, and replay fixture source.

The harness checks the pinned source bytes and recorded executable hashes, builds a fresh project from ordinary tracked Git blobs, disallows tracked compiled outputs and unsupported config keys, then rechecks input hashes after dependency setup, cache download, and candidate verification. Candidate compilation/export occurs in the strict non-root sandbox. The receipt records the comparator, exporter, and Landrun executable digests and Lean 4.33.1. Those binaries are not retained in this artifact; my review checks the source/build/receipt chain and actual controls, and does not claim to have independently rehashed an unavailable runner binary.

The pinned Mathlib revision is `0df444a360eaa60ab8c11dca51a86af692955474`; LeanCert is `621a43d7cf21f87872392a01e874f2f1dbddc926`. Exact source204 uses the reviewed kernel-mode numerical certificate and the full original target. The earlier Linux run 35269165327 remains a real C04 statement-comparison failure; local201/202 also remain failed attempts. This successful repaired-source run supersedes them for the exact commit above without erasing their history.

## Scope of acceptance

This closes my pending NM-04 Linux-runtime gate for the reviewed source. Combined with the earlier full mathematical/source approvals and package preflight, I find the exact published proof acceptable under the campaign's requested verification scope. Repository status, upstream PR publication, attribution metadata updates, and the aggregate completed-target counter remain root's separate responsibility.

A later metadata commit can preserve these proof bytes, but it must not be described as this exact run's Git head. This evidence also does not make arbitrary GitHub checks impossible to fake, formally verify the checker implementation, or constitute a second independent kernel run by this reviewer. It records one actual Linux run and an independent read-only audit of its provenance, coverage, controls, and continuity.

