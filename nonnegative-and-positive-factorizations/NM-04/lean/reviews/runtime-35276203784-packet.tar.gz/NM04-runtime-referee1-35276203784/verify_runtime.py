#!/usr/bin/env python3
"""Read-only runtime evidence and exact Git audit; no compiler or network."""
from pathlib import Path
import argparse, hashlib, json, re, subprocess, zipfile
ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--repository', type=Path, default=Path('/private/tmp/nla-lean-next-nm04-worktree'))
parser.add_argument('--forsythe', type=Path, default=Path('/Users/georgestepaniants/Research/Forsythe'))
args = parser.parse_args()
checks = 0
def check(ok, label):
    global checks
    if not ok: raise AssertionError(label)
    checks += 1
def digest(data): return hashlib.sha256(data).hexdigest()
def sha(path): return digest(path.read_bytes())
def js(rel): return json.loads((ROOT / rel).read_text())
def git(repo, *arguments): return subprocess.check_output(['git', *arguments], cwd=repo)
scope = js('SCOPE.json')
commit = scope['commit']
project = 'nonnegative-and-positive-factorizations/NM-04/lean'
runtime = ROOT / 'runtime'
run = js('runtime/run.json')
check(run['id'] == 35276203784 and run['head_sha'] == commit, 'run identity')
check(run['status'] == 'completed' and run['conclusion'] == 'success', 'actual run success')
check(run['event'] == 'push' and run['run_attempt'] == 1, 'run scope')
check(run['repository']['full_name'] == 'sgstepaniants/OpenProblemsInNLA', 'repository identity')
jobs = js('runtime/jobs.json')['jobs']
check(len(jobs) == 3, 'job inventory')
verify_job = next(j for j in jobs if j['id'] == 105387449317)
select_job = next(j for j in jobs if j['id'] == 105387335533)
for job in (verify_job, select_job):
    check(job['head_sha'] == commit and job['run_id'] == run['id'], 'job identity')
    check(job['conclusion'] == 'success' and all(s['conclusion'] == 'success' for s in job['steps']), 'job steps')
    check(job['labels'] == ['ubuntu-24.04'], 'Linux runner')
check(next(j for j in jobs if j['name'] == 'checker-controls')['conclusion'] == 'skipped', 'separate redundant controls skipped')
artifacts = js('runtime/artifacts.json')
check(artifacts['total_count'] == 1, 'single artifact')
artifact = artifacts['artifacts'][0]
check(artifact['id'] == 10521096295 and artifact['name'] == 'lean-NM-04', 'artifact identity')
check(artifact['workflow_run']['head_sha'] == commit and artifact['workflow_run']['id'] == run['id'], 'artifact run')
check(artifact['digest'] == 'sha256:' + scope['artifact_sha256'], 'API artifact digest')
archive = runtime / 'lean-NM-04.zip'
check(sha(archive) == scope['artifact_sha256'], 'downloaded artifact digest')
with zipfile.ZipFile(archive) as z:
    names = z.namelist()
    check(len(names) == len(set(names)) == 13, 'archive payload inventory')
    for item in z.infolist():
        path = Path(item.filename)
        check(not item.is_dir() and not path.is_absolute() and '..' not in path.parts, 'safe artifact path')
        check(z.read(item) == (runtime / 'artifacts/lean-NM-04' / item.filename).read_bytes(), 'exact artifact ' + item.filename)
result_path = next((runtime / 'artifacts').rglob('result.json'))
result = json.loads(result_path.read_text())
logs = result_path.parent
check(result['repository_commit'] == commit and result['project'] == project, 'result identity')
check(result['result'] == 'comparator-accepted', 'actual Comparator result')
check(result['semantic_review'] == 'not-performed-by-this-command', 'semantic distinction')
inputs = result['input_sha256']
bindings = js('PUBLISHED-GIT-BINDINGS.json')['files']
tree = git(args.repository, 'ls-tree', '-r', commit, '--', project + '/').decode().splitlines()
actual = {}
for line in tree:
    meta, path = line.split('\t')
    actual[path[len(project) + 1:]] = tuple(meta.split())
check(len(inputs) == 380 and set(actual) == set(inputs) == set(bindings), 'all 380 inputs')
for rel, expected in inputs.items():
    mode, kind, obj = actual[rel]
    check(mode in ('100644', '100755') and kind == 'blob', 'ordinary Git input ' + rel)
    check(bindings[rel]['git_blob'] == obj and bindings[rel]['sha256'] == expected, 'Git binding ' + rel)
    check(digest(git(args.repository, 'cat-file', 'blob', obj)) == expected, 'actual published hash ' + rel)
package = js('published/PACKAGE-MANIFEST.json')
check(sha(ROOT/'published/PACKAGE-MANIFEST.json') == scope['prior_approved_package_manifest'], 'prepublication package')
check(package['files'] == {k:v for k,v in inputs.items() if k != 'PACKAGE-MANIFEST.json'}, 'complete approved package identity')
for rel, expected in js('published/STATEMENT-FREEZE.json')['source_sha256'].items():
    check(inputs[rel] == expected, 'unchanged frozen source ' + rel)
continuity = js('CONTINUITY.json')
for name, entry in continuity.items():
    check(sha(ROOT/'continuity'/name/'VERDICT.json') == entry['verdict_sha256'], 'prior verdict ' + name)
v204 = js('continuity/NM04-final-referee1-local204-continuation-20260917/VERDICT.json')
check(v204['verdict'] == 'APPROVE_EXACT_SOURCE204_CONTINUATION', 'source review continuity')
check(v204['baseline187_manifest_sha256'] == continuity['NM04-final-referee1-continuation-20260917']['manifest_sha256'], 'full review binding')
check(len(v204['source_hashes']) == 38, '38 reviewed closure sources')
for rel, expected in v204['source_hashes'].items(): check(inputs[rel] == expected, 'reviewed active source ' + rel)
config = result['config']
headers = js('published/STATEMENT-HEADERS.json')['headers']
names = [h['name'] for h in headers]
check(len(names) == len(set(names)) == 35 and config['theorem_names'] == names, 'all 35 original contracts')
check(config == js('published/comparator.json'), 'exact frozen config')
check(config['definition_names'] == [], 'no definition holes')
allowed = {'propext', 'Quot.sound', 'Classical.choice'}
check(set(config['permitted_axioms']) == allowed, 'three permitted axioms')
candidate = (logs/'comparator.log').read_text()
for side in ('Challenge', 'Solution'):
    match = re.search(r'^Exporting #\[(.+)\] from ' + side + r'$', candidate, re.M)
    check(match is not None, 'actual export ' + side)
    exported = [x.strip() for x in match.group(1).split(',')]
    check([x for x in exported if x.startswith('NLA.NM04.')] == names, 'full export list ' + side)
axioms = re.findall(r"^info: Solution\.lean:\d+:0: '([^']+)' depends on axioms: \[([^\]]+)\]$", candidate, re.M)
check([name for name, _ in axioms] == names, 'all final Solution axiom statements')
for name, a in axioms: check(set(x.strip() for x in a.split(',')) == allowed, 'actual axioms ' + name)
built = set(re.findall(r'Built (NLA\.NM04\.[A-Za-z]+|Solution) \(', candidate))
for rel in v204['source_hashes']: check(rel[:-5].replace('/', '.') in built, 'actual closure build ' + rel)
check(candidate.endswith('EXIT_STATUS=0\n'), 'candidate actual exit')
markers = ['Running Lean default kernel on solution.', 'Lean default kernel accepts the solution', 'Your solution is okay!']
check(all(candidate.count(m) == 1 for m in markers), 'kernel and Comparator markers')
check([candidate.index(m) for m in markers] == sorted(candidate.index(m) for m in markers), 'phase order')
solution_phase = candidate.split('Building Solution\n', 1)[1]
check('Illegal axiom' not in solution_phase and 'declaration uses ' + chr(96) + 'sorry' + chr(96) not in solution_phase, 'no candidate admission')
warnings = re.findall(r'^warning: (.+)$', solution_phase, re.M)
check(len(warnings) == 1 and warnings[0].startswith('NLA/NM04/WeightedTransition.lean:145:59:'), 'honest linter warning')
sandbox = (logs/'sandbox.log').read_text()
check(sandbox.count('Sandbox UID: 1001') == 2, 'actual non-root uid')
for marker in ['outside .lake write-open: denied', 'outside .lake truncate: denied', 'symlink from .lake to outside write: denied',
               'outside .lake creation: denied', 'host parent: absent', 'host parent signal lookup: denied',
               'host loopback listener: unreachable', 'AF_UNIX socket creation: denied',
               'effective capabilities: none', 'no_new_privs: set', 'nested namespace write attempt: rejected']:
    check(sandbox.count('PASS ' + marker) == 2, 'both modes ' + marker)
for namespace in ('user','pid','mnt','net','ipc','uts'):
    check(sandbox.count('PASS ' + namespace + ' namespace: private') == 2, 'isolation ' + namespace)
check('PASS build .lake write: allowed' in sandbox and 'PASS export .lake write-open: denied' in sandbox, 'writable build only')
for case in ('unknown option','unexpected --rw','unexpected --rwx','relative --rwx'):
    check('NEGATIVE ' + case + ': exit=2' in sandbox, 'sandbox rejection ' + case)
check(sandbox.endswith('EXIT_STATUS=0\n'), 'sandbox controls exit')
kernel = (logs/'kernel-controls.log').read_text()
for marker in ['RETURN honest_with_inductives_and_quotients: accepted',
               'RETURN invalid_raw_proof: rejected:', 'declaration type mismatch',
               'RETURN quotient_postcheck_mismatch: rejected: Quotient constant mismatch on: Quot.lift',
               'PASS: all three actual Comparator.runBuiltinKernel cases behaved as required']:
    check(marker in kernel, 'kernel control ' + marker)
check(kernel.endswith('EXIT_STATUS=0\n'), 'kernel controls exit')
regressions = (logs/'comparator-controls.log').read_text()
for case in ('simple_match','simple_mismatch','simple_axiom_issue','simple_kind_mismatch','type_mismatch'):
    check('PASS ' + case + ': exit ' in regressions, 'actual regression ' + case)
check('PASS: all five Comparator regressions' in regressions and regressions.endswith('EXIT_STATUS=0\n'), 'five regressions')
for case, illegal in [('native', 'checked._native.native_decide.ax_1_1'), ('sorry','sorryAx')]:
    log = (logs/('negative-' + case + '.log')).read_text()
    check("Illegal axiom detected: '" + illegal + "'" in log and log.endswith('EXIT_STATUS=1\n'), 'actual rejection ' + case)
lock_path = ROOT/'checker/tools/lean/source-lock.json'
lock = js('checker/tools/lean/source-lock.json')
receipt = result['tool_receipt']
check(sha(lock_path) == result['source_lock_sha256'] == receipt['source_lock_sha256'], 'trusted source lock')
check(receipt['forsythe_commit'] == lock['commit'] == '8d1b0c0545a77b40245e84705aa7d273e6c81e62', 'source revision')
check(receipt['lean_toolchain'] == lock['lean_toolchain'] == 'leanprover/lean4:v4.33.1', 'Lean version')
check('x86_64-unknown-linux-gnu' in receipt['lean_version'] and receipt['platform'].startswith('Linux-'), 'actual Linux receipt')
check(len(receipt['executables']) == 3 and all(re.fullmatch('[0-9a-f]{64}', h) for h in receipt['executables'].values()), 'recorded executable digests')
pins = js('CHECKER-SOURCE-BINDINGS.json')
check(len(lock['files']) == len(pins) == 58, '58 pinned checker source files')
for entry in lock['files']:
    data = git(args.forsythe, 'show', lock['commit'] + ':' + entry['source'])
    check(digest(data) == entry['sha256'] == pins[entry['source']]['sha256'] and len(data) == entry['bytes'], 'pinned source ' + entry['source'])
    copied = ROOT/'checker/forsythe'/entry['source']
    if copied.exists():
        check(copied.read_bytes() == data, 'inspected checker source ' + entry['source'])
for rel in ('tools/lean/harness.py','tools/lean/source-lock.json','.github/workflows/lean-verification.yml'):
    check(git(args.repository,'show',commit+':'+rel) == (ROOT/'checker'/rel).read_bytes(), 'published checker ' + rel)
    check(git(args.repository,'show',commit+':'+rel) == git(args.repository,'show',scope['checker_unchanged_from']+':'+rel), 'unchanged checker ' + rel)
deps = (logs/'dependencies.log').read_text()
for revision in ('621a43d7cf21f87872392a01e874f2f1dbddc926','0df444a360eaa60ab8c11dca51a86af692955474'):
    check(revision in deps, 'exact dependency ' + revision)
def raw_lines(filename):
    source = (runtime/filename).read_text(encoding='utf-8-sig')
    source = re.sub(r'\x1b\[[0-9;]*m', '', source)
    return [re.sub(r'^\d{4}-\d\d-\d\dT\S+Z ', '', line) for line in source.splitlines()]
raw = raw_lines('job-105387449317.log')
for log in (runtime/'artifacts/lean-NM-04').rglob('*.log'):
    items = log.read_text().splitlines()
    check('Running ' + items[0][2:] in raw, 'raw command ' + log.name)
    wanted = [line for line in items if line and not line.startswith(('$ ', 'EXIT_STATUS='))]
    cursor = 0
    for line in wanted:
        while cursor < len(raw) and raw[cursor] != line: cursor += 1
        check(cursor < len(raw), 'ordered raw body ' + log.name)
        cursor += 1
check('Manifest schema and comparator coverage: PASS (35 declarations)' in raw, 'actual schema coverage')
check(any('SHA256 digest of uploaded artifact zip is ' + scope['artifact_sha256'] in line for line in raw), 'raw upload digest')
check(any('Artifact ID 10521096295' in line for line in raw), 'raw artifact id')
selected = [json.loads(line) for line in raw_lines('job-105387335533.log') if line.startswith('{"include":')]
check(selected == [{'include':[{'id':'NM-04','project':project}]}], 'only NM04 selected')
check(scope['reviewer_compiler_runs'] == scope['reviewer_Comparator_runs'] == scope['reviewer_network_jobs'] == 0, 'honest reviewer scope')
check(js('VERDICT.json')['verdict'] == 'APPROVE_EXACT_COMMIT_RUNTIME_EVIDENCE', 'runtime verdict')
if (ROOT/'MANIFEST.json').exists():
    manifest = js('MANIFEST.json')
    for rel, expected in manifest['files'].items(): check(sha(ROOT/rel) == expected, 'sealed ' + rel)
    actual_files = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p.name != 'MANIFEST.json'}
    check(actual_files == set(manifest['files']), 'complete packet manifest')
print(json.dumps({'result':'PASS','checks':checks,'run_id':run['id'],'commit':commit,
                  'project_inputs':380,'original_contracts':35,'proof_closure_modules':38,
                  'reviewer_Lean_run':False,'reviewer_Comparator_run':False,
                  'scope':'Read-only evidence audit of one actual GitHub Linux run'},indent=2))
