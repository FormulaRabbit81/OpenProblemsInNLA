from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
m=json.loads((r/'MANIFEST.json').read_text())
actual={p.relative_to(r).as_posix() for p in r.rglob('*') if p.is_file() and p!=r/'MANIFEST.json'}
assert actual==set(m['files'])
for rel,h in m['files'].items():assert hashlib.sha256((r/rel).read_bytes()).hexdigest()==h,rel
v=json.loads((r/'VERDICT.json').read_text())
for rel,h in v['source_sha256'].items():assert hashlib.sha256((r/'snapshot'/rel).read_bytes()).hexdigest()==h,rel
assert v['verdict']=='approve' and not v['whole_problem_accepted']
c=json.loads((r/'snapshot/comparator.json').read_text())
assert len(c['theorem_names'])==35 and not c['definition_names']
assert set(c['permitted_axioms'])=={'propext','Classical.choice','Quot.sound'}
assert (r/'snapshot/Challenge.lean').read_text().count('  sorry')==35
print('PASS: exact statement-review packet integrity; not a Lean or Comparator execution')
