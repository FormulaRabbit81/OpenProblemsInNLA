#!/usr/bin/env python3
"""Read-only review/source integrity checks, never a Lean or Comparator proof check."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_source_manifest(path, expected):
    assert digest(path) == expected, f"source manifest changed: {path}"
    record = json.loads(path.read_text())
    for name, value in record["payloads"].items():
        assert digest(path.parent / name) == value, f"source payload changed: {name}"
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, default=Path(
        "/private/tmp/nla-lean-next-20260915/MF05-full-proof-candidate-20260917-local139"))
    parser.add_argument("--repo", type=Path, default=Path(
        "/Users/georgestepaniants/Research/OpenProblemsInNLA"))
    parser.add_argument("--effective-candidate", type=Path,
                        help="Repaired project to compare with the final source approval")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    own_manifest = root / "MANIFEST.json"
    if own_manifest.exists():
        own = json.loads(own_manifest.read_text())
        for name, value in own["payloads"].items():
            assert digest(root / name) == value, f"review payload changed: {name}"
    audit = json.loads((root / "INITIAL-SOURCE-AUDIT.json").read_text())
    source = verify_source_manifest(args.candidate / "FULL-PROOF-SOURCE-MANIFEST.json",
                                    audit["manifest_sha256"])
    contracts = json.loads((args.candidate / "CONTRACT-MAP.json").read_text())["contracts"]
    for item in contracts:
        name = item["declaration"].split(".")[-1]
        matches = []
        for path in (args.candidate / "NLA/MF05").glob("*.lean"):
            found = re.search(r"(?m)^theorem " + re.escape(name) +
                              r"\b[\s\S]*?\s*:= by", path.read_text())
            if found:
                matches.append(found.group(0).removesuffix(":= by").rstrip())
        assert matches == [item["header"]], f"contract mismatch: {name}"
    for binding in audit["published_git_bindings_verified"]:
        value = subprocess.check_output([
            "git", "--no-optional-locks", "-C", str(args.repo), "show",
            binding["git_commit"] + ":" + binding["git_path"]])
        assert hashlib.sha256(value).hexdigest() == binding["sha256"], binding
    verdict = json.loads((root / "INITIAL-VERDICT.json").read_text())
    final = root / "FINAL-VERDICT.json"
    if final.exists():
        verdict = json.loads(final.read_text())
        for binding in verdict.get("additional_source_bindings", []):
            path = Path(binding["path"])
            assert digest(path) == binding["sha256"], f"final source changed: {path}"
        effective = args.effective_candidate or Path(verdict["effective_candidate_root"])
        for name, value in verdict["effective_source_hashes"].items():
            assert digest(effective / name) == value, f"approved final source changed: {name}"
        for item in contracts:
            name = item["declaration"].split(".")[-1]
            matches = []
            for path in (effective / "NLA/MF05").glob("*.lean"):
                found = re.search(r"(?m)^theorem " + re.escape(name) +
                                  r"\b[\s\S]*?\s*:= by", path.read_text())
                if found:
                    matches.append(found.group(0).removesuffix(":= by").rstrip())
            assert matches == [item["header"]], f"final contract mismatch: {name}"
    print(json.dumps({
        "scope": "Read-only source/review integrity only; not Lean, Comparator, or mathematical verification",
        "initial_candidate_payloads_verified": len(source["payloads"]),
        "exact_contract_headers_verified": len(contracts),
        "published_git_bindings_verified": len(audit["published_git_bindings_verified"]),
        "recorded_verdict": verdict["overall"],
        "source_integrity": "pass"
    }, indent=2))


if __name__ == "__main__":
    main()
