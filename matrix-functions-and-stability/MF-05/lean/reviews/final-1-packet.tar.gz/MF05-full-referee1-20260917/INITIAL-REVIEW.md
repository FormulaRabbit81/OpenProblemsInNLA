# MF-05 independent mathematical and Lean-source review

Reviewer: `/root/mf05_full_referee1`, a nonauthor referee. Date: 17 September 2026.

Candidate: `MF05-full-proof-candidate-20260917-local139`, manifest SHA-256
`6adc2744599a44458961f3394c48bd579d330bbd26bdc1702c633098d6a52c3d`.
I independently checked all 103 manifest payload hashes, read all fourteen
MF05 modules, the aggregate Solution, all twenty reused MF07 modules, the
frozen definitions and contracts, canonical README, source correspondence,
and the mathematical body of Colbrook's original manuscript.

**Initial verdict: mathematics approved; source changes requested for reuse
and one explanatory comment.** This is not the final repaired-source approval.
No mathematical gap or weakening of the original target was identified.

This is a substantive AI-agent source review using the pinned Tau Ceti
correctness, generality, proof-quality, reuse, and attribution rubrics at
`afb424eda89e8ac96d9eb69f6a88972055a4cd1b`. I read its `REVIEWING.md` and apply
the rubrics to this standalone problem formalization. I did not execute the
Tau Ceti review service, impersonate an official Tau Ceti reviewer, or conduct
external human peer review. The source-integrity checks below are not Lean or
Comparator executions.

## Original target and definitions

The retained MF-05 target is local two-family Holder continuity of the joint
spectral radius on nonempty compact complex matrix families, in every
dimension `d >= 1`, with exponent `1/d`. Its positive radius and Holder
constant must be chosen before both independently varying families. The
candidate final theorem has exactly this quantifier order and uses the
literal maximum of the two supremum-infimum spectral distances.

`Square d` is an actual complex square matrix; `spectralNorm` is the norm of
`Matrix.toEuclideanCLM`, acting on the actual complex Euclidean space. The
default entrywise matrix norm is not substituted. Words are unrestricted
lists, their reversed product preserves chronological order, and every
length is retained. Compactness is used through the parameter space
`Fin n -> M`, which permits infinitely many generators. Published compact
growth results prove attainment of the word maximum and of the family norm.

The reused radius definition is the infimum of all positive-index roots,
not an assumed root limit. `general_root_limit_semantics` now proves the
canonical limit for every eligible family. It is a mandatory Comparator
contract and also participates in the actual scaling/radius-transfer proof
dependencies. Thus the final theorem is not merely an assertion about an
unrelated radius surrogate.

The two metric definitions are concrete. The canonical one is the exact
real `sInf`, `sSup`, maximum formula from the README. The operator-image
Hausdorff distance is not allowed to exploit a total-definition fallback:
the source proves compact images, nonemptiness, finite Hausdorff edistance,
nearest-point attainment, and equality of the two distances. Equality at
zero distance is transported back using the injectivity of the actual
matrix-to-operator equivalence.

All fourteen implementation theorem headers match their frozen contract
headers exactly. I checked that the Comparator list names all fourteen,
including both mandatory semantic correspondence theorems and the original
target. `definition_names` is empty because the independent Challenge and
Solution share the same concrete definitions; no proof imports Challenge.

## Substantive proof checks

1. **General envelope and root limit.** The radius infimum is nonnegative.
   A root value below any larger positive rate gives a good positive-length
   block. Submultiplicativity controls repeated blocks, and finitely many
   remainder lengths provide one coefficient. Only the positive rate is
   divided by. The eventual root upper bound absorbs a fixed coefficient
   using geometric decay `(a/b)^n`; the infimum supplies the lower bound.
   No positivity of growth, logarithm at zero, or assumed continuity is used.

2. **Scaling.** Every word in the scaled image has an order-preserving
   preimage word. Scalar factors commute with the matrix product, giving
   exact growth equality for all lengths. Compact attainment supplies both
   directions, rather than an unjustified exchange of suprema. General root
   convergence and uniqueness of limits identify the actual scaled radius.
   Radius zero is allowed throughout.

3. **Scalar-identity adjunction.** The compression proof retains an actual
   sublist and its order. Scalar identity occurrences contribute only their
   scalar power; there is no spurious binomial factor. A generator already
   equal to the adjoined identity can be assigned the identity branch without
   losing validity. The empty residual word is included. The upper radius
   bound follows from exponential envelopes at every rate above the maximum;
   inclusion and all-identity words provide both lower bounds. The family
   norm is also proved to be the required maximum.

4. **Arbitrary-radius quantitative comparison.** At positive radius, the
   entire compact family is scaled by the inverse radius and the exact
   published MF07 comparison is invoked. At zero radius, the proof adjoins
   `e I` with `0 < e < L`, proves its radius equals `e`, applies the positive
   case, and passes to the limit in a scalar polynomial at a fixed length.
   It never assumes continuity of the joint spectral radius, which would
   be circular. The rate enlargement from the actual family norm to `L`
   has the requisite sign conditions. The empty-word case is retained.

5. **Concrete comparison norm.** The norm is the actual supremum of
   discounted word actions. Its finiteness, lower and upper Euclidean
   bounds, definiteness, triangle inequality, and complex homogeneity are
   consequences of the proved all-word bound. No norm-existence oracle or
   hidden hypothesis is introduced. The generator bound is obtained by
   prefixing a word in the correct chronological convention.

6. **Perturbation and actual radius.** For each generator of the second
   family, compactness attains a nearest generator of the first. The
   comparison norm's triangle inequality and Euclidean bounds control the
   error action. Iteration over every word gives an actual Euclidean
   operator-norm bound, followed by the proved exponential-to-radius
   implication. Only the first family is required to lie in the supplied
   ball for this one-sided theorem. Two proof helpers here duplicate
   already imported generalized results; this is a reuse issue, not a gap.

7. **Optimization and local conclusion.** The symbolic scale
   `(L/delta)^(1/d)` is positive and at least one when `0 < delta <= L`.
   Its exact power gives the optimized coefficient
   `d*(2*d+1)*L^(1-1/d)`. Dimension one is included without division by
   `d-1`. Zero distance is handled through equality of compact families;
   distances larger than `L` use both radii in `[0,L]`. The constant is
   positive. Both nearby families enter the same explicit ball
   `familyNorm M0 + 1`, and the final positive radius and constant are fixed
   before either family varies.

8. **LeanCert consumption.** `Numerical.lean` proves exactly
   `0 < 1/2 < 1` with `interval_decide (trust := kernel)`. Both inequalities
   are consumed in `local_common_norm_ball`; positivity is consumed again
   by the final radius witness. This is a real proof dependency, not an
   unused import. All dimension, word-length, scaling, and optimization
   calculations are symbolic; no finite dimension cutoff or interval grid
   weakens the target.

## Published MF07 prerequisite

I independently compared all twenty included MF07 files, and the canonical
MF05 README, against actual local Git objects at each of
`5308b2cfa30826e1314d6a8830415c14b5f1d7a3`,
`849003686970b372e1b2128ba072f86168f81d38`, and
`15b755d235477d5bb4e7f9440bdd6224b4cec8b9`: all bytes match.

I also read the substantive prerequisite proofs rather than relying on
these hashes alone. They construct the approximate norm, maximize a genuine
determinant over a compact unit ball, derive Auerbach bounds, obtain ordered
positive singular coordinates from the positive Gram matrix, and cap the
singular gaps. Triangular damping acts on complete products, with arbitrary
equal-weight blocks retained. The interspersed estimate is proved through
an equivalent orbit norm, including its zero-rate case. Similarity is
undone with the proved `s^(d-1)` bound, and only scalar continuity removes
the auxiliary rate. No principal-block contractivity shortcut or supplied
decomposition/norm hypothesis was found.

The three vendored MF07 modules not imported by MF05's final theorem
(`Final`, `ScalarFamily`, `Numerical`) do not add MF05 completion claims.
The imported comparison result is the relevant prerequisite; the separate
MF07 canonical target is not counted again.

## Required source repairs

**R1 — duplicated declarations; reuse rubric initially blocks.**
`RadiusTransfer.lean:24-59` re-proves `word_action_bound` and
`word_spectral_bound_from_action`. Existing generalized replacements are
`NLA.MF07.norm_product_from_generator` in `Interspersed.lean:30` and
`NLA.MF07.spectralNorm_product_of_norm` in `BlockComparison.lean:51`.
Specialize their generator map to the identity and simplify
`List.map_id_fun'` / `id_eq`. Remove the two new declarations and invoke
the latter published bound directly in `hausdorff_radius_transfer`.
This also removes the undocumented `change` in the duplicate norm proof.

**R2 — duplicated standard induction.**
Replace the custom induction in `Scaling.scaled_word_product` with the
generic `List.smul_prod` at
`Mathlib/Algebra/BigOperators/GroupWithZero/Action.lean:106`, specialized
to the reversed list. Its hypotheses allow noncommutative matrix products.
The named wrapper is acceptable because it expresses the project's actual
reversed-word convention and has a concrete consumer.

**R3 — duplicated standard induction.**
Replace the induction in `IdentityAdjoin.scalar_identity_replicate_product`
using `List.reverse_replicate`, `List.prod_replicate`, `smul_pow`, and
`one_pow`, after unfolding `matrixProduct`. The named wrapper again has a
concrete consumer. I located `smul_pow` in
`Mathlib/Algebra/Group/Action/Defs.lean:488` and `reverse_replicate` in
Lean's `Init/Data/List/Lemmas.lean:2591`.

**Q1 — explanatory comment.**
Explain the intentional definitional unfolding of `spectralHausdorff` in
`Final.lean:34`, or replace it by explicit unfolding/rewrite. This is the
only remaining new-code `change` clarification after R1.

No other required changes were identified. I have sent the consolidated
list before root's coherent local recompilation. The concrete replacement
proof terms still require actual local elaboration; suggestions are not
successful compiler results. A final addendum will bind and inspect the
exact repaired-source diff before granting approval.

## Attribution, generality, and verification limits

The full complex target is retained, including infinite compact families,
reducibility, singular generators, zero radius, zero distance, dimension one,
and empty words in supporting estimates. The noncompact extension, scalar
optimal constant, sharpness, MF06, and a new mathematical resolution of MF05
are not additional claims of this formalization.

Credit is present in the code and correspondence for Matthew J. Colbrook's
original mathematical proof and George Stepaniants's formalization, with
George's Department of Computing and Mathematical Sciences, California
Institute of Technology affiliation. Reused code headers are unchanged.
The original problem remains attributed to Epperlein and Wirth in the
canonical source. Substantial AI assistance is disclosed. No email is
introduced by this review.

I inspected root's completed local139 receipt
`290e2b8069fd5baec4055b2065900b6148951982fcf93a5dd31fab820ca09bd2`
and read its complete aggregate log
`8ca81acfa061e6bc8f6cf6267255b6197af51d3b0747e0d6f672837bb51f4cc4`.
The receipt records 32 successful or source-matched reused project modules,
no failed/blocked modules, and exit zero for the exact aggregate source.
The aggregate log prints only `propext`, `Classical.choice`, and `Quot.sound`
for all fourteen obligations. I did not run a compiler, independently
replay the binary proof artifacts, or run Comparator. This observation
does not certify the final repaired bytes, a published commit, Linux
sandboxing, negative controls, or final GitHub verification.

The historical draft README, formalization manifest, progress, and
precode/status records in the candidate are not approved as current
publication documentation. Root is separately updating them. This report
does not mark a problem solved, increase a count, authorize merging on
unchecked evidence, or claim an exhaustive literature/fork audit.

`INITIAL-SOURCE-AUDIT.json` binds the checks and original Git objects.
