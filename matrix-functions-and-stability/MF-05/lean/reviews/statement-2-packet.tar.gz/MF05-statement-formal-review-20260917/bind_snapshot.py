"""Independent read-only MF05 snapshot binding; does not run Lean or mutate a candidate."""
from pathlib import Path
import json,hashlib,re,datetime
B=Path('/private/tmp/nla-lean-next-20260915');P=B/'next-statements/MF-05';S=B/'MF05-statement-snapshot-20260917';R=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
mf=S/'STATEMENT-SNAPSHOT-MANIFEST.json';h=sha(mf)
assert h=='e728907ff49576fb73e778f65d5c678e323a68a7927af81dc99fc2de50a9d2f7'
m=json.loads(mf.read_text());assert isinstance(m['files'],dict)
actual={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file() and p!=mf}
assert actual==m['files']
assert sha(P/'STATEMENT-SNAPSHOT-MANIFEST.json')==h
live={str(p.relative_to(P)):sha(p) for p in P.rglob('*') if p.is_file() and p!=P/'STATEMENT-SNAPSHOT-MANIFEST.json'}
assert live==actual
assert sha(S/'NLA/MF05/Definitions.lean')=='f4ada429ed3cf768c228bd936c3a969f618bd3e87e8bc860cc371b5b315a3cb9'
assert sha(S/'Challenge.lean')=='ebe57eb8865dc19065c2ddc0d67bc16dab6e3fa40a6b61fec0954faa7fc3dba0'
sourcecheck=json.loads((R/'READ-ONLY-SOURCE-CHECK.json').read_text())
assert sourcecheck['published_binding_sha256']==sha(S/'sources/reuse/MF07-PUBLISHED-BINDINGS.json')
for x in sourcecheck['published_sources']+sourcecheck['primary_api_sources']:
 assert sha(Path(x['path']))==x['sha256']
struct=json.loads((R/'STRUCTURAL-CHECK.json').read_text())
for x in struct['core_sources']:
 assert sha(Path(x['path']))==x['sha256']
for x in struct['copied_MF07_modules_lexically_checked']:
 assert sha(Path(x['path']))==x['sha256']
std=json.loads((S/'STANDARD-BINDINGS.json').read_text());standard_rows=[]
for x in std['standards']:
 assert sha(S/x['path'])==x['sha256'];standard_rows.append(x)
# Independently compare exact declaration headers and all advertised results.
c=(S/'Challenge.lean').read_text();mp=json.loads((S/'CONTRACT-MAP.json').read_text());cfg=json.loads((S/'comparator.json').read_text())
mt=list(re.finditer(r'^theorem\s+(\w+)([\s\S]*?)\s*:= by\n  sorry',c,re.M));assert len(mt)==14
for z,x in zip(mt,mp['contracts']):
 header=z.group(0).rsplit(' := by',1)[0]
 assert x['header']==header and x['header_sha256']==hashlib.sha256(header.encode()).hexdigest()
 assert x['declaration']=='NLA.MF05.'+z.group(1)
 assert x['line']==c.count('\n',0,z.start())+1
assert [x['declaration'] for x in mp['contracts']]==cfg['theorem_names']
meta=json.loads((S/'formalization.yaml').read_text());assert meta['version']=='v0.4'
assert [x['declaration'] for x in meta['status']['main_results']]==cfg['theorem_names']
assert meta['status']['whole_problem_verified'] is False
assert meta['status']['challenge_placeholder_count']==14
assert all(x['verification_status'].startswith('PENDING:') and x['file_sha256']==sha(S/'Challenge.lean') for x in meta['status']['main_results'])
files=[{'path':str(S/k),'bytes':(S/k).stat().st_size,'sha256':v} for k,v in actual.items()]
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'PASS','snapshot_manifest':{'path':str(mf),'sha256':h,'bytes':mf.stat().st_size},'snapshot_files':files,'snapshot_payload_count':len(actual),'snapshot_including_outer':len(actual)+1,'live_payloads_byte_identical':True,'live_source_no_extra_files':True,'retained_standards':standard_rows,'previous_independent_Git_and_API_checks_remain_identical':True,'all_14_exact_headers_and_metadata_maps_match':True,'reviewer_Lean_execution':False,'scope':'Exact source/metadata/configuration binding only; no proof or root-controlled elaboration/Comparator claim.'}
(R/'SNAPSHOT-BINDING.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'verdict':'PASS','snapshot_payloads':len(actual),'including_outer':len(actual)+1,'exact_contract_headers':len(mt),'live_byte_identical':True,'reviewer_Lean_execution':False},sort_keys=True))
