"""Verify this independent review and exact immutable MF05 statement bytes; no compiler or writes."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent
m=json.loads((R/'MANIFEST.json').read_text())
a={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file() and p!=R/'MANIFEST.json'}
assert a=={f['path'] for f in m['files']}
for f in m['files']:
 b=(R/f['path']).read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256'],f['path']
s=json.loads((R/'SNAPSHOT-BINDING.json').read_text())
for f in [s['snapshot_manifest']]+s['snapshot_files']:
 b=Path(f['path']).read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256'],f['path']
for group in ['published_sources','primary_api_sources']:
 for f in json.loads((R/'READ-ONLY-SOURCE-CHECK.json').read_text())[group]:
  b=Path(f['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==f['sha256'],f['path']
print(json.dumps({'verdict':'PASS','review_files_bound':len(m['files']),'review_files_including_outer':len(m['files'])+1,'snapshot_files_checked':len(s['snapshot_files'])+1,'reviewer_Lean_execution':False},sort_keys=True))
