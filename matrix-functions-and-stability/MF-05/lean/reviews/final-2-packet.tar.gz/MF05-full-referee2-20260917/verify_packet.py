#!/usr/bin/env python3
"""Read-only integrity and contract verifier. It does not run Lean or Comparator."""
from pathlib import Path
import hashlib,json,re,sys
R=Path(__file__).resolve().parent
checks=0
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(rel):return json.loads((R/rel).read_text())
def inert(p):return p+'.txt'if p.endswith(('.lean','.py'))else p
def modpath(m):return 'Solution.lean'if m=='NLA.MF05Solution'else m.replace('.','/')+'.lean'
def strip_comments(s):
 out=[];i=0;depth=0
 while i<len(s):
  if s[i:i+2]=='/-':depth+=1;i+=2
  elif depth and s[i:i+2]=='-/':depth-=1;i+=2
  elif depth:i+=1
  elif s[i:i+2]=='--':
   j=s.find('\n',i);i=len(s)if j<0 else j
  else:out.append(s[i]);i+=1
 return ''.join(out)
def norm(s):return ' '.join(s.split())
manifest=read('MANIFEST.json')
actual={str(p.relative_to(R))for p in R.rglob('*')if p.is_file()}
check(actual==set(manifest['payloads'])|{'MANIFEST.json','VERIFICATION.json'},'exact packet inventory')
for rel,h in manifest['payloads'].items():check(sha(R/rel)==h,('payload',rel))
for c in read('COPY-MAP.json')['files']:
 check(sha(R/c['path'])==c['sha256'],('copied input hash',c['path']))
 check((R/c['path']).stat().st_size==c['bytes'],('copied input length',c['path']))
original=read('snapshot/candidate/FULL-PROOF-SOURCE-MANIFEST.json')['payloads']
for rel,h in original.items():check(sha(R/'snapshot/candidate'/inert(rel))==h,('original source',rel))
final={rel:sha(R/'snapshot/final'/inert(rel))for rel in original if rel.endswith('.lean')}
changed={rel for rel,h in final.items()if original[rel]!=h}
check(changed=={'NLA/MF05/Scaling.lean','NLA/MF05/IdentityAdjoin.lean','NLA/MF05/RadiusTransfer.lean','NLA/MF05/Final.lean'},'exact four changed files')
freeze=read('snapshot/candidate/STATEMENT-FREEZE.json')
for rel,h in freeze['frozen_files'].items():
 check(sha(R/'snapshot/candidate'/inert(rel))==h,('original freeze',rel))
 check(sha(R/'snapshot/final'/inert(rel))==h,('final freeze',rel))
config=read('snapshot/final/comparator.json');contracts=read('snapshot/final/CONTRACT-MAP.json')['contracts']
names=[x['declaration']for x in contracts]
check(len(names)==14 and len(set(names))==14,'all fourteen distinct contracts')
check(config['theorem_names']==names and config['definition_names']==[],'Comparator exact inventory')
check(set(config['permitted_axioms'])=={'propext','Classical.choice','Quot.sound'},'permitted axioms')
imports={};texts={}
for rel in final:
 mod='NLA.MF05Solution'if rel=='Solution.lean'else rel[:-5].replace('/','.')
 text=(R/'snapshot/final'/inert(rel)).read_text();texts[mod]=text
 imports[mod]=[d for l in strip_comments(text).splitlines()if l.startswith('import ')for d in l[7:].split()if d.startswith('NLA.')]
seen=set();active=set();order=[]
def dfs(m):
 if m in seen:return
 check(m not in active,('import acyclicity',m));check(m in imports,('local import availability',m));active.add(m)
 for d in imports[m]:dfs(d)
 active.remove(m);seen.add(m);order.append(m)
dfs('NLA.MF05Solution')
check(len(seen)==32,'complete entrypoint closure')
check(not any('Challenge'in m for m in seen),'independent Challenge not imported')
headers=[]
for con in contracts:
 short=con['declaration'].split('.')[-1];pattern=rf'(?m)^theorem {re.escape(short)}\b[\s\S]*?(?=\s*:=)'
 found=[]
 for m in seen:
  matches=re.findall(pattern,texts[m]);found.extend((m,h)for h in matches)
 check(len(found)==1,('single implementation',short))
 m,h=found[0];check(norm(h)==norm(con['header']),('exact frozen header',short))
 challenge=(R/'snapshot/final/Challenge.lean.txt').read_text();ch=re.findall(pattern,challenge)
 check(len(ch)==1 and norm(ch[0])==norm(con['header']),('independent Challenge header',short))
 check(hashlib.sha256(con['header'].encode()).hexdigest()==con['header_sha256'],('original header hash',short))
 headers.append({'name':con['declaration'],'module':m,'line':texts[m][:texts[m].index(h)].count('\n')+1})
for m in seen:
 code=strip_comments(texts[m])
 check(re.search(r'\b(sorry|admit|axiom|native_decide|unsafe)\b',code)is None,('no proof hole/custom axiom/native escape',m))
 check('skipKernelTC'not in code and 'implemented_by'not in code,('no kernel bypass',m))
sol=texts['NLA.MF05Solution'];check(set(re.findall(r'#print axioms (\S+)',sol))==set(names),'all14 actual print commands');check(set(re.findall(r'#assert_trust kernel (\S+)',sol))==set(names),'all14 actual trust assertions')
check('interval_decide (trust := kernel)'in texts['NLA.MF05.Numerical'],'actual LeanCert certificate invocation')
check('half_radius_certificate'in texts['NLA.MF05.LocalBall']and 'half_radius_certificate.1'in texts['NLA.MF05.Final'],'certificate consumed in target chain')
check('word_action_bound'not in texts['NLA.MF05.RadiusTransfer']and 'word_spectral_bound_from_action'not in texts['NLA.MF05.RadiusTransfer'],'duplicate helpers removed')
check('spectralNorm_product_of_norm N'in texts['NLA.MF05.RadiusTransfer'],'published word-bound reuse')
check('List.smul_prod w.reverse c'in texts['NLA.MF05.Scaling'],'Mathlib list-scaling reuse')
check('List.prod_replicate, smul_pow, one_pow'in texts['NLA.MF05.IdentityAdjoin'],'Mathlib identity-word reuse')
check('have hc := holderConstant_pos hd (localNormBound M0) hball.1'in texts['NLA.MF05.Final'],'direct positivity reuse')
audit=read('evidence/RUNTIME-AUDIT.json');copies={c['source']:c['path']for c in read('COPY-MAP.json')['files']}
receipts={p:read(p)for p in set(audit['receipts'].values())}
assemblies={sha(p):json.loads(p.read_text())for p in (R/'evidence/assemblies').glob('*.json')}
runnerhashes={sha(p)for p in (R/'evidence/runners').glob('*')}
legacy={}
for p,r in receipts.items():
 for c in r.get('commands',[]):
  if 'exit_code'in c:legacy.setdefault(json.dumps(c,sort_keys=True),[]).append(p)
for run in ['139','141']:
 a=audit['audits'][run];base=receipts[a['root_receipt']];src=original if run=='139'else final;visited=set();terminal={}
 def visit(p,m,expected=None):
  r=receipts[p];cs=[c for c in r['commands']if c['module']==m];check(len(cs)==1,('single receipt command',p,m));c=cs[0]
  check(c['source_sha256']==src[modpath(m)],('source binding',run,p,m))
  if expected:check(all(c[k]==expected[k]for k in ['source_sha256','output_sha256']),('reuse binding',p,m))
  if(p,m)in visited:return
  visited.add((p,m));check(r['runner_sha256']in runnerhashes,('runner binding',p));check(r['assembly_sha256']in assemblies,('assembly binding',p))
  check(r['compiler_sha256']==audit['compiler_observed']['sha256'],('compiler binding',p));check(r['threads']==1 and r['max_compiler_processes']==1 and r['memory_cap_mib']<=4096,('resource limits',p))
  rel=m.replace('.','/')+'.lean';check(r['source_inputs'][rel]==c['source_sha256'],('receipt sources',p,m));av=assemblies[r['assembly_sha256']]['sources'][rel]
  check((av['sha256']if isinstance(av,dict)else av)==c['source_sha256'],('assembly sources',p,m))
  for name,h in c.get('transitive_source_hashes',{}).items():check(src['Solution.lean'if name=='NLA/MF05Solution.lean'else name]==h,('transitive source',p,m,name))
  if'exit_code'in c:
   check(c['exit_code']==0,('fresh successful command',p,m));check('--threads=1'in c['argv']and any(x in c['argv']for x in ['--memory=3072','--memory=4096']),('actual command limits',p,m))
   check(not any(x.startswith('--trust')or x.startswith('-t')for x in c['argv']),('default kernel trust',p,m))
   log=str(Path(p).parent/(m+'.log'));check(sha(R/log)==c['log_sha256'],('full compiler log',p,m));terminal[m]=(p,c)
  else:
   check(c.get('status')=='reused_exact_successful_local_output',('reuse status',p,m))
   if'prior_receipt'in c:
    q=audit['receipts'][c['prior_receipt']];check(sha(R/q)==c['prior_receipt_sha256'],('prior receipt hash',p,m))
   else:
    qs=legacy.get(json.dumps(c['prior_command'],sort_keys=True),[]);check(len(qs)==1,('unique entire embedded original command',p,m));q=qs[0]
   visit(q,m,c)
  for dep,h in c.get('dependency_olean_sha256',{}).items():
   dc=next(x for x in r['commands']if x['module']==dep);check(dc['output_sha256']==h,('dependency olean link',p,m,dep));visit(p,dep)
 for m in base['module_order']:visit(a['root_receipt'],m)
 check(set(base['module_order'])==seen,('actual complete source closure',run));check(len(visited)==a['nodes']and len(terminal)==32,('recursive audit totals',run))
 check(not base['failed_modules']and not base['blocked_modules'],('target run success',run))
 for rel in a['output_paths']:
  m=rel.split('-outputs/',1)[1][:-6].replace('/','.');c=next(x for x in base['commands']if x['module']==m);check(sha(R/rel)==c['output_sha256'],('observed original/final output',run,m))
 check(len(a['output_paths'])==(27 if run=='139'else 32),('truthful retained artifact count',run))
 ag=R/Path(a['root_receipt']).parent/'NLA.MF05Solution.log';matches=re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",ag.read_text());check(len(matches)==14 and {n for n,_ in matches}==set(names),('all14 aggregate observations',run))
 for n,axs in matches:check(set(x.strip()for x in axs.split(','))==set(config['permitted_axioms']),('observed standard3',run,n))
for gitread in read('evidence/INDEPENDENT-GIT-READS.json').get('commands',[]):
 check(gitread.get('exit_code',0)==0,'independent read-only Git exit')
verdict=read('VERDICT.json');check(verdict['final_verdict']=='approve'and verdict['original_verdict']=='block','separate original/final verdicts')
check(verdict['checks_not_run_by_this_referee']==['Lean compiler','LeanCert compiler rerun','Comparator','GitHub Actions','official Tau Ceti CLI/service'],'explicit no-unrun-success limits')
print(json.dumps({'status':'PASS','checks':checks,'manifest_sha256':sha(R/'MANIFEST.json'),'original_verdict':verdict['original_verdict'],'final_verdict':verdict['final_verdict'],'contracts':len(headers),'source_closure_modules':len(seen),'original_retained_outputs':27,'final_retained_outputs':32,'ran_Lean':False,'ran_Comparator':False},indent=2))
