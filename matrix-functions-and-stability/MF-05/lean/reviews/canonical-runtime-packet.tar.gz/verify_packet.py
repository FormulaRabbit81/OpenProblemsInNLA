#!/usr/bin/env python3
"""Read-only MF05 runtime evidence audit; executes no compiler, Git or network."""
import hashlib
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
COUNT = 0
COMMIT = '06b8cf49740205c4b7b0b71ee5c636855fbe26a6'
RUN = 35252365986
JOB = 105307710518
PROJECT = 'matrix-functions-and-stability/MF-05/lean'
LOGROOT = 'snapshot/runtime/artifacts/lean-MF-05/verify-20260917T172429Z-4155/'
STANDARD = {'propext', 'Classical.choice', 'Quot.sound'}


def check(ok, message):
    global COUNT
    if not ok:
        raise AssertionError(message)
    COUNT += 1


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def path(rel):
    p = ROOT / rel
    check(not p.is_symlink() and p.resolve().is_relative_to(ROOT), 'unsafe path: ' + rel)
    return p


def raw(rel):
    return path(rel).read_bytes()


def data(rel):
    return json.loads(raw(rel))


def text(rel):
    return raw(rel).decode()


def main():
    manifest = data('MANIFEST.json')
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    check(actual - {'MANIFEST.json', 'VERIFICATION.json'} == set(manifest['payloads']),
          'packet inventory changed')
    for rel, expected in manifest['payloads'].items():
        check(sha(raw(rel)) == expected, 'packet hash differs: ' + rel)

    snapshot = data('SNAPSHOT.json')
    for row in snapshot['files']:
        check(sha(raw(row['path'])) == row['sha256'], 'initial snapshot changed')
        check(len(raw(row['path'])) == row['bytes'], 'initial snapshot size changed')
    api = data('INDEPENDENT-API-FETCH.json')['observations']
    check(len(api) == 5, 'independent API count differs')
    for row in api:
        observed = raw('independent-api/' + row['name'])
        check(sha(observed) == row['stdout_sha256'], 'independent API output changed')
        if row['name'] != 'job-105307710518.log':
            check(row['exit_code'] == 0 and not row['stderr'], 'metadata/artifact fetch failed')
            check(observed == raw('snapshot/runtime/' + row['name']), 'root/fresh API bytes differ')
        else:
            check(row['exit_code'] == 1 and 'escape sequences' in row['stderr'],
                  'initial raw log refusal not preserved')
    retry = data('INDEPENDENT-LOG-RETRY.json')
    check(retry['exit_code'] == 0 and not retry['stderr'], 'raw log retry failed')
    check(sha(raw(retry['path'])) == retry['stdout_sha256'], 'raw log retry hash differs')
    check(raw(retry['path']) == raw('snapshot/runtime/job-105307710518.log'), 'job logs differ')

    run = data('independent-api/run.json')
    check(run['id'] == RUN and run['head_sha'] == COMMIT and run['run_attempt'] == 1,
          'wrong run identity')
    check(run['conclusion'] == 'success' and run['status'] == 'completed', 'run did not succeed')
    check(run['repository']['full_name'] == 'sgstepaniants/OpenProblemsInNLA', 'wrong repository')
    jobs = data('independent-api/jobs.json')['jobs']
    check(len(jobs) == 3, 'unexpected job scope')
    verify_jobs = [j for j in jobs if j['name'].startswith('verify (')]
    check(len(verify_jobs) == 1, 'expected only one selected proof project')
    job = verify_jobs[0]
    check(job['id'] == JOB and job['head_sha'] == COMMIT and job['run_id'] == RUN,
          'wrong verification job')
    check(job['conclusion'] == 'success' and job['labels'] == ['ubuntu-24.04'], 'wrong job result/platform')
    controls = next(j for j in jobs if j['name'] == 'checker-controls')
    check(controls['conclusion'] == 'skipped', 'dedicated checker-controls scope differs')
    selector = text('snapshot/runtime/job-105307549463.log')
    check('{"include":[{"id":"MF-05","project":"' + PROJECT + '"}]}' in selector,
          'selector log does not select exactly MF05')

    artifacts = data('independent-api/artifacts.json')['artifacts']
    check(len(artifacts) == 1 and artifacts[0]['id'] == 10512231092, 'artifact identity differs')
    archive = raw('independent-api/lean-MF-05.zip')
    check(artifacts[0]['digest'] == 'sha256:' + sha(archive), 'API artifact digest differs')
    check(artifacts[0]['workflow_run']['head_sha'] == COMMIT, 'artifact source commit differs')
    members = []
    with zipfile.ZipFile(path('independent-api/lean-MF-05.zip')) as z:
        for entry in z.infolist():
            if entry.is_dir():
                continue
            check(z.read(entry) == raw('snapshot/runtime/artifacts/lean-MF-05/' + entry.filename),
                  'extracted artifact member differs: ' + entry.filename)
            members.append(entry.filename)
    check(len(members) == 13, 'artifact member count differs')

    result = data(LOGROOT + 'result.json')
    check(result['repository_commit'] == COMMIT and result['project'] == PROJECT, 'runtime source differs')
    check(result['result'] == 'comparator-accepted', 'runtime did not accept')
    check(len(result['input_sha256']) == 193, 'runtime input count differs')
    bindings = data('SOURCE-BINDINGS.json')
    check(bindings['project_inputs_exact_runtime_match'] is True, 'source inventory check absent')
    project_paths = set()
    for row in bindings['files']:
        check(sha(raw(row['path'])) == row['sha256'], 'captured Git source hash differs')
        check(len(raw(row['path'])) == row['bytes'], 'captured Git source size differs')
        check(row['exit_code'] == 0 and row['argv'][-1] == COMMIT + ':' + row['repository_path'],
              'source capture command does not bind proof commit')
        if row['repository_path'].startswith(PROJECT + '/'):
            rel = row['repository_path'][len(PROJECT) + 1:]
            project_paths.add(rel)
            check(row['sha256'] == result['input_sha256'][rel], 'runtime/source hash mismatch: ' + rel)
    check(project_paths == set(result['input_sha256']), 'runtime/source path inventories differ')
    check(not raw('snapshot/checker/unchanged-from-upstream.diff'), 'trusted checker changed')
    lock = raw('snapshot/checker/tools/lean/source-lock.json')
    check(sha(lock) == result['source_lock_sha256'] ==
          'b3833b07916e5db77579b9cc53ca582282f6a841f36d6a60d693e5b02d342b6b', 'checker lock mismatch')
    receipt = result['tool_receipt']
    check(receipt['source_lock_sha256'] == sha(lock), 'tool receipt lock differs')
    check(receipt['forsythe_commit'] == '8d1b0c0545a77b40245e84705aa7d273e6c81e62', 'checker pin differs')
    check(receipt['lean_toolchain'] == 'leanprover/lean4:v4.33.1' and
          receipt['platform'].startswith('Linux-'), 'toolchain/platform mismatch')

    prior_manifest_raw = raw('snapshot/prior-approved-review/MANIFEST.json')
    check(sha(prior_manifest_raw) == '9ce7e23fe43444c67e9e5430cbf80e39addb8d220e248e53dd4826c8e494797e',
          'original full mathematical approval manifest differs')
    prior_manifest = json.loads(prior_manifest_raw)['payloads']
    prior_verdict = data('snapshot/prior-approved-review/VERDICT.json')
    check(prior_verdict['final_verdict'] == 'approve', 'source review not approved')
    check(sha(raw('snapshot/prior-approved-review/VERDICT.json')) == prior_manifest['VERDICT.json'],
          'source review verdict not manifest-bound')
    source_comparison = data('APPROVED-SOURCE-COMPARISON.json')
    check(len(source_comparison['files']) == 36, 'active source count differs')
    for row in source_comparison['files']:
        observed = sha(raw('snapshot/published-project/' + row['path']))
        check(observed == row['published_sha256'] == prior_manifest[row['prior_approved_manifest_key']],
              'approved mathematical source differs: ' + row['path'])
    frozen = data('snapshot/published-project/STATEMENT-FREEZE.json')['frozen_files']
    check(len(frozen) == 6, 'statement freeze scope differs')
    for name, expected in frozen.items():
        rel = name + '.txt' if name.endswith('.lean') else name
        check(sha(raw('snapshot/published-project/' + rel)) == expected, 'statement freeze changed: ' + name)

    config = data('snapshot/published-project/comparator.json')
    names = config['theorem_names']
    check(config == result['config'] and len(names) == 14, 'actual Comparator contract scope differs')
    check(set(config['permitted_axioms']) == STANDARD and config['definition_names'] == [],
          'axiom/definition configuration differs')
    modules = {row['path'][:-9].replace('/', '.'): row['path'] for row in source_comparison['files']}
    closure = set()
    todo = ['Solution']
    while todo:
        module = todo.pop()
        if module in closure:
            continue
        closure.add(module)
        source = text('snapshot/published-project/' + modules[module])
        check(not re.search(r'^import Challenge\s*$', source, re.M), 'Solution closure imports Challenge')
        todo.extend(re.findall(r'^import (NLA\.[A-Za-z0-9_.]+)\s*$', source, re.M))
    check(len(closure) == 32, 'actual source import closure differs')
    comparator = text(LOGROOT + 'comparator.log')
    solution = text('snapshot/published-project/Solution.lean.txt')
    for name in names:
        lines = re.findall(r"info: Solution\.lean:\d+:0: '" + re.escape(name) +
                           r"' depends on axioms: \[([^]]+)\]", comparator)
        check(len(lines) == 1 and set(lines[0].split(', ')) == STANDARD, 'wrong aggregate axioms: ' + name)
        check('#assert_trust kernel ' + name in solution, 'missing kernel trust assertion: ' + name)
    exports = [line for line in comparator.splitlines() if line.startswith('Exporting #[')]
    check(len(exports) == 2 and exports[0].endswith(' from Challenge') and exports[1].endswith(' from Solution'),
          'expected two actual exports')
    for line in exports:
        check(re.findall(r'NLA\.MF05\.[A-Za-z_]+', line) == names, 'export names/order differ')
    for marker in ['Running Lean default kernel on solution.', 'Lean default kernel accepts the solution',
                   'Your solution is okay!', 'EXIT_STATUS=0']:
        check(marker in comparator, 'Comparator acceptance phase missing: ' + marker)
    check('interval_decide (trust := kernel)' in text('snapshot/published-project/NLA/MF05/Numerical.lean.txt'),
          'actual kernel certificate source missing')
    check('have hhalf := half_radius_certificate' in text('snapshot/published-project/NLA/MF05/LocalBall.lean.txt'),
          'certificate consumption missing')

    required = {
        'comparator-controls.log': ['PASS: all five Comparator regressions', 'EXIT_STATUS=0'],
        'kernel-controls.log': ['RETURN honest_with_inductives_and_quotients: accepted',
                                'RETURN invalid_raw_proof: rejected:', 'Quotient post-check rejects the solution',
                                'PASS: all three actual Comparator.runBuiltinKernel cases behaved as required', 'EXIT_STATUS=0'],
        'negative-sorry.log': ["Illegal axiom detected: 'sorryAx'", 'EXIT_STATUS=1'],
        'negative-native.log': ["Illegal axiom detected: 'checked._native.native_decide.ax_1_1'", 'EXIT_STATUS=1'],
        'sandbox.log': ['MODE build: exit=0', 'MODE export: exit=0', 'Sandbox UID: 1001',
                        'PASS effective capabilities: none', 'PASS no_new_privs: set',
                        'PASS host loopback listener: unreachable', 'PASS AF_UNIX socket creation: denied',
                        'PASS symlink from .lake to outside write: denied',
                        'NEGATIVE unknown option: exit=2', 'NEGATIVE unexpected --rw: exit=2',
                        'NEGATIVE unexpected --rwx: exit=2', 'NEGATIVE relative --rwx: exit=2', 'EXIT_STATUS=0'],
        'dependencies.log': ["checking out revision '621a43d7cf21f87872392a01e874f2f1dbddc926'",
                             "checking out revision '0df444a360eaa60ab8c11dca51a86af692955474'", 'EXIT_STATUS=0']
    }
    for name, markers in required.items():
        contents = text(LOGROOT + name)
        for marker in markers:
            check(marker in contents, 'actual control/dependency evidence absent: ' + name + ' / ' + marker)
    verdict = data('VERDICT.json')
    check(verdict['verdict'] == 'approve' and verdict['source_commit'] == COMMIT, 'verdict source differs')
    check(verdict['independent_compiler_rerun'] is False and verdict['independent_comparator_rerun'] is False,
          'must not claim this read-only audit reran compiler/checker')
    print(json.dumps({'result': 'PASS', 'checks': COUNT, 'source_commit': COMMIT,
                      'run_id': RUN, 'contract_count': 14, 'compiler_executions_by_verifier': 0,
                      'network_executions_by_verifier': 0,
                      'scope': 'read-only captured runtime/source/approval integrity and evidence bindings'}, sort_keys=True))


if __name__ == '__main__':
    main()
