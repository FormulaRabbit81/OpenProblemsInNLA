from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
m=json.loads((p/'MANIFEST.json').read_text())
assert {str(f.relative_to(p)) for f in p.rglob('*') if f.is_file() and f!=p/'MANIFEST.json'}==set(m['files'])
for r,s in m['files'].items():assert h(p/r)==s,r
for f in json.loads((p/'BINDINGS.json').read_text())['files']:assert h(Path(f['path']))==f['sha256'],f['path']
print('PASS exact root statement review, frozen sources and actual local-127 evidence; no new Lean/Comparator run')
