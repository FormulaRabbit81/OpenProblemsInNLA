#!/usr/bin/env python3
"""Verify sealed audit integrity; optionally compare the originally audited package."""
from pathlib import Path
import argparse,hashlib,json

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--package',type=Path);args=ap.parse_args()
    root=Path(__file__).resolve().parent;manifest=json.loads((root/'MANIFEST.json').read_text())
    for rel,h in manifest['payloads'].items():assert digest(root/rel)==h,rel
    assert not {str(f.relative_to(root)) for f in root.rglob('*') if f.is_file()}-set(manifest['payloads'])-{'MANIFEST.json','VERIFICATION.json'}
    checks=json.loads((root/'CHECKS.json').read_text());verdict=json.loads((root/'VERDICT.json').read_text())
    assert checks['result']=='PASS' and checks['check_count']==4942
    assert verdict['scope']=='publication package readiness before Linux Comparator'
    assert verdict['reviewer_Lean_execution'] is False and verdict['reviewer_Comparator_execution'] is False
    assert verdict['count_change']==0
    compared=0
    if args.package:
        for rel,h in checks['package_sha256'].items():assert digest(args.package/rel)==h,rel;compared+=1
    print(json.dumps({'result':'PASS','audit_payloads':len(manifest['payloads']),
      'original_package_files_compared':compared,'contracts':14,'closure_modules':32,
      'reviewer_Lean_execution':False,'reviewer_Comparator_execution':False,'count_change':0},indent=2))

if __name__=='__main__':main()
