#!/usr/bin/env python3
"""Read-only MF05 package evidence checks. Does not execute Lean or copied code."""
from pathlib import Path, PurePosixPath
import argparse, datetime, hashlib, importlib.util, json, re, tarfile
try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib

def sha(b):
    return hashlib.sha256(b).hexdigest()

def lean_code(s):
    # Remove nested Lean comments and string contents while retaining newlines.
    out, i, depth, string = [], 0, 0, False
    while i < len(s):
        if depth:
            if s.startswith('/-', i): depth += 1; out.append('  '); i += 2
            elif s.startswith('-/', i): depth -= 1; out.append('  '); i += 2
            else: out.append('\n' if s[i] == '\n' else ' '); i += 1
        elif string:
            if s[i] == '\\': out.append('  '); i += 2
            elif s[i] == '"': string = False; out.append(' '); i += 1
            else: out.append('\n' if s[i] == '\n' else ' '); i += 1
        elif s.startswith('/-', i): depth = 1; out.append('  '); i += 2
        elif s.startswith('--', i):
            end = s.find('\n', i)
            if end < 0: end = len(s)
            out.append(' ' * (end-i)); i = end
        elif s[i] == '"': string = True; out.append(' '); i += 1
        else: out.append(s[i]); i += 1
    assert depth == 0 and not string
    return ''.join(out)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('package',type=Path)
    ap.add_argument('repo',type=Path)
    args=ap.parse_args(); p=args.package.resolve(); repo=args.repo.resolve()
    initial={str(f.relative_to(p)):sha(f.read_bytes()) for f in p.rglob('*') if f.is_file()}
    checks=[]
    def ck(value, label):
        if not value: raise AssertionError(label)
        checks.append(label)
    def j(rel): return json.loads((p/rel).read_text())
    def match(rel, digest): ck(sha((p/rel).read_bytes())==digest,'sha:'+rel)
    metadata=j('formalization.yaml'); cfg=j('comparator.json'); freeze=j('STATEMENT-FREEZE.json')
    targets=cfg['theorem_names']; ck(len(targets)==len(set(targets))==14,'14 distinct contracts')
    ck(cfg['definition_names']==[],'no replaceable definition holes')
    allowed={'propext','Classical.choice','Quot.sound'}
    ck(set(cfg['permitted_axioms'])==allowed,'exact three permitted axioms')
    ck(cfg['challenge_module']=='Challenge' and cfg['solution_module']=='Solution','canonical module names')
    for rel,h in freeze['frozen_files'].items(): match(rel,h)
    ck(len(freeze['frozen_files'])==6,'six frozen mathematical boundary files')
    ck(freeze['new_implementation_count_at_freeze']==0,'freeze predates proof bodies')
    ck(len(freeze['independent_nonauthor_statement_reviews'])==2,'two statement approvals before freeze')
    status=metadata['status']; ck(status['whole_problem_verified'] is False,'whole-problem acceptance remains pending')
    ck(status['sorry_count']==status['sorry_in_definitions']==0,'zero implementation sorry metadata')
    ck(metadata['verification']['github_comparator']['result']=='not run','unrun Comparator truthfully pending')
    ck(metadata['verification']['local']['last_run']==143,'active metadata identifies actual run143')
    ck(j('STATE.json')['count_change']==0,'no count increase')
    # The current repository validator is read before invoking its pure validation API.
    validator_path=repo/'tools/lean/validate_manifest.py'
    spec=importlib.util.spec_from_file_location('manifest_validator',validator_path)
    validator=importlib.util.module_from_spec(spec); spec.loader.exec_module(validator)
    schema_path=repo/'docs/lean/schema/v0.4.schema.json'
    ck(schema_path.read_bytes()==(p/'sources/standards/v0.4.schema.json').read_bytes(),'repository schema matches pinned source')
    ck(schema_path.read_bytes()==(p/'sources/standards/mathlib-initiative/formalization.yaml/schema/v0.4.schema.json').read_bytes(),'primary v0.4 schema copy identical')
    validator.validate(p,json.loads(schema_path.read_text())); checks.append('actual repository metadata/schema/coverage validator passed')
    contracts=j('CONTRACT-MAP.json')['contracts']; results={r['declaration']:r for r in status['main_results']}
    challenge=lean_code((p/'Challenge.lean').read_text())
    impl=[p/'Solution.lean']+sorted((p/'NLA').rglob('*.lean'))
    for f in impl:
        code=lean_code(f.read_text())
        ck(not re.search(r'\b(?:sorry|admit|axiom|native_decide|unsafe)\b',code),'no holes/custom axioms/native/unsafe:'+str(f.relative_to(p)))
        ck(not re.search(r'^import\s+.*\bChallenge\b',code,re.M),'no Challenge import:'+str(f.relative_to(p)))
    ck(len(re.findall(r'\bsorry\b',challenge))==14,'Challenge has only14 intended specification holes')
    normalize=lambda s:' '.join(s.split())
    for c in contracts:
        name=c['declaration']; short=name.rsplit('.',1)[1]; r=results[name]
        match(r['file'],r['file_sha256'])
        ck(sha(c['header'].encode())==c['header_sha256'],'frozen header digest:'+name)
        for rel in ['Challenge.lean',r['file']]:
            text=lean_code((p/rel).read_text())
            found=re.search(r'\btheorem\s+'+re.escape(short)+r'\b(.*?)\s*:=',text,re.S)
            ck(found is not None,'header present:'+rel+':'+name)
            actual='theorem '+short+found.group(1)
            ck(normalize(actual)==normalize(c['header']),'exact normalized header:'+rel+':'+name)
        lines=(p/r['file']).read_text().splitlines()
        ck(re.search(r'\btheorem\s+'+re.escape(short)+r'\b',lines[r['line']-1]) is not None,'metadata declaration line:'+name)
    # Compute the active Solution import closure from source rather than trusting its count.
    closure={}
    def visit(module):
        if module in closure:return
        rel=module.replace('.','/')+'.lean'; f=p/rel
        ck(f.is_file(),'closure source exists:'+module)
        code=lean_code(f.read_text()); closure[module]=rel
        for line in re.findall(r'^\s*import\s+([^\n]+)',code,re.M):
            for dep in line.split():
                if dep.startswith('NLA.') or dep=='Challenge':visit(dep)
    visit('Solution'); ck(len(closure)==32,'actual32-module import closure')
    ck('Challenge' not in closure,'Solution closure independent of Challenge')
    complete=j('verification/LOCAL-COMPLETE.json')
    ck(set(complete['sources'])==set(closure.values()),'local143 exact complete source closure')
    for rel,h in complete['sources'].items():match(rel,h)
    local=p/'verification/local-development'
    def relocate(path):
        s=str(path)
        if '/runs/' in s:return local/'runs'/s.split('/runs/',1)[1]
        return local/Path(s).name
    rec_path=relocate(complete['receipt']); rec=json.loads(rec_path.read_text())
    ck(sha(rec_path.read_bytes())==complete['receipt_sha256'],'actual143 receipt hash')
    ck(sha(relocate(complete['assembly']).read_bytes())==complete['assembly_sha256']==rec['assembly_sha256'],'actual143 assembly binding')
    ck(rec['completed_modules']==32 and not rec['failed_modules'] and not rec['blocked_modules'],'actual143 complete successful closure')
    ck(rec['threads']==1 and rec['max_compiler_processes']==1 and rec['memory_cap_mib']==4096,'actual143 serial resource limits')
    ck(set(rec['module_order'])==set(closure),'actual143 source-derived module set')
    fresh=[x for x in rec['commands'] if x.get('status')!='reused_exact_successful_local_output']
    ck(len(fresh)==1 and fresh[0]['module']=='Solution','actual143 exactly one fresh canonical Solution compile')
    fresh=fresh[0]; ck(fresh['exit_code']==0,'fresh canonical Solution exited0')
    ck(fresh['argv'][-1]=='Solution.lean' and '--threads=1' in fresh['argv'] and '--memory=4096' in fresh['argv'],'canonical fresh command exact input and limits')
    log=(rec_path.parent/'Solution.log').read_bytes(); ck(sha(log)==fresh['log_sha256'],'actual canonical Solution log hash')
    printed=re.findall(r"^'([^']+)' depends on axioms: \[([^\]]*)\]$",log.decode(),re.M)
    ck(len(printed)==14 and {n for n,_ in printed}==set(targets),'actual canonical log all14 target names')
    ck(all({a.strip() for a in axioms.split(',')}==allowed for _,axioms in printed),'actual canonical log standard axioms only')
    ck(len(log.decode().splitlines())==14,'canonical aggregate log has no warnings or errors')
    solution=(p/'Solution.lean').read_text()
    ck(set(re.findall(r'^#assert_trust kernel (\S+)',solution,re.M))==set(targets),'all14 canonical kernel trust assertions')
    for absolute,h in complete['retained_original_evidence'].items():
        ck(sha(relocate(absolute).read_bytes())==h,'retained origin receipt/log:'+str(relocate(absolute).relative_to(p)))
    all_receipts={f:json.loads(f.read_text()) for f in (local/'runs').glob('*/RECEIPT.json')}
    traced={}
    def trace(receipt_path,module):
        key=(receipt_path,module)
        if key in traced:return traced[key]
        rows=[x for x in all_receipts[receipt_path]['commands'] if x['module']==module]
        ck(len(rows)==1,'unique actual command:'+receipt_path.parent.name+':'+module)
        row=rows[0]
        ck(row['source_sha256']==sha((p/closure[module]).read_bytes()),'recursive current source:'+receipt_path.parent.name+':'+module)
        if row.get('status')=='reused_exact_successful_local_output':
            if 'prior_receipt' in row:
                prior=relocate(row['prior_receipt'])
                ck(sha(prior.read_bytes())==row['prior_receipt_sha256'],'recursive receipt hash:'+receipt_path.parent.name+':'+module)
                for rel,h in row['transitive_source_hashes'].items():match(rel,h)
            else:
                candidates=[rp for rp,rd in all_receipts.items() if row['prior_command'] in rd['commands']]
                ck(len(candidates)==1,'legacy embedded prior command unique actual origin:'+module)
                prior=candidates[0]
            origin=trace(prior,module)
            ck(row['output_sha256']==origin['output_sha256'],'recursive same output:'+receipt_path.parent.name+':'+module)
        else:
            ck(row.get('exit_code')==0,'recursive fresh successful origin:'+receipt_path.parent.name+':'+module)
            for dep,h in row['dependency_olean_sha256'].items():
                ck(trace(receipt_path,dep)['output_sha256']==h,'recursive dependency output:'+receipt_path.parent.name+':'+module+':'+dep)
            origin=row
        traced[key]=origin;return origin
    for module in closure:trace(rec_path,module)
    # Confirm every claimed successful origin command and its exact source/log.
    for origin in complete['commands_and_successful_origins']:
        op=relocate(origin['success_origin_receipt']); ob=json.loads(op.read_text()); oc=origin['command']
        ck(sha(op.read_bytes())==origin['receipt_sha256'],'origin receipt:'+origin['module'])
        ck(oc in ob['commands'] and oc.get('exit_code')==0,'origin actual fresh success:'+origin['module'])
        ck(trace(rec_path,origin['module'])==oc,'independently traced origin equals summary:'+origin['module'])
        ck(oc['source_sha256']==sha((p/origin['canonical_source_path']).read_bytes()),'origin current source:'+origin['module'])
        ol=op.parent/(origin['module']+'.log')
        ck(sha(ol.read_bytes())==oc['log_sha256'],'origin log:'+origin['module'])
        ck('--threads=1' in oc['argv'] and any(x in oc['argv'] for x in ['--memory=4096','--memory=3072']),'origin resource limits:'+origin['module'])
    # Authenticate all four archive inventories without extracting or executing them.
    archive_payloads=0; email_candidates=[]
    def scan_emails(name,data):
        text=data.decode('utf-8',errors='ignore')
        for email in re.findall(r'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}',text):
            if re.search(r'george|stepaniants|sgstep|gstep',email,re.I):email_candidates.append((name,sha(email.encode())))
    for f in p.rglob('*'):
        if f.is_file() and not f.name.endswith('.tar.gz'):scan_emails(str(f.relative_to(p)),f.read_bytes())
    for index in j('reviews/INDEX.json'):
        archive=p/'reviews'/index['archive']; ck(sha(archive.read_bytes())==index['archive_sha256'],'archive hash:'+index['label'])
        with tarfile.open(archive) as tf:
            payloads={}
            for member in tf.getmembers():
                parts=PurePosixPath(member.name).parts
                ck(not member.name.startswith('/') and '..' not in parts and not member.issym() and not member.islnk(),'safe archive path:'+index['label']+':'+member.name)
                if member.isfile():
                    rel='/'.join(parts[1:]); ck(rel not in payloads,'unique archive member:'+index['label']+':'+rel)
                    payloads[rel]=tf.extractfile(member).read();scan_emails(index['archive']+'!'+rel,payloads[rel])
            ck(len(payloads)==index['files'],'archive file count:'+index['label'])
            man=payloads['MANIFEST.json'];ck(sha(man)==index['manifest_sha256'],'archive manifest:'+index['label'])
            ck(man==(p/'reviews'/index['manifest']).read_bytes(),'exposed manifest identity:'+index['label'])
            md=json.loads(man); records=md.get('payloads',md.get('files'))
            if isinstance(records,list):records={r['path']:r['sha256'] for r in records}
            extra=set(payloads)-set(records)-{'MANIFEST.json'}
            ck(set(records)<=set(payloads),'archive no missing manifest payload:'+index['label'])
            ck(extra==({'VERIFICATION.json'} if index['label']=='final-2' else set()),'archive inventory with separately archive-bound post-seal result:'+index['label'])
            if extra:
                vr=json.loads(payloads['VERIFICATION.json'])
                ck(vr['manifest_sha256']==index['manifest_sha256'] and vr['exit_code']==0,'post-seal verifier identifies exact manifest and success')
                vo=json.loads(vr['stdout'])
                ck(vo['status']=='PASS' and vo['ran_Lean'] is False and vo['ran_Comparator'] is False,'post-seal verifier scope is integrity only')
            for rel,h in records.items():ck(sha(payloads[rel])==h,'archive payload:'+index['label']+':'+rel)
            report='FINAL-REVIEW.md' if index['label']=='final-1' else 'REVIEW.md'
            verdict='FINAL-VERDICT.json' if index['label']=='final-1' else 'VERDICT.json'
            ck(payloads[report]==(p/'reviews'/index['report']).read_bytes(),'exposed report identity:'+index['label'])
            ck(payloads[verdict]==(p/'reviews'/index['verdict']).read_bytes(),'exposed verdict identity:'+index['label'])
            archive_payloads+=len(payloads)
    ck(not email_candidates,'no George-identifying email in package or review archives')
    r1=j('reviews/final-1-verdict.json');r2=j('reviews/final-2-verdict.json')
    ck(r1['overall']=='approve' and r1['independent_nonauthor'],'finalreferee1 nonauthor approval')
    ck(r2['final_verdict']=='approve','finalreferee2 approval')
    for rel,h in r1['effective_source_hashes'].items():match(rel,h)
    ck(len(r2['module_coverage'])==32,'finalreferee2 complete32-module reviewed boundary')
    for entry in r2['module_coverage']:match(entry['source'],entry['sha256'])
    ck(r1['reviewer']!=r2['reviewer'] and r1['reviewer'] not in ['/root',freeze['author']] and r2['reviewer'] not in ['/root',freeze['author']],'final reviewers distinct from statement/proof authors')
    lake=tomllib.loads((p/'lakefile.toml').read_text()); manifest=j('lake-manifest.json')
    ck(lake['name']==manifest['name']=='NLAMF05','Lake package names consistent')
    ck(lake['defaultTargets']==['Solution'],'default Lake build selects Solution')
    ck({x['name'] for x in lake['lean_lib']}=={'NLA','Challenge','Solution'},'Lake libraries registered')
    pins={x['name']:x['rev'] for x in manifest['packages']}
    ck(pins['leancert']==metadata['toolchain']['leancert']==lake['require'][0]['rev']=='621a43d7cf21f87872392a01e874f2f1dbddc926','LeanCert pin consistency')
    ck(pins['mathlib']==metadata['toolchain']['mathlib']=='0df444a360eaa60ab8c11dca51a86af692955474','Mathlib pin consistency')
    ck((p/'lean-toolchain').read_text().strip()==metadata['toolchain']['lean']=='leanprover/lean4:v4.33.1','Lean toolchain consistency')
    ck('interval_decide (trust := kernel)' in (p/'NLA/MF05/Numerical.lean').read_text(),'explicit kernel LeanCert certificate')
    for rel in ['NLA/MF05/LocalBall.lean','NLA/MF05/Final.lean']:
        ck('half_radius_certificate' in lean_code((p/rel).read_text()),'certificate consumed:'+rel)
    for record in j('STANDARD-BINDINGS.json')['standards']:match(record['path'],record['sha256'])
    ck('lake build\n' in (p/'README.md').read_text() and 'lake build -j' not in (p/'README.md').read_text(),'simple valid-shape reproduction command')
    final={str(f.relative_to(p)):sha(f.read_bytes()) for f in p.rglob('*') if f.is_file()}
    ck(initial==final,'audited package unchanged throughout checks')
    print(json.dumps({'result':'PASS','time':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'reviewer':'/root/mf05_publication_audit','scope':'Read-only publication metadata, exact source/review/log integrity and package readiness; not an independent Lean/Comparator rerun or a third full mathematical source review',
      'checks':checks,'check_count':len(checks),'package_file_count':len(initial),'package_sha256':initial,
      'archive_payload_count':archive_payloads,'contracts':14,'closure_modules':32,'fresh143_compiler_commands':1,'reused143_modules':31,
      'recursively_traced_receipt_module_nodes':len(traced),
      'actual143_receipt_sha256':sha(rec_path.read_bytes()),'actual143_log_sha256':sha(log),
      'validator_sha256':sha(validator_path.read_bytes()),'schema_sha256':sha(schema_path.read_bytes()),
      'reviewer_Lean_execution':False,'reviewer_Comparator_execution':False,'count_change':0},indent=2))

if __name__=='__main__':main()
