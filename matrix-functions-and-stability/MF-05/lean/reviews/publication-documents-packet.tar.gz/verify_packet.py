#!/usr/bin/env python3
"""Read-only publication-doc snapshot audit; no compiler, network, Git or writes."""
import hashlib
import json
import re
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
COUNT = 0
PREFIX = 'snapshot/final/matrix-functions-and-stability/MF-05/'
COMMIT = '06b8cf49740205c4b7b0b71ee5c636855fbe26a6'


def check(ok, message):
    global COUNT
    if not ok:
        raise AssertionError(message)
    COUNT += 1


def sha(b):
    return hashlib.sha256(b).hexdigest()


def read(rel):
    p = ROOT / rel
    check(not p.is_symlink() and p.resolve().is_relative_to(ROOT), 'unsafe packet path')
    return p.read_bytes()


def data(rel):
    return json.loads(read(rel))


def text(rel):
    return read(rel).decode()


def main():
    manifest = data('MANIFEST.json')['payloads']
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    check(actual - {'MANIFEST.json', 'VERIFICATION.json'} == set(manifest), 'packet inventory differs')
    for rel, expected in manifest.items():
        check(sha(read(rel)) == expected, 'packet hash changed: ' + rel)
    for index in ['SNAPSHOT.json', 'FINAL-DOCS-SNAPSHOT.json']:
        for row in data(index)['files']:
            check(sha(read(row['path'])) == row['sha256'], 'document capture binding differs')
            check(len(read(row['path'])) == row['bytes'], 'document capture length differs')

    runtime_manifest_raw = read('snapshot/runtime-audit/MANIFEST.json')
    check(sha(runtime_manifest_raw) == '8c029664395caa6271561f14b9143a7880027754c5cb5f63cf2fd43ec5f98d52',
          'sealed runtime approval manifest differs')
    runtime_manifest = json.loads(runtime_manifest_raw)['payloads']
    runtime_result = data('snapshot/runtime-audit/result.json')
    check(runtime_result['repository_commit'] == COMMIT, 'wrong accepted proof source')
    runtime_verdict = data('snapshot/runtime-audit/VERDICT.json')
    check(runtime_verdict['verdict'] == 'approve' and runtime_verdict['run_id'] == 35252365986,
          'runtime approval missing')
    integrated = data('INTEGRATED-RUNTIME-REVIEW-CHECK.json')['files']
    check(len(integrated) == 4, 'integrated runtime-review file scope differs')
    for row in integrated:
        check(sha(read(row['path'])) == row['sha256'], 'integrated review file changed')
    archive = ROOT / 'snapshot/integrated-runtime-review/canonical-runtime-packet.tar.gz'
    check(sha(archive.read_bytes()) == '992394a609d50422c655bd8d61f588e774ad86930b79d097a888dde2fceb75a6',
          'integrated runtime archive differs')
    members = {}
    with tarfile.open(archive, 'r:gz') as t:
        for member in t.getmembers():
            check(not member.issym() and not member.islnk(), 'archive symlink forbidden')
            if not member.isfile():
                continue
            name = member.name[2:] if member.name.startswith('./') else member.name
            check(name not in members, 'duplicate archive entry')
            content = t.extractfile(member).read()
            members[name] = sha(content)
            if name in runtime_manifest:
                check(sha(content) == runtime_manifest[name], 'archived runtime payload changed')
            else:
                check(name in {'MANIFEST.json', 'VERIFICATION.json'}, 'unexpected archive payload')
                check(content == read('snapshot/runtime-audit/' + name), 'runtime envelope differs')
    check(len(members) == 251 and set(members) == set(runtime_manifest) | {'MANIFEST.json', 'VERIFICATION.json'},
          'runtime archive inventory differs')

    protected = data('PROTECTED-AND-EVIDENCE-CHECK.json')
    transition = data('snapshot/MF05-PUBLICATION-DOCS-TRANSITION.json')
    check(protected['protected_input_count'] == len(protected['protected_inputs']) == 44,
          'protected source count differs')
    for row in protected['protected_inputs']:
        check(row['sha256'] == transition['protected_inputs'][row['path']] ==
              runtime_result['input_sha256'][row['path']], 'protected input not bound to accepted proof')
    check(len(protected['copied_actual_runtime_files']) == 21, 'runtime copy scope differs')
    for row in protected['copied_actual_runtime_files']:
        rel = row['published_evidence_path'].removeprefix('verification/linux-2026-09-17/')
        check(row['sha256'] == runtime_manifest['snapshot/runtime/' + rel], 'published raw runtime copy differs')

    anchor = '## Context and notation\n'
    canonical = text(PREFIX + 'README.md')
    old = text('snapshot/proof-commit/matrix-functions-and-stability/MF-05/README.md')
    check(canonical.split(anchor, 1)[1] == old.split(anchor, 1)[1], 'original mathematical statement changed')
    check('**Status:** Lean verified' in canonical and COMMIT in canonical, 'canonical evidence status differs')
    readme = text(PREFIX + 'lean/README.md')
    check('tools/lean/bootstrap.sh /tmp/nla-mf05-tools\n'
          'tools/lean/verify.sh matrix-functions-and-stability/MF-05/lean /tmp/nla-mf05-tools' in readme,
          'required bootstrap reproduction fix missing')
    check('\nlake build\n' in readme, 'simple local reproduction missing')
    evidence = text(PREFIX + 'lean/verification/linux-2026-09-17/README.md')
    check('In the submitted proof sources, only the 14 intentional Challenge specification placeholders' in evidence,
          'placeholder/control scope correction missing')
    check('will be recorded in the PR when completed' in evidence,
          'future run status correction missing')
    metadata = data(PREFIX + 'lean/formalization.yaml')
    check(metadata['version'] == 'v0.4', 'schema version differs')
    check(metadata['project']['authors'] == ['George Stepaniants'], 'author differs')
    check(metadata['project']['affiliations']['George Stepaniants'] ==
          'Department of Computing and Mathematical Sciences, California Institute of Technology',
          'department/university affiliation differs')
    github = metadata['verification']['github_comparator']
    check(github['published_commit'] == COMMIT and github['run'] == 35252365986 and
          github['job'] == 105307710518 and github['input_count'] == 193 and github['exports'] == 14,
          'published runtime identity differs')
    check(metadata['status']['whole_problem_verified'] is True and metadata['status']['sorry_count'] == 0,
          'formalization status differs')
    names = runtime_result['config']['theorem_names']
    check([row['declaration'] for row in metadata['status']['main_results']] == names,
          'metadata does not cover exact contracts')
    for row in metadata['status']['main_results']:
        check(COMMIT in row['verification_status'] and '35252365986' in row['verification_status'],
              'contract verification claim is not source-bound')
        check(set(row['axioms']) == {'propext', 'Classical.choice', 'Quot.sound'}, 'wrong stated axioms')
    schema = data('FINAL-SCHEMA-CHECK.json')
    check(schema['exit_code'] == 0 and 'PASS (14 declarations)' in schema['stdout'], 'actual schema check did not pass')
    check(schema['manifest_sha256'] == sha(read(PREFIX + 'lean/formalization.yaml')),
          'final metadata differs from validated bytes')

    commands = data('snapshot/coordinator-checks/COMMANDS.json')
    check(len(commands) == 6, 'ancillary coordinator command scope differs')
    for command in commands:
        check(command['exit_code'] == 0, 'ancillary coordinator command failed')
        check(sha(read('snapshot/coordinator-checks/' + command['log'])) == command['log_sha256'],
              'ancillary coordinator log changed')
    check('Ran 17 tests' in text('snapshot/coordinator-checks/04.log') and
          text('snapshot/coordinator-checks/04.log').rstrip().endswith('OK'), '17-test evidence missing')
    links = data('LINK-AND-ATTRIBUTION-CHECK.json')
    check(len(links['local_or_tracked_link_checks']) == 30 and links['new_prose_email_like_strings'] == 0,
          'link/privacy review scope differs')
    for link in links['local_or_tracked_link_checks']:
        check(link['worktree_file_exists'] or link['git_exit_code'] == 0, 'unresolved tracked link')
    pr = text('snapshot/MF05-UPSTREAM-PR-BODY.md')
    check('Please include this verification in `ajt60gaibb/OpenProblemsInNLA:main`.' in pr,
          'upstream main inclusion request missing')
    check('No unrun check is claimed successful.' in pr, 'pending future-check qualification missing')
    verdict = data('VERDICT.json')
    check(verdict['final_verdict'] == 'approve' and all(f['status'] == 'closed' for f in verdict['findings']),
          'documentation findings not closed')
    check(verdict['new_lean_or_comparator_executions'] == 0 and verdict['git_mutations_by_referee'] == 0,
          'incorrect independent execution claim')
    print(json.dumps({'result': 'PASS', 'checks': COUNT, 'scope': 'read-only sealed publication-doc evidence',
                      'compiler_executions': 0, 'network_executions': 0, 'source_commit': COMMIT}, sort_keys=True))


if __name__ == '__main__':
    main()
