## Change

Add a complete Lean formalization of MF-05 and promote its canonical status from Solved to Lean verified. Please include this verification in `ajt60gaibb/OpenProblemsInNLA:main`.

The original ID, path, statement, quantifiers and mathematical authorship are preserved. Formalization and verification contribution: **George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology**. Matthew J. Colbrook retains credit for the mathematical proof. AI assistance and independent AI-agent reviewer scopes are disclosed.

## Mathematical evidence

The formalization follows Colbrook's *Uniform polynomial product bounds and sharp Hölder continuity of the joint spectral radius*, Theorem 2, Proposition 5 and Corollary 7. The main theorem `NLA.MF05.canonical_local_holder` chooses positive neighborhood radius and constant before both nonempty compact complex matrix families vary. It includes every positive dimension, infinite generating sets, reducibility, zero radius and zero Hausdorff distance. The 14 contracts also prove the literal spectral-Hausdorff semantics and full chronological-product root-limit semantics. Sharpness examples and the better scalar constant are not additional formal claims.

- [Immutable proof and source](https://github.com/sgstepaniants/OpenProblemsInNLA/tree/06b8cf49740205c4b7b0b71ee5c636855fbe26a6/matrix-functions-and-stability/MF-05/lean): Lean 4.33.1, Mathlib `0df444a360eaa60ab8c11dca51a86af692955474`, LeanCert `621a43d7cf21f87872392a01e874f2f1dbddc926`.
- [Actual proof-commit Linux run 35252365986](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/35252365986/job/105307710518): all 193 submitted inputs and 14 exact exports passed real Comparator, default-kernel replay, permitted-axiom checks, non-root sandbox checks and rejection controls. Every export uses only `propext`, `Classical.choice` and `Quot.sound`. Only MF-05 was selected.
- Actual serial local Lean compilation preceded the push: 32-module closure, one compiler, one thread, at most 4096 MiB, and authenticated exact-source output reuse. Kernel-mode LeanCert proves the consumed half-radius certificate; the remaining proof is symbolic.
- Two independent statement reviews preceded proof implementation. Two independent nonauthor full source reviews and a separate audit of the actual GitHub execution approved the submission. Reports, hashes, full logs, artifact and source correspondence are retained under `lean/reviews/` and `lean/verification/`. Evidence audits are not claimed as additional compiler executions.

Local reproduction: run `lake build` inside `matrix-functions-and-stability/MF-05/lean`. The project README also provides the bootstrap and real non-root Linux Comparator commands. `formalization.yaml` follows the pinned v0.4 schema and lists every contract and its implementation.

Related mathematical resolution: #110. The current exact-title PR search found that original resolution and no separate MF-05 formalization; the retained public audit records its visible fork/branch scope and limitations.

## Documents checked

Updated the canonical Markdown, standalone TeX and two-page PDF, the project instructions/metadata, `RESOLVED.md` attribution, category index, `CATALOG.md` and README counts. Both rendered pages were visually inspected. The renderer labels this date as a verification check; the historical literature searches remain dated separately.

Permanent-ID validation against both published refs, catalog generation, all 17 permanent-ID tests, math-format checks and the manifest's 14-contract coverage passed locally. Every Lean source, frozen contract and dependency pin is unchanged from the accepted immutable proof revision.

The final documentation-commit run and the upstream PR merge-checkout run are separate checks; their exact revisions and actual results will be recorded here when completed. No unrun check is claimed successful.
