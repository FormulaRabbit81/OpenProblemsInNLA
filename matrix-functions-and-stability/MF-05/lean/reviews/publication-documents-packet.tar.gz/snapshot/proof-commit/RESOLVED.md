# Solved problems and solution claims

[Open catalog](CATALOG.md) · [Status definitions](README.md#problem-status) · [Report a solution](https://github.com/ajt60gaibb/OpenProblemsInNLA/issues/new?template=correction_or_resolution.md)

**Solved problems stay visible.** Their IDs and original statements are retained,
with a prominent status, the resolution reference, its date and exact scope.
They do not contribute to the open count. A counterexample is a solution to a
conjecture's truth question; it is recorded as a negative resolution.

Complete resolutions have three evidence levels: **🟠 SOLUTION CLAIMED**,
**✅ SOLVED**, and **🏆 LEAN VERIFIED**. `Solution claimed` means a primary
manuscript reports a full resolution whose proof has not been independently
verified here. `Solved` means the exact target has a published result or an
independently audited argument; an AI-agent audit is informal review and does
not establish formal verification. `Lean verified` adds a kernel-checked Lean
proof, reviewed correspondence to the original target, and a
[reproducible verification record](CONTRIBUTING.md#lean-verification).
None of these statuses is counted as open. A partial result leaves the
surviving target in the open catalog with **🟡 PARTIAL**, even if that partial
result is formalized in Lean.

## MF-14 — negative resolution by degree-44 coverage — Marcus Webb

**Solved negatively, 17 September 2026.** Marcus Webb, The University of Manchester. [Theorem 1 of the complete proof](references/webb-mf14-degree44-2026-09-17/proof.pdf) proves that the complex degree-at-most-44 coefficient space is contained in the Zariski closure of all seven-product outputs, in the original degree-128 ambient space. This refutes the retained equality that the maximal covered degree is 42. Corollary 3 gives $44\le d_7\le47$ using Jarlebring–Lorentzon's dimension theorem; the exact new maximum is not determined.

A simultaneous four-product border construction and an exact 45-by-45 Jacobian determinant of 256 support the result. Two separate Codex agents independently reviewed the argument and recomputed the certificates. [Submission, reviews and reproduction](references/webb-mf14-degree44-2026-09-17/README.md) · [Proof source](references/webb-mf14-degree44-2026-09-17/proof.tex) · [Retained canonical target](matrix-functions-and-stability/MF-14/README.md). The proof was developed with substantial ChatGPT assistance. This is informal AI-agent review, not external human peer review or formal verification. Colbrook retains credit for the earlier degree-42 theorem. The permanent ID, canonical path and original statement are unchanged.

## Reviewed AC-01–AC-06 research — 14 September 2026

**All six remain Open.** Sidney Holden (Center for Computational Biology, Flatiron Institute, Simons Foundation) submits independently audited supporting tensor research. The [submission record](references/holden-ac-2026-09-14/README.md) gives verified affiliation, attributed reports, exact theorem locators, original-target comparisons and three separate informal Codex AI-agent reviews.

The passing scopes include AC-01's small-CW upper bound (also relevant to AC-04), restricted AC-02 support and Sun-block results, elementary AC-03 geometric/Fourier arguments, AC-04 symmetric extraction and local rigidity, AC-05 power classifications, and AC-06 certificate compaction and finite checks. Missing verifier artifacts prevent a full audit of the AC-02 continuation and AC-03 package; their stronger unverified claims are explicitly excluded from the passing scope. None settles its original target or supports a Solved designation. No external human peer review, formal verification or novelty claim is asserted. No Lean verification was performed. Permanent IDs, original targets and the open count are unchanged.

## Resolved catalog entries

### 🏆 MF-24 — a negative resolution of uniform boundedness — Georg Maierhofer

**Solved negatively, 15 September 2026.** Georg Maierhofer (University of Cambridge), [manuscript dated 14 September 2026](references/mf24-counterexample/proof.pdf), **Theorem 1 and equation (15)**, gives super-identical-pseudospectral weighted shifts of order $`(m+1)^2`$ and a common polynomial with norm ratio at least $`(4/5)\sqrt m`$. This refutes the dimension-independent bound in the [retained original target](matrix-functions-and-stability/MF-24/README.md).

**Corollary 3** proves $`C_N\ge\sqrt{\lfloor\sqrt N\rfloor-1}`$ for $`N\ge9`$. Exact values and optimal growth of $`C_N`$ remain open. [Source, exact checks, numerical checks and AI-assistance disclosure](references/mf24-counterexample/README.md). The [fresh maintainer audit](reviews/2026-09-15-pr264/README.md) confirms the full negative resolution; the [submitted informal Codex AI-agent audit](references/mf24-counterexample/independent-review.md) is retained. Those informal records do not claim external peer review or publication priority; the separate Lean verification is recorded below.


**Lean verified, 15 September 2026.** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, supplied the [complete 22-target formalization](matrix-functions-and-stability/MF-24/lean/README.md). It refutes the original comparison for arbitrary complex matrices, shifts and polynomials with genuine Euclidean operator norms. Its conservative ratio $`(2/3)\sqrt m`$ suffices; the sharper manuscript corollaries remain outside the formalization. The [exact proof-commit Linux run](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/35033148310/job/104596164346) passed LeanCert kernel assertions, Comparator, default-kernel replay, standard transitive axioms and rejection controls. Two independent AI-agent referees reviewed the complete source and actual evidence; see the [canonical evidence section](matrix-functions-and-stability/MF-24/README.md#lean-proof-and-verification-evidence). Georg Maierhofer retains original mathematical credit.


### 🏆 MI-32 — the Latała–Świątkowski upper comparison — Diar Heidary

**Lean verified — 2026-09-14. Formalization: Diar Heidary**, unaffiliated,
with AI-agent assistance. The complete original target of [MI-32](matrix-inequalities-and-norms/MI-32/README.md)
is proved: for every $`\alpha\ge1`$ there is $`C_\alpha>0`$, independent of the
dimension and of the entry laws, with
$`\mathbb E\|X\|_2\le C_\alpha(M(X)+D(X))`$ for every square matrix of
independent mean-zero entries satisfying the displayed moment-doubling
condition at every real order $`r\ge1`$. The
[immutable proof source](https://github.com/DiarHaidary/Spectral-norms-of-independent-entries-with-regular-moment-growth/tree/762bd5ec5050a96f5e6ba3926b6cda4816fcd4b0)
exports the single declaration `MI32.main_upper` and is registered as
[Palomar entry PALOMAR-2026-09-14-000006, version 1](https://palomar-registry.org/entry.html?id=PALOMAR-2026-09-14-000006&version=1),
which preserves an archival fork of that commit. Palomar's
[Linux Comparator, NanoDa and sandboxed kernel run 34852526384](https://github.com/PalomarRegistry/PalomarSubmission/actions/runs/34852526384)
accepted the frozen statement and replayed the solution, admitting only
`propext`, `Classical.choice` and `Quot.sound`; the entry records trust level
`high` and an editorial review outcome of `neutral`. The arbitrary probability
space, the single shared deterministic deletion set on both axes, and the
subunit order $`\ln2`$ at $`k=1`$ are all retained literally, and the hypothesis
class is separately shown to be non-vacuous. The
[canonical verification evidence](matrix-inequalities-and-norms/MI-32/README.md#lean-proof-and-verification-evidence--2026-09-14)
records the toolchain, dependency pins, definition correspondence, reproduction
commands and axiom report. Conjecture credit remains with Rafał Latała and
Witold Świątkowski (Conjecture 4.3, EJP 27 (2022), paper 80); their Theorem 4.1
reverse inequality is credited and is outside the formalized scope. AI
assistance and AI review are disclosed; this catalog reviewed a public
verification record rather than rerunning the checks, and no external human peer
review is claimed.

### SP-03, SP-07 and SP-09 — further supporting and partial results — Sidney Holden

**Recorded 14 September 2026 (UTC).** [Submission, author affiliation and three independent informal AI-agent reviews](references/holden-sp-continuations-2026-09-14/README.md). SP-03 adds Stein reductions, parity and finite root certificates; SP-07 adds completion barriers and a stationary model; SP-09 adds a first-order splitting theorem with a dimension-dependent remainder bound. These do not settle the full original targets. SP-03 is Partially resolved on the new parity theorem; SP-07 remains Open and SP-09 remains Partially resolved. Original statements and IDs are unchanged. No Lean verification or external human peer review is claimed.


### RA-05, TR-03, RA-11, SP-10 and RA-14 — further submissions — Sidney Holden

**14 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Submission, verified affiliation and provenance](references/holden-further-2026-09-14/README.md). Separate independent Codex AI-agent audits passed the scopes listed below; this is informal review, with ChatGPT assistance disclosed. No Lean verification, external human peer review, formal verification or novelty claim is asserted.

- **Solved — [RA-05](randomized-and-low-rank-approximation/RA-05/README.md)**: [Part I, Theorem 1.1, and Part II, Theorem 1.1](references/holden-further-2026-09-14/RA-05/manuscript.pdf) classify the optimal strong original-row coreset size, up to logarithms, for every fixed real power greater than two and all allowed ranks and accuracies. The full target passes the [independent review](reviews/2026-09-14-further-submissions/RA-05-review.md). Historical partial notices below are superseded for this target.
- **Partially resolved — [TR-03](randomized-and-low-rank-approximation/TR-03/README.md)**: [Theorem 1.1](references/holden-further-2026-09-14/TR-03/manuscript.pdf) gives the all-positive-spectrum upper bound; the sharp joint order remains open. [Review](reviews/2026-09-14-further-submissions/TR-03-review.md).
- **Partially resolved — [RA-11](randomized-and-low-rank-approximation/RA-11/README.md)**: [Theorems 2.1–2.2 and Corollary 2.3](references/holden-further-2026-09-14/RA-11/manuscript.pdf) give probability-sensitive and diagonal-control upper bounds; the unrestricted minimax gap remains. [Review](reviews/2026-09-14-further-submissions/RA-11-review.md).
- **Partially resolved — [SP-10](eigenvalues-and-inverse-problems/SP-10/README.md)**: [Sections 2–5, especially Theorem 4.1](references/holden-further-2026-09-14/SP-10/manuscript.pdf) cover bipartite graphs with degree at most four on one side and supporting constructions; arbitrary graphs remain open. [Review](reviews/2026-09-14-further-submissions/SP-10-review.md).
- **Partially resolved — [RA-14](randomized-and-low-rank-approximation/RA-14/README.md)**: [Sections 2–7](references/holden-further-2026-09-14/RA-14/manuscript.pdf) provide exact capacity and innovation-qualified results; the unrestricted finite-parameter gap remains. [Review](reviews/2026-09-14-further-submissions/RA-14-review.md).

The repeated RA-01 tail-analysis package is excluded because its identical proof already merged in [PR #237](https://github.com/ajt60gaibb/OpenProblemsInNLA/pull/237). All original targets, permanent IDs, canonical paths and prior-source credit are preserved.


### RA-05 — further even-power high-accuracy partial result, Sidney Holden, 2026-09-13

**Partially resolved.** [Theorems 1.1–1.2 and Corollary 1.3](references/holden-ra05-even-power-2026-09-13/manuscript.pdf) prove $`S_{2s}(k,\varepsilon)=\widetilde\Theta_s(k^{s-1}/\varepsilon^2)`$ for each fixed integer $`s\ge2`$ when $`\varepsilon\le k^{-(s+1)/2}`$, with arbitrary input rank and nonnegative original-row weights. The [canonical page](randomized-and-low-rank-approximation/RA-05/README.md) records the all-accuracy upper bound and remaining gaps. A separate [independent informal AI-agent review](references/holden-ra05-even-power-2026-09-13/verification/independent-review.md) passed this partial scope. No Lean verification or external human peer review is asserted. [Author, verified affiliation, provenance and reproduction](references/holden-ra05-even-power-2026-09-13/README.md). Earlier partial results are retained; the full joint classification remains open.

### IE-20, IE-27 and IE-28 — reviewed partial results — Sidney Holden

**Partially resolved, 13 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. The [submission record](references/holden-ie-extensions-2026-09-13/README.md) links the attributed manuscripts, unchanged originals, exact checks and three independent informal AI-agent reviews. IE-20 supplies scalar, breakdown and first-step results; its all-parameter sharp precision target remains open. IE-27 certifies 66 specified stage counts for all positive real shifts and all-stage endpoint shift regimes, leaving intermediate shifts at other stages open. IE-28 proves the two-/three-stage, Laguerre-family and clustered-node cases plus twelve local certificates, leaving arbitrary-node all-stage existence open. The two IE-28 bundles form one submission.

The original targets and permanent IDs are retained: [IE-20](linear-systems-and-elimination/IE-20/README.md), [IE-27](linear-systems-and-elimination/IE-27/README.md), [IE-28](linear-systems-and-elimination/IE-28/README.md). Related [IE-11 supporting certificates](linear-systems-and-elimination/IE-11/README.md) leave its status Open. No full resolution, external human peer review or Lean verification is asserted.

### 🟡 TR-29 — the two-factor W-state rank — Maximilian Behr

**Partially resolved, 13 September 2026.** Maximilian Behr. [Theorem 1.1](references/behr-tr29-2026-09-13/manuscript/TR29_two_factor_rank.pdf) proves $`R(W_{d_1}\otimes W_{d_2})=2(d_1+d_2-2)`$ for all $`d_1,d_2\ge2`$, settling the case $`k=2`$ of [TR-29](tensor-computations/TR-29/README.md); Corollary 5.4 gives the partially symmetric rank of every bihomogeneous binary monomial with positive exponents. The case $`k\ge3`$ remains open.

Two separate [independent AI-agent informal audits](references/behr-tr29-2026-09-13/verification/independent-review.md) passed this partial scope. AI assistance is disclosed; no external human peer review or formal verification is asserted. No Lean verification was performed. [Submission record, checks and reproduction](references/behr-tr29-2026-09-13/README.md).

### RA-14 — Restricted Krylov and shifted-posterior continuation

**Partially resolved, 13 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Theorem 2.2](references/holden-ra14-v6-2026-09-13/report.pdf) gives matching finite-parameter bounds only for the deterministic-width fully charged block span-query class; Theorems 10.1 and 11.2 concern a conditional posterior and an ensemble-average rank-one algorithm. These new scopes passed an [independent informal Codex AI-agent review](references/holden-ra14-v6-2026-09-13/independent-review.md). The unrestricted finite-accuracy gap and [original target](randomized-and-low-rank-approximation/RA-14/README.md) remain unchanged. [Submission, authorship and verified affiliation](references/holden-ra14-v6-2026-09-13/README.md). No Lean verification or external human peer review is claimed.

### MI-05 — order-four determinant identities and partial classes — Sidney Holden

**Partially resolved, 13 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Theorem 2.1 and Sections 3–7](references/holden-mi05-2026-09-13/report.pdf) give a fourteen-term signed identity, optimal positive-obstruction representations, an all-complex-spectra unitary ball of radius $`1/100`$, a support-direction criterion and a sharp real-orthogonal obstruction bound. [Submission and verified affiliation](references/holden-mi05-2026-09-13/README.md) · [Proof source](references/holden-mi05-2026-09-13/report.tex).

A separate [independent informal Codex AI-agent audit](references/holden-mi05-2026-09-13/independent-review.md) passed the stated partial scope. The [retained original MI-05 target](matrix-inequalities-and-norms/MI-05/README.md) remains open for arbitrary normal pairs: negative common weights do not refute its spectrum-dependent convex-hull inclusion. No Lean verification, external human peer review or historical novelty claim is asserted. The status remains Partially resolved and the open count is unchanged.

### RA-18 — complex extension refuted; structured real cases — Sidney Holden

**Partially resolved, 13 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation ([verified affiliation](references/holden-ra18-2026-09-13/SUBMISSION.md)). [Theorem 2.1 and Section 3](references/holden-ra18-2026-09-13/manuscript/ra18.pdf) refute the separate proposed dimension-independent complex bound in [RA-18](randomized-and-low-rank-approximation/RA-18/README.md), by an explicit recursive family whose best square-submatrix inverse norm divided by the square root of the row dimension diverges. Sections 5–6 give exact spectral information and dimension-dependent lower bounds. Theorem 7.2 proves the real bound for frames with at most r+2 nonzero row directions, using the cited real two-column theorem.

The [independent informal Codex AI-agent review](references/holden-ra18-2026-09-13/independent-review.md) passed these scopes and reran the supplied checks. [Source, code and provenance](references/holden-ra18-2026-09-13/README.md). The unrestricted real conjecture remains open, so the overall entry is **not Solved** and its open-count membership is unchanged. No Lean verification, external human peer review or novelty certificate is asserted; the original target, ID, canonical path and prior-source credit are retained.

### RA-01 - tail-envelope pivot-count guarantees - Sidney Holden

**Partially resolved, 13 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Theorems 4.1, 5.1 and 6.1](references/holden-ra01-2026-09-13/report.pdf) prove the original RPCholesky relative trace-error guarantee with $`C=3`$ for half-geometric tails, $`C=4`$ for inverse-square tails, and a finite exponent-dependent $`C_p`$ for fixed summable power tails. Envelopes are normalized at the first eigenvalue after the target rank; the head spread and complex eigenvectors are unrestricted. **General RA-01 remains open.** The auxiliary clock obstruction and determinant-comparison saturation do not refute its target.

The partial results passed a separate [independent informal Codex AI-agent audit](references/holden-ra01-2026-09-13/independent-review.md). Exact and floating checks passed. No Lean verification, external human peer review or historical novelty claim is asserted. [Retained original target](randomized-and-low-rank-approximation/RA-01/README.md) · [Source, authorship, affiliation and provenance](references/holden-ra01-2026-09-13/README.md). Permanent IDs and the open count are unchanged.

### RA-11 — partial Kronecker trace-estimation bounds — Sidney Holden

**Partially resolved, 13 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Theorem 1.1 and its supporting proofs](references/holden-ra11-2026-09-13/manuscript/ra11_partial_results.pdf) give general bounds, a matched tensor-product subclass characterization, and a matched very-small-error regime. The general unrestricted adaptive target remains open; the source projection-conjecture counterexample is not a resolution of RA-11. [Retained original target](randomized-and-low-rank-approximation/RA-11/README.md) · [Proof source and attribution](references/holden-ra11-2026-09-13/README.md).

A separate [independent Codex AI-agent informal audit](references/holden-ra11-2026-09-13/independent-review.md) passed the partial claims, with exact and numerical checks rerun. No Lean verification, external human peer review, or full-resolution or novelty claim is asserted. RA-11 remains in the open count with its permanent ID, path, original target and prior-source credit intact.

### RA-14 — query-complexity partial results — Sidney Holden

**Partially resolved, 12 September 2026.** [Sidney Holden, verified affiliation and submission record](references/holden-ra14-2026-09-12/README.md). The [research note](references/holden-ra14-2026-09-12/package/report.pdf), Theorems 1.1, 1.2 and 5.1, establishes the universal rank lower bound, the large-rank regime and a spectral-to-PCA reduction giving matching bounds under a retained polynomial dimension hypothesis. [Independent informal AI-agent review](references/holden-ra14-2026-09-12/independent-review.md). The [original RA-14 target](randomized-and-low-rank-approximation/RA-14/README.md) remains open in the other simultaneous finite-parameter regimes. No full resolution, external human peer review or Lean verification is asserted.

### ✅ TR-14 — exact rank of complex Hankel tensors — Sidney Holden

**Solved affirmatively, 12 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Theorem 1.1, Sections 2–5](tensor-computations/TR-14/solution.pdf) proves ordinary/symmetric rank equality for every complex Hankel tensor in the original target, including exceptional data, together with an exact formula. [Retained target](tensor-computations/TR-14/README.md) · [Proof source](tensor-computations/TR-14/solution.tex) · [Submission and verified affiliation](references/holden-tr14-2026-09-12/README.md).

The complete proof passed a separate [independent Codex AI-agent audit](references/holden-tr14-2026-09-12/independent-review.md). Supplementary exact computations were reproduced. This is informal automated review, not external human peer review or formal verification; no Lean verification was performed. Nie and Ye retain credit for the original conjecture and earlier cases. IDs, canonical paths and the original statement are unchanged.

### MI-15 and MI-16 — earlier matrix partial results — Sidney Holden

**Partially resolved, 12 September 2026.** Author: Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Submission and verified affiliation](references/holden-matrix-2026-09-12/README.md).

- [MI-15](matrix-inequalities-and-norms/MI-15/README.md): [Sections 1–5](references/holden-matrix-2026-09-12/MI-15/proof.md) prove exact SOS certificates in orders 8–12. The all-order assertion remains open. [Independent review](references/holden-matrix-2026-09-12/verification/MI-15-review.md).
- [MI-16](matrix-inequalities-and-norms/MI-16/README.md): the [Theorem](references/holden-matrix-2026-09-12/MI-16/result.md) gives the exact orbit maximum for every one-exceptional-eigenvalue spectrum. This preceded the [all-spectrum resolution](matrix-inequalities-and-norms/MI-16/README.md). [Independent review of the earlier scope](references/holden-matrix-2026-09-12/verification/MI-16-review.md).

The same submission includes audited MI-20 projective reductions and MI-27 projection-equivalence and coefficient-sharpness lemmas. MI-20 remains Open; [MI-27 was subsequently solved](matrix-inequalities-and-norms/MI-27/README.md). Three separate informal Codex AI-agent reviews passed these earlier scopes. This partial submission alone supplied no full resolution and did not reduce the open count. No novelty, external human peer review or formal verification is asserted; no Lean verification was performed. IDs, paths, targets and prior-source credit are retained.


### MI-27 — sharp logarithmic commutator inequality — Sidney Holden

**Solved, affirmative, 12 September 2026.** [Original statement](matrix-inequalities-and-norms/MI-27/README.md).
Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation
([verified affiliation and provenance](references/holden-mi27-2026-09-12/provenance.md)),
proves the universal coefficient-one bound and its strict-positive order-two sharpness.
[Theorem 1.1 and Sections 2–5](references/holden-mi27-2026-09-12/solution.pdf)
cover every dimension and every complex positive definite input in the canonical target.
The argument uses the published Frenkel/Hirche–Tomamichel relative-entropy identity.
A [separate informal Codex AI-agent audit](references/holden-mi27-2026-09-12/verification/independent-review.md)
passed the complete proof; this is not external human peer review or formal verification.
AI assistance and the earlier partial findings in [PR #186](https://github.com/ajt60gaibb/OpenProblemsInNLA/pull/186)
are disclosed. No Lean check or priority claim is made. All IDs, paths and original targets are preserved.


### RA-05 — all-exponent coreset lower bounds — Sidney Holden

**Partially resolved, 2026-09-13.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Theorem 1.1 and Corollaries 1.2–1.3](references/holden-ra05-2026-09-13/manuscript/RA05_all_p_lower_bounds.pdf) give an all-exponent lower bound, refute the displayed additive formula for every fixed real p > 2, and match the cited upper bound up to logarithms for even powers at moderate accuracy. The separate quartic continuation below settles all accuracies for p=4. The other exponents retain unresolved regimes. [Retained target](randomized-and-low-rank-approximation/RA-05/README.md) · [Proof source](references/holden-ra05-2026-09-13/manuscript/RA05_all_p_lower_bounds.tex).

A separate [independent Codex AI-agent audit](references/holden-ra05-2026-09-13/verification/independent-review.md) passed this partial scope; the full target is not marked Solved. [Submission record, verified affiliation and reproducibility](references/holden-ra05-2026-09-13/README.md). AI assistance is disclosed; no external human peer review, novelty claim or formal verification is asserted. No Lean verification was performed. Original IDs, paths, target and prior-source attribution are preserved; the entry remains in the open count.


### RA-04 — partial clustered-gap results by Sidney Holden, 2026-09-12

[RA-04](randomized-and-low-rank-approximation/RA-04/README.md) was **Partially resolved** at this stage; the later full proof now settles it. Holden (Center for Computational Biology, Flatiron Institute, Simons Foundation) proves a general bound with an extra logarithmic term and the requested order for small gaps, exactly repeated clusters, two-step blocks and endpoints. The general clustered-spectrum target remained open in this first report. [Report](references/holden-ra04-2026-09-12/RA04_partial_results.pdf), Theorems 4.1, 5.3, 6.1 and 7.1, Corollaries 5.4 and 6.2, and Proposition 8.1; [independent agent PASS for partial results](references/holden-ra04-2026-09-12/verification/independent-review.md); [authorship and reproduction](references/holden-ra04-2026-09-12/README.md). No formal verification or external human peer review is claimed.

### RA-04 — narrow-band and exact-tail continuation — Sidney Holden

**Earlier partial results, 13 September 2026; superseded by the full resolution below.** [RA-04](randomized-and-low-rank-approximation/RA-04/README.md) retains its original universal target. Sidney Holden (Center for Computational Biology, Flatiron Institute, Simons Foundation) provides [a continuation](references/holden-ra04-continuation-2026-09-13/README.md): report Sections 3–5 prove the requested order under explicit narrow-band hypotheses; Sections 6–8 establish generic rank and exact recovery with few distinct lower eigenvalues. The [independent AI-agent review](references/holden-ra04-continuation-2026-09-13/verification/independent-review.md) passes these partial results, which alone did not justify Solved. The later unrestricted proof below settles the remaining spectra. Imported convergence and prior all-input results are explicitly credited. No Lean verification was performed; RA-04 is now excluded from the open count.


### MI-16 — exact algebraic spectral determination — Sidney Holden

**Solved, 12 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Verified affiliation and submission](references/holden-mi16-2026-09-12/README.md). [Theorem 2.1, Sections 3–5](matrix-inequalities-and-norms/MI-16/solution.pdf) give a finite exact algebraic prescription for the maximum permanent for all nonnegative spectra and every order, using critical-value elimination and an explicit finite spectral-moment selector. This settles the retained [MI-16 exact-value target](matrix-inequalities-and-norms/MI-16/README.md), without claiming a compact structural formula, an efficient general implementation, or general optimizer classification. Theorem 8.1 and Sections 9–10 also sharpen the earlier one-exceptional-eigenvalue partial result to two candidates with thresholds and complete equality cases. Prior partial findings from [PR #186](https://github.com/ajt60gaibb/OpenProblemsInNLA/pull/186) retain credit. [Independent Codex AI-agent audit: PASS](references/holden-mi16-2026-09-12/independent-review.md). Informal automated review only; no Lean verification, external human peer review, or historical novelty claim.

### ✅ RE-06 — fully nonadaptive finite-family approximation — Sidney Holden

**Solved affirmatively, 13 September 2026.** Sidney Holden (Center for Computational Biology, Flatiron Institute, Simons Foundation), [Theorem 1.1 and Sections 2–6](randomized-and-low-rank-approximation/RE-06/solution.pdf), proves the original exact-real, query-only target with $`C=4{,}000{,}000`$ and $`b=0`$: all queries are fixed before answers and the $`3+\varepsilon`$ approximation succeeds with probability at least 0.99. [Retained target](randomized-and-low-rank-approximation/RE-06/README.md) · [Proof source](randomized-and-low-rank-approximation/RE-06/solution.tex).

The full argument passed a separate [independent informal Codex AI-agent audit](references/holden-re06-2026-09-13/independent-review.md). No external human peer review or formal verification is asserted; no Lean verification was performed. [Submission, verified affiliation and checks](references/holden-re06-2026-09-13/README.md).

### ✅ TR-08 — exact square-root-logarithmic sparsity threshold — Sidney Holden

**Solved, 12 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Theorem 1.1 and Sections 2–7](randomized-and-low-rank-approximation/TR-08/solution.pdf) settle the full [retained TR-08 target](randomized-and-low-rank-approximation/TR-08/README.md): the required fixed positive lower singular-value bound holds with probability tending to one exactly when $`\liminf s_k^2/\log k>0`$, including arbitrary sequences and the critical window. [Proof source](randomized-and-low-rank-approximation/TR-08/solution.tex) · [Submission and verified affiliation](references/holden-tr08-2026-09-12/README.md).

The full proof passed a separate [independent Codex AI-agent informal audit](references/holden-tr08-2026-09-12/independent-review.md). The finite symbolic, exact-enumeration and numerical checks were rerun successfully. ChatGPT assistance is disclosed; no external human peer review, formal verification or historical novelty claim is asserted. No Lean verification was performed. The original ID, canonical path, target and prior-source credit remain unchanged.


### ✅ RA-04 — clustered-gap block Krylov approximation — Sidney Holden

**Solved, 13 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Theorem 1.1, Theorem 6.4 and Section 7](references/holden-ra04-full-proof-2026-09-13/report.pdf) establish the full affirmative [retained RA-04 target](randomized-and-low-rank-approximation/RA-04/README.md), with no extra cluster-width or spectral condition-number restriction. The same algorithm achieves both relative norm errors and ordered right singular-vector energy accuracy, including zero residual and nondivisible block sizes.

The [separate independent Codex AI-agent informal audit](references/holden-ra04-full-proof-2026-09-13/verification/independent-review.md) passed the full proof. This is not external human peer review or formal verification; no Lean verification was performed. [Submission, attribution and verified affiliation](references/holden-ra04-full-proof-2026-09-13/SUBMISSION.md). Original ID, path, target and source attribution are retained.


### ✅ PF-04 — maximum cp-rank in order six — Sidney Holden

**Solved affirmatively, 13 September 2026 (UTC).** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Theorem 1.1 and Sections 2–8](references/holden-pf04-2026-09-13/submission/PF04_proposed_proof.pdf) prove that every real order-six completely positive matrix admits a nonnegative factor with at most nine columns; Proposition 8.1 attains nine with a positive-definite example. [Retained PF-04 target](nonnegative-and-positive-factorizations/PF-04/README.md) · [Proof source](references/holden-pf04-2026-09-13/submission/PF04_proposed_proof.tex) · [Submission and verified affiliation](references/holden-pf04-2026-09-13/README.md).

The full proof passed a separate [independent Codex AI-agent informal audit](references/holden-pf04-2026-09-13/independent-review.md), and exact auxiliary checks passed on rerun. AI assistance is disclosed; no external human peer review, formal verification or historical priority certification is asserted. No Lean verification was performed. Original ID, path, target and prior-source attribution are preserved.


### ✅ PF-03 — rational completely positive boundary factors — Sidney Holden

**Solved negatively, 13 September 2026.** Sidney Holden (Center for Computational Biology, Flatiron Institute, Simons Foundation) constructs an order-444 strictly positive integer completely positive boundary matrix of rank and real cp-rank seven with no rational nonnegative factor of any finite width. [Theorem 1.1 and Sections 2-6](references/holden-pf03-2026-09-13/proof/PF03_counterexample.pdf) settle the full universal target by counterexample, without asserting a minimal order or resolving every smaller fixed order. [Retained original target](nonnegative-and-positive-factorizations/PF-03/README.md) · [Source, certificates, authorship and verified affiliation](references/holden-pf03-2026-09-13/README.md).

The complete proof and exact certificates passed a separate [independent informal Codex AI-agent audit](references/holden-pf03-2026-09-13/independent-review.md), including all 54,264 candidate facet supports, 98,790 matrix entries, 18 unit tests and a reviewer-written arithmetic check. No Lean verification, external human peer review or priority claim is asserted. The original ID, canonical path, statement and historical-source credit remain intact.

### PF-01 — further structural partial results — Sidney Holden

**Partially resolved, 13 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Manuscript Sections 2–10](references/holden-pf01-2026-09-13/paper/pf01_structural_obstructions.pdf) establish rank-one-factor counts, a span-five projection theorem, mixed-rank and covering constraints, and the exact 90-dimensional quartic derivative space for the retained [PF-01 target](nonnegative-and-positive-factorizations/PF-01/README.md). These new partial results passed a separate [independent Codex AI-agent audit](references/holden-pf01-2026-09-13/verification/independent-review.md). The exact ranks for all n >= 7 remain unresolved. Prior draft bounds are outside that audit's scope. [Authorship, verified affiliation and reproduction](references/holden-pf01-2026-09-13/README.md). No Lean verification or external human peer review is asserted.


### 🏆 NR-03 — quadratic correlation counterexample — Sidney Holden; Lean formalization by George Stepaniants

**Solved negatively, 13 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Theorem 1 and Sections 2–4](references/holden-nr03-2026-09-13/NR03_counterexample.pdf) give an exact nonnegative rational factorization with 127 terms for the prescribed 128-by-128 matrix $`C_7`$, disproving the universal equality in the [retained NR-03 question](nonnegative-and-positive-factorizations/NR-03/README.md). The general bound is strictly below $`2^n`$ for every $`n\ge7`$. Exact ranks at individual sizes and the smallest counterexample dimension are not asserted.

The complete proof passed a separate [independent Codex AI-agent informal audit](references/holden-nr03-2026-09-13/independent-review.md). The [submission record](references/holden-nr03-2026-09-13/README.md) supplies source, verified affiliation, original archive and fresh exact checks. ChatGPT assistance is disclosed; no external human peer review, formal verification or historical novelty certification is claimed. That informal audit predates the separate Lean verification appended below. Original ID, canonical path, target and earlier Colbrook partial-result credit are preserved.

<!-- nr03-lean-verification -->
**Lean verified — 2026-09-13. Formalization: George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA. The [immutable ten-export Lean proof](https://github.com/sgstepaniants/OpenProblemsInNLA/tree/f664d07e82aaa60bc9c78dd1946e763168c5c530/nonnegative-and-positive-factorizations/NR-03/lean) covers the n = 7 counterexample contracts and negates the complete original universal question: the prescribed matrix has a real nonnegative factorization of width 127 < 2^7. The canonical Linux [Comparator/default-kernel verification](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34785341662/job/103799711659) and sandbox/rejection controls passed; exact run, artifact and raw receipts are retained in [the project evidence](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/codex/lean-nr03-verification/nonnegative-and-positive-factorizations/NR-03/lean/verification/linux-2026-09-13/OPERATIONAL-REVIEW.md). Sidney Holden retains mathematical authorship of the counterexample and exact certificate, while Matthew J. Colbrook's earlier partial result remains credited. The original informal resolution record above remains the mathematical source scope; this Lean result formalizes the n = 7 universal negation only. AI assistance and independent agent reviews are disclosed; no external human peer review or official Tau Ceti endorsement is claimed.
<!-- /nr03-lean-verification -->

### NM-01 — reviewed partial progress — Sidney Holden

**Open, 13 September 2026.** Sidney Holden (Center for Computational Biology, Flatiron Institute, Simons Foundation) supplies [conditional recovery and SOS obstruction results](references/holden-nm01-round2-2026-09-13/nm01_round2.pdf): Theorem 2.3 assumes an exact decision/value oracle on strong SSC; Theorems 3.1–3.2 show weak-SSC rigidity and off-promise probes; Theorem 4.5 and Corollary 4.7 obstruct a specified input-preordering SOS strategy. The [independent informal Codex AI-agent review](references/holden-nm01-round2-2026-09-13/independent-review.md) addresses these partial scopes. No complete decision algorithm, promise-preserving hardness reduction or settled decision subclass is supplied by this round. [The original target](nonnegative-and-positive-factorizations/NM-01/README.md) remains Open and counted once; neither Solved nor a new problem ID is warranted. [Attribution, verified affiliation and provenance](references/holden-nm01-round2-2026-09-13/README.md). No Lean verification or external human peer review is claimed.


### NR-01 — exact regular-polygon small cases — Sidney Holden

**Partially resolved, 13 September 2026.** [Theorem 1.1](references/holden-nr01-2026-09-13/report.pdf) proves real nonnegative rank nine for the regular 17-, 18-, 19-, and 20-gon slack matrices. The separate [independent informal Codex AI-agent audit](references/holden-nr01-2026-09-13/independent-review.md) checks the proof and reproduces the full finite computation. The universal formula remains open, starting at size 25; **NR-01 is not marked Solved**. No Lean verification or external human peer review is claimed. [Retained target](nonnegative-and-positive-factorizations/NR-01/README.md) · [Source, verified affiliation and reproduction record](references/holden-nr01-2026-09-13/README.md).

### RA-14 — finite-accuracy partial bounds — Sidney Holden

**Partially resolved, 13 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Theorem 1.1 and Sections 3–10](references/holden-ra14-v5-2026-09-13/report.pdf) prove a universal finite-accuracy lower bound and matching regimes described on the [retained canonical page](randomized-and-low-rank-approximation/RA-14/README.md). The simultaneous finite-parameter characterization remains open: at rank one and accuracy $`(\log n/n)^2`$, the lower and upper bounds differ by an unbounded factor. A separate [independent informal AI-agent review](references/holden-ra14-v5-2026-09-13/independent-review.md) passes only this partial scope. [Authorship, verified affiliation, provenance and reproduction](references/holden-ra14-v5-2026-09-13/README.md). No Lean verification, external human peer review or priority claim is asserted; the original ID, target and open count are preserved.


### RA-05 — unrestricted quartic classification — Sidney Holden

**Partially resolved, 13 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Theorem 1.1 and Sections 2–8](references/holden-ra05-quartic-2026-09-13/manuscript/RA05_unrestricted_quartic.pdf) classify the strong original-row coreset size for $`p=4`$, arbitrary input rank and all allowed $`k,\varepsilon`$, as $`\widetilde\Theta(\min\{k^2/\varepsilon^2,k^{5/2}/\varepsilon+k/\varepsilon^2\})`$. Weights remain nonnegative and all rank-at-most-$`k`$ queries are preserved. The broader classification for $`p\ne4`$ remains open; [RA-05](randomized-and-low-rank-approximation/RA-05/README.md) stays in the open count.

The proof passed a separate [independent Codex AI-agent informal audit](references/holden-ra05-quartic-2026-09-13/verification/independent-review.md). All 7,621 finite assertions and both exact certificate checkers passed. No Lean verification, external human peer review or novelty certification is asserted. [Proof source](references/holden-ra05-quartic-2026-09-13/manuscript/RA05_unrestricted_quartic.tex) · [Submission, verified affiliation and provenance](references/holden-ra05-quartic-2026-09-13/README.md). This new quartic submission is separate from the earlier all-exponent partial lower bounds in [PR #199](https://github.com/ajt60gaibb/OpenProblemsInNLA/pull/199).


### RA-17 — exact cases and certified bounds — Sidney Holden

**Partially resolved, 12 September 2026.** Author: Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Submission and verified affiliation](references/holden-ra17-2026-09-12/SUBMISSION.md).

[Theorem 1.1 and Sections 5–6](references/holden-ra17-2026-09-12/writeup/RA17_exact_cases_and_bounds.pdf) establish the exact real uniform-recovery count $`\mu_{\mathbb R}(4,1)=11`$, with a topological lower bound and rational certificates for Xu's constructions. The manuscript supplies further bounds and exact families. [Independent informal Codex AI-agent review](references/holden-ra17-2026-09-12/independent-review.md) · [Proof source](references/holden-ra17-2026-09-12/writeup/RA17_exact_cases_and_bounds.tex) · [Retained original target](randomized-and-low-rank-approximation/RA-17/README.md).

The all-dimension classification remains open; Section 9 gives explicit unresolved intervals. No full solution, priority, external human peer review or formal verification is claimed. No Lean verification was performed. The original ID, path, target, ratings and open-count contribution are preserved.


### RA-17 — topological continuation (13 September 2026)

**Partially resolved; still counted as open.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation, gives exact criteria for continuous odd-map and abstract bundle-frame relaxations, with arithmetic checks and explicit integer measurements. These relaxations do not settle the original linear measurement classification. The submitted intervals at (6,1) and (10,1) remain undecided. [Retained target and scope](randomized-and-low-rank-approximation/RA-17/README.md) · [Manuscript and verified affiliation](references/holden-ra17-continuation-2026-09-13/SUBMISSION.md) · [Independent informal AI-agent audit](references/holden-ra17-continuation-2026-09-13/independent-review.md). No Lean verification was performed.

### RE-03 — sharper HODLR query bounds — Sidney Holden

**Partially resolved, 13 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Theorem 1.1 and Corollary 1.2](references/holden-re03-2026-09-13/submission/manuscript/re03_extended_results.pdf) establish lower bound $`c\min\{n,kL/\varepsilon+k/\varepsilon^2\}`$, upper bound $`C\min\{n,kL^2/\varepsilon+kL/\varepsilon^2\}`$, and the full-recovery regime $`q_*=\Theta(n)`$ for $`\varepsilon\le\sqrt{k/n}`$. The factor of depth in the general bounds remains; [RE-03's original target](randomized-and-low-rank-approximation/RE-03/README.md) stays open and retains its permanent ID.

A separate [independent Codex AI-agent informal audit](references/holden-re03-2026-09-13/independent-review.md) passed the partial proofs. [Submission, verified affiliation and reproduction limits](references/holden-re03-2026-09-13/README.md). Five available smoke cases passed; the missing historical continuation suite was not reproduced. No Lean verification, external human peer review or novelty claim is asserted.


### KE-02, SP-08 and SP-09 — spectral partial results — Sidney Holden

**Partially resolved, 12 September 2026.** Author: Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Submission and verified affiliation](references/holden-spectral-2026-09-12/README.md).

- [KE-02](eigenvalues-and-inverse-problems/KE-02/README.md): [Theorems A and B and Section 5](references/holden-spectral-2026-09-12/KE-02/proof.md) give deterministic diagonal separation for weak coupling, constant-diagonal/equal-magnitude tridiagonal matrices at every coupling strength, and every order-two input. General tridiagonal inputs remain open. [Independent review](references/holden-spectral-2026-09-12/verification/KE-02-review.md).
- [SP-08](eigenvalues-and-inverse-problems/SP-08/README.md): [exact finite spread results](references/holden-spectral-2026-09-12/SP-08/proof.md) cover (n,a) = (8,1/2), (10,0), (11,0), with rank-two endpoint maximizers. The all-dimensions/all-parameters target remains open. [Independent review](references/holden-spectral-2026-09-12/verification/SP-08-review.md).
- [SP-09](eigenvalues-and-inverse-problems/SP-09/README.md): [Theorem 1 and its corollary](references/holden-spectral-2026-09-12/SP-09/proof.md) prove finite-amplification invariance when at least one normal spectrum has at most two points. Both spectra having at least three distinct values remains open. [Independent review](references/holden-spectral-2026-09-12/verification/SP-09-SP-07-SP-03-review.md).

Separate informal Codex AI-agent audits passed these partial scopes. None is Solved; no Lean verification, external human peer review or novelty claim is asserted. The same submission records an audited SP-03 reduction and SP-07 subclass lemma, with both statuses retained as Open. Original targets, IDs, paths and prior-source credit are preserved; the open count does not decrease.

### ✅ IE-12 — quadratic-cost backward-error solution — Sidney Holden

**Solved affirmatively, 12 September 2026.** Sidney Holden (Center for Computational Biology, Flatiron Institute, Simons Foundation) proves the full normalized exact-real entry-access target in [Theorem 1 and Sections 2–6](linear-systems-and-elimination/IE-12/solution.pdf): deterministic worst-case cost $`O(n^2\varepsilon^{-3})`$, nonzero output on every outcome, and A-only backward error at most $`5\varepsilon/8`$ with probability greater than $`0.997`$. [Retained original target](linear-systems-and-elimination/IE-12/README.md) · [Proof source](linear-systems-and-elimination/IE-12/solution.tex).

The full argument passed a separate [independent Codex AI-agent audit](references/holden-ie12-2026-09-12/independent-review.md). ChatGPT assistance in the submitted draft and informal automated review are disclosed; no external human peer review, formal verification, practical-speed result or priority certificate is asserted. No Lean verification was performed. The original problem, permanent ID and prior-source attribution are preserved. [Submission record and verified affiliation](references/holden-ie12-2026-09-12/README.md).

### 🏆 IE-16 - normal-GMRES subset bound - Sidney Holden; Lean formalization by George Stepaniants

**Solved negatively, 12 September 2026.** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Theorem 1.1, Sections 2-3](linear-systems-and-elimination/IE-16/solution.pdf) gives nine distinct nonzero complex points at degree four with full-set/subset ratio greater than 13/10 > 4/π, disproving the original universal bound. Theorem 1.2, Sections 4-5, additionally rules out every finite dimension-independent replacement constant. [Retained original target](linear-systems-and-elimination/IE-16/README.md) · [Proof source](linear-systems-and-elimination/IE-16/solution.tex).

The complete argument passed a separate [independent Codex AI-agent informal audit](references/holden-ie16-2026-09-12/INDEPENDENT-REVIEW.md), including exact checks of all 126 subsets and independent rational calculations. That dated informal audit did not establish external human peer review or formal verification. The separate complete Lean verification is recorded below. The original ID, canonical path and target are retained. [Attribution, verified affiliation and submission record](references/holden-ie16-2026-09-12/README.md).


**Lean verified — 2026-09-13. Formalization: George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA. The [immutable fifteen-export proof](https://github.com/sgstepaniants/OpenProblemsInNLA/tree/697a2a1d88337a6747aa5c82fb6e554d3ff1b356/linear-systems-and-elimination/IE-16/lean) verifies Holden’s exact finite counterexample and the negation of the complete original inequality, including attained full and subset minima and a positive actual subset maximum. [Actual Ubuntu Comparator, permitted-axiom and default-kernel verification](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34774629327/job/103770408910) passed with all controls; [raw evidence, reproduction and referee records](linear-systems-and-elimination/IE-16/lean/verification/linux-2026-09-13/README.md) preserve the scope. The stronger amplification result remains an informal source result. Sidney Holden retains all mathematical resolution and certificate credit; AI assistance and independent agent reviews are disclosed.

### KE-01 — partial sparse-solver results — Sidney Holden

**Partially resolved, 12 September 2026.** [Theorem 2.1 and Corollary 2.2](references/holden-ke01-2026-09-12/report.pdf) give a sparse CGLS baseline and four regimes attaining the target. Theorem 4.1 treats exactly flat SPD tails; Corollary 5.1 retains a potentially larger row-support cost for nonsymmetric input. **General KE-01 remains open.** The restricted claims passed a separate [independent informal AI-agent audit](references/holden-ke01-2026-09-12/independent-review.md); no Lean verification or external human peer review is asserted. [Retained original target](linear-systems-and-elimination/KE-01/README.md) · [Author, verified affiliation, source and checks](references/holden-ke01-2026-09-12/README.md).

### AV-03 and IV-01 — further partial results — Sidney Holden

**Partially resolved, 12 September 2026.** Author: Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation. [Submission record and verified affiliation](references/holden-interval-ave-2026-09-12/README.md).

- [AV-03](intervals-and-absolute-value-equations/AV-03/README.md): [Theorem H](references/holden-interval-ave-2026-09-12/manuscripts/AV-03/result.md), Sections 2.1–2.5, and [Theorem F](references/holden-interval-ave-2026-09-12/manuscripts/AV-03/general_reductions.md) give exact polynomial-bit solvers for two structured subclasses. The arbitrary dense regular-AVE target remains open. [Independent review](references/holden-interval-ave-2026-09-12/verification/AV-03-review.md).
- [IV-01](intervals-and-absolute-value-equations/IV-01/README.md): [Theorem G](references/holden-interval-ave-2026-09-12/manuscripts/IV-01/result.md) covers an acyclic fixed-entry graph condition, and [Theorem V](references/holden-interval-ave-2026-09-12/manuscripts/IV-01/dimension_five_theorem.md) covers dimension five with no fixed zeros and nonsingular fully fixed adjacent two-by-two blocks. The unrestricted interval question remains open. [Independent review](references/holden-interval-ave-2026-09-12/verification/IV-01-review.md).

Both submissions passed independent informal Codex AI-agent reviews at their stated partial scopes. Neither is marked Solved. Finite exact checks, AI assistance and source provenance are documented; no external human peer review, formal verification or novelty claim is asserted. No Lean verification was performed. Original IDs, canonical paths, targets and prior-source attribution are retained.


### 🟡 TR-03 - the one-column spectral minimax identity - Sidney Holden

**Partially resolved, 12 September 2026.** Sidney Holden (Center for Computational Biology, Flatiron Institute, Simons Foundation) proves $`R_{n,1}=1`$ for all $`n\ge3`$ and positive spectra in [Theorem 1, proved in Sections 2-3](references/holden-tr03-2026-09-12/one-column.pdf). A separate [independent Codex AI-agent audit](references/holden-tr03-2026-09-12/independent-review.md) passed the special-case proof. The original joint target for $`2\le k\le n-2`$ remains open; no full resolution, novelty, external human review or formal verification is claimed. No Lean verification was performed. [Original target](randomized-and-low-rank-approximation/TR-03/README.md) · [Proof source](references/holden-tr03-2026-09-12/one-column.tex) · [Attribution and submission record](references/holden-tr03-2026-09-12/README.md).

### ✅ TR-07 — unrestricted fixed-sparsity column subsets — Sidney Holden

**Author:** Sidney Holden, Center for Computational Biology, Flatiron Institute, Simons Foundation, New York, USA.

**Solved affirmatively, 12 September 2026.** [Theorem 1.1 and Corollary 1.2](randomized-and-low-rank-approximation/TR-07/solution.pdf) prove the full deterministic signed fixed-sparsity target, including arbitrary support intersections and repeated columns. The least singular value tends to zero in probability for every fixed positive threshold under the original aspect-ratio and redundancy assumptions. [Proof source](randomized-and-low-rank-approximation/TR-07/solution.tex) · [Retained target](randomized-and-low-rank-approximation/TR-07/README.md).

The complete argument passed a separate [independent Codex AI-agent audit](references/holden-tr07-2026-09-12/independent-review.md), with no mathematical corrections. AI assistance was used for review and submission preparation; informal automated review is not external human peer review or formal verification. No Lean verification was performed. Huang, Rudelson and Tikhomirov retain credit for the conjecture and prior structural-subclass result. The original ID, path and mathematical target remain unchanged. [Submission record and verified affiliation](references/holden-tr07-2026-09-12/README.md).



### ✅ RA-19 - the one-zero corank-one critical-point count - George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Solved affirmatively, 2026-09-11.** The [Theorem and Sections 1-5](randomized-and-low-rank-approximation/RA-19/solution.md) prove $\operatorname{EDdeg}(V_n)=5n-7$ for every integer $n\ge3$ in the original complex bilinear smooth-locus model. The exact quadratic spectral curve and stationarity resultant give the degree; a generic critical-point bijection, reducedness argument and all-dimension exceptional-locus witness make it the number of distinct critical points. [Proof PDF](randomized-and-low-rank-approximation/RA-19/solution.pdf) · [Original canonical target](randomized-and-low-rank-approximation/RA-19/README.md).

The complete argument passed a separate [independent Codex-agent review](references/stepaniants-ra19-2026-09-11/verification/independent-review/review.md), with reviewer-written universal polynomial checks, and a distinct coordinating audit. Substantial AI assistance and automated-review limitations are documented in the [submission record](references/stepaniants-ra19-2026-09-11/README.md). No external human peer review or formal certification is asserted. Kubjas, Sodomaco and Tsigaridas retain attribution for their conjecture and finite evidence. The permanent ID, full original statement, historical ratings and dimension-two scope correction remain unchanged.

### ✅ SP-13 - trace-norm perturbations preserve Hermitian spectral distributions - George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Solved affirmatively, 11 September 2026.** The [Theorem in Section 1 and proof in Sections 2-5](eigenvalues-and-inverse-problems/SP-13/solution.md) establish the full Barbarino-Serra-Capizzano conjecture with arbitrary complex perturbations of trace norm $o(n)$. Neither matrix sequence requires a spectral-norm bound; the perturbed matrices need not be normal, and every original compactly supported continuous complex test function is covered. [Proof PDF](eigenvalues-and-inverse-problems/SP-13/solution.pdf) · [Original target](eigenvalues-and-inverse-problems/SP-13/README.md).

The proof uses the published weak-type triangular-truncation theorem with its original attribution, followed by Schur decomposition and elementary spectral-counting arguments. A separate [independent Codex-agent mathematical review](references/stepaniants-sp13-2026-09-11/verification/SP-13-independent-review.md) returned PASS for the complete target. Substantial AI assistance and the limits of informal automated review are disclosed; no external human peer review or formal verification is asserted. The [submission record](references/stepaniants-sp13-2026-09-11/README.md) preserves source and eligibility evidence. The permanent ID, original target, historical ratings and prior partial results remain unchanged.

### ✅ SP-15 - infinitely many unitary classes with identical shifted singular values - George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Solved negatively, 12 September 2026 (UTC).** The [Theorem and Sections 1-4](eigenvalues-and-inverse-problems/SP-15/solution.md) prove that a single complete shifted-singular-value data fiber in complex dimension nine contains a smooth curve of pairwise non-unitarily-similar matrices. Every member is nilpotent with Jordan type $(3,3,3)$. No finite $M_9$ exists, which refutes the exact universal finiteness statement; no classification of other dimensions is asserted. [Proof PDF](eigenvalues-and-inverse-problems/SP-15/solution.pdf) · [Retained original target](eigenvalues-and-inverse-problems/SP-15/README.md).

The full proof passed a separate [independent Codex-agent audit](references/stepaniants-sp15-2026-09-12/verification/independent-review-aa01/review.md), with an independent universal coefficient check. Substantial AI assistance and informal-review limits are explicit; that earlier review claimed no external human peer review or Lean verification. Fortier Bourque and Ransford retain credit for the question and generic finiteness theorem. Their theorem is compatible with this exceptional fiber. [Submission record, frozen sources and current public eligibility](references/stepaniants-sp15-2026-09-12/README.md). The permanent ID, original target, historical ratings and source history remain unchanged.

**Lean verified - 2026-09-17.** Formalization and verification submission by **George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology. The [immutable 29-contract proof](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/69938fe5ac20768f7c23c0bead00b6add2516200/eigenvalues-and-inverse-problems/SP-15/lean/Solution.lean) settles the complete original target. [Actual Linux run 35229660506](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/35229660506) passed Comparator, default-kernel replay, permitted-axiom checks and per-proof controls. The [canonical verification section](eigenvalues-and-inverse-problems/SP-15/README.md#lean-proof-and-verification-evidence---2026-09-17) records exact scope, local versus Linux executions, two full mathematical reviews and independent runtime evidence. Prior mathematical attribution is retained; stronger unexported manuscript claims are not additional formal results.


### ✅ MF-02 - uniform constant-factor cubic-composition overhead - George Stepaniants

**Expository proof-note author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Canonical asymptotic-order resolution recorded 2026-09-12.** The [Theorem in Section 1](matrix-functions-and-stability/MF-02/solution.md) proves $T_{\min}(m,\delta)=\Theta(m+1)$ uniformly for every $0<\delta<1$, with $\lfloor m/2\rfloor\le T_{\min}\le m$ for $m\ge2$ and both small-budget values equal to one. [Proof PDF](matrix-functions-and-stability/MF-02/solution.pdf) · [Retained canonical target](matrix-functions-and-stability/MF-02/README.md).

Cheon-Kim-Kim (2020) retain credit for prior constant-factor optimality, and Chen-Chow (2014) and Polar Express for the classical cubic construction. Uniform order already follows from the prior estimates by a short synthesis; this self-contained note supplies the explicit $T_{\min}\le m$ comparison and makes no first-discovery claim. The exact minimum, optimal leading constant and same-budget error comparison remain unanswered. The full proof passed a separate [independent mathematical and scope audit](references/stepaniants-mf02-2026-09-12/verification/independent-review/MF-02-independent-review.md). AI assistance and the limits of automated review are explicit in the [submission record](references/stepaniants-mf02-2026-09-12/README.md); those original audits did not assert formal verification or external human peer review.


**Lean verified, 15 September 2026.** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, supplied the [complete thirteen-target formalization](matrix-functions-and-stability/MF-02/lean/README.md). The original program model, all gaps and budgets, both endpoint cases and uniform order are retained. The [exact-commit Linux verification](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/35016473743/job/104541199904) passed LeanCert kernel assertions, Comparator, default-kernel replay, standard transitive-axiom checks and rejection controls. Two independent AI-agent final referees inspected the source and actual logs; see the [canonical evidence section](matrix-functions-and-stability/MF-02/README.md#lean-proof-and-verification-evidence). Original mathematical attribution and the remaining sharper questions above are unchanged.

### ✅ IE-26 — both sharp perturbed Fourier stability bounds — George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Affirmative resolution recorded 2026-09-12.** [Theorem 1](linear-systems-and-elimination/IE-26/solution.md) proves the original Lebesgue bound with one absolute constant for every $0<\alpha<1/2$, and the normalized square Fourier inverse-norm bound without a logarithmic factor for each fixed $1/4<\alpha<1/2$. Both apply to every $N\ge2$ and every admissible perturbed grid. [Proof PDF](linear-systems-and-elimination/IE-26/solution.pdf) · [Retained target](linear-systems-and-elimination/IE-26/README.md). The second-bound endpoint is not asserted.

The entire argument passed a separate [independent Codex-agent audit](references/stepaniants-ie26-2026-09-12/verification/independent-review/IE-26-independent-review.md), with no mathematical correction. The coordinating contributor's check is identified separately. Substantial AI assistance is disclosed; informal automated review does not establish external human peer review or formal verification. Austin–Trefethen and later authors retain credit for the conjectures and previous results; Laugesen's weak Hilbert-transform theorem supplies the sole external harmonic-analysis inequality. [Submission, source hashes, and verification record](references/stepaniants-ie26-2026-09-12/README.md).

### 🏆 KE-05 - spectrum-uniform interpolation constants are unbounded - George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Negative resolution recorded 2026-09-12 (UTC).** The [exact target and Sections 1-5](randomized-and-low-rank-approximation/KE-05/solution.md) exhibit admissible deterministic $2\times2$ blocks with $d=3$ for which $\chi_{\rm mono}\chi_{\rm coef}$ diverges in probability as two eigenvalues approach zero. Hence no finite uniform constant exists even for failure probability $1/2$. [Proof PDF](randomized-and-low-rank-approximation/KE-05/solution.pdf) · [Original canonical target](randomized-and-low-rank-approximation/KE-05/README.md).

The complete argument passed a separate [independent Codex-agent mathematical audit](references/stepaniants-ke05-2026-09-12/independent-review.md). Substantial AI assistance and informal-review limits are explicit. That historical audit supplied no formal verification; the later Lean record follows below. External human peer review is not asserted. Shao retains credit for the conjecture and framework. The example uses interlaced block spectra, which the canonical target permits; it does not settle a different ordered-interval variant or disprove block Lanczos convergence. The [submission record](references/stepaniants-ke05-2026-09-12/README.md) documents exact verification, source checks and public eligibility. The permanent ID, original statement and historical ratings remain intact.

**Lean verified, 16 September 2026 UTC. Formalization: Sidney Holden; mathematical proof and integration/verification: George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology. The [complete ten-target formalization](randomized-and-low-rank-approximation/KE-05/lean/README.md) retains the actual recurrence, all root orderings, Gaussian law, operator norms and deterministic-input probability quantifiers. [Canonical Linux run 35058392398](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/35058392398/job/104673346252) passed all ten LeanCert kernel-trust assertions, Comparator, default-kernel replay, standard transitive axioms and required controls at immutable proof commit `414371c9a76aafd7477d9705f9644f7efeb5e329`. Two independent AI-agent complete-source reviews and an authenticated fresh-run audit are retained. Holden's Apache-2.0 mathematical Lean implementation is unchanged, and Shao retains the original framework credit. See the [canonical evidence section](randomized-and-low-rank-approximation/KE-05/README.md#lean-proof-and-verification-evidence).


### ✅ MF-21 - the higher-order Toeplitz expansion threshold - George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Affirmative resolution recorded 2026-09-12 (UTC).** [Theorem 1 and Sections 2-5](matrix-functions-and-stability/MF-21/solution.md) establish the complete three-part threshold for every integer $m\ge3$: one smooth coefficient family gives uniform expansions through order $2m-1$, the stated high-index order-$2m$ expansion, and failure of that last order uniformly over all eigenvalues. [Proof PDF](matrix-functions-and-stability/MF-21/solution.pdf) · [Original canonical target](matrix-functions-and-stability/MF-21/README.md).

The complete proof passed a separate [independent Codex-agent mathematical audit](references/stepaniants-mf21-2026-09-12/independent-review.md). Substantial AI assistance and informal-review limits are explicit; no external human peer review or formal verification is asserted. The original conjecture, prior special cases, and the external inverse-kernel theorem retain their source attribution. The [submission record](references/stepaniants-mf21-2026-09-12/README.md) records frozen-source comparison, exact checks, document inspection, and public eligibility. The permanent ID, original statement and historical ratings remain unchanged.


### ✅ FR-12 - the Hadamard counting conjecture is false - George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Negative resolution recorded 2026-09-12 (UTC).** [Lemma 1 and Theorem 1](frames-and-matrix-designs/FR-12/solution.md) give an injective matching-indexed doubling construction and the lower bound $H(2^k)\ge2^{2^k(k-1)(k-2)/8}$ for every $k\ge2$. This disproves the proposed $2^{O(n\log n)}$ upper bound for labeled real Hadamard matrices. [Proof PDF](frames-and-matrix-designs/FR-12/solution.pdf) · [Original canonical target](frames-and-matrix-designs/FR-12/README.md).

The complete argument passed a separate [independent Codex-agent mathematical and source-scope audit](references/stepaniants-fr12-2026-09-12/REVIEW.md). Substantial AI assistance is disclosed. That original review was informal; the later formal verification is documented below. External human peer review is not claimed. Ferber, Jain and Zhao retain credit for the conjecture and prior upper bounds. The Hadamard existence conjecture and optimal counting order are not settled. [Submission record and eligibility audit](references/stepaniants-fr12-2026-09-12/README.md).

**Lean verified - 2026-09-12.** The full original counting conjecture is refuted by
[seven checked exports](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/3e20bae9a07b1a33db8fdfb18bdebb9e590071a9/frames-and-matrix-designs/FR-12/lean/Solution.lean).
**Mathematical proof and Lean formalization: George Stepaniants, Department of Computing and
Mathematical Sciences, California Institute of Technology, Pasadena, California, USA**, with
substantial AI-agent assistance. The formal permutation-indexed injection proves
$m!H(m)^2\le H(2m)$ and the identical source power-of-two lower bound; the stronger informal
$(2m-1)!!$ recurrence is outside the exports. Ferber, Jain and Zhao retain the original
conjecture and prior-upper-bound credit. See the
[canonical verification evidence](frames-and-matrix-designs/FR-12/README.md#lean-proof-and-verification-evidence---2026-09-12),
[two statement and two final proof reviews](frames-and-matrix-designs/FR-12/lean/reviews/),
[successful Linux run](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34718277411)
and [independent operational audit](frames-and-matrix-designs/FR-12/lean/verification/linux-2026-09-12/OPERATIONAL-REVIEW.md).
All 137 submitted input hashes, actual default-kernel replay, standard-three axioms and real
rejection controls were checked. LeanCert audits kernel trust; no numerical interval
certificate or external human peer review is claimed.


### ✅ MF-06 - pointwise Lipschitz lower stability of the joint spectral radius - George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Affirmative resolution recorded 2026-09-12 (UTC).** [Theorem (1), Lemmas 1-5 and Section 6](matrix-functions-and-stability/MF-06/solution.md) prove the full lower-Lipschitz perturbation bound for every fixed nonempty compact complex matrix family in all dimensions. The maximal critical exterior-power reduction handles reducible reference families with unbounded normalized products; the perturbing family may be arbitrary. [Proof PDF](matrix-functions-and-stability/MF-06/solution.pdf) · [Retained canonical target](matrix-functions-and-stability/MF-06/README.md).

The full clarified argument passed a separate [independent Codex-agent mathematical audit](references/stepaniants-mf06-2026-09-12/REVIEW.md). Substantial AI assistance is disclosed; this is informal agent review, not human peer review or formal verification. Epperlein and Wirth retain target attribution, and Barabanov/Wirth extremal norms and Chitour-Mason-Sigalotti nonresonance theory retain credit. The constants depend on the fixed reference family; a two-sided Lipschitz bound uniform over two varying families is not asserted. [Submission record and eligibility audit](references/stepaniants-mf06-2026-09-12/README.md).
### ✅ IE-04 — the uniform exponential GEPP tail is false — George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Solved negatively, 2026-09-11.** The [complete proof's theorem, equation (2), and robustness lemma](linear-systems-and-elimination/IE-04/solution.md) give an explicit full entrywise box of strict-pivot matrices with growth greater than $(3/2)^{n-1}/2$, and Gaussian probability at least $2^{-n^2(n^2+n+5)}$. With the admissible center $I_n$ and noise level one, this contradicts the displayed IE-04 tail for every proposed universal pair of constants at sufficiently large $x$. The proof covers all dimensions needed for the contradiction and does not claim a replacement optimal tail or a sharp high-probability exponent. [Proof PDF](linear-systems-and-elimination/IE-04/solution.pdf) · [Original target](linear-systems-and-elimination/IE-04/README.md).

The complete analytic proof passed a separate [independent Codex-agent review](references/stepaniants-ie04-2026-09-11/verification/IE-04-independent-review.md). Finite exact interval and rational checks are supplementary. AI assistance and automated-review limits are disclosed; no external human peer review is asserted. [Submission record and public eligibility audit](references/stepaniants-ie04-2026-09-11/README.md). All original target quantifiers, the permanent ID and historical ratings are retained.

**Lean verified, 2026-09-15. Formalization: George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology. The [immutable complete formalization](https://github.com/sgstepaniants/OpenProblemsInNLA/tree/026b3e5534a4d6e15ebffb85318c2ff031df32bf/linear-systems-and-elimination/IE-04/lean) proves all 21 frozen targets, including `NLA.IE04.not_uniformExponentialTail`, for the actual Gaussian model and every positive real proposed constant pair. [Canonical Linux run 35034399633](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/35034399633/job/104600154206) accepted Comparator, independent default-kernel replay, all LeanCert kernel assertions and the mandatory rejection controls with only the three standard Lean axioms. The full nonsingular perturbation-box estimate consumes the LeanCert certificate $`e^{-2}>1/8`$. [Project and original runtime evidence](linear-systems-and-elimination/IE-04/lean/README.md) · [Both independent final AI-agent reviews](linear-systems-and-elimination/IE-04/lean/reviews/final). The publication documentation preserves the accepted proof bytes and requires its own workflow rerun.

### ✅ IE-05 - the orthogonal partial-pivoting extremizer equality is false - George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Lean verified, 2026-09-13.** The complete negative resolution is formalized
in [17 checked exports](linear-systems-and-elimination/IE-05/lean/README.md),
including `NLA.IE05.orthogonalExtremizerConjecture`, while preserving the full
real orthogonal supremum and all admissible partial-pivoting paths. The exact
order-eight witness refutes the universal equality. The proof passed
[Ubuntu Comparator/default-kernel verification](linear-systems-and-elimination/IE-05/lean/verification/linux-2026-09-13/)
and an independent operational evidence audit. **Lean formalization and
mathematical proof:** George Stepaniants, Department of Computing and
Mathematical Sciences, California Institute of Technology, Pasadena,
California, USA, with AI-agent assistance. Peca-Medlin retains credit for the
conjecture and cited element-growth analysis. The true supremum and separate
asymptotic leading-constant question remain outside scope.

**Negative resolution recorded 2026-09-11.** The [Theorem and Sections 1-4](linear-systems-and-elimination/IE-05/solution.md) give an exact real orthogonal counterexample at order eight. The positive-diagonal QR factor of $L_8+e_8e_2^T$ has partial-pivoting growth $5272/63$, strictly above the prescribed candidate's $\sqrt{17948132/2601}$. Both use the first available row in ties, so the counterexample also belongs to the supremum over all admissible paths. [Proof PDF](linear-systems-and-elimination/IE-05/solution.pdf) · [Canonical target](linear-systems-and-elimination/IE-05/README.md).

The proof passed a separate [Codex-agent full-target review](references/stepaniants-ie05-2026-09-11/independent-review.md), including independently reconstructed exact orthogonality, QR signs, all pivots and all active maxima. Substantial AI assistance and the limits of automated review are explicit. This settles the finite-order extremizer equality and leaves the true supremum and the distinct asymptotic leading constant undetermined. Peca-Medlin's conjecture and prior element-growth analysis retain their attribution. [Submission record and public-source check](references/stepaniants-ie05-2026-09-11/README.md).

<a id="tr-01"></a>

### 🏆 TR-01 — optimal dimension for a rerandomized Hadamard embedding — Yuning Yang

[Original target and resolution](randomized-and-low-rank-approximation/TR-01/README.md) · [TR-01 statement and result PDF](randomized-and-low-rank-approximation/TR-01/problem.pdf)

**Lean verified, 2026-09-12.** The manuscript for v7, *Subspace embeddings with the rerandomized SRHT* (Theorem 1, [manuscript PDF](https://github.com/yuningyang19/OpenProblemsInNLA_TR-01/blob/ed21181197ac839eac95f549404f94e7e3aa6e10/manuscript.pdf)), proves the exact TR-01 target at prescribed width for the two-round rerandomized SRHT law, with full width cap and constant success probability $0.99$, for every power-of-two $n$, every $1\le r\le n$, and every fixed target subspace $V\subseteq\mathbb R^n$. For any orthonormal basis matrix $U\in\mathbb R^{n\times r}$ of $V$, Theorem 1 proves

$$
\Pr\left\{\|U^T\Omega\Omega^T U-I_r\|_2\le\varepsilon\right\}\ge0.99.
$$

The manuscript range is $\varepsilon\in(0,1)$, which strictly contains TR-01’s $\varepsilon\in(0,1/2)$. The canonical assumptions match the original statement’s target model and quantifiers, and there is no remaining open parameter case.

The public Lean repository is immutable revision [`ed211811`](https://github.com/yuningyang19/OpenProblemsInNLA_TR-01/tree/ed21181197ac839eac95f549404f94e7e3aa6e10), with toolchain `lean 4.33.0`, `mathlib` commit `db584cd6d46c92f209a44c0f1c829460d327499d`. The submitted verification package identifies the corresponding Lean declarations

- `Problem56.PaperV7.certified_main`
- `Problem56.PaperV7.certified_explicit_main`
- `Problem56.PaperV7.main_prescribed_width_ose`

and includes an independent manuscript-to-Lean statement-correspondence review. Reproducible evidence is linked from the canonical TR-01 page and the immutable public revision. The axiom audit accepts only `propext`, `Classical.choice`, and `Quot.sound`. The catalog’s [independent Lean audit](references/maintainer-review-2026-09-12-tr01/pr141-lean-review.md) records its own executed checks and the archived evidence reviewed. Separate agents checked the complete mathematical argument, exact original target and publication artifacts. See the canonical TR-01 page for the reproduction commands, complete evidence, and the disclosed mismatch in the pinned PDF’s older formalization acknowledgment.

<a id="ie-01"></a>

### 🏆 IE-01 — Forsythe's conjecture beyond restart length two

[Original statement and resolution](linear-systems-and-elimination/IE-01/README.md) · [PDF](linear-systems-and-elimination/IE-01/problem.pdf)

**Complete classification; Lean verified status recorded 2026-09-11.** Colbrook, Stepaniants and Townsend's [September 2026 paper, v2, Theorem 1.1](https://arxiv.org/html/2609.04659v2) proves convergence for restart length three and gives nonterminating diagonal SPD counterexamples in dimension $s+4$ for every $s\ge4$. This settles the entire original target. The paper also proves the positive case $s=2$.

The authors' [Lean proof](https://github.com/sgstepaniants/Forsythe/tree/main/lean-proof), described in Appendix D, formalizes the classification including the analytic and numerical premises. Its [verification record](https://github.com/sgstepaniants/Forsythe/blob/8d1b0c0545a77b40245e84705aa7d273e6c81e62/lean-proof/VERIFICATION.md) documents successful Comparator statement checks and Lean kernel replay for all five exports, with only the standard axioms `propext`, `Classical.choice` and `Quot.sound`. This catalog checked the formal statement scope and public verification evidence; it did not rerun Lean or Comparator locally. This supersedes the former **Solution claimed** label. The stable ID and original statement remain, and the entry stays outside the open count.

### ✅ SP-11 and SP-12 — Hall's theorem; application notes by George Stepaniants

**Application-note author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology. **Theorem author:** H. Tracy Hall.

**Literature-dependent affirmative resolutions recorded 2026-09-11.** Hall's [*The Delta Theorem*, arXiv:2601.01211v1](https://arxiv.org/html/2601.01211v1), Theorem 3.20 and Corollary 3.22, proves the all-graph PSD/SAP bound $\nu(G)\ge\delta(G)$. The source is a preprint, submitted 3 January 2026; the complete essential proof and both deductions passed a separate [independent Codex-agent mathematical review](references/stepaniants-sp11-sp12-2026-09-11/verification/SP-11-SP-12-independent-review.md). This is automated-agent verification, not human peer review or formal certification.

- **SP-11:** [Original target and resolution](eigenvalues-and-inverse-problems/SP-11/README.md) · [Application note](eigenvalues-and-inverse-problems/SP-11/solution.md) · [PDF](eigenvalues-and-inverse-problems/SP-11/solution.pdf). Forgetting PSD and SAP gives $\operatorname{mr}(G)\le n-\delta(G)$; Hall's Corollary 3.24 already states this ordinary Delta consequence.
- **SP-12:** [Original target and resolution](eigenvalues-and-inverse-problems/SP-12/README.md) · [Application note](eigenvalues-and-inverse-problems/SP-12/solution.md) · [PDF](eigenvalues-and-inverse-problems/SP-12/solution.pdf). The supplied proof of induced-subgraph monotonicity, followed by a chromatic-critical subgraph reduction, gives $\nu(G)\ge\chi(G)-1$ for every finite simple graph.

These are explanatory applications of Hall's theorem, with substantial AI assistance disclosed and no novelty or priority claim. The [submission record](references/stepaniants-sp11-sp12-2026-09-11/README.md) preserves the original six-file package, withdrawn unsupported artifact claims, current audit, and review. Both permanent IDs, original targets, and earlier attributed partial results are retained.

### ✅ IE-02 — ideal and worst-case GMRES coincide for every Jordan block — George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Solved affirmatively, 2026-09-11.** [Theorem 1](linear-systems-and-elimination/IE-02/solution.md) proves the exact complex equality for every $n\ge2$, $1\le k<n$, and $\lambda\ne0$. Theorem 6 establishes the stronger affine triangular-Toeplitz minimax result, using finite Carathéodory–Fejér interpolation and scalar spectral factorization to preserve all complex orthogonality conditions in one extremal vector. [Proof PDF](linear-systems-and-elimination/IE-02/solution.pdf) · [Canonical target](linear-systems-and-elimination/IE-02/README.md).

The complete analytic proof passed a separate [independent Codex-agent review](references/stepaniants-ie02-2026-09-11/verification/IE-02-independent-review.md). AI assistance and automated-review limits are disclosed; no external human peer review or formal certification is asserted. [Submission record and public eligibility check](references/stepaniants-ie02-2026-09-11/README.md). All original target quantifiers, the permanent ID and historical ratings are retained.

### RA-20 - symmetric rank-two critical-point formula refuted

**Negative resolution recorded 2026-09-11 during the Codex maintainer audit.** For the retained [original target](randomized-and-low-rank-approximation/RA-20/README.md), the admissible case n=s=3 has exactly three generic smooth-locus critical points, whereas the displayed formula predicts four. The hollow symmetric determinant is 2abc; the three coordinate planes each contribute one simple critical point. [Complete proof](randomized-and-low-rank-approximation/RA-20/solution.md) · [Independent reconstruction and exact checks](references/research-expansion-2026-09-11/ra20-resolution/README.md). This refutes the joint universal conjecture without narrowing it. The other formulas and parameter ranges remain unclaimed. The ID and canonical path are retained; that original audit was by automated agents. The separate full-target Lean verification below supersedes its informal-only status; external human peer review is not claimed.


**Lean verified - 2026-09-13. Lean formalization:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA, with AI-agent assistance. Original negative-resolution credit remains with the Codex automated maintainer audit, and original conjecture credit with Kubjas, Sodomaco and Tsigaridas. The [twelve exported theorems](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/43603b173beb294c2588d83f936a8a96246fd5f0/randomized-and-low-rank-approximation/RA-20/lean/Solution.lean) prove the actual reduced-ring, smooth-locus, tangent, derivative and generic-cardinality bridges and negate the complete original four-formula conjecture at its allowed case n=s=3. [Ubuntu run 34743832047](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34743832047) matched every frozen export and replayed the solution through Lean's default kernel, with 61 LeanCert kernel assertions and 57 source reports allowing only the standard three axioms. The [canonical proof and verification evidence](randomized-and-low-rank-approximation/RA-20/README.md#lean-proof-and-verification-evidence---2026-09-13) gives immutable sources, pins, commands, two independent mathematical reviews and the accepted operational audit. The other individual formulas and a separate scheme-multiplicity theorem remain outside the claims.

### 🏆 MF-22 — cubic C1 spline Schrödinger Toeplitz conditioning — George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology.

**Solved affirmatively, 2026-09-11.** The [Theorem in Section 1 and proof in Sections 2–4](matrix-functions-and-stability/MF-22/solution.md) establish eventual invertibility and $\kappa_2(H_n(\rho))\le K_\rho n$ for every fixed real $\rho>0$. This answers the exact pure Toeplitz question with exponent one, including $\rho=\sqrt{10}$ and all stated boundary entries. [Proof PDF](matrix-functions-and-stability/MF-22/solution.pdf) · [Original canonical target](matrix-functions-and-stability/MF-22/README.md).

The full proof passed a separate [Codex-agent mathematical review](references/stepaniants-mf22-2026-09-11/verification/MF-22-independent-review.md), with an independent checker confirming 31 exact polynomial identities. The [submission record](references/stepaniants-mf22-2026-09-11/README.md) documents substantial AI assistance, the exact reviewed source, public branch/fork checks, and verification limits. That original audit was informal automated-agent review. The later Lean proof is recorded separately below; external human peer review is not claimed. The original authors retain credit for the family, root classification and question; the original ID, statement, path and historical ratings remain unchanged.

**Lean verified, 16 September 2026 UTC. Formalization: George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology. The [complete 22-target formalization](matrix-functions-and-stability/MF-22/lean/README.md) proves eventual invertibility and $`\kappa_2(H_n(\rho))\le K_\rho n^2`$ for every fixed positive real parameter, including $`\rho=\sqrt{10}`$, with the literal complex matrix, exact pure Toeplitz boundaries and genuine Euclidean condition number. Exponent **two** fully answers the original existential polynomial question; the manuscript's stronger exponent-one bound is not a formalized result. [Exact proof-commit Linux run 35053254275](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/35053254275/job/104658059786) passed LeanCert kernel assertions, Comparator, default-kernel replay, standard transitive axioms and required rejection/sandbox controls. Two independent AI-agent final referees accepted the complete source and actual evidence. See the [canonical verification record](matrix-functions-and-stability/MF-22/README.md#lean-proof-and-verification-evidence). Original source authors retain their credit; no contact email is published.


### ✅ RA-13 - absolute-error Gaussian trace-tail threshold - George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Solved affirmatively, 2026-09-11.** [Sections 1-8 of the complete proof](randomized-and-low-rank-approximation/RA-13/solution.md) establish both canonical probability comparisons for every nonzero real symmetric matrix, including indefinite matrices, every positive sample count, and the stated threshold endpoint. The argument proves a stronger one-sided comparison for centered signed Gamma sums, then applies it to both signs and takes an infinite-divisibility limit. [Proof PDF](randomized-and-low-rank-approximation/RA-13/solution.pdf) · [Original target](randomized-and-low-rank-approximation/RA-13/README.md).

The full proof passed a separate [independent Codex-agent review](references/stepaniants-ra13-2026-09-11/verification/RA-13-independent-review.md), including the published bell-shape theorem, new inflection identity, grouped transfers and endpoint limits. AI assistance and the limits of automated review are explicit. Kwaśnicki's and Hallman's external results retain attribution; Colbrook's earlier auxiliary counterexamples remain valid and separately credited. [Submission record and public-status audit](references/stepaniants-ra13-2026-09-11/README.md). The permanent ID, original statement and historical ratings are retained.

### ✅ MF-18 — general complex Green-function imaginary rank — George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Solved affirmatively, 2026-09-11.** [Theorem 1 and Sections 1-4](matrix-functions-and-stability/MF-18/solution.md) prove that the imaginary part of the finite nonsingular stabilizing limit has rank exactly half the number of simple unit-circle eigenvalues of the quadratic matrix polynomial. The proof covers the full complex $C,D,R,P$ assumptions, singular coefficient matrices, roots at $1$ or $-1$, and arbitrary strictly stable Jordan blocks. [Proof PDF](matrix-functions-and-stability/MF-18/solution.pdf) · [Original canonical target](matrix-functions-and-stability/MF-18/README.md).

The complete proof passed a separate [Codex-agent mathematical review](references/stepaniants-mf18-2026-09-11/verification/MF-18-independent-review.md). The [submission record](references/stepaniants-mf18-2026-09-11/README.md) documents substantial AI assistance, the exact reviewed source, public branch/fork checks, and verification limits. The earlier Guo-Kuo-Lin results and Matthew J. Colbrook's distinct real-coefficient defective extension retain their credit. The original ID, statement, path and historical ratings are preserved.

### ✅ TR-17 and TR-27 — global Frobenius minimality and tensor-square rank

**Resolutions by Matthew J. Colbrook recorded 2026-09-11.** Author affiliation: Department of Applied Mathematics and Theoretical Physics, University of Cambridge. Two independent mathematical agents reviewed the complete sources, one per target; a separate agent reviewed and reran all three supplied verification programs. This is AI-assisted agent verification, not external human peer review or formal certification, and no priority claim is made. [Submission, source hashes and verification record](references/colbrook-tensor-metrics-rank-2026-09-11/README.md). Original statements, IDs and historical ratings are retained.

- **[TR-17](tensor-computations/TR-17/README.md), affirmative:** [Theorem 1](references/colbrook-tensor-metrics-rank-2026-09-11/manuscripts/tr17_solution.pdf) proves that the Frobenius metric globally minimizes the Euclidean distance degree for every Segre–Veronese format in the target and every positive definite real symmetric metric, using the stated complex-bilinear and multiplicity conventions. Singular and nonreduced quadric sections are included. [Complete-source mathematical review: PASS](references/colbrook-tensor-metrics-rank-2026-09-11/verification/reviews/TR-17-review.md).
- **[TR-27](tensor-computations/TR-27/README.md), negative:** [Theorem 1 and Section 4](references/colbrook-tensor-metrics-rank-2026-09-11/manuscripts/tr27_solution.pdf) exhibit a smooth irreducible nondegenerate curve in $\mathbb P^{11}$ with border rank 2, rank 3 and rank 9 at the Segre tensor square. This refutes the universal implication for projective varieties. The stronger construction permits any prescribed finite delay of strict submultiplicativity; it does not refute the known eventual-power saving or assert a counterexample restricted to Segre or Veronese varieties. [Complete-source mathematical review: PASS](references/colbrook-tensor-metrics-rank-2026-09-11/verification/reviews/TR-27-review.md).

**TR-27 author feedback, 2026-09-17.** In personal correspondence, Alessandra Bernardi said she thought the argument works and agreed that it contradicts Conjecture 1.1 in its stated generality, while the Segre and Veronese restrictions remain open. This is informal mathematical feedback, not a formal referee report. [Correspondence summary](references/colbrook-tensor-metrics-rank-2026-09-11/README.md#tr-27-author-feedback--2026-09-17).

### ✅ Two randomly pivoted factorization resolutions by Matthew J. Colbrook — 2026-09-11

**Author:** Matthew J. Colbrook, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. The complete shared manuscript passed separate independent agent audits for RA-02 and RA-03, with a separate exact-code review and fresh computations. AI assistance is disclosed. The original targets, IDs and historical ratings are retained. [Submission record](references/colbrook-random-pivoting-2026-09-11/README.md). No external human peer review, formal certification or priority determination is claimed.

#### RA-02 — Lean-verified negative resolution — formalization by George Stepaniants

[Original target](randomized-and-low-rank-approximation/RA-02/README.md) · [Complete proof](references/colbrook-random-pivoting-2026-09-11/manuscripts/sharp_random_pivoting.pdf) · [Independent review](references/colbrook-random-pivoting-2026-09-11/verification/reviews/RA-02-review.md). Theorem 1 and Corollary 3 disprove the existence of constants $C,p$ giving the displayed polynomial bound after exactly $r$ pivots. For every fixed $r\ge1$, real entrywise-positive positive-definite matrices of order $r+1$ approach the sharp expected trace-error ratio $2^r$ as a parameter tends to zero. Choose $r$ first and then the parameter; no limit uniform in $r$ is needed. The result does not address oversampling (RA-01).

**Lean verified, 2026-09-17 (UTC).** **George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology, supplied the [complete 27-contract formalization](randomized-and-low-rank-approximation/RA-02/lean/README.md). For every real $C>0$ and $p\ge0$, it gives a positive-definite witness of order $r+1$ whose actual expected trace after exactly $r$ pivots strictly exceeds $C r^p$ times its positive, genuinely ordered eigenvalue tail. The full normalized law includes every ordered history. The sufficient finite factor $2^r/3$ negates the complete original complex-PSD assertion; the manuscript's sharp limiting, entrywise-positive, correlation-matrix, LU and oversampling extensions are not additional formal claims. The [immutable proof](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/26dc080e47b75a3aaf2e75fc2a282d0b8f4a4bbb/randomized-and-low-rank-approximation/RA-02/lean/Solution.lean) passed [actual non-root Linux run 35175272827](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/35175272827/job/105055587640): all 27 Comparator targets, default-kernel replay, standard transitive axioms and required rejection and sandbox controls. Two complete nonauthor source reviews and an independent runtime audit are retained with the [canonical evidence](randomized-and-low-rank-approximation/RA-02/README.md#lean-proof-and-verification-evidence). Matthew J. Colbrook retains mathematical credit. AI assistance and review scopes are disclosed; the original informal manuscript audit above remains historical.

#### RA-03 — Lean-verified negative resolution — formalization by George Stepaniants

[Original target](randomized-and-low-rank-approximation/RA-03/README.md) · [Complete proof](references/colbrook-random-pivoting-2026-09-11/manuscripts/sharp_random_pivoting.pdf) · [Independent review](references/colbrook-random-pivoting-2026-09-11/verification/reviews/RA-03-review.md). Section 2 gives the exact counterexample $A=\left(\begin{smallmatrix}2&1\\1&2\end{smallmatrix}\right)$: one pivot has expected squared Frobenius error $18/5$, while the best rank-one squared error is $1$. Thus the displayed $2^k$ bound is false already at $k=1$. Theorem 1 additionally proves that the known $4^r$ factor is sharp as a supremum at every rank, even on real entrywise-positive positive-definite inputs.

**Lean verified, 2026-09-12. Lean formalization:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA, with AI-agent assistance. Mathematical proof credit remains with Matthew J. Colbrook. The [four checked exports](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/973f95969701601dcae7b30683b175843baa9c22/randomized-and-low-rank-approximation/RA-03/lean/Solution.lean) establish the actual Frobenius norm bridge, normalization of the full conditional pivot process, the exact counterexample and the negation of the complete original universal bound. [Linux run 34704564047](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34704564047) accepted the frozen statements and replayed all exports through Lean's default kernel with only `propext`, `Classical.choice` and `Quot.sound`. Two independent mathematical referees and an independent operational audit are retained with the [proof and verification evidence](randomized-and-low-rank-approximation/RA-03/README.md#lean-proof-and-verification-evidence--2026-09-12). The sharp all-rank and Cholesky results of the manuscript are outside the formalized scope; the original informal audit record above remains historical.

### Three joint-spectral-radius and growth resolutions by Matthew J. Colbrook — 2026-09-11

**Author:** Matthew J. Colbrook, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. Two separate Codex agents reviewed the two complete manuscripts against three exact canonical targets; all three received PASS. A third agent reviewed the computational evidence and fresh diagnostics. The proofs were developed with AI assistance; no external human peer review, formal certification or priority claim is asserted. [Submission record, preserved originals, public eligibility audit and reviews](references/colbrook-jsr-growth-2026-09-11/README.md).

**MF-05 — affirmative resolution.** [Original target and resolution](matrix-functions-and-stability/MF-05/README.md) · [Complete proof, Theorem 2 and Corollary 7](references/colbrook-jsr-growth-2026-09-11/manuscripts/uniform_growth_and_holder.pdf) · [Independent review](references/colbrook-jsr-growth-2026-09-11/verification/reviews/MF-05-MF-07-review.md). For every pair of nonempty compact real or complex matrix families in a spectral-norm ball of radius $L>0$, the joint spectral radii differ by at most $d(2d+1)L^{1-1/d}d_H^{1/d}$. This proves the local two-family assertion, including reducible families and zero joint spectral radius. The exponent is sharp; MF-06 is unaffected.

**MF-07 — affirmative resolution; Lean formalization by George Stepaniants.** [Original target and resolution](matrix-functions-and-stability/MF-07/README.md) · [Complete proof, Theorem 1 and Proposition 5](references/colbrook-jsr-growth-2026-09-11/manuscripts/uniform_growth_and_holder.pdf) · [Independent review](references/colbrook-jsr-growth-2026-09-11/verification/reviews/MF-05-MF-07-review.md). Every product of length $k$ from a family of joint spectral radius one is bounded by $\Theta_d(Lk)^{d-1}$, where $\Theta_1=1$ and $\Theta_d=d(2ed^2/(d-1))^{d-1}$ for $d\ge2$. The constant depends only on dimension; arbitrary compact complex families and every switching word are covered. The exponent $d-1$ is sharp, while the stated constant is not claimed optimal.

**Lean verified, 2026-09-17 (UTC).** **George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology, supplied the [complete 18-target formalization](matrix-functions-and-stability/MF-07/lean/README.md). It preserves all positive dimensions, arbitrary nonempty compact complex families, actual Euclidean operator norms, every positive-length switching word and the original joint-spectral-radius limit. The [immutable proof](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/b2b9acc83ad7d6b7d3888de8390475a30c720af8/matrix-functions-and-stability/MF-07/lean/Solution.lean) and [actual Linux run 35172783207](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/35172783207/job/105047879291) passed default-kernel replay, Comparator, standard transitive axioms and rejection/isolation controls. Two complete nonauthor source reviews and an independent runtime audit support the [canonical evidence](matrix-functions-and-stability/MF-07/README.md#lean-proof-and-verification-evidence). Matthew J. Colbrook retains original mathematical credit. The formal constant uses 6 in place of 2e; the smaller manuscript constant, sharpness and other extensions are not additional formal claims. AI assistance and reviewer scopes are disclosed.

**MF-12 — affirmative resolution; Lean formalization by George Stepaniants.** [Original target and resolution](matrix-functions-and-stability/MF-12/README.md) · [Complete proof, Theorem 1 and §§2–5](references/colbrook-jsr-growth-2026-09-11/manuscripts/arbitrary_growth_exponents.pdf) · [Independent review](references/colbrook-jsr-growth-2026-09-11/verification/reviews/MF-12-review.md). For every real $\alpha\ge0$, two fixed real matrices have joint spectral radius one and maximal length-$k$ product norm comparable to $k^\alpha$ at every positive integer length. Six-dimensional pairs suffice between exponents zero and one; rational exponents admit dyadic-rational entries. This is the finite-family, every-length result, not an infinite-family or subsequence construction.

**Lean verified, 15 September 2026.** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, supplied the [complete 28-target formalization](matrix-functions-and-stability/MF-12/lean/README.md). It preserves every nonnegative real exponent, exactly two distinct fixed real matrices, genuine Euclidean operator norms, every product at every positive length, attained maxima and the actual root limit one. The [exact proof-commit Linux run](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/35037011332/job/104608341268) passed LeanCert kernel assertions, Comparator, default-kernel replay, standard transitive axioms and rejection/sandbox controls. Two independent AI-agent final referees accepted the complete source and actual evidence; see the [canonical evidence section](matrix-functions-and-stability/MF-12/README.md#lean-proof-and-verification-evidence). Matthew J. Colbrook retains original mathematical authorship. The source's additional rational-entry and density results and sharper constants are outside this formalization.

The original statements, permanent IDs and historical ratings remain retained. The archive's preparation-stage HOLD and access limitations are preserved as history; the current public eligibility audit and independent proof reviews support these three original mathematical resolutions.

### ✅ Three tensor resolutions by Matthew J. Colbrook — 2026-09-11

**Author:** Matthew J. Colbrook, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. Complete AI-assisted arguments passed separate independent Codex-agent reviews; TR-06 passed two. This is independent agent verification, not external human peer review or formal certification. The [submission record](references/colbrook-unclaimed-2026-09-11/README.md) separates the supplied summary-only archive from the complete arguments developed here. No novelty or priority claim is made. Original IDs, targets and historical ratings remain intact.

#### TR-06 — affirmative resolution

[Canonical target](tensor-computations/TR-06/README.md) · [Complete proof](references/colbrook-unclaimed-2026-09-11/manuscripts/TR-06.md) · [PDF](references/colbrook-unclaimed-2026-09-11/manuscripts/TR-06.pdf) · [Independent review](references/colbrook-unclaimed-2026-09-11/verification/reviews/TR-06-review.md) · [Second review](references/colbrook-unclaimed-2026-09-11/verification/reviews/TR-06-second-review.md). **Theorem and Sections 2–4.** The mean angular condition number is finite for every generically complex-identifiable format and rank in the original volume-Gaussian model. A bounded semialgebraic graph gives finite first-derivative integral on the unit link; conical scaling gives a finite Gaussian radial factor. This does not assert finite regular-condition means or higher moments.

#### TR-15 — negative resolution; Lean formalization by George Stepaniants

[Canonical target](tensor-computations/TR-15/README.md) · [Complete proof](references/colbrook-unclaimed-2026-09-11/manuscripts/TR-15.md) · [PDF](references/colbrook-unclaimed-2026-09-11/manuscripts/TR-15.pdf) · [Independent review](references/colbrook-unclaimed-2026-09-11/verification/reviews/TR-15-review.md). **“Counterexample” and “The premise is not vacuous”.** The common generating vector $(2,0,1,0,2,0,-1)$ gives an order-three, dimension-three Hankel tensor whose real H-eigenvalues are all positive, and an order-six, dimension-two tensor with H-eigenvalue $-1$. This exactly refutes the odd-order inheritance conjecture; it does not contradict results requiring a positive-semidefinite associated Hankel matrix. The included standard-library checker verifies the contractions and positivity identity in exact integer arithmetic.

**Lean verified — 2026-09-12.** The full original inheritance conjecture is refuted, with a
proved nonvacuous lower premise, by the
[seven checked exports](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/6a2d0868e8b7905dbd5c04d4beaae8cf43288e1f/tensor-computations/TR-15/lean/Solution.lean).
**Lean formalization: George Stepaniants, Department of Computing and Mathematical Sciences,
California Institute of Technology, Pasadena, California, USA**, with AI-agent assistance.
Matthew J. Colbrook retains authorship of the counterexample and informal proof. See the
[canonical verification evidence](tensor-computations/TR-15/README.md#lean-proof-and-verification-evidence---2026-09-12),
[two statement and two final proof reviews](tensor-computations/TR-15/lean/reviews/),
[successful Linux run](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34716902324)
and [independent operational audit](tensor-computations/TR-15/lean/verification/linux-2026-09-12/OPERATIONAL-REVIEW.md).
All 135 submitted input hashes, default-kernel replay, standard-three axioms and actual rejection
controls were verified. No external human peer review is claimed.


#### TR-26 — affirmative resolution

[Canonical target](tensor-computations/TR-26/README.md) · [Complete proof](references/colbrook-unclaimed-2026-09-11/manuscripts/TR-26.md) · [PDF](references/colbrook-unclaimed-2026-09-11/manuscripts/TR-26.pdf) · [Independent review](references/colbrook-unclaimed-2026-09-11/verification/reviews/TR-26-review.md). **Theorem 1 and Sections 2–7.** For every $d\ge2$ in the exact standard unweighted embedding, the reduced isotropic and nonisotropic Rayleigh–Ritz discriminants have degrees $2d$ and $6(d-1)$. The proof establishes distinct isotropic hyperplanes, irreducibility of the other part and generic discriminant multiplicity one, including $d=2$ and matrix-map degeneracies.

### ✅ Three further tensor resolutions by Matthew J. Colbrook — 2026-09-11

**Author:** Matthew J. Colbrook, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. Three separate agents reviewed the complete recovered AI-assisted manuscripts and returned PASS for their exact canonical targets. Original IDs, targets, historical ratings and provenance remain intact. Verification is independent agent review, not external human peer review or formal certification. [Submission record](references/colbrook-recovered-tensors-2026-09-11/README.md). The already-pushed TR-06, TR-15 and TR-26 submissions are excluded from this batch.

#### TR-04 — affirmative resolution

[Canonical target](tensor-computations/TR-04/README.md) · [Complete proof](references/colbrook-recovered-tensors-2026-09-11/manuscripts/TR-04.pdf) · [Independent review](references/colbrook-recovered-tensors-2026-09-11/verification/reviews/TR-04-review.md). **Theorem 3 and Sections 2–4.** A deterministic algorithm tests at most $n_1$ first-cut singular-subspace choices and TT-SVD completions. It returns a tensor within the prescribed ranks with squared error strictly less than $(d-1)E_*$ whenever $E_*>0$, and exactly reconstructs when $E_*=0$, in the canonical idealized arithmetic/SVD model. This settles the displayed pointwise target. It does not give a smaller uniform factor $c<d-1$ or a finite-precision bit-complexity guarantee; the fixed-format limiting example in Section 5 makes this distinction explicit.

#### TR-13 — affirmative resolution

[Canonical target](tensor-computations/TR-13/README.md) · [Complete proof](references/colbrook-recovered-tensors-2026-09-11/manuscripts/TR-13.pdf) · [Independent review](references/colbrook-recovered-tensors-2026-09-11/verification/reviews/TR-13-review.md). **Theorem 1 and Sections 2–5.** For every odd $m\ge5$ and $n\ge2$, a nonempty Zariski-open set of complex Hankel tensors has ordinary rank, symmetric rank, ordinary border rank, symmetric border rank and Vandermonde rank all equal to $\lceil(m(n-1)+1)/2\rceil$. A compressed three-slice Koszul flattening gives the ordinary-border-rank lower bound, including arbitrary unstructured limiting sequences; a dominant moment map supplies the matching actual Vandermonde-rank upper bound. Exceptional Hankel tensors and the separate all-tensors question TR-14 are not settled.

#### TR-20 — affirmative resolution

[Canonical target](tensor-computations/TR-20/README.md) · [Complete proof](references/colbrook-recovered-tensors-2026-09-11/manuscripts/TR-20.pdf) · [Independent review](references/colbrook-recovered-tensors-2026-09-11/verification/reviews/TR-20-review.md). **Theorem 1 and Sections 2–8.** For every $n\ge2$, the reduced nonisotropic Rayleigh–Ritz discriminants in the original complex bilinear Segre model have degrees $24\binom{n+1}{3}$ for $2\times n$ matrices and $24n^2\binom n2$ for $3\times n$ matrices. The proof handles the logarithmic boundary and crossings, proves simple ramification and generic degree one onto the reduced irreducible image, and then extracts both formulas. Its general coefficient expression is additional to the two requested formulas.

### ✅ MI-28 — determinant comparison for all nonnegative base powers — George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Solved, 2026-09-11.** The proof establishes $\det(A^k+|AB|^p)\ge\det(A^k+A^pB^p)$ for every complex positive definite pair, every dimension, $k\ge0$ and $0\le p\le2$. [Theorem 1 and Corollary 6](matrix-inequalities-and-norms/MI-28/solution.md) establish a stronger normalized log-majorization. The published $k\ge2$ range is credited to Ghabries, Abbas, Mourad and Assi; Furuta inequalities and a parameter interchange close the remaining range. [Proof PDF](matrix-inequalities-and-norms/MI-28/solution.pdf) · [Canonical target](matrix-inequalities-and-norms/MI-28/README.md).

The complete analytic proof and source applications passed a separate [Codex-agent review](references/stepaniants-mi28-2026-09-11/verification/reviews/MI-28-review.md). AI assistance and the limits of automated verification are explicit; no external peer review or formal certificate is asserted. [Submission record](references/stepaniants-mi28-2026-09-11/README.md). No canonical parameter case remains unresolved; the original ID, statement, path and historical ratings are retained.

### ✅ MI-24 — the full Schatten norm complement — George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Solved, 2026-09-11.** The proof establishes the full comparison $\|A+B+G+L\|_p\le\|A+B+2L\|_p$ for every complex positive definite pair, every dimension and all $1\le p\le\infty$. [Theorem 1](matrix-inequalities-and-norms/MI-24/solution.md) combines the published Dinh–Dumitru–Franco Heron inequality, a positive matrix comparison, and the triangle inequality. [Proof PDF](matrix-inequalities-and-norms/MI-24/solution.pdf) · [Canonical target](matrix-inequalities-and-norms/MI-24/README.md).

The complete argument passed a separate [Codex-agent review](references/stepaniants-mi24-2026-09-11/verification/reviews/MI-24-review.md). AI assistance, the existing published inputs and the limits of automated review are explicit. [Submission record and public-branch check](references/stepaniants-mi24-2026-09-11/README.md). The original ID, statement, path and historical ratings are retained.

### ✅ RA-12 — the relative-error threshold for extremal Gaussian trace bounds — George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Affirmative resolution recorded 2026-09-11.**

[Original statement and resolution](randomized-and-low-rank-approximation/RA-12/README.md) · [Complete proof](randomized-and-low-rank-approximation/RA-12/solution.md) · [Proof PDF](randomized-and-low-rank-approximation/RA-12/solution.pdf) · [Independent PASS report](references/stepaniants-ra12-2026-09-11/verification/RA-12-independent-review.md).

**Theorem 1, Lemmas 2-4 and the final theorem proof** establish both comparisons in the canonical Gaussian trace-tail chain for every permitted matrix, sample count, effective rank and $\varepsilon\ge2/(m\mu)$. The proof treats the two one-sided tails separately, including the stated endpoint; no case of RA-12 remains open. It uses an elementary mode bound, minimum-positive-coefficient transfers, the published unimodality theorem of Roosta-Khorasani and Székely, Hallman's coefficient-derivative method and Gamma infinite divisibility. The proof does not claim optimality of the threshold or resolve the different RA-13 target.

A separate Codex agent independently reviewed the full proof and external theorem application. Substantial ChatGPT/Codex assistance and the exact frozen-source hashes are documented in the [submission record](references/stepaniants-ra12-2026-09-11/README.md). This is independent agent verification, not external human peer review or formal certification. The original RA-12 statement and historical ratings remain, and Matthew J. Colbrook's earlier auxiliary counterexamples retain their attribution and links.

### ✅ RA-10 - constant-loss nuclear-error transfer - George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Solved, 2026-09-11.** The universal constant $C=11$ proves the full nuclear-error transfer implication for arbitrary real PSD approximation pairs and every permitted nonnegative continuous operator-monotone function. [Theorem 1 and Lemma 2](randomized-and-low-rank-approximation/RA-10/solution.md) cover all ranks, selected eigenspaces, ties, $f(0)>0$ and zero-tail cases. [Proof PDF](randomized-and-low-rank-approximation/RA-10/solution.pdf) · [Canonical target](randomized-and-low-rank-approximation/RA-10/README.md).

The proof passed a separate [Codex-agent mathematical review](references/stepaniants-ra10-2026-09-11/verification/RA-10-independent-review.md). Substantial AI assistance and the limits of automated review are explicit; no external human peer review or formal certification is asserted. Matthew J. Colbrook's earlier commuting result and lower bound $C\ge2$ retain their attribution below. [Submission record and public-branch check](references/stepaniants-ra10-2026-09-11/README.md).

### ✅ IE-15 — exact rook-pivoting growth in orders three and four — George Stepaniants

**Author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA.

**Solved, 2026-09-11.** The proof establishes $g_{\mathrm{RP}}(3)=3$ and $g_{\mathrm{RP}}(4)=14/3$. [Theorem 1 and Sections 1–5](linear-systems-and-elimination/IE-15/solution.md) give universal bounds for real nonsingular matrices and all admissible rook paths, including ties and intermediate active entries, with explicit rational attaining matrices. [Proof PDF](linear-systems-and-elimination/IE-15/solution.pdf) · [Canonical target](linear-systems-and-elimination/IE-15/README.md).

The complete analytic proof passed a separate [Codex-agent review](references/stepaniants-ie15-2026-09-11/verification/reviews/IE-15-review.md) and independent rational witness checks. AI assistance and the limits of automated review are explicit; that original review did not assert external human peer review or formal certification. [Submission record and public-branch check](references/stepaniants-ie15-2026-09-11/README.md). Existing issue 71 concerns order five and does not settle these two constants. The original ID, statement, path and historical ratings are retained.


**Lean verified, 15 September 2026.** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, supplied the [complete formalization at immutable revision `591690a3`](https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/591690a3ca1715b61e769e7fae68cbda84565f07/linear-systems-and-elimination/IE-15/lean). All eight exports cover the original real-matrix target, every admissible rook choice and tie, all intermediate active entries, and the attained suprema. [Fresh Linux Comparator and default-kernel verification](https://github.com/ajt60gaibb/OpenProblemsInNLA/actions/runs/35010138599/attempts/1) passed with only the three permitted axioms and successful sandbox and rejection controls. Two independent AI-agent final source reviews and two operational reviews are retained in the [canonical evidence record](linear-systems-and-elimination/IE-15/README.md#lean-verification--2026-09-15). Mathematical authorship and the separate order-five result remain unchanged.

### ✅ AA-01, MD-03 and MD-04 — submissions by George Stepaniants, 2026-09-11

**Submission author:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA. Two separate Codex agents independently reviewed the three exact targets and returned PASS. The drafts were supplied in a ChatGPT conversation. Verification is independent automated-agent review, not external human peer review or formal certification. [Authorship, complete manuscripts, review reports and duplicate-submission check](references/stepaniants-2026-09-11/README.md).

**AA-01 (Solved, affirmative) — George Stepaniants.** [Original target and resolution](arithmetic-and-complexity/AA-01/README.md) · [Complete proof](arithmetic-and-complexity/AA-01/solution.pdf), **Theorem 2.1 and Corollary 7.1** · [Independent review](references/stepaniants-2026-09-11/verification/reviews/AA-01-review.md). Stepaniants's signed-order gap characterization gives a finite family of real-quantifier-elimination tests deciding accurate evaluability and constructs an evaluator on positive instances. It covers the exact constant-free finite-tree model, including stored reuse, error-dependent branches, all real inputs and zeros.

**MD-03 (Solved, affirmative) — application note by George Stepaniants.** [Original target and resolution](matrix-discrepancy-and-optimization/MD-03/README.md). **Shengtao Guo, Ethan X. Fang and Junwei Lu**, [arXiv:2609.11189v1](https://arxiv.org/abs/2609.11189v1), **Theorem 1.1, p. 1**, prove the universal Komlós bound with $C=3\sqrt{2\pi}$. Stepaniants's [application note](references/stepaniants-2026-09-11/manuscripts/md03_md04_proofs.pdf), Theorem 1, identifies the matrix columns with the source vectors.

**MD-04 (Solved, affirmative) — application note by George Stepaniants.** [Original target and resolution](matrix-discrepancy-and-optimization/MD-04/README.md). **Guo, Fang and Lu, Corollary 1.2, p. 2**, prove $\operatorname{disc}(A)<3\sqrt{2\pi t}$ at every allowed sparsity. Stepaniants's [application note](references/stepaniants-2026-09-11/manuscripts/md03_md04_proofs.pdf), Theorem 2, records the exact match. The [discrepancy review](references/stepaniants-2026-09-11/verification/reviews/MD-03-MD-04-review.md) checks the substantive source proof as well as both applications. The source remains a preprint, discloses Odin AI use, and retains full theorem attribution to Guo, Fang and Lu.

All three original statements, canonical paths, IDs and historical ratings/audits remain visible. The three surviving targets were open in the published base and all other public branches when checked before this submission.

### ✅ MI-13 — Nobori's spectral-middle-factor commutator inequality

[Original statement and complete proof](matrix-inequalities-and-norms/MI-13/README.md) · [PDF](matrix-inequalities-and-norms/MI-13/problem.pdf)

**Affirmative resolution recorded 2026-09-10.** The complex refined commutator
bound in [Audenaert, Corollary 5](https://arxiv.org/pdf/0907.3913), combined with
square padding and a two-unitary decomposition of a contraction, proves the
exact target for every allowed rectangular dimension. The constant is sharp.
The complete repository proof passed two independent Codex-agent reviews of
its assumptions and steps. It has not received external peer review; no
novelty claim is made. The former difficulty label remains
historical and the entry no longer contributes to the open count.


**Lean verified — 2026-09-17. Formalization contributor: George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology. The [complete formalization](matrix-inequalities-and-norms/MI-13/lean/README.md) proves the full original complex rectangular target, including the refined commutator bound internally and the sharp constant. Actual [non-root Linux verification](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/35191730986/job/105105676064) at immutable revision `e37310121f154b1a0d94efa4f98fdcd469177134` passed all 36 exact Comparator contracts, default-kernel replay, standard-axiom and rejection/isolation checks. Local Lean development and two complete nonauthor source reviews preceded the run; the retained evidence distinguishes those scopes. Original mathematical attribution is unchanged.

### ✅ Five resolutions by Matthew J. Colbrook — 2026-09-11

**Author:** Matthew J. Colbrook, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. Each complete proof passed a separate Codex-agent audit against its exact catalog target on 11 September 2026. Three independent review agents covered the five proofs, with one review per proof. The original drafts were generated in a ChatGPT conversation; the independent agent verification is documented, and no external human peer review or formal proof certificate is asserted. The original statements and historical ratings remain intact. [Review reports, authorship and submission history](references/colbrook-2026-09-11/README.md).

#### IS-02 — negative resolution; Lean formalization by George Stepaniants

**Lean verified — 2026-09-13. Formalization: George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology. The [immutable complete Lean proof](https://github.com/sgstepaniants/OpenProblemsInNLA/tree/522f091b9f0d39d4846f5939bcafc1549ba16a55/eigenvalues-and-inverse-problems/IS-02/lean) proves spectral uniqueness among all real competitors, exclusion from every original vertex-segment family and the complete universal negation. All nine exports passed actual Ubuntu Comparator, permitted-axiom and default-kernel checks; [raw evidence and independent operational review](eigenvalues-and-inverse-problems/IS-02/lean/verification/linux-2026-09-13/README.md). Original mathematical proof: Matthew J. Colbrook, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. AI assistance and independent agent review are disclosed.

[Original statement and resolution](eigenvalues-and-inverse-problems/IS-02/README.md) · [Complete manuscript](eigenvalues-and-inverse-problems/IS-02/solution.md) · [Manuscript PDF](eigenvalues-and-inverse-problems/IS-02/solution.pdf) · [Independent review](references/colbrook-2026-09-11/verification/reviews/IS-02-review.md). **Theorem IS-02, sections 1–2.** The order-four counterexample is real symmetric, nonnegative and stochastic, has spectrum $\{1,1,0,-1\}$ and positive trace, and is spectrally unique up to permutation. It lies outside every segment in the proposed locus, disproving the universal necessary condition at an allowed dimension.

#### SP-04 — negative resolution

[Original statement and resolution](eigenvalues-and-inverse-problems/SP-04/README.md) · [Complete manuscript](eigenvalues-and-inverse-problems/SP-04/solution.md) · [Manuscript PDF](eigenvalues-and-inverse-problems/SP-04/solution.pdf) · [Independent review](references/colbrook-2026-09-11/verification/reviews/SP-04-review.md). **Theorem SP-04, sections 1–4.** The stationary pair with uniquely smallest absolute multiplier fails to minimize the Frobenius distance on a nonempty open set of real $3\times3$ data matrices with distinct singular values in $(7/4,44/25)$. Both determinant signs are allowed, and the open-set argument refutes the algebraic-generic formulation.

**Lean verified, 15 September 2026.** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, supplied the [complete formalization at immutable revision `fcd722e9`](https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/fcd722e923a339dfeee89051886e82c7384a04d7/eigenvalues-and-inverse-problems/SP-04/lean). The eleven exports refute the original algebraic-generic selection rule outside the zero set of every nonzero polynomial in all nine matrix entries. They prove finiteness of the full stationary set, unique least-absolute-multiplier selection and a strictly closer feasible matrix in the literal Frobenius norm, with both determinant signs included. [Fresh Linux Comparator and default-kernel verification](https://github.com/ajt60gaibb/OpenProblemsInNLA/actions/runs/35025876241/attempts/1) passed with only the three permitted axioms and successful sandbox and rejection controls. Two independent AI-agent final source reviews and two operational reviews are retained in the [project record](eigenvalues-and-inverse-problems/SP-04/lean/README.md). Matthew J. Colbrook retains the original mathematical proof credit; substantial AI assistance is disclosed, and no external human review is claimed.

#### SP-05 — affirmative resolution

[Original statement and resolution](eigenvalues-and-inverse-problems/SP-05/README.md) · [Complete manuscript](eigenvalues-and-inverse-problems/SP-05/solution.md) · [Manuscript PDF](eigenvalues-and-inverse-problems/SP-05/solution.pdf) · [Independent review](references/colbrook-2026-09-11/verification/reviews/SP-05-review.md). **Theorem SP-05, sections 1–3.** For arbitrary real symmetric positive definite $A,B$, a nonzero real positive-semidefinite eigenmatrix attains the smallest eigenvalue of $X\mapsto AXB+BXA$. Section 3 derives the exact symmetric/skew-symmetric Rayleigh-quotient inequality in the original target, without commutativity, rank restrictions or a simple-eigenvalue assumption.

**Lean verified, 15 September 2026.** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, supplied the [complete formalization at immutable revision `9c8369dc`](https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/9c8369dcea69f9f243a0502fb7e89beaa8f49fad/eigenvalues-and-inverse-problems/SP-05/lean). The six exports prove both attained sector Rayleigh minima and their comparison for every real symmetric positive definite pair in every dimension at least two. They also prove the stronger global-minimum PSD eigenmatrix theorem in every dimension at least one. Kalantarova and Tunçel retain the original conjecture credit. [Fresh Linux Comparator and default-kernel verification](https://github.com/ajt60gaibb/OpenProblemsInNLA/actions/runs/35030259545/attempts/1) passed with only the three permitted axioms and successful sandbox and rejection controls. Two independent AI-agent final source reviews and two operational reviews are retained in the [project record](eigenvalues-and-inverse-problems/SP-05/lean/README.md). Matthew J. Colbrook retains the original mathematical proof credit; substantial AI assistance is disclosed, and no external human review is claimed.

#### KE-04 — affirmative resolution

**Lean verified — 2026-09-13. Formalization: George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology. The [complete Lean project](https://github.com/sgstepaniants/OpenProblemsInNLA/tree/40b0bf52e73e776e7769f0f12dbbda7cd9fff183/eigenvalues-and-inverse-problems/KE-04/lean) proves the original strict interval-occupancy target with all dimensions, multiplicities and arbitrary Krylov bases. Its 24 exports passed real Ubuntu Comparator, default-kernel and permitted-axiom checks; [verification evidence and independent operational review](eigenvalues-and-inverse-problems/KE-04/lean/verification/linux-2026-09-13/README.md). Original mathematical proof credit remains Matthew J. Colbrook, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. AI assistance and independent agent review are disclosed; no external human peer review is claimed.

[Original statement and resolution](eigenvalues-and-inverse-problems/KE-04/README.md) · [Complete manuscript](eigenvalues-and-inverse-problems/KE-04/solution.md) · [Manuscript PDF](eigenvalues-and-inverse-problems/KE-04/solution.pdf) · [Independent review](references/colbrook-2026-09-11/verification/reviews/KE-04-review.md). **Theorem KE-04, sections 1–3.** Strict interval occupancy holds for every allowed pair of block Lanczos iterations and every indicated index, in exact arithmetic before the first loss of full block dimension. The quadratic-polynomial argument includes multiplicities and excludes coincident interval endpoints in the stated range.

#### KE-03 — affirmative resolution

[Original statement and resolution](eigenvalues-and-inverse-problems/KE-03/README.md) · [Complete manuscript](eigenvalues-and-inverse-problems/KE-03/solution.md) · [Manuscript PDF](eigenvalues-and-inverse-problems/KE-03/solution.pdf) · [Independent review](references/colbrook-2026-09-11/verification/reviews/KE-03-review.md). **Theorem KE-03, sections 1–5.** The algorithm uses $O(\varepsilon^{-2}[1+\log(nK)])$ exact matrix-vector queries, with success probability at least $0.997$, for every input in the displayed model. It supplies both eigenvalue-location guarantees using the given condition bound $K$ and finite exact arithmetic between queries. The result bounds query count, not total runtime, bit complexity or floating-point error.

### ✅ Three further resolutions by Matthew J. Colbrook — 2026-09-11

**Author:** Matthew J. Colbrook, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. Separate Codex agents checked the complete arguments against the exact catalog targets and returned PASS. Two reviewers covered the three full resolutions; a third checked the related partial bound below. Original AI provenance is preserved, and the verification level is explicitly independent agent review. [Detailed reports and submission record](references/colbrook-additional-2026-09-11/README.md).

#### IS-03 — negative resolution by Matthew J. Colbrook; Lean formalization by George Stepaniants

[Original statement](eigenvalues-and-inverse-problems/IS-03/README.md) · [Complete manuscript](eigenvalues-and-inverse-problems/IS-03/solution.md) · [PDF](eigenvalues-and-inverse-problems/IS-03/solution.pdf) · [Independent PASS report](references/colbrook-additional-2026-09-11/verification/reviews/IS-03-review.md). **Theorem 1 and equations (1)–(7).** The nonnegative real order-seven matrix $A=\operatorname{diag}(1/2,C_2,C_4)$ has a normalized characteristic-polynomial derivative whose seventh power sum is $-8593/823543<0$. Every power of a nonnegative matrix has nonnegative trace, so the derivative cannot be realized at order six, or after any zero padding. Reducibility and positive trace are allowed in the original target. This refutes its universal assertion.

**Lean verified - 2026-09-12.** The [seven checked exports](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/f87375fa5d7926fe0e065199eaab8f15ac5a5e48/eigenvalues-and-inverse-problems/IS-03/lean/Solution.lean) negate the complete original derivative-realizability conjecture using the unchanged nonnegative order-seven source matrix and the impossibility of an entrywise-nonnegative realization of exactly order six. Actual characteristic-polynomial differentiation, arbitrary-real-matrix power traces and all original quantifiers are retained, without symmetry or diagonalizability assumptions. **Formalization: George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA**, with AI-agent assistance. Matthew J. Colbrook retains mathematical counterexample credit; Johnson and Hoover, McCormick, Paparella and Thrall retain original-question credit. See the [canonical verification evidence](eigenvalues-and-inverse-problems/IS-03/README.md#lean-proof-and-verification-evidence---2026-09-12), [statement and final reviews](eigenvalues-and-inverse-problems/IS-03/lean/reviews/), [successful Ubuntu run](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34728101436), [operational audit](eigenvalues-and-inverse-problems/IS-03/lean/verification/linux-2026-09-12/OPERATIONAL-REVIEW.md) and [root acceptance](eigenvalues-and-inverse-problems/IS-03/lean/verification/root-operational-2026-09-12/ROOT-CHECKS.json). All 303 inputs, eighteen standard-three axiom reports, actual default-kernel replay and both real control suites were checked. The material explicit kernel LeanCert computation is the singleton sign $`-8593/823543<0`$; exact algebra, derived spectral semantics and Newton identities complete the argument. Operational and publication work does not add mathematical referees. The stronger zero-padding exclusion and separate Monov consequence remain informal source results outside these seven exports. External human peer review is not claimed.

#### SP-06 — negative resolution; Lean formalization by George Stepaniants

**Lean verified — 2026-09-13. Formalization: George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology. The [immutable complete Lean proof](https://github.com/sgstepaniants/OpenProblemsInNLA/tree/3122d69460b0ed6dda3ea00dfaa899f93411ce2f/eigenvalues-and-inverse-problems/SP-06/lean) verifies the entire real Jordan curve, an actual nonreal finite Toeplitz spectral point and the negation of the original universal target. All twenty exports passed real Ubuntu Comparator, permitted-axiom and default-kernel checks; [raw evidence and independent operational review](eigenvalues-and-inverse-problems/SP-06/lean/verification/linux-2026-09-13/README.md). Original mathematical proof: Matthew J. Colbrook, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. AI assistance and independent agent review are disclosed.

[Original statement](eigenvalues-and-inverse-problems/SP-06/README.md) · [Complete manuscript](eigenvalues-and-inverse-problems/SP-06/solution.md) · [PDF](eigenvalues-and-inverse-problems/SP-06/solution.pdf) · [Independent PASS report](references/colbrook-additional-2026-09-11/verification/reviews/SP-06-review.md). **Theorem 1 and equations (1)–(8).** The integer-coefficient Laurent polynomial in Theorem 1 is real on a rigorously constructed star-shaped Jordan curve enclosing zero, while its $2\times2$ Toeplitz section has eigenvalues $-128\pm8i$. The proof checks continuity, injectivity and reality on the entire curve. It refutes the conjectured implication for every finite section; it does not refute the distinct limiting-spectrum statement.

#### IE-08 — affirmative resolution

[Original statement](eigenvalues-and-inverse-problems/IE-08/README.md) · [Complete manuscript](eigenvalues-and-inverse-problems/IE-08/solution.md) · [PDF](eigenvalues-and-inverse-problems/IE-08/solution.pdf) · [Independent PASS report](references/colbrook-additional-2026-09-11/verification/reviews/IE-08-review.md). **Theorem 1, Lemmas 2–12 and the final four proof sections.** The end-to-end algorithm uses $O(n^3\log^c(n/\delta))$ arithmetic operations and $O(\log(n/\delta))$ mantissa bits, with universal constants, for every complex input with $\|A\|_2\le1$. With probability at least $0.99$ it returns an exactly upper triangular $T$ and a $Q$ satisfying both displayed residual bounds. The proof includes finite random sampling, deterministic work caps, global recursive conditioning and floating-point error control, without an input separation or diagonalizability assumption. It is an asymptotic existence result with conservative constants, not a production implementation.

**Related partial result — IS-05 (still counted as open).** [Theorems 1–2](eigenvalues-and-inverse-problems/IS-05/solution.md), independently checked in a [separate PASS report](references/colbrook-additional-2026-09-11/verification/reviews/IS-05-review.md), prove the upper bound $\alpha_*\le1/2$ and an additional parity obstruction. The updated interval is $17/92\le\alpha_*\le1/2$; its exact value remains unresolved. [IS-05](eigenvalues-and-inverse-problems/IS-05/README.md) is **Partially resolved**, not Solved.

### ✅ Ten matrix-inequality resolutions by Matthew J. Colbrook — 2026-09-11

**Author:** Matthew J. Colbrook, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. Three independent Codex agents reviewed thirteen complete arguments, with one PASS report per argument. Ten resolve their exact targets and three establish the partial results below. [Authorship, exact scopes, original proofs and reviews](references/colbrook-matrix-2026-09-11/README.md). Verification is independent agent review; the original drafts were AI-assisted.

#### MI-03 — affirmative result by Matthew J. Colbrook; Lean formalization by George Stepaniants

[Canonical entry](matrix-inequalities-and-norms/MI-03/README.md) · [Complete proof](matrix-inequalities-and-norms/MI-03/solution.pdf) · [Independent review](references/colbrook-matrix-2026-09-11/verification/reviews/MI-03-review.md). **Theorem 1.1 and its proof.** The sharp additive contraction constant is $c_k=k/4$ for every $k\ge2$, including every odd summand count. Exact dimension-two extremizers match the universal upper bound.

**Lean verified - 2026-09-12.** The [eight checked exports](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/901ba5ffad3b57557b60c7360df67659d8b8aa21/matrix-inequalities-and-norms/MI-03/lean/Solution.lean) prove the complete original odd-summand conjecture, via the stronger least admissible constant $`k/4`$ for every $`k\ge2`$. The actual CFC moduli, Euclidean operator norms, all complex contraction tuples and real infimum of the entire admissible set are retained; the universal upper bound is proved internally. **Formalization: George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA**, with AI-agent assistance. Matthew J. Colbrook retains mathematical proof/result credit; Jean-Christophe Bourin and Eun-Young Lee retain the conjecture and prior-bound credit. See the [canonical verification evidence](matrix-inequalities-and-norms/MI-03/README.md#lean-proof-and-verification-evidence---2026-09-12), [statement and final proof reviews](matrix-inequalities-and-norms/MI-03/lean/reviews/), [successful Linux run](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34722618003) and [independent operational audit](matrix-inequalities-and-norms/MI-03/lean/verification/linux-2026-09-12/OPERATIONAL-REVIEW.md). All 173 submitted inputs, sixteen standard-three axiom reports, actual default-kernel replay and real controls were checked. The operational reviewer also served as final proof referee 1. LeanCert audits this exact proof's kernel trust; no numerical interval certificate or external human peer review is claimed. The source's additional three-dimensional Hermitian extremizers and rank classification are outside the formalized exports.


#### MI-04 — affirmative result by Matthew J. Colbrook; Lean formalization by George Stepaniants

[Canonical entry](matrix-inequalities-and-norms/MI-04/README.md) · [Complete proof](matrix-inequalities-and-norms/MI-04/solution.pdf) · [Independent review](references/colbrook-matrix-2026-09-11/verification/reviews/MI-04-review.md). **Theorem 1.1 and its proof.** The universal positive-block operator-norm property holds exactly when the off-diagonal block is essentially Hermitian. The proof applies in every finite dimension without invertibility or distinct-singular-value assumptions. 

**Lean verified - 2026-09-16.** Formalization and verification submission by **George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology. Matthew J. Colbrook retains the original mathematical proof credit. The [immutable 21-export proof](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/63340ef17139606dce03c4d9000288129b773157/matrix-inequalities-and-norms/MI-04/lean/Solution.lean) settles the complete original necessity implication, including singular completions and repeated values. [Actual Linux run 35150473054](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/35150473054) passed default-kernel replay, Comparator, permitted axioms and controls; [independent source and runtime evidence](matrix-inequalities-and-norms/MI-04/lean/VERIFICATION-NOTE.md) records the scope. The source manuscript's stronger equivalence is not an additional formal claim. AI assistance and independent AI-agent reviews are disclosed.

#### MI-06 — negative result by Matthew J. Colbrook; Lean formalization by George Stepaniants

[Canonical entry](matrix-inequalities-and-norms/MI-06/README.md) · [Complete proof](matrix-inequalities-and-norms/MI-06/solution.pdf) · [Independent review](references/colbrook-matrix-2026-09-11/verification/reviews/MI-06-review.md). **Theorem 1.1 and its proof.** No finite constant permits the proposed two-unitary Loewner-order domination for the arithmetic symmetric modulus, already in dimension three. A fixed rational example also refutes the proposed $\sqrt2$ constant. This concerns matrix order, not a separate norm triangle inequality. 

**Lean verified — 2026-09-12:** the complete original factor-$\sqrt2$ assertion is negated by six checked exports at [revision 43b3dc6](https://github.com/sgstepaniants/OpenProblemsInNLA/tree/43b3dc65116633a68c32ec582fd093f3adc95597/matrix-inequalities-and-norms/MI-06/lean), verified in [Linux run 34711237623](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34711237623). The [independent reviews and retained evidence](matrix-inequalities-and-norms/MI-06/lean/README.md) cover the actual CFC moduli, every complex unitary pair, the nonzero orthogonal vector, the homogeneous quadratic bounds and the retained kernel LeanCert certificate. **Formalization: George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA**, with AI-agent assistance. Mathematical counterexample and informal proof remain attributed to Matthew J. Colbrook. The stronger no-finite-constant source theorem is outside these six exports.

#### MI-07 — negative result by Matthew J. Colbrook; Lean formalization by George Stepaniants

[Canonical entry](matrix-inequalities-and-norms/MI-07/README.md) · [Complete proof](matrix-inequalities-and-norms/MI-07/solution.pdf) · [Independent review](references/colbrook-matrix-2026-09-11/verification/reviews/MI-07-review.md). **Theorem 1.1 and its proof.** No finite two-unitary domination constant exists for the maximal symmetric modulus, already in dimension two. The rank-one family gives the necessary bound $C\ge\sqrt{1+t^2}/t$ for every $t>0$. 

**Lean verified — 2026-09-12. Lean formalization:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA, with AI-agent assistance. Mathematical counterexample credit remains with Matthew J. Colbrook. The [seven checked exports](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/f55777156432043de4201747a3759e0c6485e568/matrix-inequalities-and-norms/MI-07/lean/Solution.lean) prove the actual complex moduli, three root-sequence limits, genuine spectral-norm bridge, all-unitary trace obstruction and full original constant-one conjecture negation. [Linux run 34709291624](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34709291624) matched all frozen declarations and replayed the exported solution through Lean's default kernel with only `propext`, `Classical.choice` and `Quot.sound`. The [proof and verification evidence](matrix-inequalities-and-norms/MI-07/README.md#lean-proof-and-verification-evidence--2026-09-12) retain two independent mathematical reviews, the operational audit and original artifacts. The stronger no-finite-constant theorem and generic convergence for unrelated matrices are outside the formalized scope; the original informal record above remains historical.


#### MI-19 — Negative result by Matthew J. Colbrook; Lean formalization by George Stepaniants

[Canonical entry](matrix-inequalities-and-norms/MI-19/README.md) · [Complete proof](matrix-inequalities-and-norms/MI-19/solution.pdf) · [Independent review](references/colbrook-matrix-2026-09-11/verification/reviews/MI-19-review.md). **Theorem 1.1 and its proof.** A real order-four PSD Gram matrix, $q=7/8$ and the interior singleton $S=\{2\}$ give full minus restricted $q$-permanent equal to $-3235575/16384$. Inversions are counted in the full original ordering. The strict counterexample also persists under sufficiently small positive diagonal perturbations. 

**Lean verified — 2026-09-12.** Mathematical counterexample: **Matthew J. Colbrook**, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. Lean formalization: **George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA. [Proof and verification evidence](matrix-inequalities-and-norms/MI-19/README.md#lean-proof-and-verification-evidence--2026-09-12) cover the complete negative target through `NLA.MI19.counterexample` and `NLA.MI19.not_subsetConjecture`, at [proof revision cd44ce9](https://github.com/sgstepaniants/OpenProblemsInNLA/tree/cd44ce9bcb84ebc79a1aa934918d1f76b2a9c6e7/matrix-inequalities-and-norms/MI-19/lean). [Linux Comparator and kernel checks passed](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34703363593) with only the standard three axioms. The optional perturbation extension is not part of the formalized claims.

#### MI-21 — Lean-verified negative result — formalization by George Stepaniants

[Canonical entry](matrix-inequalities-and-norms/MI-21/README.md) · [Complete proof](matrix-inequalities-and-norms/MI-21/solution.pdf) · [Independent review](references/colbrook-matrix-2026-09-11/verification/reviews/MI-21-review.md). **Theorem 1.1 and its proof.** Two rational positive definite $2\times2$ summands with $s=t=1/2$, $r=2$ and aggregate matrices $A=B=I$ violate the operator-norm inequality for every $p>0$. The left side has eigenvalue $1351000/1350907>1$, while the right side is one.

**Lean verified — 2026-09-12.** Mathematical counterexample: **Matthew J. Colbrook**, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. **Lean formalization:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA, with AI-agent assistance. The [three checked exports](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/06ade659dee260a18b79ce638383bf0a49125ecf/matrix-inequalities-and-norms/MI-21/lean/Solution.lean) prove the genuine operator norm's admissibility, every witness premise and actual CFC identity, the strict violation for every positive outer parameter, and the full original conjecture's negation. [Linux run 34709291489](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34709291489) matched the frozen statements and replayed the solution through Lean's default kernel, with only `propext`, `Classical.choice` and `Quot.sound`. Two independent mathematical referees and an independent operational audit are retained with the [proof and verification evidence](matrix-inequalities-and-norms/MI-21/README.md#lean-proof-and-verification-evidence--2026-09-12). The original informal proof remains separately credited; narrower established parameter regimes are not contradicted.

#### MI-22 — negative result

[Canonical entry](matrix-inequalities-and-norms/MI-22/README.md) · [Complete proof](matrix-inequalities-and-norms/MI-22/solution.pdf) · [Independent review](references/colbrook-matrix-2026-09-11/verification/reviews/MI-22-review.md). **Theorem 1.1 and its proof.** Rational positive definite $3\times3$ matrices at $t=1/8$ violate the first singular-value inequality: the left operator norm exceeds 10900, while $\|AB\|_2<10200$. Exact rational root residuals and a proved operator-root error bound certify the actual principal powers. 

**Lean verified — 2026-09-12.** Mathematical resolution and method: **Matthew J. Colbrook**, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. **Lean formalization:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA, with AI-agent assistance. The [eight checked exports](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/26f526cf8b6232af9528b30616076dc7a2c66ac6/matrix-inequalities-and-norms/MI-22/lean/Solution.lean) prove the full original conjecture false using the disclosed rational adaptation $B=DT^8D$, with actual CFC powers, true singular-value/norm bridges and strict bounds 11000 and 10500. The printed source witness and its different thresholds remain separately credited informal results. [Linux run 34720684925](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34720684925) passed actual Comparator/default-kernel verification of every export with only `propext`, `Classical.choice` and `Quot.sound`. Both independent mathematical reviews and the separate operational audit are retained with the [proof and verification evidence](matrix-inequalities-and-norms/MI-22/README.md#lean-proof-and-verification-evidence--2026-09-12).

#### MI-23 — negative result; Lean formalization by George Stepaniants

[Canonical entry](matrix-inequalities-and-norms/MI-23/README.md) · [Complete proof](matrix-inequalities-and-norms/MI-23/solution.pdf) · [Independent review](references/colbrook-matrix-2026-09-11/verification/reviews/MI-23-review.md). **Theorem 1.1 and its proof.** Rational positive definite $3\times3$ matrices with $r=s=1$, $p=2$ and $t=1/8$ violate the corrected eigenvalue log-majorization conjecture. An exact integer-power construction and rational norm separation establish failure of the first ordered eigenvalue inequality.

**Lean verified — 2026-09-12.** The complete corrected eigenvalue conjecture is refuted by the
[eight checked exports](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/17194f9060609acae429e14d3dc3c4562b84f2bd/matrix-inequalities-and-norms/MI-23/lean/Solution.lean).
**Lean formalization: George Stepaniants, Department of Computing and Mathematical Sciences,
California Institute of Technology, Pasadena, California, USA**, with AI-agent assistance.
Matthew J. Colbrook retains authorship of the counterexample and informal proof. See the
[canonical verification evidence](matrix-inequalities-and-norms/MI-23/README.md#lean-proof-and-verification-evidence---2026-09-12),
[two statement and two final proof reviews](matrix-inequalities-and-norms/MI-23/lean/reviews/),
[successful Linux run](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34716784038)
and [independent operational audit](matrix-inequalities-and-norms/MI-23/lean/verification/linux-2026-09-12/OPERATIONAL-REVIEW.md).
All 133 submitted input hashes, default-kernel replay, standard-three axioms and actual rejection
controls were verified. No external human peer review is claimed.


#### MI-26 — negative result; Lean formalization by George Stepaniants

[Canonical entry](matrix-inequalities-and-norms/MI-26/README.md) · [Complete proof](matrix-inequalities-and-norms/MI-26/solution.pdf) · [Independent review](references/colbrook-matrix-2026-09-11/verification/reviews/MI-26-review.md). **Theorem 1.1 and its proof.** The real-valued concave function $f(x)=x-x^2$ and two rational projections refute the two-unitary inequality; an explicit positive definite variant also works. The allowed condition is $f(0)\ge0$, without global nonnegativity or monotonicity. This does not refute the narrower nonnegative-valued function class. **Lean verified (2026-09-12).** Formalization: **George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA**, with AI-agent assistance. The seven [formal exports](matrix-inequalities-and-norms/MI-26/lean/Solution.lean) refute the complete original complex PSD and real-valued concave-function assertion; the additional positive-definite source variant is outside their scope. Two independent statement and final proof reviews and [Linux run 34713045511](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34713045511) verify the unchanged proof at [revision 81176af](https://github.com/sgstepaniants/OpenProblemsInNLA/tree/81176af27e570b59ba1e1a0745e28944e7d57c03/matrix-inequalities-and-norms/MI-26/lean); [original evidence and independent operational audit](matrix-inequalities-and-norms/MI-26/lean/verification/linux-2026-09-12/) are retained. Matthew J. Colbrook retains mathematical authorship.

#### MI-29 — Lean-verified negative result — formalization by George Stepaniants

[Canonical entry](matrix-inequalities-and-norms/MI-29/README.md) · [Complete proof](matrix-inequalities-and-norms/MI-29/solution.pdf) · [Independent review](references/colbrook-matrix-2026-09-11/verification/reviews/MI-29-review.md). **Theorem 1.1 and its proof.** A rational positive definite $A$ and invertible indefinite Hermitian $B$ in dimension three, with $k=6$ and $p=8$, reverse the proposed determinant comparison. The exact right-minus-left gap is $21036678407451/156250000000000>0$. The known $k=2$ theorem and the variant $B>0$ are not contradicted.

**Lean verified, 2026-09-12. Lean formalization:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA, with AI-agent assistance. Matthew J. Colbrook retains mathematical proof credit. The [five checked exports](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/c0c5eced77d2528f37d931200248fc54a190813e/matrix-inequalities-and-norms/MI-29/lean/Solution.lean) establish the genuine CFC and modulus bridges, positive-real determinant semantics, the exact admissible witness and the negation of the complete original all-real-exponent conjecture. [Linux run 34706412510](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34706412510) matched the frozen declarations and replayed the solution through Lean's default kernel, with only `propext`, `Classical.choice` and `Quot.sound`. Two independent mathematical referees and an independent operational audit are retained with the [proof and verification evidence](matrix-inequalities-and-norms/MI-29/README.md#lean-proof-and-verification-evidence--2026-09-12). The separate singular-input extension, established $k=2$ case and positive-$B$ variants are outside these exports. The original informal proof and its review record remain separately credited.

#### Related partial results: MI-08, MI-09 and MI-25

These three entries remain in the open count.

#### MI-08 — partial result

[Canonical entry](matrix-inequalities-and-norms/MI-08/README.md) · [Complete proof](matrix-inequalities-and-norms/MI-08/solution.pdf) · [Independent review](references/colbrook-matrix-2026-09-11/verification/reviews/MI-08-review.md). **Theorem 1.1 and its proof.** The fixed and adaptive orthogonal pinching lengths both equal the least row count $h(d)$ of a sign matrix $H$ with $H^TH=h(d)I_d$. In particular, the exact length is 12 for $9\le d\le12$. The general value of $h(d)$ is undetermined; the all-dimension optimization remains open and includes Hadamard-order existence questions.

#### MI-09 — partial result

[Canonical entry](matrix-inequalities-and-norms/MI-09/README.md) · [Complete proof](matrix-inequalities-and-norms/MI-09/solution.pdf) · [Independent review](references/colbrook-matrix-2026-09-11/verification/reviews/MI-09-review.md). **Theorem 1.1 and its proof.** For every $m\ge2$, the exact dimension-two operator-norm constant is $c_\infty^{\rm sym}(m,2)=\sqrt{6\sqrt3-9}$. This is also the sharp single constant valid simultaneously for every unitarily invariant norm on $M_2$. This does not determine each individual finite Schatten constant. The cases $1<p<\infty$ remain open; the previously established trace endpoint and higher-dimensional operator endpoint are retained.

#### MI-25 — partial result

[Canonical entry](matrix-inequalities-and-norms/MI-25/README.md) · [Complete proof](matrix-inequalities-and-norms/MI-25/solution.pdf) · [Independent review](references/colbrook-matrix-2026-09-11/verification/reviews/MI-25-review.md). **Theorem 1.1 and its proof.** The trace-norm endpoint has $C_1=\infty$: a real $2\times3$ rank-one family has defect ratio asymptotic to $2/(3t)$ as $t\downarrow0$. Zero-row padding gives the same failure on real $3\times3$ matrices. The remaining finite Schatten exponents $1<p<\infty$ are undetermined by this result; the known value $C_2=1$ is unchanged.

### Four resolutions by Matthew J. Colbrook — 2026-09-11

**Author:** Matthew J. Colbrook, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. Three separate Codex agents reviewed the six submitted arguments; the following four resolve exact catalog targets. Verification is independent agent review, not external peer review or formal certification. [Submission record, provenance and reproduction](references/colbrook-transfer-2026-09-11/README.md).

**RA-07 (Lean verified; formalization by George Stepaniants).** The sequence $(j+1)e_{j+1}/e_j$ is decreasing and discretely convex for every positive spectrum, including both endpoints. The exact second-difference certificate proves the full canonical conjecture.  [Complete proof](references/colbrook-transfer-2026-09-11/manuscripts/01_volume_sampling_convexity.pdf), Theorem 1.1; [review](references/colbrook-transfer-2026-09-11/verification/reviews/RA-07-review.md). **Lean verification — 2026-09-12:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA, with AI-agent assistance. Matthew J. Colbrook retains mathematical authorship. The six [formal exports](randomized-and-low-rank-approximation/RA-07/lean/Solution.lean) prove the complete original scalar convexity target for every positive spectrum and every canonical index; the source’s additional monotonicity and sampling applications are outside their scope. Two independent statement reviews, two independent final proof reviews and [Linux run 34715563781](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34715563781) verify the unchanged proof at [revision bf144a8](https://github.com/sgstepaniants/OpenProblemsInNLA/tree/bf144a8ea84992d64f79f4425b18352843376286/randomized-and-low-rank-approximation/RA-07/lean); [original evidence and independent operational audit](randomized-and-low-rank-approximation/RA-07/lean/verification/linux-2026-09-12/) are retained. LeanCert audits kernel trust for this exact proof, without a numerical interval certificate.

**RA-08 (Lean verified; formalization by George Stepaniants).** A rational positive definite $6\times6$ matrix and its exact rank-three Nyström approximation attain the optimal input spectral error but violate transformed optimality for $f(x)=\min(x,1)$. At $t=1/65536$, the output ratio is at least $1+334583/15769728$. Since the input excess is zero, this also excludes every finite factor $1+C\varepsilon$ for that scalar-concave class.  [Complete proof](references/colbrook-transfer-2026-09-11/manuscripts/03_concave_transfer_counterexamples.pdf), Theorem 3.1; [review](references/colbrook-transfer-2026-09-11/verification/reviews/RA-08-review.md). **Lean verification — 2026-09-13:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA, with AI-agent assistance. Matthew J. Colbrook retains mathematical authorship. The [fourteen exports](randomized-and-low-rank-approximation/RA-08/lean/Solution.lean) refute the complete original concave spectral-transfer implication, with genuine Euclidean operator norm/CFC and every selected eigenbasis retained. The unchanged witness has exact input and optimal tail error $t$ but strictly larger transformed error. The source's larger contour ratio, separate Nyström sketch identity and ancillary nuclear extensions are outside these exports. Exact algebra and a materially used explicit-kernel LeanCert singleton sign certificate suffice. Two independent statement and two independent final mathematical reviews were followed by [Ubuntu run 34735273999](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34735273999), with all fourteen exports, default-kernel replay, 59 standard-three reports and both real control suites passing. The [canonical evidence](randomized-and-low-rank-approximation/RA-08/README.md#lean-proof-and-verification-evidence---2026-09-13) links the independent operational audit and root acceptance binding all 613 inputs. External human peer review is not claimed.

**RA-09 (Lean verified; formalization by George Stepaniants).** The ordered theorem transfers ordinary relative Frobenius residual error with no loss for the larger monotone subhomogeneous function class. Put $B=\widehat A_k$. Since $0\preceq B\preceq A$, $\|A-B\|_F^2=\|A\|_F^2-\|B\|_F^2-2\operatorname{tr}(B(A-B))\le\|A\|_F^2-\|B\|_F^2$. Thus the original stronger trace-deficit premise implies the proved residual premise, establishing the exact canonical conclusion. All specified eigenbasis choices and zero-tail cases are covered.  [Complete proof](references/colbrook-transfer-2026-09-11/manuscripts/02_frobenius_function_transfer.pdf), Theorem 1.1, with the trace-deficit reduction in the entry; [review](references/colbrook-transfer-2026-09-11/verification/reviews/RA-09-review.md). **Lean verification — 2026-09-13:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA, with AI-agent assistance. Matthew J. Colbrook retains mathematical authorship. The [seventeen exports](randomized-and-low-rank-approximation/RA-09/lean/Solution.lean) prove the full original concave Frobenius-transfer implication, including its trace-deficit premise, every allowed ordered eigenbasis and functions with positive value at zero. Genuine Frobenius norm, PSD order and CFC are linked by proved semantic bridges. Exact scalar algebra and LeanCert kernel trust checks require no interval computation. Two independent statement and two independent final mathematical approvals were followed by [Ubuntu run 34738884548](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34738884548), with all seventeen exports, default-kernel replay, 49 standard-three reports and both actual control suites passing. The [canonical evidence](randomized-and-low-rank-approximation/RA-09/README.md#lean-proof-and-verification-evidence---2026-09-13) gives immutable sources, exact declarations, pins, commands and the independent operational audit binding all 524 inputs. External human peer review is not claimed.

**RE-05 (Solved).** The nonadaptive two-sided algorithm achieves pure relative Frobenius error with $O(\sqrt{q(\log q+1/\varepsilon)}+\log q)$ queries at constant success. Fifteen independent copies with internal squared parameter $\varepsilon/9$ and the proved median selector give failure at most $e^{-4.8}<0.01$ and norm factor at most $1+\varepsilon$. This meets the exact canonical uniform query bound and arithmetic model.  [Complete proof](references/colbrook-transfer-2026-09-11/manuscripts/05_linear_family_relative_sketch.pdf), Theorem 2.1 and Proposition 5.1; [review](references/colbrook-transfer-2026-09-11/verification/reviews/RE-05-review.md).

#### Related partial result and auxiliary counterexamples

**RA-10 - historical partial result (the canonical target is now Solved).** Matthew J. Colbrook proved that the sharp nuclear relative-excess factor is two when $A$, $B=\widehat A_k$ and the actual selected rank-$k$ projector have a simultaneous orthonormal eigenbasis. The finite-Schatten extension is also proved. Diagonal operator-monotone power examples show that any constant solving the full question must satisfy $C\ge2$. Existence of a finite universal constant for arbitrary noncommuting PSD pairs was open at that stage; George Stepaniants's complete proof with $C=11$ is now recorded above. Commutation of $A$ and $\widehat A$ alone does not cover every truncation inside a repeated eigenspace. The separate scalar-concave nuclear counterexamples use functions outside the required operator-monotone class. [Complete proof](references/colbrook-transfer-2026-09-11/manuscripts/06_commuting_schatten_transfer.pdf), Theorem 1.1 and Section 3; [review](references/colbrook-transfer-2026-09-11/verification/reviews/RA-10-review.md).

**RA-12 — historical auxiliary results (the canonical target is now Solved).** Matthew J. Colbrook's submitted Gamma-density examples refute the upper-mode assertion in Hallman Conjecture 1 and the upper-inflection assertion in Conjecture 2, with legally distinct augmentation indices. These are counterexamples to auxiliary assertions; they neither prove nor refute the complete relative Gaussian trace-tail probability chain and do not establish a revised sharp tail threshold. RA-12 remained open at that stage. George Stepaniants's complete proof of the canonical tail comparisons is now recorded above. [Complete auxiliary proof](references/colbrook-transfer-2026-09-11/manuscripts/04_gamma_auxiliary_counterexamples.pdf), Proposition 2.1 (with Proposition 3.1 for related evidence); [review](references/colbrook-transfer-2026-09-11/verification/reviews/gamma-auxiliary-review.md).

**RA-13 (Solved separately; auxiliary counterexamples retained).** The centered augmented density has a genuine inflection point beyond the proposed auxiliary upper bound. Together with the mode example, this refutes the upper assertions of Hallman Conjectures 1 and 2. These auxiliary examples neither prove nor refute the complete absolute Gaussian trace-tail probability chain. George Stepaniants's [separate proof](randomized-and-low-rank-approximation/RA-13/solution.md) now establishes the canonical comparisons; Colbrook's auxiliary counterexamples remain valid. [Complete proof](references/colbrook-transfer-2026-09-11/manuscripts/04_gamma_auxiliary_counterexamples.pdf), Proposition 3.1 (with Proposition 2.1 for related evidence); [review](references/colbrook-transfer-2026-09-11/verification/reviews/gamma-auxiliary-review.md).

### Five factorization resolutions by Matthew J. Colbrook — 2026-09-11

**Author:** Matthew J. Colbrook, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. Three separate Codex agents reviewed all seven arguments; five resolve full canonical targets and two provide partial family results. This is independent agent verification, not external peer review or formal certification. [Submission record and reproduction](references/colbrook-factorization-2026-09-11/README.md).

**NM-03 (Solved).** The exact rational-input decision problem is NP-hard under polynomial-time many-one reductions, even for strictly positive symmetric positive-definite inputs. The proof supplies an inverse-polynomial additive squared-error gap and a polynomial-time rational perturbation to simple spectrum. Factors may be real, exactly as in the canonical question. NP membership and constant-relative-error hardness are not asserted.  [Complete proof](references/colbrook-factorization-2026-09-11/manuscripts/NM-03_rank_two_approximation_hardness.pdf), Theorem 1; Theorem 5 and Corollary 6 strengthen the construction; [review](references/colbrook-factorization-2026-09-11/verification/reviews/NM-03-review.md).

**NM-04 (Solved).** The complete Rowland--Wu coefficient identity holds for every positive real rectangular matrix and all $m,n\ge1$. The proof identifies the coefficient sum with one determinant and constructs a null vector after scaling. Vanishing minors and the cases $m=1$ or $n=1$ are included. This proves the displayed coefficients, beyond the previously known algebraic-degree bound.  [Complete proof](references/colbrook-factorization-2026-09-11/manuscripts/NM-04_sinkhorn_identity.pdf), Theorem 1; [review](references/colbrook-factorization-2026-09-11/verification/reviews/NM-04-review.md).

**NR-04 (Solved).** The nine-point matrix $D_{ij}=(i-j)^2$ has nonnegative rank seven, so no exact six-term nonnegative factorization exists. A polygon-contact argument applied to both factors, together with Sylvester's rank inequality, proves the lower bound; an explicit seven-term integer factorization proves the upper bound.  [Complete proof](references/colbrook-factorization-2026-09-11/manuscripts/NR-04_nine_point_distance.pdf), Theorem 1, with Theorem 4 for the lower bound; [review](references/colbrook-factorization-2026-09-11/verification/reviews/NR-04-review.md).

**PF-02 (Solved).** A strictly positive integer $6\times6$ matrix has ordinary rank six and real positive semidefinite rank three, while its minimal-factor congruence quotient is disconnected. A continuous congruence-invariant orientation takes opposite signs on two explicit factorizations, proving actual disconnectedness in the required quotient topology. Further constructions cover every factor size $k\ge3$, including strictly positive rational examples by a nonquantitative perturbation argument.  [Complete proof](references/colbrook-factorization-2026-09-11/manuscripts/PF-02_disconnected_orbits.pdf), Theorem 1; Theorem 4 extends the counterexamples to every factor size; [review](references/colbrook-factorization-2026-09-11/verification/reviews/PF-02-review.md).

**Lean verified, 15 September 2026.** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, supplied the [complete formalization at immutable revision `a3e984ce`](https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/a3e984ced348f4d8529c5d0f8f87c9be7dd979e2/nonnegative-and-positive-factorizations/PF-02/lean). The nine exports establish attained real PSD rank three and disconnectedness of the complete factorization quotient under the full real invertible congruence group, with the actual Euclidean quotient topology. This proves the original universal claim false; the further all-size constructions remain outside the formalization. [Fresh Linux Comparator and default-kernel verification](https://github.com/ajt60gaibb/OpenProblemsInNLA/actions/runs/35021020857/attempts/1) passed with only the three permitted axioms and successful sandbox and rejection controls. Two independent AI-agent final source reviews and two operational reviews are retained in the [project record](nonnegative-and-positive-factorizations/PF-02/lean/README.md). Matthew J. Colbrook retains the original mathematical proof credit; substantial AI assistance is disclosed, and no external human review is claimed.

**PF-05 (Solved).** For every real size-two positive semidefinite factorization of an ordinary-rank-three matrix, feasible straight-line infinitesimal rigidity is equivalent to uniqueness up to congruence. The zero-entry argument handles repeated or singular factors and zero rows and columns; the cited positive-entry theorem covers the remaining case. The feasible directions and equivalence group agree exactly with the canonical definitions.  [Complete proof](references/colbrook-factorization-2026-09-11/manuscripts/PF-05_rigidity_with_zeros.pdf), Theorem 1, with Theorem 8 for the zero-entry construction; [review](references/colbrook-factorization-2026-09-11/verification/reviews/PF-05-review.md).

#### Related partial family results

**NR-03 (earlier partial result; now Solved negatively).** The fixed three-bit quadratic correlation matrix has nonnegative rank exactly eight. Its ordinary-rank-seven parity null vector constrains both factors in a hypothetical seven-term factorization; nine distinguished entries then exclude such a factorization. This left the all-order conjecture unresolved at the time; [Holden’s later counterexample](nonnegative-and-positive-factorizations/NR-03/README.md) disproves it from n=7 onward. The parity restriction is proved only for a hypothetical factorization whose inner dimension equals ordinary rank; it is not imposed on arbitrary wider factorizations. [Complete proof](references/colbrook-factorization-2026-09-11/manuscripts/NR-03_n3_exact_rank.pdf), Theorem 1 and Lemma 2; [review](references/colbrook-factorization-2026-09-11/verification/reviews/NR-03-review.md).

**PF-01 (Partially resolved).** The real positive semidefinite rank is exactly four for $n=5$ and $n=6$. Explicit graph factors give the general bound $\operatorname{rank}_{\rm psd}M^{(n)}\le\lceil2\sqrt{2\lfloor(n-1)/2\rfloor}\rceil$, and submatrix monotonicity gives a lower bound of four for every $n\ge5$. The exact ranks as a function of $n$ remain undetermined for $n\ge7$. In particular, the new upper bound five at $n=7,8$ is not accompanied by a matching lower bound five. The finite orders remain part of this single family entry. [Complete proof](references/colbrook-factorization-2026-09-11/manuscripts/PF-01_subset_intersection.pdf), Theorem 1, Corollary 5 and equation (8); [review](references/colbrook-factorization-2026-09-11/verification/reviews/PF-01-review.md).

### Three matrix-function resolutions by Matthew J. Colbrook — 2026-09-11

**Author:** Matthew J. Colbrook, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. Three separate Codex agents independently reviewed the six manuscripts. [Submission record and reproduction](references/colbrook-matrix-functions-2026-09-11/README.md).

**MF-03 (Solved).** For every integer $m\ge1$, the normalized diagonal Padé denominator for $\cosh\sqrt z$ is nonzero on $|z|\le3$ and $|1-r_m(z)|\le2$ there. The bound is strict for $m\ge2$ and sharp for $m=1$ at $z=3$. The analytic tail argument and exact finite certificates cover every order.  [Complete proof](references/colbrook-matrix-functions-2026-09-11/manuscripts/MF-03.pdf), Theorem 1; [review](references/colbrook-matrix-functions-2026-09-11/verification/reviews/MF-03-review.md).

**MF-14 (Earlier partial result, 11 September 2026; subsequently solved negatively above).** A fixed seven-product scheme has a full-rank complex coefficient map, certified by a nonzero exact integer Jacobian minor. Its image contains a nonempty Zariski-open subset of $\mathbb C[x]_{\le42}$ and is Euclidean dense there. That manuscript did not establish maximality and asserted neither exact representation of every polynomial nor real Euclidean dense coverage. Its degree-42 theorem remains valid; Webb’s later degree-44 construction refutes the equality. [Complete proof](references/colbrook-matrix-functions-2026-09-11/manuscripts/MF-14.pdf), Theorem 1 and equations (1)-(2); [review](references/colbrook-matrix-functions-2026-09-11/verification/reviews/MF-14-review.md).

**MF-15 (Partially resolved).** The conventional critical exponent satisfies $\mathrm{CE}_n\ge2n-4$ for every $n\ge3$, already for rational entrywise nonnegative matrices with distinct positive eigenvalues. Combining this with the published upper bound gives $\mathrm{CE}_4=4$. The matching upper bound for every $n\ge5$, and hence the full family equality, remain unresolved. These are conventional matrix powers, not entrywise powers. [Complete proof](references/colbrook-matrix-functions-2026-09-11/manuscripts/MF-15.pdf), Theorem 1 and Corollary 4; [review](references/colbrook-matrix-functions-2026-09-11/verification/reviews/MF-15-review.md).

**MF-16 (Lean verified; formalization by George Stepaniants).** The ordinary symmetric two-letter word $XBX^{12}BX=P$ has at least three distinct real symmetric positive definite solutions for explicit integer $B,P$. These are also Hermitian positive definite solutions, refuting the canonical universal uniqueness assertion in dimension two. An exact negative Jacobian determinant and two independent interval implementations certify the counterexample.  [Complete proof](references/colbrook-matrix-functions-2026-09-11/manuscripts/MF-16.pdf), Theorem 1; Theorem 4 gives three certified solutions, and Theorem 3 gives a family threshold; [review](references/colbrook-matrix-functions-2026-09-11/verification/reviews/MF-16-review.md). **Lean verification — 2026-09-12:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA, with AI-agent assistance. Matthew J. Colbrook retains mathematical authorship. The [nine exports](matrix-functions-and-stability/MF-16/lean/Solution.lean) negate the full original universal complex positive-definite uniqueness target using two distinct solutions of the unchanged word equation. The source's stronger three-solution count and exponent-family threshold are outside those exports. A genuine LeanCert Krawczyk root certificate in explicit kernel mode, actual Cayley–Hamilton reduction and full complex matrix-word recovery establish the result. Two independent statement and two independent final mathematical reviews were followed by [actual Ubuntu run 34735259429](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34735259429), with all nine exports, default-kernel replay, 22 standard-three reports and both real control suites passing. The [canonical evidence](matrix-functions-and-stability/MF-16/README.md#lean-proof-and-verification-evidence---2026-09-12) links the complete operational audit and root acceptance binding all 294 candidate inputs. External human peer review is not claimed.

**MF-18 (Solved separately; auxiliary result retained).** For real $A,Q$ with $Q=Q^\top$, scalar regularization $i\eta I$, and a finite invertible stabilizing limit, the manuscript proves that the imaginary-part rank is half the number of odd unit-circle Jordan blocks. It also establishes semisimple regularity and an exact defective example. This does not settle the canonical general complex $C,D,R,P$ problem. Its simple-eigenvalue real subcase was already known; the defective extension is an auxiliary result outside the canonical simple-eigenvalue hypothesis. The full canonical complex target is now solved by [George Stepaniants](matrix-functions-and-stability/MF-18/solution.md). Colbrook's distinct real-coefficient defective extension remains valid and separately credited. [Complete proof](references/colbrook-matrix-functions-2026-09-11/manuscripts/MF-18.pdf), Theorem 1 and Corollary 3; Section 8 exact defective example; [review](references/colbrook-matrix-functions-2026-09-11/verification/reviews/MF-18-review.md).

**SF-01 (Lean verified); formalization by George Stepaniants.** Every exact Newton square-root iterate initialized at $X_0=A$ remains a real nonsingular H-matrix with positive diagonal. The theorem includes arbitrary positive scalar scaling and nonnegative affine initializations, with one diagonal-dominance weight for all iterates; it also proves the corresponding Halley preservation result.  [Complete proof](references/colbrook-matrix-functions-2026-09-11/manuscripts/SF-01.pdf), Theorem 1; Corollary 5 gives the Halley extension; [review](references/colbrook-matrix-functions-2026-09-11/verification/reviews/SF-01-review.md).

**Lean verified, 2026-09-17 (UTC).** **George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology, supplied the [complete 24-target formalization](matrix-functions-and-stability/SF-01/lean/README.md). The original all-dimension, all-iteration positive-diagonal real H-matrix Newton target, its full complex spectral-radius definition and actual inverse availability are proved. The [immutable proof](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/3312b0795873cfecade03fa421a5433651d47674/matrix-functions-and-stability/SF-01/lean/Solution.lean) and [actual non-root Linux run 35175258802](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/35175258802/job/105055517720) passed default-kernel replay, Comparator, standard transitive axioms and rejection/isolation controls. Two complete nonauthor proof reviews and an independent runtime audit are retained in the [canonical evidence](matrix-functions-and-stability/SF-01/README.md#lean-proof-and-verification-evidence). Matthew J. Colbrook retains mathematical credit; Sidney Holden retains authorship and license credit for the two unchanged imported IV03 files. Scaled/affine initializations and Halley extensions are not additional formal claims. AI assistance and reviewer scopes are disclosed.

## Reviewed interval and absolute-value submissions - 2026-09-11

Seven exact targets are classified below. Independent agent review is not external peer review; the [submission record](references/colbrook-intervals-2026-09-11/README.md) preserves AI-draft provenance, authorship requested by Matthew J. Colbrook, full source hashes and fresh checks. No priority claim is made. Original IDs and historical ratings are retained. AV-03 and IV-01 are unchanged.

### AV-01 - Affirmative complexity classification

[Original statement](intervals-and-absolute-value-equations/AV-01/README.md). **Solved, recorded 2026-09-11.** Matthew J. Colbrook (University of Cambridge). Theorem 1 and the algorithm in Section 4 prove polynomial-time recognition of exactly $2^n$ distinct solutions to $Ax+|x|=b$ using $n+1$ rational LP feasibility tests. The result uses rational binary input, has no regularity or finiteness promise, and rejects infinite solution sets. It classifies the displayed decision problem in $\mathsf P$.

[Complete manuscript](references/colbrook-intervals-2026-09-11/manuscripts/AV-01.pdf); [full independent agent review](references/colbrook-intervals-2026-09-11/verification/reviews/AV-01-review.md).

### AV-02 - Hardness classification

[Original statement](intervals-and-absolute-value-equations/AV-02/README.md). **Solved, recorded 2026-09-11.** Matthew J. Colbrook (University of Cambridge). Theorem 2 and Sections 2-3 give a polynomial-time many-one reduction from MAX-CUT to the threshold $c_2(A)\ge t$, using integer upper-triangular matrices with diagonal 2. All queried families are regular. This proves the requested promise-preserving Turing hardness, with equality in the yes case; the restricted rational triangular problem is NP-complete. The result does not assert $\mathsf P\ne\mathsf{NP}$.

[Complete manuscript](references/colbrook-intervals-2026-09-11/manuscripts/AV-02.pdf); [full independent agent review](references/colbrook-intervals-2026-09-11/verification/reviews/AV-02-review.md).

### IV-02 - Complexity classification

[Original statement](intervals-and-absolute-value-equations/IV-02/README.md). **Solved, recorded 2026-09-11.** Matthew J. Colbrook (University of Cambridge). Theorem 1 proves NP-completeness of the upper determinant threshold and NP-hardness of exact determinant-range computation, even for regular independent-entry tridiagonal interval matrices. Section 5 supplies the exact-output upper bound: a polynomial algorithm for the full displayed target exists if and only if $\mathsf P=\mathsf{NP}$. No unconditional separation or strong NP-hardness is asserted.

[Complete manuscript](references/colbrook-intervals-2026-09-11/manuscripts/IV-02_IV-04.pdf); [full independent agent review](references/colbrook-intervals-2026-09-11/verification/reviews/IV-02_IV-04-review.md).

### 🏆 IV-03 - Affirmative resolution with Lean verification

[Original statement](intervals-and-absolute-value-equations/IV-03/README.md). **Solved, recorded 2026-09-11.** Matthew J. Colbrook (University of Cambridge). Theorem 1 proves that every interval member is inverse-M if and only if the $n^2$ vertices $C-D_iRD_j$ are inverse-M. These are contained in the displayed two-sign family, so the original $2n^2$ equivalence follows. The proof covers all real endpoints, every dimension, zero widths, zero entries and reducible matrices without assuming regularity.

[Complete manuscript](references/colbrook-intervals-2026-09-11/manuscripts/IV-03.pdf); [full independent agent review](references/colbrook-intervals-2026-09-11/verification/reviews/IV-03-review.md).
**Lean verified, 16 September 2026 UTC. Mathematical argument: Matthew J. Colbrook**, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. **Formalization: Sidney Holden**, under Apache-2.0. **Integration and verification submission: George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology. The [complete four-target formalization](intervals-and-absolute-value-equations/IV-03/lean/README.md) proves both vertex equivalences in every positive dimension without assuming regularity, retaining zero widths, zero entries and reducible cases. [Canonical Linux run 35059255598](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/35059255598/job/104675949451) passed all four LeanCert kernel-trust assertions, Comparator statement checks, Lean default-kernel replay, standard transitive axioms and required controls at literal proof/integration commit `cef3e2f486285d0f6885231cda3ac2ff04c975cb`. Two independent AI-agent complete-source reviews and an authenticated fresh-run audit are retained. The fourteen active mathematical Lean inputs, frozen boundary and original manuscript are unchanged. See the [canonical evidence section](intervals-and-absolute-value-equations/IV-03/README.md#lean-proof-and-verification-evidence). This is not an external human peer-review claim; later publication and merge commits need their own checks.


### IV-04 - Complexity classification

[Original statement](intervals-and-absolute-value-equations/IV-04/README.md). **Solved, recorded 2026-09-11.** Matthew J. Colbrook (University of Cambridge). Theorem 2 proves NP-hardness of exact tridiagonal solution-hull computation even for a regular independent-entry matrix family and the point right-hand side $-e_n$. Section 5 covers the full exact-output convention, including empty solution sets and infinite endpoints, and makes polynomial-time existence equivalent to $\mathsf P=\mathsf{NP}$. It does not unconditionally rule out polynomial time.

[Complete manuscript](references/colbrook-intervals-2026-09-11/manuscripts/IV-02_IV-04.pdf); [full independent agent review](references/colbrook-intervals-2026-09-11/verification/reviews/IV-02_IV-04-review.md).

### IV-05 - Affirmative algorithmic resolution

[Original statement](intervals-and-absolute-value-equations/IV-05/README.md). **Solved, recorded 2026-09-11.** Matthew J. Colbrook (University of Cambridge). Theorem 3 and Sections 3-5 give the exact coordinatewise solution hull using $2n$ rational LPs, each with $n$ variables and $2n$ inequalities, in polynomial binary input length. The construction uses precisely the inverse-M promise and arbitrary interval right-hand sides. Promise recognition is not needed; no solver for the general regular AV-03 problem is claimed.

[Complete manuscript](references/colbrook-intervals-2026-09-11/manuscripts/IV-05.pdf); [full independent agent review](references/colbrook-intervals-2026-09-11/verification/reviews/IV-05-review.md).

### IV-06 - Negative resolution by Matthew J. Colbrook; Lean formalization by George Stepaniants

[Original statement](intervals-and-absolute-value-equations/IV-06/README.md). **Solved, recorded 2026-09-11.** Matthew J. Colbrook (University of Cambridge). Theorem 1 gives a $3\times3$ independent-entry interval matrix with at least four components in its real eigenvalue set. Four exact integer eigenpairs at $-3,0,3,25$ and excluded separators $-1,1,12$ refute the universal at-most-$n$ conjecture. No symmetry assumption is introduced, and locating every component endpoint is unnecessary.

[Complete manuscript](references/colbrook-intervals-2026-09-11/manuscripts/IV-06.pdf); [full independent agent review](references/colbrook-intervals-2026-09-11/verification/reviews/IV-06-review.md).

**Lean verified - 2026-09-12.** The [eight checked exports](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/18b5ef3127da0ae4f68e09289f60fd4f6e3d9bcb/intervals-and-absolute-value-equations/IV-06/lean/Solution.lean) negate the complete original universal component bound using the unchanged dimension-three box with at least four actual components. Full independent-entry variation, genuine nonzero eigenvectors, real subset topology and `Cardinal` component counts are retained; no finiteness premise is assumed. **Formalization: George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA**, with AI-agent assistance. Matthew J. Colbrook retains mathematical counterexample credit; Hladík, Daney and Tsigaridas retain original-question credit. See the [canonical verification evidence](intervals-and-absolute-value-equations/IV-06/README.md#lean-proof-and-verification-evidence---2026-09-12), [statement and final proof reviews](intervals-and-absolute-value-equations/IV-06/lean/reviews/), [successful Ubuntu run](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34725713519), [operational audit](intervals-and-absolute-value-equations/IV-06/lean/verification/linux-2026-09-12/OPERATIONAL-REVIEW.md) and [root acceptance](intervals-and-absolute-value-equations/IV-06/lean/verification/root-operational-2026-09-12/ROOT-CHECKS.json). All 200 inputs, seventeen standard-three axiom reports, actual default-kernel replay and both real control suites were checked. The material explicit kernel LeanCert computation is the singleton sign $`-18<0`$; exact algebra and topology complete the argument. Additional operational and publication roles do not add mathematical referees. Exactly four components, every endpoint and an all-dimension replacement bound are outside these exports. External human peer review is not claimed.


## Reviewed discrepancy submission - 2026-09-11

### MD-06 - negative resolution by Matthew J. Colbrook

[Original statement](matrix-discrepancy-and-optimization/MD-06/README.md). **Solved.** **Negative resolution, Theorem 1.** For a uniformly random labelled simple cubic graph on an even number of vertices, the probability that every local minimum of the homogeneous Kuramoto energy is synchronized tends to **zero**, rather than one. With high probability a nonsynchronized local minimum has edge cosines at least $1/32$ and Hessian at least $(1/320)I$ on the mean-zero subspace. The full analytic argument and the primary random-graph inputs passed two independent agent reviews. The graph model, torus topology and quantification over every local minimum are unchanged.

[Complete primary manuscript](references/colbrook-discrepancy-2026-09-11/manuscripts/MD-06.pdf); [submission and independent review record](references/colbrook-discrepancy-2026-09-11/README.md). Author: Matthew J. Colbrook, University of Cambridge. Verification is by independent agents, not external human peer review. Historical ratings and the original statement are preserved; no priority claim is made.

## Recovered linear-system submissions - 2026-09-11

Eight exact targets passed independent agent review. Author: **Matthew J. Colbrook**, University of Cambridge. [Submission record](references/colbrook-recovered-2026-09-11/README.md) documents the substantial AI assistance, reconstructed sources, full proof hashes and checks. Agent review is not external human peer review or formal certification; no priority claim is made. All original targets and historical ratings are retained.

### 🏆 IE-13 - Sharp growth classification

[Original statement](linear-systems-and-elimination/IE-13/README.md). **Solved.** Theorem 1 and Sections 2-4 prove $G(0,q)=1$ and $G(p,q)=h_{p+q}$ for $p\ge1$, where $h_t=0$ for $t\le0$ and $h_t=1+\sum_{r=1}^p h_{t-r}$ otherwise. The upper bound covers every complex input and admissible tie path, with growth over all active entries in the fixed original ordering. A real nonsingular matrix of order $2p+q+1$ attains it, including zero upper bandwidth.

[Complete manuscript](references/colbrook-recovered-2026-09-11/manuscripts/IE-13.pdf); [independent review](references/colbrook-recovered-2026-09-11/verification/reviews/IE-13-review.md).

**Lean verified, 16 September 2026 UTC. Formalization and verification submission:
George Stepaniants**, Department of Computing and Mathematical Sciences,
California Institute of Technology. **Original mathematical proof: Matthew J.
Colbrook**, Department of Applied Mathematics and Theoretical Physics,
University of Cambridge. The [complete 28-target formalization](linear-systems-and-elimination/IE-13/lean/README.md)
retains all complex inputs, dimensions, legal ties and both zero-bandwidth
boundaries, and proves exact attainment and the real supremum.
[Canonical Linux run 35081003513](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/35081003513/job/104744813757)
passed LeanCert kernel trust, Comparator, default-kernel replay, standard
transitive axioms and required controls at immutable proof commit
`032d4c86c52ffde0c4d440f28527ba43555a0a24` ([immutable proof revision](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/032d4c86c52ffde0c4d440f28527ba43555a0a24/linear-systems-and-elimination/IE-13/lean/Solution.lean)). Two independent AI-agent
complete-source/runtime reviews are retained. This adds formal verification
to the existing mathematical resolution. See the
[canonical evidence section](linear-systems-and-elimination/IE-13/README.md#lean-proof-and-verification-evidence).


### IE-14 - Sharp growth classification; Lean formalization by George Stepaniants

[Original statement](linear-systems-and-elimination/IE-14/README.md). **Lean verified.** Theorem 1 and Sections 2-4 prove $c_n=F_{n+1}+1$ for every $n\ge4$, with $F_0=0,F_1=1$. The bound covers complex cyclic tridiagonal matrices, every active entry and every permitted GEPP tie path in the original ordering. A rational matrix with both cyclic corners nonzero attains it at every order.

[Complete manuscript](references/colbrook-recovered-2026-09-11/manuscripts/IE-14.pdf); [independent review](references/colbrook-recovered-2026-09-11/verification/reviews/IE-14-review.md).

**Lean formalization:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology. Matthew J. Colbrook, University of Cambridge DAMTP, retains original mathematical authorship. All seven declarations passed [actual Linux verification at proof revision 6e48f25f](https://github.com/ajt60gaibb/OpenProblemsInNLA/actions/runs/35035525244/job/104603738111), including LeanCert kernel assertions, Comparator, default-kernel replay and required rejection/sandbox controls. The full complex all-tie extremum and an attaining all-size witness are covered. The [independent source/runtime reports and authentic evidence](linear-systems-and-elimination/IE-14/README.md#lean-proof-and-verification-evidence) distinguish the checked proof revision from later publication commits.

### IE-17 - Negative resolution

[Original statement](linear-systems-and-elimination/IE-17/README.md). **Solved.** Sections 1-4 give one exact full-column-rank $4\times3$ LSMR example for which both displayed errors increase from the first to the second nonzero iterate. The matrix-only spectral backward error satisfies $\mu(x_1)^2\le1979/2000<99/100<\mu(x_2)^2$, and the specified approximation also strictly increases. The right-hand side stays fixed. This settles the canonical spectral-norm formulation; the cited SISC paper uses a different default norm convention, so no Frobenius-error conclusion is inferred.

[Complete manuscript](references/colbrook-recovered-2026-09-11/manuscripts/IE-17.pdf); [independent review](references/colbrook-recovered-2026-09-11/verification/reviews/IE-17-review.md).

**Lean verified, 15 September 2026.** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, formalized Colbrook's counterexample in the [complete proof at immutable revision `6e531929`](https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/6e53192977d87097666c039f6d8134a800ff7501/linear-systems-and-elimination/IE-17/lean). The eight exports prove the attained minimum over all real spectral-norm matrix perturbations, the specified Moore–Penrose approximation, the exact minimum-length LSMR run through first termination, and separate failures of both monotonicity claims. [Fresh Linux Comparator and default-kernel verification](https://github.com/ajt60gaibb/OpenProblemsInNLA/actions/runs/35016724809/attempts/1) passed with only the three permitted axioms and successful sandbox and rejection controls. Two independent AI-agent final source reviews and two operational reviews are retained in the [project record](linear-systems-and-elimination/IE-17/lean/README.md). Colbrook retains the original mathematical credit; the stronger manuscript variants and a different Frobenius-error question are outside this formalization.

### 🏆 IE-18 — Prior negative resolution by Yunhui He; later examples by Matthew J. Colbrook and Lean formalization by George Stepaniants

[Original statement](linear-systems-and-elimination/IE-18/README.md). **Lean verified.** The original identity was already disproved by **Yunhui He (17 January 2025)** in *The worst-case root-convergence factor of GMRES(1)*, Section 2.3, equation (2.36) and Example 2.1, pp. 14-15 ([arXiv:2501.10248v1](https://arxiv.org/pdf/2501.10248v1#page=15)). The September literature checks missed this prior result; [the attribution correction and exact recomputation](references/colbrook-recovered-2026-09-11/verification/IE-18-prior-work-2026-09-15.md) record it.

**Later supplementary results, 11 September 2026.** Colbrook's manuscript Section 2 refutes the exact four-step identity using $M=\operatorname{diag}(1/10,1/2,3/5)$ and $v=(1,1,1)^T$: the squared norm ratio is $1920682/21289638243>1/14641$, the square of the proposed factor. Both $M$ and $I-M$ are positive definite. Section 3 proves unbounded underestimation over a parameter family. The separate asymptotic convergence question is not resolved.

[Complete manuscript](references/colbrook-recovered-2026-09-11/manuscripts/IE-18.pdf); [independent review](references/colbrook-recovered-2026-09-11/verification/reviews/IE-18-review.md).

**Lean verified — 2026-09-12 (original negative target).** Specific counterexample formalized: **Matthew J. Colbrook**, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. Lean formalization: **George Stepaniants**, Department of Computing and Mathematical Sciences, California Institute of Technology. [Proof and verification evidence](linear-systems-and-elimination/IE-18/README.md#lean-proof-and-verification-evidence--2026-09-12) cover the actual residual certificate, admissible counterexample and full original negation through `NLA.IE18.not_fourStepConjecture`, at [immutable revision `7b8512e`](https://github.com/sgstepaniants/OpenProblemsInNLA/tree/7b8512e21c50adc8597dcdbed32f2aec13c3b43e/linear-systems-and-elimination/IE-18/lean). [Linux Comparator and kernel checks passed](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34703657954) with only the standard three axioms. The stronger parameter family and separate asymptotic question are outside the formalized claims.

### 🏆 IE-19 — Negative resolution by Matthew J. Colbrook; Lean formalization by George Stepaniants

[Original statement](linear-systems-and-elimination/IE-19/README.md). **Lean verified, 2026-09-12.** The exact original lower-bound and sharp conjectures are false: the admissible $3\times3$ matrix with diagonal entries $2$ and off-diagonal entries $1/2$, at $m=\alpha=1$, has inverse infinity norm $7/9<5/4$. The [Lean proof at revision 531941c](https://github.com/sgstepaniants/OpenProblemsInNLA/tree/531941ca0062049ccf03d3f2df418ea805ac4036/linear-systems-and-elimination/IE-19/lean) exports `NLA.IE19.counterexample`, `NLA.IE19.not_lowerBoundConjecture`, and `NLA.IE19.not_sharpConjecture`. Independent agents reviewed the statement and complete proof; [Linux run 34703188616](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34703188616) matched all three declarations with Comparator and replayed the solution through Lean's default kernel, permitting only `propext`, `Classical.choice`, and `Quot.sound`. The [permanent verification archive](linear-systems-and-elimination/IE-19/lean/verification/linux-2026-09-12/) retains the original artifacts, logs and independent operational review; the canonical page gives pinned dependencies and reproduction commands.

**Mathematical proof:** Matthew J. Colbrook, Department of Applied Mathematics and Theoretical Physics, University of Cambridge. **Lean formalization:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA. The manuscript's further sharp-infimum and nonattainment results remain informally reviewed and are outside this Lean certificate. The stable problem ID and original target are retained.

[Complete manuscript](references/colbrook-recovered-2026-09-11/manuscripts/IE-19.pdf); [independent mathematical review](references/colbrook-recovered-2026-09-11/verification/reviews/IE-19-review.md); [independent formalization reviews](linear-systems-and-elimination/IE-19/lean/reviews/).

### IE-21 - Affirmative resolution

[Original statement](linear-systems-and-elimination/IE-21/README.md). **Solved.** Theorem 1 and Sections 2-5 prove the displayed Gaussian trimmed-second-moment limit in probability along every sequence $n\to\infty$ and $m/n\to\infty$, with exactly $\lfloor\theta m\rfloor$ retained rows and the variational least singular value. Explicit failure-probability and error bounds are included; no faster aspect-ratio growth assumption is added.

[Complete manuscript](references/colbrook-recovered-2026-09-11/manuscripts/IE-21-22.pdf); [independent review](references/colbrook-recovered-2026-09-11/verification/reviews/IE-21-22-review.md).

### IE-22 - Affirmative sharp-constant resolution

[Original statement](linear-systems-and-elimination/IE-22/README.md). **Solved.** Theorem 2 and Sections 6-7 prove the sharp constant $c_\theta=\sqrt{h_\theta}$. The upper bound is uniform over all unit-row matrices and even all $m\ge1$ for sufficiently large $n$, with squared normalized error $O_\theta(n^{-1/6})$. Theorem 1 supplies matching spherical realizations along every high-aspect-ratio sequence, proving the exact eventual-uniform optimality quantifiers.

[Complete manuscript](references/colbrook-recovered-2026-09-11/manuscripts/IE-21-22.pdf); [independent review](references/colbrook-recovered-2026-09-11/verification/reviews/IE-21-22-review.md).

### IE-23 - Negative resolution

[Original statement](linear-systems-and-elimination/IE-23/README.md). **Lean verified.** Theorem 1 gives a $2\times3$ full-row-rank matrix with distinct norm-minimizing right inverses for every $2<p<\infty$ over both fields. Their common induced norm is $2^{1/2-1/p}$. Sections 3-4 identify the complete minimizer sets, including a complex higher-dimensional family. The smallest matrix is attributed to Dokmanic and Gribonval\'s spectral-norm example; its extension to the displayed direct-inverse objective is checked. No conclusion about the separate product objective is claimed.

[Complete manuscript](references/colbrook-recovered-2026-09-11/manuscripts/IE-23.pdf); [independent review](references/colbrook-recovered-2026-09-11/verification/reviews/IE-23-review.md).


**Lean formalization:** George Stepaniants, Department of Computing and Mathematical Sciences, California Institute of Technology, Pasadena, California, USA, with AI-agent assistance. **Matthew J. Colbrook** retains mathematical authorship; **Ivan Dokmanić and Rémi Gribonval** retain the underlying example and original-question credit. The [eight exports at revision a40e560](https://github.com/sgstepaniants/OpenProblemsInNLA/blob/a40e5608f61dd4086708cb2e03901ffd01e4c0a9/linear-systems-and-elimination/IE-23/lean/Solution.lean) prove the actual p=4 norms, global minimality over every complex right inverse and the complete canonical conjecture's negation. The stronger all-p formulas and classifications above retain their manuscript and informal-review scope. [Ubuntu run 34725525250](https://github.com/sgstepaniants/OpenProblemsInNLA/actions/runs/34725525250) passed sandboxed Comparator matching, default-kernel replay and both actual control suites with the standard three axioms. LeanCert supplies kernel trust auditing of the pure exact proof, with no interval certificate. The proof author's [operational audit](linear-systems-and-elimination/IE-23/lean/verification/linux-2026-09-12/OPERATIONAL-REVIEW.md) was [independently accepted by the coordinator](linear-systems-and-elimination/IE-23/lean/verification/root-operational-2026-09-12/ROOT-CHECKS.json). See the [project guide](linear-systems-and-elimination/IE-23/lean/README.md) and [manifest](linear-systems-and-elimination/IE-23/lean/formalization.yaml).

The related order-five rook bound is outside the order-three/order-four target of [IE-15](linear-systems-and-elimination/IE-15/README.md). That target was open when the order-five result was recorded; George Stepaniants's complete order-three/order-four resolution is now recorded above.

## Random cyclic Krylov compression - 2026-09-11

**[IE-10](eigenvalues-and-inverse-problems/IE-10/README.md): Solved.** Theorem 1 proves $\mathbb E\kappa_V(H_k)\leq17n^2k$ for the exact complex-sphere cyclic-shift model. Markov\'s inequality gives the uniform $0.99$ target with $C=1700$ and $c=3$. Sections 5 and 6-7 give two probability proofs; real starts and arbitrary nonnormal inputs are outside the result.

Author: **Matthew J. Colbrook**, University of Cambridge. [Complete proof](references/colbrook-round3-2026-09-11/manuscripts/IE-10.pdf), [independent review](references/colbrook-round3-2026-09-11/verification/reviews/IE-10-review.md), and [submission record](references/colbrook-round3-2026-09-11/README.md). AI generation is disclosed; agent verification is not external human peer review or formal certification. Original target and historical ratings are retained. The accompanying IS-04 prime-square construction remains partial for its all-orders target.

## Accurate polynomial evaluability - 2026-09-11

**[AA-01](arithmetic-and-complexity/AA-01/README.md): Solved.** Theorem 1.1 gives an always-halting decision procedure for the exact constant-free finite-tree model in the statement. In every signed ordering chart $x_{\pi(i)}=\sigma_i(y_1+\cdots+y_i)$, the coefficientwise absolute majorant of $q(y)=p(x(y))$ must be bounded by $C|q(y)|$ on $y\geq0$. This finite real-quantifier criterion is necessary and sufficient; Sections 2-4 prove the equivalence and construct an evaluator when it holds. Both independent reviews cover comparisons, branching, stored-value reuse and arbitrary independent rounding errors.

Author: **Matthew J. Colbrook**, University of Cambridge. [Complete proof](references/colbrook-arithmetic-2026-09-11/manuscripts/AA-01.pdf), [first review](references/colbrook-arithmetic-2026-09-11/verification/reviews/AA-01-review.md), [second review](references/colbrook-arithmetic-2026-09-11/verification/reviews/AA-01-second-review.md), and [submission record](references/colbrook-arithmetic-2026-09-11/README.md). AI assistance and missing experimental sources are disclosed. Agent review is not external human peer review or formal certification. Historical ratings and the exact original target are retained. The accompanying AC-11 and AC-12 finite cases remain partial.

## Published resolutions of historical questions

These questions were screened out before receiving current catalog folders;
they are included here to make their resolutions easy to find. No new problem
IDs or admissions are created by this list. Sources and scope rechecked on
**2026-09-10**.

| Status | Historical question | Resolution and scope |
| --- | --- | --- |
| ✅ **SOLVED** | Higham's growth bound for complex symmetric matrices with positive-definite real and imaginary parts | S. W. Drury, *Fischer determinantal inequalities and Higham's Conjecture*, LAA 439 (2013), 3129–3133, [published result](https://doi.org/10.1016/j.laa.2013.08.031). The bound of two for elimination without pivoting answers the historical below-three question. [Zhang's 2026 paper, §1.1 and Appendix A](https://arxiv.org/html/2604.23024), explicitly traces and refines that result. This does not assert the same bound for arbitrary complex symmetric matrices. |
| ✅ **SOLVED** | Higham's Fréchet-derivative Jordan-form question, *Functions of Matrices*, Research Problem 3.11 | V. Noferini, *The Jordan canonical form of the Fréchet derivative of a matrix function and the bivariate Jordan problem*, [published online in 2026](https://doi.org/10.1016/j.laa.2026.06.002); [primary manuscript, §§4–5](https://arxiv.org/html/2512.08399). The matrix-function problem is answered; the more general bivariate Jordan problem has separate unresolved cases. The journal issue date is October 2026, later than the online publication. |

## Former catalog entries with complete-resolution claims

The classification below concerns the strength of the available evidence, not a
claim that an unrefereed proof is incorrect. The records below were checked
on **2026-09-10**.

<a id="tr-02"></a>

### 🟠 TR-02 — Greedy cross approximation of the fermionic kernel

The [current workshop report, update after Problem 4.2](https://arxiv.org/html/2602.05394), records V. S. Pendyala's [2026 full-solution claim](https://doi.org/10.5281/zenodo.21863274) for the logarithmic cutoff/accuracy rate. The workshop's report of the claim was checked; the claimed proof itself has not been independently reviewed. The [screening note](references/SCREENED-OUT.md#screened-items-that-are-not-counted) preserves the context.

<a id="re-04"></a>

### 🟠 RE-04 — Finite-family structured approximation with relative error

The [August 2026 update following the abstract of Amsel et al.](https://arxiv.org/html/2507.19290v2) reports an improvement to relative error $1+\varepsilon$ and links an author-endorsed argument. This supersedes its stale question in §5. The [screening note](references/SCREENED-OUT.md#excluded-and-uncounted-leads) records the exact distinction from the still-open linear-family and nonadaptive questions. This catalog has checked the scope of the reported resolution, not independently verified its proof.

### 🟠 Sharp Paulsen bound — proposed FR-12, not admitted

[Lau and Ramachandran, §7, manuscript p. 13](https://arxiv.org/pdf/2510.13751),
announce an optimal unrestricted distance bound in forthcoming work. Their
normalization differs by the frame energy from the usual Parseval formulation;
the announcement addresses the proposed sharp strengthening. The announcement
was independently checked, but its forthcoming proof was not available for
verification. The temporary expansion candidate was withheld and does not
contribute to the open count. Its disposition is recorded in the
[expansion screen](references/EXPANSION-TO-200-2026-09.md).

Other historical exclusions and full-proof claims remain documented in the
[source record](references/SOURCES.md#important-historical-questions-excluded).
This page highlights resolutions and former catalog IDs; it is not a list of
every rejected candidate.

## Recording a new resolution

1. Keep the original problem ID, folder and statement. Do not delete or reuse the ID.
2. Set `**Status:** Solution claimed`, `**Status:** Solved`, or `**Status:** Lean verified` on its canonical page according to the evidence. Add a prominent resolution notice, a primary reference and theorem/page locator, the resolution date, the outcome (affirmative, negative or classification), and a comparison with the original assumptions and quantifiers. Identify the actual review level; for `Lean verified`, include the [required formal-verification evidence](CONTRIBUTING.md#lean-verification).
3. For a partial result, use `Partially resolved` and state the exact remaining cases. A weaker bound, a different algorithm, or a different input model does not settle the target.
4. Add the resolution here, validate IDs with `python3 tools/validate_problem_ids.py --base-ref origin/main`, regenerate the catalog indexes with `python3 tools/update_catalog.py --base-ref origin/main`, and regenerate the affected TeX/PDF with `python3 tools/render_problems.py ID`. Run `python3 -m unittest discover -s tests -p 'test_problem_ids.py' -v`.
5. Submit a pull request. An issue being closed is not, by itself, evidence that a mathematical problem is solved. If a claim is withdrawn or a gap is found, retain the history and revise the status using the new evidence.
