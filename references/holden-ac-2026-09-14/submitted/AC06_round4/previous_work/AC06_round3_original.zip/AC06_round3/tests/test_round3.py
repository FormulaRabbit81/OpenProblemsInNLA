from fractions import Fraction
from itertools import product
from math import comb, prod
import unittest

import sympy as sp

from ac06_round3 import (
    AllocationGuard, binary_dimensions, bit_budget, clear_denominators,
    evaluate, exponential_product_demo, exponent_box, finite_certificate,
    greedy_grid, interpolate_products, multiplication_values, odd_minimum,
    phase_demo, polynomial_from_json, pullback_monomial, pullback_polynomial,
    quarter_dimensions, rank_parameter_monomials, shifted_product_weights,
)


class DimensionTests(unittest.TestCase):
    def test_constant_alphabet_exact_dimensions(self):
        for n in range(2, 31):
            D = quarter_dimensions(n)
            self.assertGreater(D['columns'], D['row_bound'])
            self.assertEqual(D['columns'], 2**(11*n**3))

    def test_constant_alphabet_elementary_threshold(self):
        self.assertGreater(2048, 12**3)
        # Equivalent to (12q)^(3N/4)<q^N, with no floating point.
        for N in (1, 8, 27, 64):
            self.assertLess((12*2048)**(3*N), 2048**(4*N))

    def test_binary_exact_dimensions(self):
        for n in range(11, 31):
            d = binary_dimensions(n)
            self.assertGreater(d['columns'], d['row_bound'])
            self.assertFalse(d['theorem_uses_diagonal_branch'])

    def test_binary_entropy_gap_exact(self):
        self.assertGreater(3**192*2**253, 5**240)

    def test_binary_binomial_mode_lower_bound(self):
        for N in range(1, 200):
            d = N//3
            self.assertGreaterEqual(comb(N,d)*2**(N-d)*(N+1), 3**N)

    def test_binary_codomain_entropy_bound(self):
        for n in range(4, 31):
            d = binary_dimensions(n)
            s, degree, V = d['s'], d['d'], d['row_bound']
            self.assertLessEqual(V * 4**(3*degree), 5**(s+3*degree))

    def test_binary_large_N_threshold(self):
        for N in range(1024, 6000):
            # 2^(N/64 - 1) > N+1, raised to the 64th power.
            self.assertGreater(2**(N-64), (N+1)**64)

    def test_small_n_diagonal_branch(self):
        for n in range(1,11):
            self.assertGreater(12*n, n*n)
            flatten = sp.zeros(n,n*n)
            for i in range(n):
                flatten[i,i+n*i] = 1
            self.assertEqual(flatten.rank(), n)

    def test_dimension_guards(self):
        with self.assertRaises(AllocationGuard):
            quarter_dimensions(100)
        with self.assertRaises(AllocationGuard):
            binary_dimensions(100)
        with self.assertRaises(ValueError):
            quarter_dimensions(1)


class EliminationTests(unittest.TestCase):
    def test_squarefree_space(self):
        E = exponent_box(8,2,total_cap=2)
        self.assertEqual(len(E),37)
        self.assertTrue(all(max(e)<=1 and sum(e)<=2 for e in E))

    def test_exact_squarefree_layer(self):
        E = exponent_box(8,2,exact_degree=2)
        self.assertEqual(len(E),28)
        self.assertTrue(all(sum(e)==2 for e in E))
        self.assertEqual(exponent_box(3,2,exact_degree=4),[])
        self.assertEqual(exponent_box(2,3,total_cap=1,exact_degree=2),[])

    def test_exponential_allocation_guard(self):
        with self.assertRaises(AllocationGuard):
            exponent_box(8,2048)
        with self.assertRaises(AllocationGuard):
            exponent_box(1331,2,exact_degree=443)

    def test_pullback_coefficient_bound(self):
        for n,r in [(2,1),(2,2),(2,3)]:
            coords = rank_parameter_monomials(n,r)
            for a in exponent_box(n**3,2,total_cap=2):
                P = pullback_monomial(a,coords)
                self.assertEqual(sum(P.values()),r**sum(a))
                self.assertLessEqual(max(P.values()),r**sum(a))

    def test_binary_elimination_certificate(self):
        obj = finite_certificate()
        self.assertEqual((obj['columns'],obj['occurring_rows'],obj['rank'],obj['nullity']), (37,28,28,9))
        P = polynomial_from_json(obj['annihilator'])
        self.assertEqual(pullback_polynomial(P,2,1),{})
        self.assertNotEqual(evaluate(P,obj['tensor_flat']),0)
        self.assertTrue(all(x in {0,1} for x in obj['tensor_flat']))
        self.assertEqual(obj['certified_complex_border_rank_at_least'],2)

    def test_homogeneous_elimination_certificate(self):
        obj = finite_certificate(exact_degree=2)
        self.assertEqual(obj['columns'],28)
        P = polynomial_from_json(obj['annihilator'])
        self.assertTrue(all(sum(a)==2 for a in P))
        self.assertEqual(pullback_polynomial(P,2,1),{})

    def test_rank_two_n2_has_no_degree_two_kernel(self):
        obj = finite_certificate(r=2)
        self.assertEqual(obj['nullity'],0)
        self.assertIsNone(obj['annihilator'])

    def test_box_q3_elimination_certificate(self):
        obj = finite_certificate(q=3,total_cap=2)
        self.assertEqual((obj['columns'],obj['occurring_rows'],obj['nullity']),(45,36,9))
        P = polynomial_from_json(obj['annihilator'])
        self.assertNotEqual(evaluate(P,obj['tensor_flat']),0)

    def test_greedy_grid_all_small_height_one_polynomials(self):
        E = exponent_box(2,2)
        for coefficients in product((-1,0,1),repeat=len(E)):
            P = {a:Fraction(c) for a,c in zip(E,coefficients) if c}
            if P:
                point, val = greedy_grid(P,2)
                self.assertNotEqual(val,0)
                self.assertEqual(val,evaluate(P,point))

    def test_greedy_rejects_invalid_degree(self):
        with self.assertRaises(ValueError):
            greedy_grid({(2,):Fraction(1)},2)
        with self.assertRaises(ValueError):
            greedy_grid({},2)


class TemplateTests(unittest.TestCase):
    def test_denominator_clearing(self):
        xs = [Fraction(2,3),Fraction(-5,7),Fraction(0),Fraction(1,11)]
        Q, scaled, L = clear_denominators(xs)
        self.assertEqual(Q,231)
        self.assertEqual(scaled,[154,-165,0,21])
        self.assertTrue(all(abs(v)<2**L for v in scaled))
        self.assertEqual(L,bit_budget(xs))

    def test_cleared_coordinate_l1_bound(self):
        for m in range(1,5):
            xs = [Fraction((-1)**t*(t+1),t+2) for t in range(m**3)]
            Q, vals, L = clear_denominators(xs)
            self.assertLess(sum(abs(x) for x in vals),m**3*2**L)

    def test_template_dimension_bound(self):
        for n in range(4,17):
            N=n**3; r=n*n//4; D=2**16*N
            U=comb(N+D,N)
            for m in sorted({1,n,r}):
                s=3*n*m; V=comb(s+3*D,s)
                self.assertGreater(U,V*2**N)

    def test_template_overhead_bound(self):
        for n in range(4,101):
            N=n**3
            self.assertLess(2**19*N*N,2**(N-2))

    def test_small_rational_template_identity(self):
        # A 1x1x1 template maps only to pure tensors; check the exact identity.
        a0,a1,b0,b1,c0=sp.symbols('a0 a1 b0 b1 c0')
        s=sp.Rational(-7,11)
        x0=s*a0*b0*c0; x1=s*a1*b0*c0
        x2=s*a0*b1*c0; x3=s*a1*b1*c0
        self.assertEqual(sp.expand(x0*x3-x1*x2),0)

    def test_cyclotomic_degree_injection(self):
        t=sp.Symbol('t')
        for N,D in [(2,2),(3,2),(2,3)]:
            B=D+1; E=B**N; d=1<<(E-1).bit_length()
            self.assertEqual(sp.cyclotomic_poly(2*d,t),t**d+1)
            exps=exponent_box(N,D+1,total_cap=D)
            weights=[B**i for i in range(N)]
            costs=[sum(a*w for a,w in zip(alpha,weights)) for alpha in exps]
            self.assertEqual(len(costs),len(set(costs)))
            self.assertLess(max(costs),d)
            # Every single monomial and a signed combination survive reduction.
            q=sum((-1)**j*t**e for j,e in enumerate(costs))
            self.assertEqual(sp.rem(q,t**d+1,t),q)
            self.assertNotEqual(q,0)


class InterpolationTests(unittest.TestCase):
    def test_multiplication_counts(self):
        self.assertEqual([len(multiplication_values(n)) for n in range(1,11)], [1,3,6,9,14,18,25,30,36,42])

    def test_exponential_product_decompositions(self):
        for n in range(1,6):
            for base in (2,3):
                obj=exponential_product_demo(n,base)
                self.assertEqual(obj['certified_rank_upper_bound'],len(multiplication_values(n)))

    def test_arbitrary_product_functions(self):
        obj=interpolate_products([1,2,3],[2,3,4],[lambda s:s*s+1,lambda s:1/(s+1),lambda s:(-1)**int(s)])
        self.assertEqual(obj['certified_rank_upper_bound'],len({a*b for a in [1,2,3] for b in [2,3,4]}))

    def test_product_nodes_zero_and_repeated(self):
        obj=interpolate_products([0,0,1],[0,2],[lambda s:s,lambda s:s+1])
        self.assertEqual(obj['certified_rank_upper_bound'],2)

    def test_quadratic_phase(self):
        for n in range(1,6):
            self.assertEqual(phase_demo(n)['certified_rank_upper_bound'],3*n-2)

    def test_shifted_product_collision_count(self):
        for n in range(1,101):
            M=n*n
            self.assertEqual(len({(M+i)*(M+j) for i in range(n) for j in range(n)}),n*(n+1)//2)

    def test_shifted_weights_and_diagonal_equivalence(self):
        for n in range(1,8):
            M=n*n
            weights=shifted_product_weights(n)
            for k,j,i in product(range(n),repeat=3):
                ell=i+n*j+n*n*k
                self.assertEqual(weights[ell],(M+i)*(M+j)*(M+k)-M**3-M**2*(i+j+k))
            self.assertLessEqual(max(weights),4*n**4)

    def test_interpolation_guards(self):
        with self.assertRaises(AllocationGuard):
            exponential_product_demo(100)
        with self.assertRaises(AllocationGuard):
            phase_demo(20)


class TargetedWitnessTests(unittest.TestCase):
    def test_minor_odd_minimum(self):
        e1=(1,0,0,1,0,0,0,0);e2=(0,1,1,0,0,0,0,0)
        P={e1:Fraction(1),e2:Fraction(-1)}
        w=[0,0,0,1,0,0,0,0]
        self.assertEqual(pullback_polynomial(P,2,1),{})
        self.assertTrue(odd_minimum(P,w)['nonvanishing_guaranteed'])
        self.assertEqual(evaluate(P,[2**x for x in w]),1)

    def test_odd_minimum_all_small_signed_polynomials(self):
        exps=exponent_box(2,3,total_cap=2)
        for coeffs in product((-1,0,1),repeat=len(exps)):
            P={a:Fraction(c) for a,c in zip(exps,coeffs) if c}
            if P:
                for w in [(0,0),(1,1),(1,3)]:
                    if odd_minimum(P,w)['nonvanishing_guaranteed']:
                        self.assertNotEqual(evaluate(P,[2**v for v in w]),0)

    def test_even_minimum_is_not_enough(self):
        P={(1,):Fraction(1),(0,):Fraction(-2)}
        self.assertFalse(odd_minimum(P,[1])['nonvanishing_guaranteed'])
        self.assertEqual(evaluate(P,[2]),0)

    def test_unique_minimum_is_not_an_annihilator_test(self):
        P={(0,):Fraction(1)}
        self.assertTrue(odd_minimum(P,[0])['nonvanishing_guaranteed'])
        # A nonzero constant is never an annihilator; the code makes no such claim.
        self.assertNotEqual(evaluate(P,[0]),0)

    def test_rational_coefficients_rejected(self):
        with self.assertRaises(ValueError):
            odd_minimum({(0,):Fraction(1,2)},[1])


if __name__=='__main__':
    unittest.main()
