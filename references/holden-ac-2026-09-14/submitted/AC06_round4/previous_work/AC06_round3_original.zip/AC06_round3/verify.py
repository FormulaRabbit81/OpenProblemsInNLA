from pathlib import Path
import datetime
import io
import json
import platform
import sys
import time
import unittest
import sympy

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
start=time.perf_counter()
stream=io.StringIO()
suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'))
result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
text=stream.getvalue()
print(text,end='')
(ROOT/'evidence').mkdir(exist_ok=True)
(ROOT/'evidence'/'tests.log').write_text(text)
(ROOT/'evidence'/'verification.json').write_text(json.dumps({
    'utc_completed':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
    'success':result.wasSuccessful(),'elapsed_seconds':time.perf_counter()-start,
    'python':sys.version,'sympy':sympy.__version__,'platform':platform.platform(),
    'scope':'Exact finite regression tests, not proof-assistant formalization or independent review. General exponential matrices were not allocated. No quadratic-rank candidate is certified by numerical fitting.'
},indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() else 1)
