# Sources consulted and their scope

Consulted September 14, 2026. Public web/raw GitHub pages were used, not a GitHub plugin. No repository changes were performed.

1. **AC-06 statement.** Open Problems in Numerical Linear Algebra. https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/arithmetic-and-complexity/AC-06/README.md . The retrieved statement explicitly requires deterministic polynomial time in n, full binary rational entries, and quadratic complex border rank. Its displayed status was Open; its own last-check date was September 10, 2026. The category GitHub page did not render successfully in an earlier direct attempt; the exact problem's raw web text did.

2. **Prior reports.** Current-conversation attachment AC06_round2/report.pdf was read in full through the file tool. The corresponding archive was inspected programmatically and its tests rerun on an extracted copy. The first archive nested inside it was also extracted and tested. `prior_provenance.json` records hashes. These reports are unreviewed supplied work, not independent sources.

3. **Kumar–Volk (2021).** A Polynomial Degree Bound on Equations for Non-Rigid Matrices and Small Linear Circuits. https://benleevo.lk/pdf/degbound.pdf ; https://doi.org/10.4230/LIPIcs.ITCS.2021.9 . Section 4 explicitly gives the cubic rank parameterization and polynomial-degree annihilator framework. Its theorem does not automatically yield an efficient rational high-rank point or compact equation representation.

4. **Ford (2008).** The distribution of integers with a divisor in a given interval. Annals of Mathematics 168, 367–433. https://www.ford126.web.illinois.edu/wwwpapers/hxyz.pdf . Corollary 3 on printed page 373 (PDF page index 6) was read and visually inspected. The paper uses x as the size bound on products; substituting x=n² gives the order of the n-by-n multiplication table up to constants. It is a Theta/order-of-magnitude estimate, not a proved asymptotic equivalent. The author's bibliography at https://www.ford126.web.illinois.edu/papers-ann.html independently restates the same application.

5. **Mańdziuk (September 10, 2026).** Border rank lower bounds beyond weak border apolarity. https://arxiv.org/abs/2609.12121 ; https://arxiv.org/html/2609.12121v1 . Submission date and main claims were checked. The new apolarity tests and finite tensors in this paper are relevant lower-bound methods, but the inspected claims do not furnish the uniform quadratic rational family required by AC-06.

6. **Sturmfels–Sullivant.** Combinatorial Secant Varieties. https://arxiv.org/abs/math/0506223 ; https://arxiv.org/html/math/0506223 . Corollary 4.2 establishes in(I^{r}) contained in (in I)^{r}. Definition 4.8 names the extra equality property. This does not permit reversing the containment when proposing a secant equation from a combinatorial degeneration.

Additional scope checks, not needed as premises of the new proofs:

- Michałek–Landsberg, Theory of Computing 21(13), 2025: https://www.theoryofcomputing.org/articles/v021a013/v021a013.pdf . Explicit 2.02m lower bound, not quadratic.
- Narayanan, July 2026: https://arxiv.org/html/2607.15848v1 . Theorem 1.5 uses semi-explicit number-field entries, not AC-06's binary rational convention.
- Doležálek–Michałek, February 2026: https://arxiv.org/html/2602.12762v1 . Nonlinear determinantal methods; no general nonlinear impossibility theorem is inferred.
- Conca–De Negri–Stojanac, 2020: https://alco.centre-mersenne.org/articles/10.5802/alco.115/ . The paper's triple Segre result is for a two-dimensional first factor (P^1), not a general quadratic-threshold cubic tensor theorem.

The literature check is bounded. The incomplete status of this report follows from its own missing algorithmic proof, not from an assertion that no one could have resolved the problem elsewhere.
