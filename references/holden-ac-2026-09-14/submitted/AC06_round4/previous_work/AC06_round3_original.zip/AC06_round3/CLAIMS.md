# Claim audit

The proof numbers below refer to `report.pdf`. “Proved” means a written mathematical argument is supplied, not that it has been independently reviewed or formalized.

## Proved in this report

**C1 — deterministic constant alphabet (Theorem 3.1).** For every n, a uniform deterministic algorithm returns entries in {0,...,2047} and complex border rank > n²/4. Its bit-time bound is 2^{O(n³)}. The numeral 2048 is a sufficient fixed alphabet, not an optimality claim. The implementation only runs guarded toy examples of the general exponential algorithm.

**C2 — deterministic binary output (Theorem 4.1).** For n>=11, a nonzero homogeneous multilinear annihilator is obtained by exact dimension comparison, then greedily specialized to a binary point. The border rank is > n²/12. For n<=10, a diagonal tensor supplies the same bound. Time remains 2^{O(n³)}. This is not a faster version of the prior randomized binary sampler; it is a different, exponential-time construction.

**C3 — arbitrary complex basis changes and templates (Theorem 5.4).** Let N=n³, D=2^{16}N, n>=4. A tensor avoiding every nonzero degree<=D height-one integer polynomial cannot be in the restriction closure of a rational m-cubic template with m<=floor(n²/4) and bit budget L<=2^N/(4D). Complex restriction matrices are unrestricted. The earlier H and G families have this avoidance property. Thus all of their same-dimensional rational orbit representatives have exponential bit budgets. The result is NOT a lower bound on the output length of every high-border-rank family.

**C4 — no exact rational descent for the retained cyclotomic family (Theorem 6.3).** The family Z avoids every nonzero degree<=D rational polynomial. Every rational template with m<=floor(n²/4) has a nonzero equation of that degree for its restriction closure. Therefore Z cannot lie in any such closure. In particular, no same-dimensional rational tensor is complex modewise equivalent to Z for n>=4. Approximation, rounding, and unrelated number-field constructions are not excluded.

**C5 — product-index rank upper bound (Theorem 7.1).** A tensor f_k(a_i b_j) has a CP decomposition with no more than |{a_i b_j}| terms. The proof is exact Vandermonde interpolation. Applied to positive integer indices, the classical multiplication-table theorem gives o(n²). Hence q_n^{ijk} fails AC-06 for every sequence of bases q_n. No equality of rank and the interpolation bound is asserted.

**C6 — quadratic-phase upper bound (Proposition 7.3).** The family 2^{ij+jk+ki}, indices from zero, has exact complex rank <=3n-2. Rational finite tests use base four to avoid irrational intermediate scaling.

**C7 — targeted single-witness condition (Proposition 8.1 and Corollary 8.2).** A unique minimum-weight monomial with odd coefficient prevents cancellation after x_l=2^{w_l}. If a polynomial-time, polynomially bounded weight family has this property for an annihilator at a quadratic rank threshold, it gives a solution. This implication is proved. Its premise is NOT established at quadratic rank for any explicit weight family here.

## Retained from the previous package

The previous height-one annihilator and H/G avoidance properties are recalled with proofs where needed. The random binary and 32-symbol guarantees, monomial-sparsity lower bound, huge-integer weight construction, and previous certificate gap remain separate results. None is relabeled as a polynomial-time deterministic solution.

## External inputs

The polynomial-pullback framework has prior literature (Kumar–Volk). The o(n²) multiplication-table estimate and its sharper order are cited from Ford (2008, Corollary 3). The initial-ideal inclusion and the extra equality requirement are cited from Sturmfels–Sullivant. The latest literature check is limited to actual statements inspected, including Mańdziuk's September 10, 2026 preprint; it is not proof that no solution exists anywhere.

## Not established

There is no complete AC-06 solution, no independently verified new superlinear polynomial-time explicit tensor lower bound, no polynomial-time evaluation or construction of the dense annihilators, and no quadratic border-rank certificate for the shifted-product candidate. The 38+25+16 passing tests check finite algebra and implementations only.

No novelty priority or repository status change is claimed.
