# Remaining mathematical obligations

## The actual completion test

Exhibit a single uniform deterministic algorithm with polynomial bit cost in n, outputting the full rational tensor, together with a proof of complex border rank >=c n² for a constant c>0 in all sufficiently large dimensions. The present exponential-time construction does not pass this test.

## A targeted witness route

Prove a bounded-weight isolation statement for a genuine tensor secant equation. Specifically, produce w^(n) in nonnegative integers, computable in polynomial time with maximum polynomial in n, and prove that an integer equation of V_{n,floor(c n²)} has a unique minimum-weight monomial with odd coefficient. Corollary 8.2 then completes the construction without requiring an efficient evaluator for that equation.

The missing result is the isolation statement for an ACTUAL annihilator, not just a combinatorial support guess. A monomial in the secant of an initial ideal need not lift to the initial ideal of the secant; the general inclusion points the other way. The weight isolation must also hold for the bounded integer weights, not merely for an abstract term order.

The shifted weights w_ijk=n²(ij+ik+jk)+ijk are a specific unresolved test case, not a recommended or proven successful route. Their product nodes have n(n+1)/2 distinct values. This removes the unshifted multiplication-table upper-bound obstruction but supplies no lower bound. Any proposed proof should first verify the secant-annihilator identity symbolically and distinguish border rank from exact rank.

## An efficient selection route

A polynomial-time procedure for obtaining one nonzero annihilating equation in a representation supporting polynomial-time identity testing under successive substitutions would also suffice. The dense coefficient representation is exponential. The prior sparsity theorem excludes polynomial-length monomial lists at quadratic rank but does not exclude compact arithmetic circuits.

A general polynomial identity testing assumption alone does not construct the equation. Both the equation representation/construction and the identity tests require justification.

## Routes no longer sufficient as stated

Arbitrary complex changes of basis cannot make the H/G universal-avoidance family into polynomial-bit rational output; the new theorem is stronger than the earlier diagonal-scaling argument. Exact descent of the retained Z cyclotomic tensor from a rational template requires side >floor(n²/4), so constant-factor dimensional padding cannot fix that family. The elementary replacement 2^{ijk} has a proved o(n²) rank upper bound, and 2^{ij+jk+ki} has a proved linear upper bound. The previous fixed-seed tensor-power obstruction also remains applicable.

None of these exclusions is a proof that AC-06 is impossible. They delimit the constructions and operations actually analyzed.
