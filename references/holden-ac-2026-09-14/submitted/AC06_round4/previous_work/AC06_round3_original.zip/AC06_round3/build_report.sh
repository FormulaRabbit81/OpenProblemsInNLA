#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p .latex_build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=.latex_build report.tex > .latex_build/pass1.log
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=.latex_build report.tex > .latex_build/pass2.log
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=.latex_build report.tex > .latex_build/pass3.log
cp .latex_build/report.pdf report.pdf
printf 'Built report.pdf\n'
