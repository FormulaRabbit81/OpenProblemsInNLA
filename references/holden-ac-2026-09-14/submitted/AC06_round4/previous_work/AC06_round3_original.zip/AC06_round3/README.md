# AC-06 — third-round partial research

**This archive does not contain a complete solution of AC-06.** The missing requirement is a deterministic polynomial-time rational-output construction with a proved quadratic complex border-rank guarantee. The new finite-alphabet constructions run in exponential time.

Start with `report.pdf` (15 pages). `report.tex` is the editable mathematical source. The work is an extension of the two supplied working reports, not an independently reviewed publication or a claim of a new state-of-the-art explicit tensor lower bound.

## Results established by the written arguments

| Result | Guarantee | Limitation |
|---|---|---|
| Theorem 3.1 | Deterministic entries in 0,...,2047; complex border rank > n²/4 | Bit time 2^{O(n³)}, not polynomial |
| Theorem 4.1 | Deterministic binary entries; complex border rank > n²/12 | Bit time 2^{O(n³)}, not polynomial |
| Theorem 5.4 | Universal-avoidance tensors cannot be obtained from a small rational template of side at most floor(n²/4); same-dimensional rational orbit representatives need > 2^{n³}/(2^{18} n³) bits in the stated budget | Specific universal-avoidance property only; does not exclude small rational hard tensors |
| Theorem 6.3 | The retained cyclotomic tensor is not in the restriction closure of any rational template of side at most floor(n²/4), irrespective of coefficient size | Exact descent only; does not rule out rounding or unrelated constructions |
| Theorem 7.1 and Corollary 7.2 | T_ijk=f_k(a_i b_j) has rank at most the number of distinct products; T_ijk=q_n^{ijk} has rank o(n²) | Upper bound; classical multiplication-table theorem is an external ingredient |
| Proposition 7.3 | 2^{ij+jk+ki} has rank at most 3n-2 | Upper bound |
| Corollary 8.2 | Polynomially bounded integer weights plus a proved unique odd minimum-weight monomial in one annihilator would solve AC-06 | Sufficient condition only; no qualifying weights are proved |

The shifted weights in Section 7.3 are **unresolved candidates**, not a solution. Their polynomial output length and a quadratic rank upper bound are proved; a quadratic lower bound is not.

## Reproduce the exact demonstrations

Python 3.10 or later and SymPy are required. The environment actually used is recorded in `evidence/verification.json`.

```bash
python -m pip install -r requirements.txt
python verify.py
python src/ac06_round3.py toy-certificate
python src/ac06_round3.py binary-dimensions 11
python src/ac06_round3.py box-dimensions 4
python src/ac06_round3.py product-decomposition 4
```

The dense implementation has allocation guards. It executes small, exact pullback/nullspace examples, **not** the enormous all-dimension construction. The `toy-certificate` output contains its actual annihilating polynomial, exact nonzero evaluation, and certified finite border-rank lower bound. Dimension commands compute dimension comparisons only; they do not output the asymptotic hard tensors.

The new test suite has 38 passing tests. The preserved previous archive has 25 tests, and its nested first archive has 16; both were rerun on extracted working copies and passed. These are finite regression checks, not proof-assistant formalizations, an independent review, or a computational proof of all dimensions. The multiplication-table asymptotic is cited from Ford, not inferred from the enumerated examples.

## Contents

- `report.pdf`, `report.tex`, `build_report.sh`: mathematical report and source.
- `src/ac06_round3.py`, `tests/test_round3.py`, `verify.py`: guarded exact demonstrations and regression suite.
- `examples/`: exact finite certificates and upper-bound decompositions. Files prefixed `UNRESOLVED_` are explicitly uncertified candidates.
- `CLAIMS.md`, `NEXT_STEPS.md`: theorem audit and precise unfulfilled proof obligations.
- `evidence/`: test logs, provenance, source notes, and PDF-quality records.
- `previous_work/AC06_round2_original.zip`: byte-for-byte preserved second archive, itself retaining the first archive.
- `SHA256SUMS.txt`: file integrity hashes, excluding this checksum file itself.

To rebuild the PDF, use `bash build_report.sh` in a LaTeX environment with the packages listed in `report.tex`. Temporary output goes to `.latex_build/`; it is not part of the distributed archive.

No GitHub repository was modified. This package is not proposed as a completed AC-06 proof.
