"""Exact finite demonstrations for the third AC-06 report.

No polynomial-time solution of AC-06 is implemented here.  Dense elimination
is deliberately guarded.  The all-dimension algorithms are exponential-time
algorithms described in report.pdf; the tests below are small exact examples.
Coordinate order: ell = i + n*j + n*n*k, with zero-based indices.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
from itertools import combinations, product
import json
from math import comb, gcd, lcm, prod
from pathlib import Path
from typing import Callable, Iterable, Sequence

import sympy as sp

Exponent = tuple[int, ...]
Polynomial = dict[Exponent, Fraction]


class AllocationGuard(ValueError):
    """An exponential-size demonstration was refused before allocation."""


def require_int(value: int, name: str, minimum: int = 0) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def quarter_dimensions(n: int, q: int = 2048) -> dict[str, int | bool]:
    """Exact dimensions, not a construction or membership test."""
    require_int(n, "n", 2)
    require_int(q, "q", 2)
    if n > 40 or q > 4096:
        raise AllocationGuard("Exact dimension display is limited to n<=40, q<=4096")
    N, r = n**3, n*n//4
    s, d = 3*n*r, (q-1)*N
    U, V = q**N, comb(s+3*d, s)
    return {"n": n, "N": N, "r": r, "s": s, "q": q, "d": d,
            "columns": U, "row_bound": V, "nonzero_kernel_guaranteed": U > V}


def binary_dimensions(n: int) -> dict[str, int | bool]:
    require_int(n, "n", 1)
    if n > 50:
        raise AllocationGuard("Exact binary dimension display is limited to n<=50")
    N, r = n**3, n*n//12
    s, d = 3*n*r, N//3
    U, V = comb(N, d), comb(s+3*d, s)
    return {"n": n, "N": N, "r": r, "s": s, "d": d,
            "columns": U, "row_bound": V, "nonzero_kernel_guaranteed": U > V,
            "theorem_uses_diagonal_branch": n <= 10}


def exponent_box(N: int, q: int, total_cap: int | None = None,
                 exact_degree: int | None = None, max_columns: int = 1000) -> list[Exponent]:
    require_int(N, "N", 1)
    require_int(q, "q", 2)
    require_int(max_columns, "max_columns", 1)
    if total_cap is not None:
        require_int(total_cap, "total_cap")
    if exact_degree is not None:
        require_int(exact_degree, "exact_degree")
    cap = min((q-1)*N, total_cap if total_cap is not None else (q-1)*N)
    if exact_degree is not None:
        if exact_degree > cap:
            return []
        cap = min(cap, exact_degree)
    # A special squarefree layer can be enumerated without traversing 2**N.
    if q == 2 and exact_degree is not None:
        if exact_degree > N or (total_cap is not None and exact_degree > total_cap):
            return []
        count = comb(N, exact_degree)
        if count > max_columns:
            raise AllocationGuard(f"Squarefree layer has {count.bit_length()}-bit column count; guard={max_columns}")
        ans = []
        for subset in combinations(range(N), exact_degree):
            a = [0]*N
            for i in subset:
                a[i] = 1
            ans.append(tuple(a))
        return ans
    # Dynamic count, saturated above the guard, before recursive enumeration.
    if N > 64 or cap > 12:
        raise AllocationGuard("Demonstration dimensions exceed the pre-allocation guard")
    counts = [1] + [0]*cap
    for _ in range(N):
        nxt = [0]*(cap+1)
        for d, num in enumerate(counts):
            for e in range(min(q-1, cap-d)+1):
                nxt[d+e] = min(max_columns+1, nxt[d+e]+num)
        counts = nxt
    count = counts[exact_degree] if exact_degree is not None else sum(counts)
    if count > max_columns:
        raise AllocationGuard(f"Polynomial space exceeds {max_columns} columns")
    ans: list[Exponent] = []
    def rec(prefix: list[int], remaining: int) -> None:
        if len(prefix) == N:
            if exact_degree is None or sum(prefix) == exact_degree:
                ans.append(tuple(prefix))
            return
        for e in range(min(q-1, remaining)+1):
            rec(prefix+[e], remaining-e)
    rec([], cap)
    return sorted(ans, key=lambda a: (sum(a), a))


def rank_parameter_monomials(n: int, r: int) -> list[list[Exponent]]:
    require_int(n, "n", 1)
    require_int(r, "r", 1)
    if n**3 > 64 or 3*n*r > 120:
        raise AllocationGuard("Rank-parameter demonstration is limited to 64 tensor coordinates")
    s = 3*n*r
    ans = []
    for k in range(n):
        for j in range(n):
            for i in range(n):
                terms = []
                for h in range(r):
                    e = [0]*s
                    e[h*n+i] += 1
                    e[n*r+h*n+j] += 1
                    e[2*n*r+h*n+k] += 1
                    terms.append(tuple(e))
                ans.append(terms)
    return ans


def pullback_monomial(alpha: Exponent, coordinate_terms: list[list[Exponent]],
                      max_terms: int = 10000) -> dict[Exponent, int]:
    if len(alpha) != len(coordinate_terms):
        raise ValueError("Exponent vector has the wrong length")
    s = len(coordinate_terms[0][0])
    out = {(0,)*s: 1}
    for a, terms in zip(alpha, coordinate_terms):
        require_int(a, "exponent")
        for _ in range(a):
            nxt: dict[Exponent, int] = {}
            for x, coeff in out.items():
                for y in terms:
                    z = tuple(u+v for u, v in zip(x, y))
                    nxt[z] = nxt.get(z, 0)+coeff
            if len(nxt) > max_terms:
                raise AllocationGuard("Intermediate polynomial exceeds max_terms")
            out = nxt
    return out


def pullback_polynomial(P: Polynomial, n: int, r: int) -> Polynomial:
    terms = rank_parameter_monomials(n, r)
    result: Polynomial = {}
    for alpha, c in P.items():
        for beta, v in pullback_monomial(alpha, terms).items():
            result[beta] = result.get(beta, Fraction(0))+c*v
    return {a: c for a, c in result.items() if c}


def evaluate(P: Polynomial, x: Sequence[int | Fraction]) -> Fraction:
    if any(len(a) != len(x) for a in P):
        raise ValueError("Coordinate vector has the wrong length")
    return sum((c*prod(Fraction(t)**e for t, e in zip(x, a)) for a, c in P.items()), Fraction(0))


def greedy_grid(P: Polynomial, q: int) -> tuple[list[int], Fraction]:
    require_int(q, "q", 2)
    P = {a: Fraction(c) for a, c in P.items() if c}
    if not P:
        raise ValueError("Polynomial must be nonzero")
    N = len(next(iter(P)))
    if any(len(a) != N or any(e < 0 or e >= q for e in a) for a in P):
        raise ValueError("Individual degrees must be below the grid size")
    choices = []
    current = P
    for _ in range(N):
        for x in range(q):
            nxt: Polynomial = {}
            for a, c in current.items():
                key = a[1:]
                nxt[key] = nxt.get(key, Fraction(0))+c*x**a[0]
            nxt = {a: c for a, c in nxt.items() if c}
            if nxt:
                choices.append(x)
                current = nxt
                break
        else:
            raise AssertionError("Grid nonvanishing lemma was violated")
    value = current.get((), Fraction(0))
    assert value and evaluate(P, choices) == value
    return choices, value


def finite_certificate(n: int = 2, r: int = 1, q: int = 2,
                       total_cap: int | None = 2, exact_degree: int | None = None,
                       max_columns: int = 400, max_rows: int = 4000) -> dict:
    """Actually constructs a small annihilator and proves a finite lower bound.

    This is an exponential dense method, NOT the requested poly-time algorithm.
    A None annihilator means only that this chosen polynomial space has no kernel.
    """
    require_int(n, "n", 1)
    require_int(r, "r", 1)
    exps = exponent_box(n**3, q, total_cap, exact_degree, max_columns)
    coord = rank_parameter_monomials(n, r)
    cols = [pullback_monomial(a, coord, max_rows) for a in exps]
    rows = sorted(set().union(*(p.keys() for p in cols))) if cols else []
    if len(rows) > max_rows:
        raise AllocationGuard("Pullback row count exceeds max_rows")
    row_id = {a: i for i, a in enumerate(rows)}
    data = {(row_id[a], j): c for j, P in enumerate(cols) for a, c in P.items()}
    A = sp.SparseMatrix(len(rows), len(exps), data)
    null = A.nullspace()
    result = {"n": n, "r": r, "q": q, "total_cap": total_cap,
              "exact_degree": exact_degree, "columns": len(exps),
              "occurring_rows": len(rows), "rank": len(exps)-len(null),
              "nullity": len(null), "method": "GUARDED_EXACT_DENSE_ELIMINATION",
              "scope": "A finite certificate only; not a polynomial-time AC-06 solution."}
    if not null:
        result["annihilator"] = None
        return result
    coeff = [Fraction(c) for c in null[0]]
    scale = lcm(*(c.denominator for c in coeff))
    ints = [int(c*scale) for c in coeff]
    common = gcd(*ints)
    ints = [c//common for c in ints]
    P = {a: Fraction(c) for a, c in zip(exps, ints) if c}
    assert not pullback_polynomial(P, n, r)
    point, value = greedy_grid(P, q)
    result.update({"annihilator": polynomial_json(P), "tensor_flat": point,
                   "evaluation": rational_json(value), "pullback_is_identically_zero": True,
                   "certified_complex_border_rank_at_least": r+1})
    return result


def rational_json(x: int | Fraction) -> dict[str, int]:
    x = Fraction(x)
    return {"numerator": x.numerator, "denominator": x.denominator}


def polynomial_json(P: Polynomial) -> list[dict]:
    return [{"exponents": list(a), "coefficient": rational_json(c)} for a, c in sorted(P.items()) if c]


def polynomial_from_json(items: list[dict]) -> Polynomial:
    return {tuple(x["exponents"]): Fraction(x["coefficient"]["numerator"], x["coefficient"]["denominator"])
            for x in items}


def multiplication_values(n: int) -> list[int]:
    require_int(n, "n", 1)
    if n > 2000:
        raise AllocationGuard("Multiplication-table enumeration is limited to n<=2000")
    return sorted({i*j for i in range(1, n+1) for j in range(1, n+1)})


def interpolate_products(a: Sequence[int | Fraction], b: Sequence[int | Fraction],
                         functions: Sequence[Callable[[Fraction], int | Fraction]],
                         max_products: int = 50) -> dict:
    """Returns an exact CP decomposition, proving an UPPER rank bound."""
    if not a or not b or not functions:
        raise ValueError("All three modes must be nonempty")
    a, b = list(map(Fraction, a)), list(map(Fraction, b))
    nodes = sorted({x*y for x in a for y in b})
    M = len(nodes)
    if M > max_products:
        raise AllocationGuard("Vandermonde demonstration exceeds max_products")
    V = sp.Matrix([[sp.Rational(x)**t for t in range(M)] for x in nodes])
    values = sp.Matrix([[sp.Rational(Fraction(f(x))) for f in functions] for x in nodes])
    C = V.inv()*values
    U = [[x**t for t in range(M)] for x in a]
    W = [[y**t for t in range(M)] for y in b]
    third = [[Fraction(C[t, k]) for t in range(M)] for k in range(len(functions))]
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            for k, f in enumerate(functions):
                assert sum(U[i][t]*W[j][t]*third[k][t] for t in range(M)) == Fraction(f(x*y))
    return {"nodes": nodes, "first": U, "second": W, "third": third,
            "certified_rank_upper_bound": M,
            "scope": "Upper bound only. Equality or a lower bound is not asserted."}


def exponential_product_demo(n: int, base: int = 2) -> dict:
    require_int(n, "n", 1)
    require_int(base, "base", 1)
    if n > 6 or base > 16:
        raise AllocationGuard("Explicit decomposition demo is limited to n<=6 and base<=16")
    funcs = [(lambda s, k=k: Fraction(base)**(int(s)*k)) for k in range(1, n+1)]
    return interpolate_products(range(1, n+1), range(1, n+1), funcs)


def phase_demo(n: int) -> dict:
    """Exact decomposition of 4**(ij+jk+ki), indices 0,...,n-1."""
    require_int(n, "n", 1)
    if n > 5:
        raise AllocationGuard("Quadratic phase demo is limited to n<=5")
    L = 3*n-2
    nodes = list(range(1, L+1))
    V = sp.Matrix([[x**s for x in nodes] for s in range(L)])
    c = [Fraction(v) for v in V.inv()*sp.Matrix([2**(s*s) for s in range(L)])]
    factors = [[Fraction(1, 2**(i*i))*x**i for x in nodes] for i in range(n)]
    for i, j, k in product(range(n), repeat=3):
        assert sum(c[t]*factors[i][t]*factors[j][t]*factors[k][t] for t in range(L)) == 4**(i*j+j*k+k*i)
    return {"nodes": nodes, "coefficients": c, "factors": factors,
            "certified_rank_upper_bound": L, "scope": "Exact upper-bound identity, not a lower bound."}


def odd_minimum(P: Polynomial, weights: Sequence[int]) -> dict:
    """Tests the algebraic nonvanishing sufficient condition for a GIVEN P.

    It does not prove P is a tensor annihilator; that is a separate obligation.
    """
    P = {a: Fraction(c) for a, c in P.items() if c}
    if not P:
        raise ValueError("Polynomial must be nonzero")
    for w in weights:
        require_int(w, "weight")
    if any(len(a) != len(weights) for a in P):
        raise ValueError("Wrong weight vector length")
    if any(c.denominator != 1 for c in P.values()):
        raise ValueError("Integer coefficients are required")
    costs = {a: sum(e*w for e, w in zip(a, weights)) for a in P}
    best = min(costs.values())
    mins = [a for a, cost in costs.items() if cost == best]
    valid = len(mins) == 1 and int(P[mins[0]]) % 2 == 1
    return {"unique_minimum": len(mins) == 1, "minimum_weight": best,
            "odd_coefficient": len(mins) == 1 and int(P[mins[0]]) % 2 == 1,
            "nonvanishing_guaranteed": valid}


def bit_budget(entries: Iterable[int | Fraction]) -> int:
    return sum(max(abs(Fraction(x).numerator), Fraction(x).denominator).bit_length() for x in entries)


def clear_denominators(entries: Sequence[int | Fraction]) -> tuple[int, list[int], int]:
    xs = list(map(Fraction, entries))
    if not xs:
        raise ValueError("Entries must be nonempty")
    Q = prod(x.denominator for x in xs)
    scaled = [int(Q*x) for x in xs]
    L = bit_budget(xs)
    assert all(abs(x) < 2**L for x in scaled)
    return Q, scaled, L


def shifted_product_weights(n: int) -> list[int]:
    """UNRESOLVED candidate; no quadratic lower-bound certificate is supplied."""
    require_int(n, "n", 1)
    if n > 100:
        raise AllocationGuard("Candidate weight display is limited to n<=100")
    M = n*n
    return [M*(i*j+i*k+j*k)+i*j*k for k in range(n) for j in range(n) for i in range(n)]


def jsonable(obj):
    if isinstance(obj, Fraction):
        return rational_json(obj)
    if isinstance(obj, dict):
        return {str(k): jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [jsonable(x) for x in obj]
    return obj


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("toy-certificate")
    p.add_argument("--n", type=int, default=2)
    p.add_argument("--r", type=int, default=1)
    p.add_argument("--q", type=int, default=2)
    p.add_argument("--total-cap", type=int, default=2)
    p.add_argument("--output", type=Path)
    p = sub.add_parser("binary-dimensions")
    p.add_argument("n", type=int)
    p = sub.add_parser("box-dimensions")
    p.add_argument("n", type=int)
    p = sub.add_parser("product-decomposition")
    p.add_argument("n", type=int)
    p.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        if args.command == "toy-certificate":
            result = finite_certificate(args.n, args.r, args.q, args.total_cap)
        elif args.command == "binary-dimensions":
            d = binary_dimensions(args.n)
            result = {k: v for k, v in d.items() if k not in {"columns", "row_bound"}}
            result.update(columns_bit_length=d["columns"].bit_length(), row_bound_bit_length=d["row_bound"].bit_length())
        elif args.command == "box-dimensions":
            d = quarter_dimensions(args.n)
            result = {k: v for k, v in d.items() if k not in {"columns", "row_bound"}}
            result.update(columns_bit_length=d["columns"].bit_length(), row_bound_bit_length=d["row_bound"].bit_length())
        else:
            result = exponential_product_demo(args.n)
    except (ValueError, AllocationGuard) as exc:
        parser.error(str(exc))
    text = json.dumps(jsonable(result), indent=2)+"\n"
    output = getattr(args, "output", None)
    if output:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(text)
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
