"""Exact rational certificates for the CW spectral inequalities.

No floating-point arithmetic is used.  All radical enclosures are checked by
cubing integers, and all recurrence evaluations use fractions.Fraction.
"""
from __future__ import annotations
from fractions import Fraction as F
from pathlib import Path
import json


def integer_cuberoot(n:int)->int:
    if n<0:raise ValueError('Only nonnegative inputs are supported')
    lo=0;hi=1 << ((n.bit_length()+2)//3)
    while lo+1<hi:
        mid=(lo+hi)//2
        if mid**3<=n:lo=mid
        else:hi=mid
    return hi if hi**3<=n else lo


def radical_certificate(n:int,den:int)->dict:
    z=integer_cuberoot(n*den**3)
    return {'radicand':n,'denominator':den,'floor_numerator':z}


def verify_radical(obj:dict)->tuple[F,F]:
    n,den,z=[obj[k] for k in ('radicand','denominator','floor_numerator')]
    if not all(type(v) is int for v in (n,den,z)) or n<0 or den<=0 or z<0:
        raise AssertionError('Invalid radical certificate fields')
    if not z**3<=n*den**3<(z+1)**3:
        raise AssertionError('Integer cubing rejected a radical enclosure')
    return F(z,den),F(z+1,den)


def state_sequence(choices:list[int])->list[dict]:
    d,t,H=108,112,330
    states=[]
    for j in range(len(choices)+1):
        states.append({'stage':j,'active_main_rank':d,'cw_size':t,
                       'source_form_rank':2*d+t,'spectral_source_upper':H})
        if j<len(choices):
            k=choices[j]
            if t%4 or not 1<=k<=t//2:raise ValueError('Invalid graph parameter')
            m=t*k
            d,t,H=d*d+2*d*t+m,t*t+2*d*d-2*m,H*H
    return states


def make_certificate()->dict:
    choices=[42,13232,1486535198]
    states=state_sequence(choices);den=10**40
    radicals={}
    for j,state in enumerate(states):
        t=state['cw_size']
        radicals[f'cw_{j}']=radical_certificate((t//2)**2,den)
        if j<len(choices):radicals[f'graph_{j}']=radical_certificate(choices[j],den)
    return {'schema':'symmetric-cw-spectral-bound-v1',
            'upper_bound':'3878657073/1000000000',
            'simple_exchange_upper_bound':'3883733322/1000000000',
            'choices':choices,'states':states,'radicals':radicals,
            'simple_exchange_radical':radical_certificate(56**2,den)}


def decimal_floor(x:F,digits:int=24)->str:
    scale=10**digits
    z=(x.numerator*scale)//x.denominator
    sign='-' if z<0 else ''
    z=abs(z)
    return f'{sign}{z//scale}.{z%scale:0{digits}d}'


def verify_certificate(data:dict)->dict:
    if data.get('schema')!='symmetric-cw-spectral-bound-v1':
        raise AssertionError('Unknown bound certificate')
    x=F(data['upper_bound']);xs=F(data['simple_exchange_upper_bound'])
    if not 3<x<4 or not x<xs<4:raise AssertionError('Unexpected claimed range')
    choices=data['choices'];states=state_sequence(choices)
    if data['states']!=states:raise AssertionError('The integer state recurrence is incorrect')
    a=x**3+x**4;steps=[]
    for j,state in enumerate(states):
        t=state['cw_size'];obj=data['radicals'][f'cw_{j}']
        if obj['radicand']!=(t//2)**2:raise AssertionError('Incorrect CW radicand')
        q=3*verify_radical(obj)[0]
        lhs=a+q;H=F(state['spectral_source_upper'])
        steps.append({'stage':j,'active_main_rank':state['active_main_rank'],
                      'cw_size':t,'source_form_rank':state['source_form_rank'],
                      'spectral_source_upper':state['spectral_source_upper'],
                      'lhs_over_rhs_lower_decimal_floor':decimal_floor(lhs/H),
                      'relative_gap_lower_decimal_floor':decimal_floor(lhs/H-1)})
        if j<len(choices):
            k=choices[j];gobj=data['radicals'][f'graph_{j}']
            if gobj['radicand']!=k:raise AssertionError('Incorrect graph radicand')
            z=3*t*verify_radical(gobj)[0]
            a=a*a+2*a*q+z
    if lhs<=H*(1+F(1,10**9)):raise AssertionError('The bound is not certified with the stated relative margin')
    simple_obj=data['simple_exchange_radical']
    if simple_obj['radicand']!=56**2:raise AssertionError('Bad simple radicand')
    simple_lhs=xs**3+xs**4+3*verify_radical(simple_obj)[0]
    if simple_lhs<=330+F(4,10**8):raise AssertionError('Simple exchange bound did not pass with its stated margin')
    return {'status':'PASS','certified_strict_upper_bound':str(x),
            'simple_exchange_strict_upper_bound':str(xs),
            'number_of_integer_cube_enclosures':len(data['radicals'])+1,
            'final_relative_gap_lower_decimal_floor':decimal_floor(lhs/H-1),
            'simple_exchange_gap_lower_decimal_floor':decimal_floor(simple_lhs-330),
            'stages':steps,
            'numerical_method':'integer cubes and exact rational inequalities',
            'proof_scope':'finite inequalities only; the degeneration and spectral implications are proved in the report'}

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('certificate',type=Path)
    ap.add_argument('--generate',action='store_true');a=ap.parse_args()
    if a.generate:a.certificate.write_text(json.dumps(make_certificate(),indent=2)+'\n')
    print(json.dumps(verify_certificate(json.loads(a.certificate.read_text())),indent=2))
