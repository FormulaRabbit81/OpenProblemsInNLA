"""Literal one-parameter composition of the two Fourier exchange maps.

A Laurent entry is stored as [integer coefficient, integer degree], or 0.
The verifier contracts every symmetric output coefficient exactly.  Fourier
character sums are used only after checking the literal row entries.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
from cw_exchange import character, no_zero_digits, verify_certificate


def create_composite(first: dict, second: dict) -> dict:
    if (first['n'], first['u'], second['n'], second['u']) != (3,8,4,18):
        raise ValueError('This composition is specified for (3,8),(4,18)')
    ns=329; rows=[]
    # Source: diagonal-64, diagonal-256, paired-CW8 (head then 8 large).
    def first_embed(row):
        ans=[0]*ns
        for j,c in enumerate(row['entries']):
            if c: ans[j if j<64 else j+256]=[c,7*row['degree']]
        return ans
    for row in first['rows'][:27]:
        rows.append({'kind':'P3','label':row['label'],'entries':first_embed(row)})
    mid=[first_embed(row) for row in first['rows'][27:]]
    for pos,row in enumerate(second['rows']):
        ans=[0]*ns; degree=row['degree']
        for j,c in enumerate(row['entries'][:256]):
            if c:ans[64+j]=[c,degree]
        for j,c in enumerate(row['entries'][256:]):
            if not c:continue
            for z,entry in enumerate(mid[j]):
                if entry:
                    if ans[z]:raise AssertionError('Unexpected entry collision')
                    ans[z]=[c*entry[0], degree+entry[1]]
        kind='P4' if pos<81 else 'head' if pos==81 else 'large'
        rows.append({'kind':kind,'label':row['label'],'entries':ans})
    return {'schema':'composed-symmetric-cw-exchange-v1',
            'source_dimension':329,'target_dimension':221,
            'source_diagonal_blocks':[64,256],'source_auxiliary_cw':8,
            'main_dimension':108,'target_cw':112,
            'first_parameter_power':7,'second_parameter_power':1,
            'source_head_index':320,'target_head_index':108,'rows':rows}


def verify_composite(data: dict, first: dict, second: dict) -> dict:
    if data.get('schema')!='composed-symmetric-cw-exchange-v1':
        raise AssertionError('Unknown composite schema')
    # Literal composition is checked separately from the tensor contraction.
    if data!=create_composite(first,second):
        raise AssertionError('Stored composite differs from the composed maps')
    rows=data['rows']; nt=221
    chars={r:{tuple(character(h,g) for g in range(r)):h for h in range(r)}
           for r in (64,256)}
    blocks=[]; aux=[]
    for row in rows:
        entries=row['entries']; current=[]
        for off,r in ((0,64),(64,256)):
            nonzero=[v for v in entries[off:off+r] if v]
            if not nonzero:
                current.append(None);continue
            exponents={v[1] for v in nonzero}
            if len(nonzero)!=r or len(exponents)!=1:
                raise AssertionError('A diagonal block is not a monomial character')
            amp=entries[off][0]
            if amp not in (-1,1):raise AssertionError('Unexpected character amplitude')
            literal=tuple(v[0]*amp for v in entries[off:off+r])
            if literal not in chars[r]:raise AssertionError('Not a literal character')
            current.append((chars[r][literal],amp,nonzero[0][1]))
        blocks.append(current)
        aux.append({j:tuple(v) for j,v in enumerate(entries[320:]) if v})
    def coeff(i,j,k):
        ans=defaultdict(int)
        for z in (0,1):
            a,b,c=blocks[i][z],blocks[j][z],blocks[k][z]
            if a is not None and b is not None and c is not None and a[0]^b[0]^c[0]==0:
                ans[a[2]+b[2]+c[2]]+=a[1]*b[1]*c[1]
        ai,aj,ak=aux[i],aux[j],aux[k]
        for a,b,c in ((ai,aj,ak),(aj,ai,ak),(ak,ai,aj)):
            if 0 not in a:continue
            ha,he=a[0]
            for p,(ba,be) in b.items():
                if p==0:continue
                ca,ce=c.get(1+((p-1)^1),(0,0))
                if ca:ans[he+be+ce]+=ha*ba*ca
        return {degree:value for degree,value in ans.items() if value}
    p3=[h for h in range(64) if no_zero_digits(h,3)]
    p4=[h for h in range(256) if no_zero_digits(h,4)]
    def target(i,j,k):
        if k<27:
            hs=[p3[z] for z in (i,j,k)];n=3
        elif i>=27 and k<108:
            hs=[p4[z-27] for z in (i,j,k)];n=4
        else:
            return int(i==108 and j>108 and ((j-109)^1)==k-109)
        return int(all({(h>>(2*z))&3 for h in hs}=={1,2,3} for z in range(n)))
    total=0;zero_nonzero=0;errors=Counter();negative_cancellations=0
    # Each triple is evaluated as a Laurent polynomial, not at sample points.
    for i in range(nt):
        for j in range(i,nt):
            for k in range(j,nt):
                polynomial=coeff(i,j,k)
                if any(z<0 for z in polynomial):
                    raise AssertionError(f'Uncancelled pole at {(i,j,k)}: {polynomial}')
                if polynomial.get(0,0)!=target(i,j,k):
                    raise AssertionError(f'Bad limiting coefficient {(i,j,k)}: {polynomial}')
                multiplicity=1 if i==k else 3 if i==j or j==k else 6
                total+=multiplicity
                if polynomial.get(0,0):zero_nonzero+=multiplicity
                for z in polynomial:
                    if z>0:errors[z]+=multiplicity
    for i in range(nt):
        for j in range(nt):
            want={0:1} if i>108 and j>108 and ((i-109)^1)==j-109 else {}
            if coeff(108,i,j)!=want:
                raise AssertionError('The composed head is not exactly isolated')
    # f - lambda^-2 A4_a4 + lambda^-16 A3_a3 = lambda^-16 e_auxhead.
    a3=1+4+16;a4=1+4+16+64
    r3=next(row for row in rows if row['kind']=='P3' and row['label']==a3)
    r4=next(row for row in rows if row['kind']=='P4' and row['label']==a4)
    for col in range(329):
        acc=defaultdict(int)
        for row,amp,shift in ((rows[108],1,0),(r4,-1,-2),(r3,1,-16)):
            v=row['entries'][col]
            if v:acc[v[1]+shift]+=amp*v[0]
        acc={e:c for e,c in acc.items() if c}
        want={-16:1} if col==320 else {}
        if acc!=want:raise AssertionError('Composed head/radical identity failed')
    # The contraction form is diagonal on the first 320 coordinates and
    # lambda^-16 times the nonsingular 8-by-8 hyperbolic block.  Its only
    # radical coordinate is the auxiliary head.
    f=rows[108]['entries']
    if not all(f[j] and f[j][0] in (-1,1) for j in range(320)):
        raise AssertionError('Missing diagonal contraction coefficient')
    if f[320]!=[1,-16] or any(f[321:]):
        raise AssertionError('Bad auxiliary contraction')
    if any(f[j][1]%2 for j in range(320)):
        raise AssertionError('Expected even Laurent exponents for split form')
    # Triangular Fourier blocks independently certify the active main rank.
    if len({blocks[i][0][0] for i in range(27)})!=27:
        raise AssertionError('P3 active-rank check failed')
    if any(blocks[i][1] is not None for i in range(27)):
        raise AssertionError('P3 rows unexpectedly meet the second diagonal')
    if len({blocks[i][1][0] for i in range(27,108)})!=81:
        raise AssertionError('P4 active-rank check failed')
    return {'status':'PASS','ordered_coefficients_checked':total,
            'nonzero_limit_coefficients':zero_nonzero,
            'positive_error_degrees':dict(sorted(errors.items())),
            'source_form_rank':328,'source_form_radical_dimension':1,
            'active_main_rank':108,'extracted_cw':112,
            'exact_head_isolation':'PASS','head_modulo_radical':'PASS',
            'split_form_even_exponents':'PASS',
            'literal_map_composition':'PASS'}

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('certificate_directory',type=Path)
    ap.add_argument('--generate',action='store_true');a=ap.parse_args()
    first=json.loads((a.certificate_directory/'exchange_n3_u8.json').read_text())
    second=json.loads((a.certificate_directory/'exchange_n4_u18.json').read_text())
    out=a.certificate_directory/'composed_exchange.json'
    if a.generate:out.write_text(json.dumps(create_composite(first,second),separators=(',',':'))+'\n')
    print(json.dumps(verify_composite(json.loads(out.read_text()),first,second),indent=2))
