"""Exact Fourier/CW exchange certificates. Python standard library only.

All tensor coefficients and Laurent-map entries are integers or Fractions.
The generator is not the verifier: verification recomputes contractions from
stored row maps and checks every output coefficient of nonpositive degree.
"""
from __future__ import annotations
from collections import Counter
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json


def character(h: int, g: int) -> int:
    return -1 if (h & g).bit_count() % 2 else 1


def no_zero_digits(h: int, n: int) -> bool:
    return all((h >> (2*j)) & 3 for j in range(n))


def pairs_in(labels: list[int], a: int) -> list[tuple[int,int]]:
    ss=set(labels)
    if any((h^a) not in ss or h==h^a for h in ss):
        raise ValueError('The matching must be a fixed-point-free involution')
    return [(h,h^a) for h in sorted(ss) if h < (h^a)]


def create_certificate(n: int, u: int) -> dict:
    if n<1 or u<2**n or u%2:
        raise ValueError('Require n>=1 and even u>=2**n')
    r=4**n; s=2**n
    main=[h for h in range(r) if no_zero_digits(h,n)]
    main_set=set(main)
    a=sum(1 << (2*j) for j in range(n))
    I=[h for h in main if (h^a) in main_set]
    R=[h for h in range(r) if h not in main_set and (h^a) not in main_set]
    ipairs=pairs_in(I,a); rpairs=pairs_in(R,a)
    assert len(I)==s
    assert len(R)==r-2*len(main)+s
    iorder=[h for pair in ipairs for h in pair]
    rorder=[h for pair in rpairs for h in pair]
    ipos={h:i for i,h in enumerate(iorder)}
    rows=[]
    # Source ordering: r diagonal coordinates; auxiliary head; u large coords.
    for h in main:
        vec=[character(h,g) for g in range(r)]+[0]*(u+1)
        if h in ipos:vec[r+1+ipos[h]]=1
        rows.append({'kind':'main','label':h,'degree':0,'entries':vec})
    head=[character(a,g) for g in range(r)]+[-1]+[0]*u
    rows.append({'kind':'head','label':a,'degree':-2,'entries':head})
    for h in rorder:
        vec=[character(h,g) for g in range(r)]+[0]*(u+1)
        rows.append({'kind':'large','label':h,'degree':1,'entries':vec})
    for j in range(s,u):
        # Minus sign from auxiliary-head map is removed by congruence on each
        # extra hyperbolic pair: diag(1,-1) (-J_2) diag(1,-1) = J_2.
        vec=[0]*(r+u+1)
        vec[r+1+j]=1 if j%2==0 else -1
        rows.append({'kind':'padding','label':j,'degree':1,'entries':vec})
    t=u+r-2*len(main)
    return {'schema':'symmetric-cw-exchange-v1','n':n,'u':u,'r':r,'s':s,
            'd':len(main),'t':t,'center':a,'source_dimension':r+u+1,
            'target_dimension':len(main)+t+1,'source_diagonal_coefficient':f'1/{r}',
            'source_auxiliary':'paired_cw','I_order':iorder,'R_order':rorder,
            'rows':rows}


def verify_certificate(data: dict) -> dict:
    """Verify stored maps, orthogonality, and all nonpositive coefficients.

    Character sums are evaluated from the stored diagonal entries, not assumed
    from a label: identify each stored row as an exact character or zero first,
    then check the full character table orthogonality.  Aux coefficients are
    independently contracted from the stored sparse auxiliary rows.
    """
    if data.get('schema')!='symmetric-cw-exchange-v1':
        raise ValueError('Unknown certificate schema')
    n,u,r,s,d,t=[data[k] for k in ('n','u','r','s','d','t')]
    if not (n>=1 and u>=2**n and u%2==0 and r==4**n and s==2**n
            and d==3**n and t==u+r-2*d and t>=0):
        raise AssertionError('Bad parameters')
    rows=data['rows']; ns=r+u+1; nt=d+t+1
    if len(rows)!=nt or data['source_dimension']!=ns or data['target_dimension']!=nt:
        raise AssertionError('Bad dimensions')
    if F(data['source_diagonal_coefficient'])!=F(1,r):
        raise AssertionError('Bad diagonal coefficient')
    chars=[[character(h,g) for g in range(r)] for h in range(r)]
    # Orthogonality suffices with the separately tested character product law.
    # Full Gram check is exact and costs O(r^3), only r=64 or r=256 here.
    for h in range(r):
        for k in range(h,r):
            if sum(x*y for x,y in zip(chars[h],chars[k])) != (r if h==k else 0):
                raise AssertionError('Character orthogonality failed')
    for h in range(r):
        for k in range(r):
            # Test on generators of the character group; all columns follow by
            # multiplicativity, whose explicit character formula is also used.
            for bit in range(2*n):
                g=1<<bit
                if chars[h][g]*chars[k][g]!=chars[h^k][g]:
                    raise AssertionError('Character product law failed')
    cindex={tuple(row):h for h,row in enumerate(chars)}
    diaglabels=[]; aux=[]; degrees=[]
    for i,row in enumerate(rows):
        v=row['entries']
        if len(v)!=ns or any(type(x) is not int for x in v):
            raise AssertionError('Bad map entries')
        h=cindex.get(tuple(v[:r]))
        if h is None and any(v[:r]):
            raise AssertionError('Non-character diagonal row')
        diaglabels.append(h)
        aux.append({j:x for j,x in enumerate(v[r:]) if x})
        degree=row['degree']
        if type(degree) is not int:
            raise AssertionError('Nonintegral Laurent degree')
        degrees.append(degree)
    # Check declared ordering against literal tensor definitions, not generator.
    wanted_main=[h for h in range(r) if no_zero_digits(h,n)]
    if [row['label'] for row in rows[:d]]!=wanted_main:
        raise AssertionError('Main labels differ from P tensor product basis')
    if any(row['kind']!='main' or row['degree']!=0 for row in rows[:d]):
        raise AssertionError('Bad main row type')
    if rows[d]['kind']!='head' or degrees[d]!=-2:
        raise AssertionError('Bad head row')
    if any(deg!=1 for deg in degrees[d+1:]):
        raise AssertionError('Bad large row degree')
    # Source paired-CW tensor has terms (head,j,j^1) in all three positions.
    # Contract an arbitrary triple of sparse auxiliary rows literally.
    def aux_coeff(i: int,j: int,k: int) -> int:
        ai,aj,ak=aux[i],aux[j],aux[k]
        ans=0
        for x,y,z in ((ai,aj,ak),(aj,ai,ak),(ak,ai,aj)):
            h=x.get(0,0)
            if h:
                ans += h*sum(c*y.get(1+((p-1)^1),0)
                             for p,c in z.items() if p>0)
        return ans
    def coeff(i: int,j: int,k: int) -> int:
        hs=(diaglabels[i],diaglabels[j],diaglabels[k])
        val=int(None not in hs and hs[0]^hs[1]^hs[2]==0)
        return val+aux_coeff(i,j,k)
    def target(i: int,j: int,k: int) -> int:
        if i<d and j<d and k<d:
            # Each 2-bit coordinate must contain the three different labels.
            h1,h2,h3=(wanted_main[i],wanted_main[j],wanted_main[k])
            return int(all({(h1>>(2*z))&3,(h2>>(2*z))&3,(h3>>(2*z))&3}
                           =={1,2,3} for z in range(n)))
        trip=(i,j,k)
        if trip.count(d)==1 and all(z>=d for z in trip):
            large=[z-d-1 for z in trip if z!=d]
            if len(large)==2 and large[0]>=0 and large[1]>=0:
                return int((large[0]^1)==large[1])
        return 0
    count=Counter(); nonzero=Counter()
    # Tensor is symmetric, so checking sorted triples and multiplicities checks
    # every ordered output coefficient, with no random sampling.
    for i in range(nt):
        for j in range(i,nt):
            for k in range(j,nt):
                deg=degrees[i]+degrees[j]+degrees[k]
                if deg>0:continue
                multiplicity=1 if i==k else 3 if (i==j or j==k) else 6
                val=coeff(i,j,k)
                want=target(i,j,k) if deg==0 else 0
                if val!=want:
                    raise AssertionError(f'Coefficient mismatch at {(i,j,k)}: degree {deg}, {val}!={want}')
                count[deg]+=multiplicity
                if val:nonzero[deg]+=multiplicity
    # Full head isolation is stronger than merely taking a limit: verify all
    # contractions with head, including all positive-degree positions if any.
    for i in range(nt):
        for j in range(nt):
            want=int(i>d and j>d and ((i-d-1)^1)==(j-d-1))
            if coeff(d,i,j)!=want:
                raise AssertionError('Head isolation failed')
    a=data['center']
    apos=wanted_main.index(a)
    # f - A_a is supported only on source auxiliary head before row scaling.
    delta=[x-y for x,y in zip(rows[d]['entries'],rows[apos]['entries'])]
    if delta!=[0]*r+[-1]+[0]*u:
        raise AssertionError('Head/radical relation failed')
    return {'n':n,'u':u,'target_cw':t,'source_dimension':ns,'target_dimension':nt,
            'all_nonpositive_ordered_coefficients_checked':sum(count.values()),
            'counts_by_degree':dict(sorted(count.items())),
            'nonzero_counts_by_degree':dict(sorted(nonzero.items())),
            'head_isolation':'PASS','head_radical_relation':'PASS',
            'full_character_gram':'PASS','status':'PASS'}


def write_certificate(n:int,u:int,path:Path)->None:
    path.write_text(json.dumps(create_certificate(n,u),separators=(',',':'))+'\n')

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('certificate',type=Path)
    args=ap.parse_args()
    print(json.dumps(verify_certificate(json.loads(args.certificate.read_text())),indent=2))
