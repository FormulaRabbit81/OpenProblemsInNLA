"""Small exact checks supporting the general algebraic proofs in the report.

These finite tests are not substitutes for the all-parameter proofs.
"""
from __future__ import annotations
from collections import Counter
from fractions import Fraction as F
from itertools import product, combinations
from math import prod
import json


def rank(a):
    a=[[F(x) for x in row] for row in a]
    if not a:return 0
    m,n=len(a),len(a[0]);r=0
    for j in range(n):
        pivot=next((i for i in range(r,m) if a[i][j]),None)
        if pivot is None:continue
        a[r],a[pivot]=a[pivot],a[r]
        z=a[r][j];a[r]=[v/z for v in a[r]]
        for i in range(r+1,m):
            if a[i][j]:
                z=a[i][j];a[i]=[u-z*v for u,v in zip(a[i],a[r])]
        r+=1
        if r==m:break
    return r


def matmul(a,b):
    return [[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]


def kron(a,b):
    return [[x*y for x in ra for y in rb] for ra in a for rb in b]


def power(a,n):
    ans=[[1]]
    for _ in range(n):ans=kron(ans,a)
    return ans


def check_border_cw(q=8):
    # epsilon^-2 [ sum_i (h+epsilon e_i)^3
    #              -(h+epsilon sum_i e_i)^3 -(q-1)h^3 ].
    vectors=[]
    for i in range(q):vectors.append([1]+[int(i==j) for j in range(q)])
    vectors.append([1]*(q+1));vectors.append([1]+[0]*q)
    weights=[1]*q+[-1,-(q-1)]
    tested=0
    for i,j,k in product(range(q+1),repeat=3):
        degree=(i>0)+(j>0)+(k>0)-2
        coeff=sum(w*v[i]*v[j]*v[k] for w,v in zip(weights,vectors))
        expected=0
        if degree==0:
            large=[z for z in (i,j,k) if z>0]
            expected=int(large[0]==large[1])-1
        if degree<=0 and coeff!=expected:
            raise AssertionError('Border-CW polynomial identity failed')
        tested+=1
    G=[[int(i==j)-1 for j in range(q)] for i in range(q)]
    if rank(G)!=q:raise AssertionError('The limiting quadratic form is singular')
    return {'q':q,'rank_one_terms':len(vectors),'ordered_coefficients_checked':tested,
            'limiting_form':'I-J','limiting_form_rank':q,
            'conclusion':'Over C this form is congruent to paired CW_q; border rank <= q+2',
            'status':'PASS'}


def check_simplex_minrank():
    cases=[]
    for d in range(2,7):
        m=d-1
        W=[[int(i==j) for j in range(d)]+[1] for i in range(d)]
        L=[[0]*d for _ in range(m)];R=[[0]*d for _ in range(m)]
        for j in range(1,d-1):L[j-1][j]=R[j-1][j]=1
        for i in range(m):
            L[i][d-1]=R[i][0]=1 if i==m-1 else -1
        LW,RW=matmul(L,W),matmul(R,W)
        K=list(range(1,d-1))+[d]
        for j in range(d+1):
            outer=[[LW[a][j]*RW[b][j] for b in range(m)] for a in range(m)]
            expected=[[int(j in K and a==b==K.index(j)) for b in range(m)] for a in range(m)]
            if outer!=expected:raise AssertionError('Symbolic coefficient-compression witness failed')
        cases.append({'d':d,'kept_columns':K,'base_symbolic_compression':'PASS'})
    # A fully correlated coefficient vector is checked, not a product vector.
    d=3;n=3;m=2
    W=[[1,0,0,1],[0,1,0,1],[0,0,1,1]]
    L=[[0,1,-1],[0,0,1]];R=[[-1,1,0],[1,0,0]]
    WW=power(W,n);LL=power(L,n);RR=power(R,n)
    coefficients=[((-1)**(z.bit_count()))*(1+(z*z+3*z)%17) for z in range(4**n)]
    coefficient_flattening_rank=rank([coefficients[16*i:16*(i+1)] for i in range(4)])
    if coefficient_flattening_rank<=1:
        raise AssertionError('The correlated test coefficient array is unexpectedly a product')
    M=[[sum(WW[i][z]*coefficients[z]*WW[j][z] for z in range(4**n))
        for j in range(3**n)] for i in range(3**n)]
    C=matmul(matmul(LL,M),list(map(list,zip(*RR))))
    selected=[sum(a*4**(n-1-j) for j,a in enumerate(alpha)) for alpha in product((1,3),repeat=n)]
    expected=[[coefficients[selected[i]] if i==j else 0 for j in range(2**n)] for i in range(2**n)]
    if C!=expected or rank(C)!=2**n:raise AssertionError('Correlated coefficient compression failed')
    upper=[[F(int(i==j))-F(1,d) for j in range(d)] for i in range(d)]
    upper_power=power(upper,n)
    if rank(upper_power)!=(d-1)**n:raise AssertionError('Matching minrank upper witness failed')
    H=[[1,-1,1,-1],[1,1,-1,-1],[1,-1,-1,1]]
    full_spark_ranks=[rank([[row[j] for j in columns] for row in H])
                      for columns in combinations(range(4),3)]
    if full_spark_ranks!=[3]*4:
        raise AssertionError('The prior Hadamard frame is not full spark')
    return {'status':'PASS','base_dimensions':cases,
            'correlated_case':{'d':d,'n':n,'coefficient_count':len(coefficients),
                               'extracted_diagonal_rank':rank(C),
                               'coefficient_mode_flattening_rank':coefficient_flattening_rank},
            'hadamard_three_column_ranks':full_spark_ranks,
            'matching_upper_witness_rank':rank(upper_power),
            'scope':'The general theorem, including arbitrary n and coefficients, is proved in the report.'}


def check_active_pairing():
    from graph_retention import edges
    cases=[]
    for d in (1,2,3):
        for t in (4,8):
            for k in (1,t//2):
                D=2*d+t
                def pairing(i,second=False):
                    if i<d:return d+i
                    if i<2*d:return i-d
                    return 2*d+((i-2*d)^(2 if second else 1))
                A=range(d);C=range(2*d,D)
                W=set(product(A,A))|set(product(A,C))|set(product(C,A))
                W|={(2*d+i,2*d+j) for i,j in edges(t,k)}
                partner={(pairing(i),pairing(j,True)) for i,j in W}
                dn=d*d+2*d*t+t*k;tn=t*t+2*d*d-2*t*k
                if len(W)!=dn or W&partner:raise AssertionError('New main space not isotropic')
                leftover=set(product(range(D),repeat=2))-W-partner
                if len(leftover)!=tn:raise AssertionError('Residual CW dimension incorrect')
                if {(pairing(i),pairing(j,True)) for i,j in leftover}!=leftover:
                    raise AssertionError('The residual pairing is not perfect')
                if (0,0) not in W:raise AssertionError('The head class was not retained')
                cases.append({'d':d,'t':t,'k':k,'new_active_dimension':dn,'new_cw':tn})
    return {'status':'PASS','canonical_pairing_cases':cases,
            'scope':'Finite canonical-space tests supplement the general rank and degeneration proof.'}


def verify_all():
    return {'status':'PASS','cw8_border_identity':check_border_cw(),
            'coefficient_minrank':check_simplex_minrank(),
            'active_space_recursion':check_active_pairing()}

if __name__=='__main__':print(json.dumps(verify_all(),indent=2))
