"""Exact finite checks for the regular isotropic graph retention construction."""
from __future__ import annotations
from collections import Counter
from itertools import permutations, product
from pathlib import Path
import json


def group_add(i:int,j:int,t:int)->int:
    return 4*((i//4+j//4)%(t//4))+((i%4)^(j%4))


def edges(t:int,k:int)->list[tuple[int,int]]:
    if t%4 or t<4 or not 1<=k<=t//2:raise ValueError('Require 4|t, 1<=k<=t/2')
    K=[4*(q//2)+(q%2) for q in range(k)]
    return [(i,group_add(i,h,t)) for i in range(t) for h in K]


def check_graph(t:int,k:int,check_tensor:bool=True)->dict:
    E=edges(t,k);es=set(E)
    if len(es)!=t*k:raise AssertionError('Edges are not distinct')
    if Counter(i for i,j in E)!=Counter({i:k for i in range(t)}):
        raise AssertionError('Left degrees are not k')
    if Counter(j for i,j in E)!=Counter({j:k for j in range(t)}):
        raise AssertionError('Right degrees are not k')
    if any((i^1,j^2) in es for i,j in E):
        raise AssertionError('The selected VV coordinate space is not isotropic')
    weights={('A',i):3*i+1 for i in range(t)}
    weights.update({('B',j):3*t*(j+1)+1 for j in range(t)})
    weights.update({('C',i,j):3*(-1-i-t*(j+1))+1 for i,j in E})
    if len(set(weights.values()))!=len(weights):
        raise AssertionError('Tight weights are not injective')
    support={triple for i,j in E for triple in permutations((('A',i),('B',j),('C',i,j)))}
    if len(support)!=6*t*k:raise AssertionError('Unexpected graph support size')
    for triple in support:
        if sum(weights[v] for v in triple)!=0:raise AssertionError('Support is not tight')
    marginals=[Counter(triple[z] for triple in support) for z in range(3)]
    if not marginals[0]==marginals[1]==marginals[2]:raise AssertionError('Marginals differ')
    for v,count in marginals[0].items():
        expected=2 if v[0]=='C' else 2*k
        if count!=expected:raise AssertionError('Wrong uniform-support marginal')
    if check_tensor:
        # Literal paired CW tensors; -1 denotes their head coordinate.
        def cw_terms(flip):
            out=[]
            for j in range(t):
                p=j^flip
                out.extend([(-1,j,p),(j,-1,p),(j,p,-1)])
            return out
        observed=Counter()
        def retained_coordinate(i,j):
            if i==-1 and j==-1:return None
            if j==-1:return ('A',i^1)
            if i==-1:return ('B',j^2)
            return ('C',i,j) if (i,j) in es else None
        for x,y in product(cw_terms(1),cw_terms(2)):
            triple=tuple(retained_coordinate(i,j) for i,j in zip(x,y))
            if None not in triple:observed[triple]+=1
        if observed!=Counter({triple:1 for triple in support}):
            raise AssertionError('Restricted CW-square is not the claimed graph tensor')
    return {'t':t,'k':k,'edges':len(E),'retained_ordered_tensor_terms':len(support),
            'regularity':'PASS','isotropic_coordinate_pairing':'PASS',
            'integer_tight_weights':'PASS','uniform_marginals':'PASS',
            'literal_cw_square_restriction':'PASS' if check_tensor else 'not requested'}


def verify_graph_family(choices:list[int],states:list[dict])->dict:
    # The first graph is enumerated in full.  Later graphs have enormous size;
    # the report proves the group recipe for every permitted t,k. Here their
    # integer preconditions and all low-bit cases of its algebra are checked.
    first=check_graph(states[0]['cw_size'],choices[0])
    parameters=[]
    for j,k in enumerate(choices):
        t=states[j]['cw_size']
        if type(t) is not int or type(k) is not int or t%4 or not 1<=k<=t//2:
            raise AssertionError('A family member violates the proven hypotheses')
        for bi in range(4):
            for bj in range(4):
                if ((bi^1)^(bj^2)) != ((bi^bj)^3):
                    raise AssertionError('The edge matching does not flip the offset by 3')
        if any((b^3) in (0,1) for b in (0,1)):
            raise AssertionError('The allowed offset residues meet their partners')
        parameters.append({'stage':j,'t':t,'k':k,'edge_count':t*k,
                           'hypotheses_and_low_bit_identity':'PASS',
                           'enumerated':j==0})
    small_checks=0
    for t in (4,8,12,16,20):
        for k in range(1,t//2+1):
            check_graph(t,k)
            small_checks+=1
    return {'status':'PASS','first_graph_complete_check':first,
            'additional_small_graph_complete_checks':small_checks,
            'family_parameters':parameters,
            'scope':'Later graphs use the general proof in the report; they are not enumerated.'}

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('bound_certificate',type=Path);a=ap.parse_args()
    data=json.loads(a.bound_certificate.read_text())
    print(json.dumps(verify_graph_family(data['choices'],data['states']),indent=2))
