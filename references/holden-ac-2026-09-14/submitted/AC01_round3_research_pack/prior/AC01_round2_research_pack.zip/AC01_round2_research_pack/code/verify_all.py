#!/usr/bin/env python3
"""Run every exact finite certificate check in the AC-01 round-two pack.

Usage: python3 code/verify_all.py --output results/verification_rerun.json
Only Python's standard library is required. A failure gives a nonzero exit.
"""
from __future__ import annotations
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import argparse
import json
import platform
import time
from cw_exchange import verify_certificate as verify_seed
from compose_exchange import verify_composite
from exact_bounds import verify_certificate as verify_bound
from graph_retention import verify_graph_family
from structural_checks import verify_all as verify_structural

ROOT=Path(__file__).resolve().parents[1]


def rejected(name,fn):
    try:fn()
    except (AssertionError,ValueError,KeyError,TypeError) as exc:
        return {'test':name,'result':'REJECTED AS REQUIRED','reason':str(exc)}
    raise AssertionError(f'Corrupted input was accepted: {name}')


def run()->dict:
    start=time.perf_counter();folder=ROOT/'certificates'
    load=lambda name:json.loads((folder/name).read_text())
    first=load('exchange_n3_u8.json');second=load('exchange_n4_u18.json')
    composite=load('composed_exchange.json');bound=load('spectral_bound.json')
    result={'started_utc':datetime.now(timezone.utc).isoformat(),
            'python_version':platform.python_version(),
            'certificate_sha256':{p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(folder.glob('*.json'))}}
    result['seed_exchanges']=[verify_seed(first),verify_seed(second)]
    result['composed_exchange']=verify_composite(composite,first,second)
    result['graph_retention']=verify_graph_family(bound['choices'],bound['states'])
    result['structural_checks']=verify_structural()
    result['spectral_bound']=verify_bound(bound)
    bad_seed=deepcopy(first);bad_seed['rows'][0]['entries'][0]*=-1
    bad_degree=deepcopy(first);bad_degree['rows'][27]['degree']=-3
    bad_comp=deepcopy(composite);bad_comp['rows'][108]['entries'][0][0]*=-1
    bad_radical=deepcopy(bound);bad_radical['radicals']['cw_3']['floor_numerator']+=1
    bad_upper=deepcopy(bound);bad_upper['upper_bound']='387/100'
    bad_graph=deepcopy(bound);bad_graph['choices'][0]=57
    result['adversarial_tests']=[
        rejected('seed map entry sign',lambda:verify_seed(bad_seed)),
        rejected('seed head Laurent degree',lambda:verify_seed(bad_degree)),
        rejected('composed head entry',lambda:verify_composite(bad_comp,first,second)),
        rejected('cube-root enclosure numerator',lambda:verify_bound(bad_radical)),
        rejected('unsupported claimed upper bound 3.87',lambda:verify_bound(bad_upper)),
        rejected('nonisotropic-family graph parameter k>t/2',lambda:verify_graph_family(bad_graph['choices'],bad_graph['states']))]
    result['status']='ALL CHECKS PASSED'
    result['verification_elapsed_seconds']=round(time.perf_counter()-start,6)
    result['scope_note']=('This run verifies finite identities, finite graph instances, integer parameter hypotheses, and exact rational inequalities. '
                          'It does not formalize Strassen duality, the tight-support theorem, the general extraction proof, or AC-01.')
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path)
    args=ap.parse_args();result=run()
    if args.output:
        out=args.output if args.output.is_absolute() else Path.cwd()/args.output
        out.parent.mkdir(parents=True,exist_ok=True)
        out.write_text(json.dumps(result,indent=2)+'\n')
    print(result['status'])
    print('Strict CW2 bound:',result['spectral_bound']['certified_strict_upper_bound'])
    print('Composite ordered coefficients checked:',result['composed_exchange']['ordered_coefficients_checked'])
    print('First graph ordered terms checked:',result['graph_retention']['first_graph_complete_check']['retained_ordered_tensor_terms'])
    print('Adversarial tests rejected:',len(result['adversarial_tests']))
    print('Verification elapsed seconds:',result['verification_elapsed_seconds'])
    print(result['scope_note'])
