# Primary sources and mathematical dependencies

`sources.json` records the sources, exact locations used, and access limitations. The report's bibliography contains the corresponding citations and links.

The two structural inputs used for the derived bound are Strassen's spectral duality and his entropy theorem for tight three-tensor supports. They are explicitly stated in report Section 2. The entropy result supplies a lower bound on asymptotic subrank, not a rank upper bound. The report proves the special degenerations and extraction mechanism it needs.

The cited August 2026 matrix-multiplication bound is context, not an ingredient in the new tensor bound. Likewise, the implication `AR(cw2)=3 => omega=2` identifies the sufficient goal; the present result does not establish its hypothesis.

The bibliography identifies the original Strassen theorem through the checked Christandl–Vrana–Zuiddam restatement. It does not imply a new independent proof or a separate inspection of the 1991 original article.

The prior report is working material supplied in this conversation and retained in the package. Its code's successful rerun is evidence for those finite checks, not independent publication or formal proof verification.
