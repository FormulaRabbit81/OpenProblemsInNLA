# The unresolved exponent-two step

## Precise target

For the 2-by-2 matrix multiplication tensor `M_2`, prove

```
R(M_2^(tensor n)) = 4^n exp(o(n)).
```

Equivalently, prove `AR(M_2)=4`. The report gives the standard connection to arithmetic straight-line complexity and `omega=2`. No family with this rank growth is constructed here.

An alternative sufficient target, used to motivate the current work, is

```
AR(cw_2) = 3.
```

The established literature gives this as a sufficient condition for `omega=2`; the package does not assert that it is a necessary condition. The newly derived upper bound is `3.878657073`, so the sufficient target has not been reached.

## What changed from the previous pack

The earlier calculation extracted a single matrix slice. The new exchange retains an entire coupled CW tensor: its three head placements share coordinates. This changes the degeneration data and exits the restricted scalar recurrence for which the previous pack gave a barrier.

The next squaring step also retains a regular-graph tensor from the square of the coupled auxiliary part. Its tight support gives a spectral lower bound. Actual coordinates that become radical for the chosen contraction are retained; they are not declared redundant in the tensor itself.

## Concrete next mathematical targets, not proved here

A stronger relative restriction result for the graph tensor would be useful if it retained meaningful tensor value beyond the diagonal subrank furnished by the entropy estimate. Such a result would need actual restriction or degeneration maps, or a valid theorem applying to every spectral point. A numerical hypothesis about a graph tensor's value is not enough.

Another possible target is a new source family with decompositions whose asymptotic overhead is controlled on the scale of the extracted saving. A strict finite speedup does not supply that control. A theorem must quantify how the decomposition overhead, extracted auxiliary value, and tensor-power normalization interact.

A direct near-dimension-rank family for powers of `M_2` would bypass the CW route. This is an alternative research target, not a reduction proved by the present graph construction.

## Invalid shortcuts to avoid

The tight-support entropy theorem determines asymptotic subrank information, not asymptotic rank. It cannot be used to replace a rank upper bound by an entropy value.

A proof that each finite construction has a strict improvement does not show that repeated improvements converge to three. Their sizes can shrink too quickly with the starting power, and subexponential decomposition overhead can still dominate the extracted saving.

The previous scalar-relaxation barrier is not a lower bound on actual tensor rank. The new simplex minrank theorem is likewise a statement about a fixed product frame with all coefficient entries nonzero, not a universal obstruction.

A finite verification of all explicitly stored maps does not verify the later enormous maps, the general extraction theorem, or Strassen's external results. Their mathematical arguments have to be reviewed separately.

No percentage of progress to a full proof is assigned. A smaller numerical upper bound does not measure the probability of resolving the remaining structural question.
