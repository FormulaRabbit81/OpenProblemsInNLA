# Claim and dependency audit

The claims below concern the mathematical derivation in this package. They are not a claim of independent review or formal verification.

| Claim | Proof or certificate | What is not being claimed |
|---|---|---|
| The two Fourier seed exchanges are valid degenerations. | Report Section 3; literal rational matrices; complete nonpositive-coefficient checks. | A finite test alone proves the whole all-parameter exchange theorem. |
| The seeds compose to `P^3 + P^4 + C112 <=deg D320 + C8`. | Report Section 4; the explicit 221-by-329 map; every ordered Laurent coefficient checked through symmetry; exact head and radical identities. | The source may be replaced by a diagonal tensor before checking the contraction geometry. |
| `AR(cw2) < 3.883733322`. | The preceding composite; `phi(C8) <= 10`; tight-support lower bound on `C112`; spectral duality; strict rational inequality. | This already proves any bound below the existing record on the matrix multiplication exponent. |
| The symmetric extraction lemma is valid. | Report Section 5: the main space is isotropic, the head class is in it modulo the radical, and the complementary large form is paired. Every negative parameter degree is accounted for. | Isotropy alone, without the head-class condition, suffices. |
| Regular graphs can be retained in a CW square. | Report Section 6: explicit group construction, isotropic-coordinate proof, and literal restriction; complete first-graph and small-instance checks. | The later giant graphs were enumerated. |
| The enriched squaring theorem iterates. | Report Section 7: active quotient pairing basis, exact main active span, paired-coordinate complement, and separated parameters. | Actual main coordinates may be replaced by their smaller active quotient dimension. |
| `AR(cw2) < 3.878657073`. | Three specified graph degrees, the squaring theorem, entropy lower bounds, and exact integer-cube/Fraction certificate. | The displayed constant is optimal, the exact rank value, or a proved limiting value for all possible recurrences. |
| Product-simplex full-support coefficient minrank is `(d-1)^n`. | Report Section 9: exact left/right compression for all correlated coefficients, plus matching upper witness. | A lower bound on the rank of `P^n`, or a barrier covering other decompositions. |
| The old pack still passes its checks. | `prior/round1_verification_rerun.json`; original ZIP retained. | An independent formal audit of the old pack's entire proof. |
| AC-01 is solved. | **No proof in this package.** | Neither `omega=2` nor a strict lower bound `omega>2` is established. |

## Highest-priority independent review points

The general enriched squaring proof is the most important non-computational review target. In particular, check that all retained old-head rows lie in the stated active span, that their actual coordinates are nevertheless retained, and that the new head remains in the main span modulo the new contraction radical. The scalar endpoint certificate is simple once those structural conditions are established.

The smaller `3.883733322` result is an independent review checkpoint. It does not use the enriched squaring theorem and can be audited from the two explicit maps, their composite, and the stated external spectral/subrank inputs.

The external tight-support theorem supplies a lower bound on asymptotic **subrank**, which in turn lower-bounds every spectral point. It is not a formula for asymptotic **rank**. The distinction is essential: conflating them would manufacture the missing exponent-two step.
