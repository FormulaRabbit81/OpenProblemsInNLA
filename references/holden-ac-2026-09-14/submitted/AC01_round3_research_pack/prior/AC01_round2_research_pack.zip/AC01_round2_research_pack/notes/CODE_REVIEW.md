# Scope of the exact code

`verify_all.py` is the entry point. It reads the four supplied JSON certificates and invokes the exact checks. Acceptance conditions use integer arithmetic or `fractions.Fraction`; there is no floating-point tolerance.

`cw_exchange.py` checks the literal seed row data and contracts every nonpositive-degree symmetric output coefficient. The source is symmetric and the same row map is used in all modes; symmetry therefore converts these tests into coverage of the reported ordered coefficients. Positive-degree blocks vanish in the limit, by the finite Laurent-degree description.

`compose_exchange.py` first checks the stored composite against literal composition of the two seeds. It then verifies that each diagonal-block row is exactly a signed Fourier character with one Laurent degree. Character orthogonality is used only after this literal check. The auxiliary contractions are evaluated directly, and every symmetric output triple is inspected as a Laurent polynomial. This covers all 221^3 ordered coefficients, not random input evaluations. Head contractions are checked exactly, including positive-degree terms, so isolation is a statement about the full rational tensor rather than just its limit.

`graph_retention.py` constructs and checks the first graph literally, together with thirty small cases. It checks the group recipe for the later integer parameters without enumerating their edges. `structural_checks.py` supplies small exact tests of the general pairing geometry, the CW8 border identity, and the minrank witnesses. Its correlated coefficient sample has matrix-flattening rank greater than one and is not a product coefficient array.

`exact_bounds.py` checks every integer cube enclosure and evaluates the scalar recurrence with rational lower endpoints. Its final acceptance includes the displayed strict margin. Decimal floors are only human-readable output. No numerical optimizer result enters the proof.

Six adversarial checks alter data or ask for an unsupported claim and must fail. They are useful tests of the validators, not an exhaustive security audit.

The exact suite is reproducible evidence for its finite claims. The mathematical proof still depends on the all-parameter extraction argument and the two stated external spectral/subrank results. None of these is replaced by the success message.
