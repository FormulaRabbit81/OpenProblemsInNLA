#!/usr/bin/env bash
set -euo pipefail
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
command -v pdflatex >/dev/null 2>&1 || {
  printf '%s\n' 'pdflatex is required to rebuild the report.' >&2
  exit 1
}
cd "$ROOT/report"
pdflatex -interaction=nonstopmode -halt-on-error AC01_round2_report.tex
pdflatex -interaction=nonstopmode -halt-on-error AC01_round2_report.tex
printf '\nReport written to %s\n' "$ROOT/report/AC01_round2_report.pdf"
