# AC-01: symmetric residual extraction

**Status: a research derivation of partial results; AC-01 is not resolved.**

The main report derives

\[
\widetilde R(\mathrm{cw}_2)<3.878657073
\]

over the complex numbers. It supplies explicit rational degenerations, an all-parameter algebraic extraction proof, and exact finite certificates. It does not prove that the matrix-multiplication exponent is two, disprove that equality, or improve the currently reported upper bound on that exponent.

The result has not been independently peer reviewed or formalized in a proof assistant. No priority claim is made. The exact code verifies finite identities and inequalities, not the entire mathematical proof.

## Read first

`report/AC01_round2_report.pdf` is the self-contained mathematical report. The editable source is `report/AC01_round2_report.tex`. The main theorem is on the first page; the precise missing implication for AC-01 is in Section 10.

The previous report and certificates are retained in `prior/AC01_round1_research_pack.zip`. A successful fresh run of that pack's original verifier is in `prior/round1_verification_rerun.json`. The new construction changes the auxiliary tensor, rather than repeating the one-slice recurrence bounded in the previous report.

## What is established in the report

The paired tensor `C_q` is a rational symmetric presentation of the small Coppersmith–Winograd tensor `cw_q`, isomorphic to it over the complex numbers. `P` is the six-permutation tensor, a relabelling of `C_2`. The symbol `T <=deg S` below means that `T` is a degeneration of `S`.

The first result is an explicit family of exchanges. For `n >= 2`, even `u >= 2^n`, and `t = u + 4^n - 2*3^n`,

```
P^(tensor n) direct-sum C_t
    <=deg diagonal_(4^n) direct-sum C_u.
```

The two stored instances compose to give

```
P^(tensor 3) direct-sum P^(tensor 4) direct-sum C_112
    <=deg diagonal_320 direct-sum C_8.
```

The composite is represented by a literal 221-by-329 Laurent-monomial row map applied identically in the three modes. Its coefficients and exact head-isolation identities are checked. Spectral duality, a tight-support entropy lower bound, and the elementary border-rank bound for `C_8` yield the independent conclusion

```
asymptotic_rank(P) < 3.883733322.
```

The second result is an enriched symmetric squaring construction. It retains an explicitly defined regular-graph tensor from the square of the coupled residual. Three specified parameter choices yield the stronger displayed bound `3.878657073`. The report carefully distinguishes actual coordinate dimension from dimension modulo the radical of a contraction form. Later huge tensors and maps are covered by the general proof; they were not materialized or exhaustively enumerated.

A separate theorem proves the exact full-support coefficient minrank of the tensor-product simplex frame:

```
min rank(W^(tensor n) diag(c) (W^(tensor n))^T) = (d-1)^n,
W = [I_d | ones], every c_alpha nonzero.
```

The coefficients may be arbitrarily correlated. This limits a particular fixed-frame contraction search, not the rank of the original tensor and not every possible decomposition.

## Run the exact verification

Requirements: **Python 3.10 or later**, standard library only. No network, numerical package, proprietary software, or external solver is required.

From this directory:

```bash
python3 code/verify_all.py --output results/verification_rerun.json
```

The recorded run in `results/verification.log` completed with `ALL CHECKS PASSED`. The unified JSON result is `results/verification.json`.

The checks cover the two seeds, every ordered coefficient of the composed Laurent tensor (using symmetry and checked Fourier character identities), exact head isolation and the initial radical relation, the CW8 border identity, the first retained graph and thirty small graph cases, twelve canonical active-pairing cases, the minrank witnesses, and exact integer-cube/rational inequalities. Six deliberately corrupted inputs are rejected.

The certificate for the stronger bound uses `x = 3878657073/1000000000`. Its radical enclosures have denominator `10^40` and are checked by cubing integers. The final strict inequality is stronger than

```
certified_lower_left_side > 330^8 * (1 + 10^(-9)).
```

There is no floating-point tolerance in any acceptance condition. A decimal display is not substituted for a rational comparison.

### Individual checks

```bash
python3 code/cw_exchange.py certificates/exchange_n3_u8.json
python3 code/cw_exchange.py certificates/exchange_n4_u18.json
python3 code/compose_exchange.py certificates
python3 code/exact_bounds.py certificates/spectral_bound.json
python3 code/graph_retention.py
python3 code/structural_checks.py
```

The main suite locates the certificate directory relative to its own file, so it also works when invoked by an absolute path from another working directory.

## Verification boundaries

The finite checks do **not** formally verify Strassen's spectral duality, his tight-support theorem, or the general extraction proof. The external results are stated and cited in the report. The algebraic construction is proved for all stated parameters in the report and supplemented by finite checks.

The two later graph edge counts are `350171648` and `4891038542216985600`. The checker verifies their integer hypotheses and the finite low-bit identities behind the graph recipe; it does not enumerate those graphs. Likewise, it does not store the full later-stage degeneration matrices.

The number `3.878657073` is an **upper bound** on a related tensor's asymptotic rank, not its computed exact value. The coefficient-minrank theorem and the previous recurrence limitation are **not** lower bounds on that tensor's asymptotic rank.

## What remains for AC-01

Let `M_2` be the tensor of 2-by-2 matrix multiplication. The required rank statement is

\[
R(M_2^{\otimes n})=4^n\exp(o(n)).
\]

The report explains its equivalence with `omega = 2`, but does not prove it. The known sufficient small-CW route requires `asymptotic_rank(cw_2) = 3`. The new upper bound remains above three. There is no proved convergence theorem carrying the present recurrence to three.

`notes/CLAIM_AUDIT.md` identifies the dependency and review boundary of each main assertion. `notes/REMAINING_GAP.md` separates concrete next research targets from statements that are not justified.

## Files and integrity

- `report/`: final PDF, LaTeX source, and the printed integer radical entries.
- `certificates/`: two seed maps, the composed map, and the spectral inequality certificate.
- `code/`: exact verification and certificate-generation routines.
- `results/`: the actual successful verification records.
- `references/`: primary-source metadata and a short citation guide.
- `notes/`: claim audit, code-review scope, and the unresolved mathematical target.
- `prior/`: the original research ZIP and its fresh verification result.

`SHA256SUMS` records the packaged file hashes. On a system with `sha256sum`, check integrity before generating any new output:

```bash
sha256sum -c SHA256SUMS
```

To rebuild the PDF with a TeX installation containing `newtx`, `amsmath`, `amsthm`, `mathtools`, `microtype`, `booktabs`, `enumitem`, `listings`, `hyperref`, and `bookmark`:

```bash
bash build_report.sh
```

Rebuilding a PDF or changing a verification output can change the corresponding file hash. The supplied PDF and verification results require no rebuilding to read or inspect.
