"""Exact Borel-fixed pair-space enumeration for 3x3 matrix multiplication.

All basis indices in this module are zero-based. Sparse vectors are dictionaries.
The sole nonstandard dependency in the package is SymPy, in parameter.py.
The classification and completeness argument are in the accompanying report.
"""
from fractions import Fraction as F
from itertools import product
from collections import defaultdict
import json, time

# All vectors have coordinate dictionaries; exact sparse elimination over Q.
def echelon(columns):
    pivots = {}
    for c in columns:
        v = {i: F(a) for i,a in c.items() if a}
        while v:
            p = min(v)
            if p not in pivots:
                d = v[p]
                v = {i:a/d for i,a in v.items()}
                pivots[p] = v
                break
            d = v[p]
            for i,a in pivots[p].items():
                w = v.get(i, 0)-d*a
                if w: v[i]=w
                elif i in v: del v[i]
    return pivots

def rank(columns): return len(echelon(columns))
def root(i,j): return {3*i+j:F(1)}
H1 = {0:F(1),4:F(-1)}
H2 = {4:F(1),8:F(-1)}
def lin(a,b):
    return {k: a*H1.get(k,0)+b*H2.get(k,0) for k in [0,4,8]
            if a*H1.get(k,0)+b*H2.get(k,0)}
E = root(0,2)
L = root(0,1)
R = root(1,2)
P = root(1,0)
Q = root(2,1)
S = root(2,0)
n = [E,L,R]
TYPES = {
 '0':[], 'E':[E], 'L':[E,L], 'R':[E,R], 'N':n,
 'HL':[E,L,lin(F(2),F(1))], 'HR':[E,R,lin(F(1),F(2))],
 'F0':n+[H1], 'Fhalf':n+[lin(F(2),F(1))],
 'F2':n+[lin(F(1),F(2))], 'Finf':n+[H2],
 'Fgen':n+[lin(F(1),F(3))],
 'D':n+[H1,H2], 'P':n+[H1,P], 'Q':n+[H2,Q],
 'P6':n+[H1,H2,P], 'Q6':n+[H1,H2,Q],
 'S7':n+[H1,H2,P,Q], 'ALL':n+[H1,H2,P,Q,S],
}
NAMES = list(TYPES)
DIMS = {a:len(v) for a,v in TYPES.items()}
INC = {(a,b):rank(TYPES[b]+TYPES[a])==DIMS[b] for a,b in product(NAMES,repeat=2)}

def enumerate_configs(extra):
    """At most one independent Cartan-line parameter occurs when extra<=12."""
    if not 0<=extra<=12: raise ValueError('implementation covers extra<=12')
    out=[]
    def visit(pos,budget,conf):
        if pos==9:
            if budget==0: out.append(tuple(conf))
            return
        i,k=divmod(pos,3)
        for name in NAMES:
            d=DIMS[name]
            if d>budget: continue
            if i and not INC[name,conf[pos-3]]: continue
            if k and not INC[name,conf[pos-1]]: continue
            # A nonzero remainder cannot be filled if too few dimensions fit.
            visit(pos+1,budget-d,conf+[name])
    visit(0,extra,[])
    return out

def pair_columns(config, t=F(3)):
    """A=x^i_j, B=y^l_k. Outer highest cell i=2,k=0; inner raising upper triangular."""
    cols=[]
    for i,k in product(range(3),repeat=2):
        cols.append({(3*i+j,3*j+k):F(1) for j in range(3)})
    for pos,name in enumerate(config):
        h,k=divmod(pos,3)
        i=2-h
        vv = n+[lin(F(1),t)] if name=='Fgen' else TYPES[name]
        for v in vv:
            cols.append({(3*i+int(z)//3,3*(int(z)%3)+k):a for z,a in v.items()})
    return cols

def pair_tests(config,t=F(3)):
    Ecols=pair_columns(config,t)
    r=len(Ecols)
    # Direct-sum weight blocks in A tensor E and B tensor E.
    results=[]
    for factor in [0,1]:
        columns=[]
        for v in Ecols:
            for z in range(9):
                out={}
                for (a,b),c in v.items():
                    w=[a,b][factor]
                    other=[b,a][factor]
                    if z==w: continue
                    sign=1 if z<w else -1
                    out[(min(z,w),max(z,w),other)]=sign*c
                columns.append(out)
        results.append(9*r-rank(columns))
    return tuple(results)

