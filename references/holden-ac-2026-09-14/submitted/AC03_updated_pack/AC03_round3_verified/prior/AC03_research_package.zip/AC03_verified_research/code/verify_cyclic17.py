"""Classify rank-17 low-degree data with cyclically identical Borel pair spaces.

This extra symmetry is a restriction, NOT a without-loss-of-generality reduction
for AC-03. Passing these tests does NOT establish a border-rank decomposition.
"""
from __future__ import annotations
from pathlib import Path
from fractions import Fraction
import json
import sympy as sp
from borel import enumerate_configs, pair_tests, pair_columns
from triples import triple_test
from parameter import symbolic_test, cyclic_symbolic, t

ROOT=Path(__file__).resolve().parents[1]

def encode_columns(columns):
    return [[[*k,str(v)] for k,v in sorted(c.items())] for c in columns]

def verify(output: Path | None = None) -> dict:
    configurations=enumerate_configs(8)
    assert len(configurations)==343
    pair_parameters=[]; triple_parameters=[]; fixed_passing=[]; families=[]
    for c in configurations:
        kernels=pair_tests(c)
        if 'Fgen' in c:
            tests=[symbolic_test(c,f) for f in (0,1)]
            for z in tests:
                assert set(z['nonconstant_factors']) <= {'t - 2','2*t - 1'}
            assert tuple(z['generic_kernel'] for z in tests)==kernels
            pair_parameters.append(dict(config=list(c),tests=tests))
            if min(kernels)>=17:families.append(c)
        elif min(kernels)>=17:fixed_passing.append(c)
    assert len(pair_parameters)==29
    assert len(fixed_passing)==126 and len(families)==11
    survivors=[]
    for c in fixed_passing:
        d=triple_test(c,c,c)
        if d>=17:
            survivors.append(dict(config=list(c),parameter=None,kernels=list(pair_tests(c)),
                                  intersection_111=d))
    assert len(survivors)==1
    for c in families:
        record=cyclic_symbolic(c)
        triple_parameters.append(record)
        assert record['generic_intersection']<17
        assert set(record['nonconstant_factors']) <= {'t + 1'}
        if record['nonconstant_factors']:
            d=triple_test(c,c,c,Fraction(-1),Fraction(-1),Fraction(-1))
            predicted=459-record['fixed_rank']-sum(
                sp.sympify(p).subs(t,-1)!=0 for p in record['smith_diagonal'])
            assert d==predicted
            if d>=17:
                survivors.append(dict(config=list(c),parameter='-1',
                    kernels=list(pair_tests(c,Fraction(-1))), intersection_111=d))
    assert len(survivors)==4
    assert sorted(x['intersection_111'] for x in survivors)==[19,19,21,21]
    for i,s in enumerate(survivors):s['id']=i
    result=dict(status='VERIFIED_RESTRICTED_CLASSIFICATION',
        scope='Borel-stable E_AB with E_BC and E_CA its identical cyclic coordinate copies; pair and (111) tests only',
        not_a_full_border_rank_solution=True,
        candidate_charts=343, fixed_pair_survivors=126, generic_pair_families=11,
        parameter_pair_rank_drop_values=['1/2','2'],
        additional_cyclic_111_rank_drop_values=['-1'], survivors=survivors)
    if output is not None:
        output.mkdir(parents=True,exist_ok=True)
        (output/'cyclic17_verification.json').write_text(json.dumps(result,indent=2)+'\n')
        (output/'cyclic17_pair_parameter_smith.json').write_text(json.dumps(pair_parameters,indent=2)+'\n')
        (output/'cyclic17_triple_parameter_smith.json').write_text(json.dumps(triple_parameters,indent=2)+'\n')
        bases=[]
        for s in survivors:
            par=Fraction(s['parameter']) if s['parameter'] else Fraction(3)
            bases.append(dict(id=s['id'],config=s['config'],parameter=s['parameter'],
                              E_AB_columns=encode_columns(pair_columns(tuple(s['config']),par))))
        (output/'cyclic17_pair_bases.json').write_text(json.dumps(bases,indent=2)+'\n')
    return result

if __name__=='__main__':
    print(json.dumps(verify(ROOT/'results'),indent=2))
