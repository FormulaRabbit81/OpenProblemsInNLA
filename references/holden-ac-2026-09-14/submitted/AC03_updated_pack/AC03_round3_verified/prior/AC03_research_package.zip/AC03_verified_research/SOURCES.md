# Sources and attribution

Accessed through ordinary web pages during this run on 14 September 2026. No GitHub plugin was used. URLs are supplied here so the mathematical sources can be retrieved independently.

## Exact problem

OpenProblemsInNLA, **AC-03 — Border rank of the 3 x 3 matrix product**.

https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/main/arithmetic-and-complexity/AC-03

Raw statement:
https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/arithmetic-and-complexity/AC-03/README.md

The task is the exact border rank over C, not ordinary bilinear rank, asymptotic rank, or the exponent of matrix multiplication.

## Known lower bound and the principal obstruction

Austin Conner, Alicia Harper, J. M. Landsberg, **New lower bounds for matrix multiplication and det_3**, Forum of Mathematics, Pi 11 (2023), e17.

https://doi.org/10.1017/fmp.2023.14
https://arxiv.org/abs/1911.07981

Theorem 1.1 establishes the lower bound 17. Remark 1.8 reports an r=17 ideal that passes all border-apolarity tests. The distinction between passing the tests and representing an actual border decomposition is therefore central.

The authors' supplementary code was inspected as a source reference, but is not bundled or used by the verifier. The implementation in this package was independently written.

https://github.com/adconner/chlbapolar

## Known upper construction

A. V. Smirnov, **The bilinear complexity and practical algorithms for matrix multiplication**, Computational Mathematics and Mathematical Physics 53 (2013), 1781–1795.

https://doi.org/10.1134/S0965542513120129

Open original Russian edition, volume 53(12), pp. 1970–1984:
https://www.mathnet.ru/eng/zvmmf9955

**The final coefficient data come directly from Table 6, pp. 1982–1983 of that original edition.** Both table pages were visually inspected, and the complete integer-Laurent identity was then checked programmatically. The gamma/output matrices are transposed when placed in the third tensor factor.

An additional exposition consulted during source review was J. M. Landsberg and Nicholas Ryder, *On the geometry of border rank algorithms for n x 2 by 2 x 2 matrix multiplication*, arXiv:1509.08323, Section 10:
https://arxiv.org/abs/1509.08323

An initial transcription based on that exposition was rejected by the exact checker. The final package uses only the independently checked original-table data. This is a statement about our transcription audit, not an assertion that every edition of the exposition contains the same discrepancies.

## Contemporary context, not a solution of AC-03

Josh Alman and Baitian Li, **Asymptotic Rank Speedup Theorems, Revisited**, arXiv:2605.21738, submitted 20 May 2026.

https://arxiv.org/abs/2605.21738

The introduction distinguishes the unresolved finite-size border-rank question from asymptotic-rank statements. No upper or lower certificate in this package is inferred from an asymptotic exponent.

## General border-apolarity framework

Weronika Buczynska and Jaroslaw Buczynski, **Apolarity, border rank and multigraded Hilbert scheme**, arXiv:1910.01944.

https://arxiv.org/abs/1910.01944

The relevant object is the component obtained from limits of general reduced-point ideals in the multigraded Hilbert scheme. Correct dimensions and apolarity constraints alone do not establish membership in this component.

## Attribution boundary

Smirnov's length-20 construction and the Conner–Harper–Landsberg lower bound are not new results of this package. The exact expansion, compact reconstruction of the lower-bound enumeration, parameter audits, and restricted rank-17 classification are independently generated computations. No novelty or peer-review claim is made.
