# Non-certifying numerical experiments

These files are not used in the exact proofs. The searches did not yield a new
upper bound. A nonzero residual from local optimization does not establish any
lower bound or exclude a border degeneration.

Install the optional dependency with `python -m pip install -r experiments/requirements.txt`.
Then reproduce the recorded configurations using:

```bash
OPENBLAS_NUM_THREADS=1 python experiments/cp_als_search.py 19 30 1200
OPENBLAS_NUM_THREADS=1 python experiments/cp_als_search.py 18 20 1200
OPENBLAS_NUM_THREADS=1 python experiments/cp_als_search.py 17 20 1200
```

Arguments are requested length, number of trials, and ALS sweeps per trial.
Floating-point results may vary with numerical libraries and hardware. The
random seed is fixed. Generated NPZ arrays are approximate search iterates,
not exact decomposition certificates. No NPZ iterate is necessary for the
mathematical results in the report.
