# Completed work and audit trail

## Scope

This run attempted the exact complex border-rank problem, rather than substituting tensor rank or asymptotic rank. It did not obtain a matching upper and lower bound. All current proof claims are listed in the report; there is no unreported final lemma that closes the gap.

## Source review and the upper certificate

The problem statement, lower-bound paper, original Smirnov table, an additional exposition of the upper algorithm, and the May 2026 asymptotic-rank paper were examined through the website.

The first upper-data transcription failed: exact expansion found 43 mismatched nonpositive-power coefficients. It was discarded. The original Smirnov table was then transcribed directly, including the transpose in the output factor. All negative powers canceled and all 729 constant tensor coordinates matched.

Comparing the two normalized transcriptions revealed six changed factor entries: the first factor of term 1; the third factors of terms 3, 7 and 12; and the second factors of terms 6 and 16. The invalid initial transcription is deliberately not included as usable coefficient data. The final proof depends only on the original-table transcription and its exact verification.

The error tensor has degree support 1,2,3,4,5,6,7,8,10. Its coefficient l1 sum is 111, and the leading coefficient has squared Frobenius norm 14.

## Reconstruction of the lower bound

A direct representation-theoretic classification reduces pair-space enumeration to nested arrays of Borel-stable subspaces of sl_3. Every subspace type was checked for closure under the two simple raising operators. Every generated array was checked for closure under the six relevant outer/inner raising operators.

At total extra dimension seven, 184 charts were generated. A generic rational sample initially found eight surviving pair spaces, but was not taken as a complete parameter proof. Smith forms of the residual Q[t] matrices established that the only possible pair-test rank drops are t=1/2 and t=2. Those values and infinity were already included as separate charts. This closes the parameter gap.

All 512 independent ordered triples of the eight pair spaces were then checked over Q. Every intersection dimension is at most 11, below the required 16. The histogram and every individual result are packaged. The result is the known bound 17, independently reconstructed.

## Rank-17 extension and exceptional parameters

At total extra dimension eight, 343 charts were generated. The pair tests leave 126 fixed spaces and 11 generic parameter families. For the extension, cyclic equality of the three pair spaces was imposed as an explicit additional restriction.

At a generic parameter, only one fixed cyclic candidate survived. Symbolic analysis of all 11 families then found the extra exceptional factor t+1. At t=-1, three additional spaces pass the cyclic (111) test. Two intersections jump from dimension 15 to 21; one jumps from 16 to 19.

This yielded an exact four-space restricted classification. It also demonstrated why a generic numerical rank test would have given an incorrect classification. The cyclic restriction is not justified for the full problem.

## Exploratory numerical searches below length 20

A separate double-precision alternating least-squares experiment attempted to find shorter approximations. It used truncated evaluations of the known 20-term family, with occasional seeded random initializations, and 1,200 sweeps per trial. The normal equations used relative ridge 1e-12.

| Requested length | Trials | Best Frobenius residual |
|---|---:|---:|
| 17 | 20 | 2.220074564341407 |
| 18 | 20 | 1.753133001155888 |
| 19 | 30 | 1.4299209678051021 |

These searches did **not** produce a useful new degeneration, an exact decomposition, or a lower bound. The reported values are outcomes of particular local searches, not global minima or evidence excluding shorter border decompositions. They are not used in any theorem. The optional script and run records are in `experiments/`.

## Final audit

The exact verifier passes all three stages and nine consistency tests. The PDF was compiled from LaTeX, rendered page by page, and visually inspected. The full problem remains unresolved by this work. No elapsed research duration of three hours is claimed.
