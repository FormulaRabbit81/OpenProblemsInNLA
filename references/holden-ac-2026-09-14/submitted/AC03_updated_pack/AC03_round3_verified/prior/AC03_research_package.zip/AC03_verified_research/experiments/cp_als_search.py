"""Exploratory, non-certifying CP-ALS search below length20."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import numpy as np
import json,time,itertools,sys
from pathlib import Path
P=Path(__file__).resolve().parents[1]
OUT=P/'experiments'
OUT.mkdir(exist_ok=True)
terms=json.loads((P/'data/smirnov20.json').read_text())['rank_one_terms']
T=np.zeros((9,9,9))
for i,j,k in itertools.product(range(3),repeat=3):T[3*i+j,3*j+k,3*k+i]=1.

def initialize(t,drop):
 factors=[]
 for f in 'abc':
  X=np.zeros((9,20))
  for q,term in enumerate(terms):
   for p,c,i,j in term[f]:X[3*(i-1)+j-1,q]+=c*t**p
  factors.append(np.delete(X,drop,axis=1))
 return factors

def res(X):
 return np.linalg.norm(T-np.einsum('ar,br,cr->abc',*X,optimize=True))

def balance(X):
 norms=[np.maximum(np.linalg.norm(a,axis=0),1e-100)for a in X]
 target=(norms[0]*norms[1]*norms[2])**(1/3)
 return[a*(target/v)for a,v in zip(X,norms)]

def als(X,iterations,ridge=1e-12):
 X=balance(X)
 for step in range(iterations):
  for mode in range(3):
   b,c=(X[j]for j in range(3)if j!=mode)
   gram=(b.T@b)*(c.T@c)
   rhs=np.einsum(['abc,br,cr->ar','abc,ar,cr->br','abc,ar,br->cr'][mode],T,b,c,optimize=True)
   # Relative regularization prevents singular normal equations. This affects search only.
   reg=ridge*np.trace(gram)/len(gram)
   X[mode]=np.linalg.solve(gram+reg*np.eye(len(gram)),rhs.T).T
  X=balance(X)
 return X

if __name__=='__main__':
 rank=int(sys.argv[1]) if len(sys.argv)>1 else 19
 trials=int(sys.argv[2])if len(sys.argv)>2 else 20
 iterations=int(sys.argv[3])if len(sys.argv)>3 else 1000
 rng=np.random.default_rng(20260914);records=[];best=None;start=time.time()
 for trial in range(trials):
  if trial<20 and rank==19:
   drop=[trial];t=.5;X=initialize(t,drop)
  else:
   drop=sorted(rng.choice(20,20-rank,replace=False).tolist());t=float(rng.choice([.3,.4,.5,.7,1.]));X=initialize(t,drop)
   if trial%5==4:X=[rng.standard_normal((9,rank))for _ in range(3)]
  X=als(X,iterations)
  rr=res(X);norm=max(np.linalg.norm(a)for a in X)
  rec={'trial':trial,'dropped_zero_based':drop,'initial_parameter':t,'error_frobenius':rr,'factor_frobenius_max':norm}
  records.append(rec)
  if best is None or rr<best:
   best=rr;np.savez(OUT/f'numerical_best_{rank}.npz',a=X[0],b=X[1],c=X[2]);print('BEST',rec,flush=True)
 print('rank',rank,'trials',trials,'iterations',iterations,'best',best,'elapsed',time.time()-start)
 (OUT/f'numerical_{rank}.json').write_text(json.dumps(dict(rank=rank,trials=trials,iterations_per_trial=iterations,ridge=1e-12,elapsed_seconds=time.time()-start,records=records),indent=2))
