"""Verify the length-20 Laurent degeneration with integer arithmetic only."""
from __future__ import annotations
from collections import defaultdict
from itertools import product
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]

def expand(terms: list[dict]) -> dict[tuple[int, int, int, int], int]:
    coefficients = defaultdict(int)
    for term in terms:
        if set(term) != {'a', 'b', 'c'}:
            raise ValueError('Each summand must have exactly three factors.')
        for factor in term.values():
            if not factor:
                raise ValueError('Zero factors are not allowed in this data file.')
            for item in factor:
                if (len(item) != 4 or not all(isinstance(x, int) for x in item)
                        or item[1] == 0 or not 1 <= item[2] <= 3
                        or not 1 <= item[3] <= 3):
                    raise ValueError(f'Invalid factor entry: {item!r}')
        for a, b, c in product(term['a'], term['b'], term['c']):
            power = a[0] + b[0] + c[0]
            indices = tuple(3*(q[2]-1)+q[3]-1 for q in (a,b,c))
            coefficients[power, *indices] += a[1]*b[1]*c[1]
    return {k:v for k,v in coefficients.items() if v}

def target() -> dict[tuple[int, int, int, int], int]:
    return {(0,3*i+j,3*j+k,3*k+i):1 for i,j,k in product(range(3),repeat=3)}

def verify(output: Path | None = None) -> dict:
    data = json.loads((ROOT/'data/smirnov20.json').read_text())
    terms = data['rank_one_terms']
    assert len(terms) == 20
    coefficients = expand(terms)
    expected = target()
    assert not any(k[0] < 0 for k in coefficients), 'Negative Laurent power survives.'
    assert {k:v for k,v in coefficients.items() if k[0] == 0} == expected
    residual = {k:v for k,v in coefficients.items() if k[0] > 0}
    by_degree = {}
    for degree in sorted({k[0] for k in residual}):
        entries = [v for k,v in residual.items() if k[0] == degree]
        by_degree[str(degree)] = dict(nonzero_entries=len(entries),
                coefficient_l1=sum(abs(v) for v in entries),
                squared_frobenius_norm=sum(v*v for v in entries))
    by_coordinate = defaultdict(dict)
    for (degree,a,b,c), value in residual.items():
        by_coordinate[a,b,c][degree] = value
    squared_norm = defaultdict(int)
    for polynomial in by_coordinate.values():
        for d,v in polynomial.items():
            for e,w in polynomial.items():
                squared_norm[d+e] += v*w
    report = dict(status='VERIFIED', rank_one_terms=20,
        field='Q(t); consequently also C for t nonzero',
        target_nonzero_entries=27, target_ambient_coordinates=729,
        negative_power_coefficients_surviving=0,
        constant_tensor_matches=True, residual_by_degree=by_degree,
        residual_coefficient_l1=sum(abs(v) for v in residual.values()),
        complex_frobenius_bound='||S(t)-M3||_F <= 111 |t| for 0 < |t| <= 1',
        real_parameter_squared_error_polynomial={str(d):v for d,v in sorted(squared_norm.items()) if v})
    assert report['residual_coefficient_l1'] == 111
    assert by_degree['1']['squared_frobenius_norm'] == 14
    if output is not None:
        output.mkdir(parents=True, exist_ok=True)
        (output/'upper_verification.json').write_text(json.dumps(report,indent=2)+'\n')
        (output/'upper_residual.json').write_text(json.dumps(
            dict(entry_format=['power','A index (zero-based)','B index','C index','coefficient'],
                 entries=[[*k,v] for k,v in sorted(residual.items())]),indent=2)+'\n')
    return report

if __name__ == '__main__':
    print(json.dumps(verify(ROOT/'results'), indent=2))
