"""Reproduce the known lower bound 17, with all complex parameters covered."""
from __future__ import annotations
from pathlib import Path
from itertools import product
from collections import Counter
import csv
import json
from borel import enumerate_configs, pair_tests
from triples import triple_test
from parameter import symbolic_test

ROOT = Path(__file__).resolve().parents[1]
ALLOWED_FACTORS = {'t - 2', '2*t - 1'}

def verify(output: Path | None = None) -> dict:
    configurations = enumerate_configs(7)
    assert len(configurations) == 184
    parameter_records = []
    all_records = []
    passing = []
    for config in configurations:
        kernels = pair_tests(config)
        if 'Fgen' in config:
            record = dict(config=list(config), tests=[symbolic_test(config,f) for f in (0,1)])
            parameter_records.append(record)
            for test in record['tests']:
                assert set(test['nonconstant_factors']) <= ALLOWED_FACTORS
            # Outside t=1/2,2, the Smith form proves the sampled ranks universal.
            assert tuple(z['generic_kernel'] for z in record['tests']) == kernels
            assert min(kernels) < 16
        all_records.append(dict(config=list(config), kernels=list(kernels),
                                parameter_family='Fgen' in config))
        if min(kernels) >= 16:
            assert 'Fgen' not in config
            passing.append(config)
    assert len(parameter_records) == 13
    assert len(passing) == 8
    records = []
    for i,j,k in product(range(8),repeat=3):
        dimension = triple_test(passing[i], passing[j], passing[k])
        assert dimension < 16
        records.append((i,j,k,dimension))
    histogram = Counter(z[3] for z in records)
    expected = {2:1,3:12,4:57,5:43,6:168,7:60,8:102,9:50,10:18,11:1}
    assert dict(histogram) == expected
    result = dict(status='VERIFIED_KNOWN_LOWER_BOUND', conclusion='border rank(M3) >= 17',
        candidate_charts=184, zero_dimensional_charts=171, one_parameter_charts=13,
        parameter_rank_drop_values=['1/2','2'],
        separate_projective_parameter_values=['0','1/2','2','infinity'],
        surviving_pair_spaces=[dict(id=i,config=list(c),kernels=list(pair_tests(c))) for i,c in enumerate(passing)],
        triples_checked=512, maximum_111_intersection=11,
        intersection_histogram={str(k):v for k,v in sorted(histogram.items())},
        pair_records=all_records)
    if output is not None:
        output.mkdir(parents=True,exist_ok=True)
        (output/'lower_verification.json').write_text(json.dumps(result,indent=2)+'\n')
        (output/'lower_parameter_smith.json').write_text(json.dumps(parameter_records,indent=2)+'\n')
        with (output/'lower_triples.csv').open('w',newline='') as f:
            w=csv.writer(f);w.writerow(['E_AB','E_BC','E_CA','intersection_dimension']);w.writerows(records)
    return result

if __name__ == '__main__':
    result=verify(ROOT/'results')
    print(json.dumps({k:v for k,v in result.items() if k!='pair_records'},indent=2))
