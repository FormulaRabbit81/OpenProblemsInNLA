"""Independent consistency tests for coordinate, group-action, and rank code."""
from __future__ import annotations
import copy
import json
import random
import unittest
from collections import defaultdict
from fractions import Fraction
from itertools import product
from pathlib import Path
import sympy as sp
from borel import TYPES, echelon, rank, pair_columns, pair_tests, enumerate_configs
from triples import reduce_vector, triple_test
from parameter import full_intersection_matrix_columns
from verify_upper import expand, target

ROOT=Path(__file__).resolve().parents[1]

def commutator(vector,p,q):
    out=defaultdict(Fraction)
    for z,v in vector.items():
        i,j=divmod(z,3)
        if i==q:out[3*p+j]+=v
        if j==p:out[3*i+q]-=v
    return {k:v for k,v in out.items() if v}

def pair_action(vector,group,p,q):
    out=defaultdict(Fraction)
    for (a,b),v in vector.items():
        i,j=divmod(a,3);l,k=divmod(b,3)
        if group==0 and i==p:out[3*q+j,b]-=v
        if group==1:
            if j==q:out[3*i+p,b]+=v
            if l==p:out[a,3*q+k]-=v
        if group==2 and k==q:out[a,3*l+p]+=v
    return {k:v for k,v in out.items() if v}

class VerificationTests(unittest.TestCase):
    def test_sparse_rank_against_sympy(self):
        rng=random.Random(20260914)
        for m,n in [(7,5),(5,7),(9,9),(11,4)]:
            for _ in range(8):
                array=[[rng.choice([0,0,0,1,-1,2]) for _ in range(n)] for _ in range(m)]
                columns=[{i:array[i][j] for i in range(m) if array[i][j]} for j in range(n)]
                self.assertEqual(rank(columns),sp.Matrix(array).rank())
    def test_reduction_kills_span(self):
        for cols in TYPES.values():
            pivots=echelon(cols)
            for c in cols:self.assertFalse(reduce_vector(c,pivots))
    def test_inner_borel_subspaces(self):
        for name,cols in TYPES.items():
            pivots=echelon(cols)
            self.assertEqual(len(pivots),len(cols),name)
            for c in cols:
                for p,q in [(0,1),(1,2)]:
                    self.assertFalse(reduce_vector(commutator(c,p,q),pivots),name)
    def test_full_pair_borel_closure(self):
        for conf in enumerate_configs(7)+enumerate_configs(8):
            cols=pair_columns(conf);pivots=echelon(cols)
            self.assertEqual(len(pivots),len(cols))
            for c in cols:
                for group,p in product(range(3),range(2)):
                    self.assertFalse(reduce_vector(pair_action(c,group,p,p+1),pivots),conf)
    def test_slice_containment(self):
        for conf in enumerate_configs(7):
            pivots=echelon(pair_columns(conf))
            for i,k in product(range(3),repeat=2):
                v={(3*i+j,3*j+k):Fraction(1) for j in range(3)}
                self.assertFalse(reduce_vector(v,pivots))
    def test_two_intersection_implementations(self):
        passing=[c for c in enumerate_configs(7) if min(pair_tests(c))>=16]
        for c in passing:
            block=full_intersection_matrix_columns(c,Fraction(3))
            self.assertEqual(len(block)-rank(block),triple_test(c,c,c))
    def test_upper_constant_and_poles(self):
        terms=json.loads((ROOT/'data/smirnov20.json').read_text())['rank_one_terms']
        coefficients=expand(terms)
        self.assertFalse(any(k[0]<0 for k in coefficients))
        self.assertEqual({k:v for k,v in coefficients.items() if k[0]==0},target())
    def test_upper_detects_corruption(self):
        terms=json.loads((ROOT/'data/smirnov20.json').read_text())['rank_one_terms']
        terms=copy.deepcopy(terms);terms[0]['a'][0][1]+=1
        coefficients=expand(terms)
        bad=any(k[0]<0 for k in coefficients) or {k:v for k,v in coefficients.items() if k[0]==0}!=target()
        self.assertTrue(bad)
    def test_target_trace_pairing(self):
        A=[[2,1,-1],[0,3,2],[-2,1,4]]
        B=[[1,0,2],[-1,2,3],[4,1,0]]
        C=[[0,1,2],[3,-1,1],[2,0,4]]
        af=sum(A,[]);bf=sum(B,[]);cf=sum(C,[])
        tensor_value=sum(v*af[a]*bf[b]*cf[c] for (_,a,b,c),v in target().items())
        direct=sum(A[i][j]*B[j][k]*C[k][i] for i,j,k in product(range(3),repeat=3))
        self.assertEqual(tensor_value,direct)

if __name__=='__main__':unittest.main(verbosity=2)
