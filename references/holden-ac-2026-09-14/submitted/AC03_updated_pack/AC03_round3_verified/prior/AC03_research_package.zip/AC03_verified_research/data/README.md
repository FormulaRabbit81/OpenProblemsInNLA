# Upper-certificate data

`smirnov20.json` records 20 triples of factor vectors. Each vector is a list of

```
[integer_exponent, integer_coefficient, one_based_row, one_based_column]
```

For example, `[2, -1, 1, 3]` in factor `a` denotes `-t^2 x_13`.

The tensor represented is the sum of the 20 products `a(t) tensor b(t) tensor c(t)`, with no additional outer prefactors. Negative exponents are allowed in this original Laurent representation. The normalized version printed in the PDF has extracted these powers into one scalar prefactor per summand.

The original source orders the coefficient matrices as gamma, alpha, beta. We store alpha in factor a, beta in factor b, and **transpose gamma** into factor c, because the target convention is

```
sum_{i,j,k} x_ij tensor y_jk tensor z_ki.
```

Rows and columns in this input data are one-based. Tensor indices in generated result files are zero-based and row-major, `index = 3*(row-1) + (column-1)`.

Source: Smirnov (2013), original Russian edition, Table 6, pp. 1982–1983. See `SOURCES.md`.
