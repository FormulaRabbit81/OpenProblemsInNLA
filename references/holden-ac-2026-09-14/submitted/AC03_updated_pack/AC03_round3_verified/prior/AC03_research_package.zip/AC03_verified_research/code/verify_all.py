"""Run the exact upper/lower certificates, restricted extension, and tests.
Usage (from any directory): python /path/to/code/verify_all.py
Do not use Python's -O flag, which disables assertion checks.
"""
from pathlib import Path
import json
import platform
import time
import unittest
import sympy
from verify_upper import verify as upper
from verify_lower import verify as lower
from verify_cyclic17 import verify as cyclic
from test_verifiers import VerificationTests

ROOT=Path(__file__).resolve().parents[1]

def main():
    if not __debug__:
        raise RuntimeError('Do not run this certificate verifier with python -O.')
    start=time.perf_counter();output=ROOT/'results'
    u=upper(output);print('Upper: verified length-20 degeneration; error <= 111 |t|.',flush=True)
    l=lower(output);print('Lower: 184 charts -> 8 spaces -> 512 rejected triples.',flush=True)
    c=cyclic(output);print('Restricted rank-17 analysis: four cyclic pair-space candidates.',flush=True)
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(VerificationTests)
    tests=unittest.TextTestRunner(verbosity=2).run(suite)
    if not tests.wasSuccessful():raise SystemExit(1)
    report=dict(status='ALL_CHECKS_PASSED',python=platform.python_version(),sympy=sympy.__version__,
                tests_run=tests.testsRun,elapsed_seconds=round(time.perf_counter()-start,6),
                full_problem_solved=False,verified_bounds=[17,20],
                restricted_cyclic_pair_candidates=len(c['survivors']))
    (output/'run_summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2),flush=True)

if __name__=='__main__':main()
