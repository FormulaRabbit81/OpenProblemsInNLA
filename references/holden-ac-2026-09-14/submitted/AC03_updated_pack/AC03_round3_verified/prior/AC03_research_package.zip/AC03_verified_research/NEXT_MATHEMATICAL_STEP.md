# Missing obligations for a full solution

The established interval is still [17,20]. The four-space classification is restricted to cyclically identical pair spaces and only low-degree conditions. Neither its finiteness nor its exact arithmetic turns it into a full border-rank result.

The most concrete rank-17 objects produced here are the four explicit bases in `results/cyclic17_pair_bases.json`. A continuation should distinguish three logically separate questions:

1. Does a given pair-space triple extend to a multigraded apolar ideal with the correct generic-point Hilbert function in all degrees? The low-degree spaces alone do not answer this.
2. Does an extension belong to the principal component obtained by limits of general reduced-point ideals? Correct dimensions alone are insufficient, and ordinary smoothability of a saturation need not settle the original multigraded ideal.
3. Can a positive membership result be converted to an explicit one-parameter family of decomposable tensors whose sum tends to M3?

A certified positive answer for an r=17 border-apolar ideal, with the required principal-component membership, would combine with the verified lower bound to solve AC-03 at 17. A proof at 18, 19 or 20 must instead exclude every shorter degeneration, including noncyclic candidates, and provide a matching upper construction.

Do not assume cyclic equality without proving a reduction. Do not infer a universal parameter statement from generic samples: the three t=-1 survivors in this package are an explicit counterexample to that workflow. Do not use failure of the optional numerical searches as an impossibility certificate.

Conner–Harper–Landsberg's Remark 1.8 reports an r=17 ideal passing all border-apolarity tests. That reported ideal has not been identified with or reconstructed from the four spaces here. Repeating those necessary tests without a component-membership strategy would not by itself close the central gap.
