# AC-03 — Exact certificates and a restricted rank-17 classification

**This package does not fully solve AC-03.** It establishes the known interval

\[
17\leq \underline R_{\mathbb C}(M_3)\leq20,
\]

and provides a complete **restricted** classification at rank 17. It does not prove which of 17, 18, 19, or 20 is the exact value. No repository change has been made, and this package does not support marking the problem solved.

Start with **`AC03_report.pdf`**, a 13-page mathematical report with all 20 upper-certificate summands printed in an appendix. `report.tex` and `upper_appendix.tex` are its editable source.

## Verified results

**Upper bound.** An independent transcription of Smirnov's original Table 6 is expanded using integer arithmetic. Every negative Laurent coefficient cancels. The constant tensor is exactly the 27-entry 3x3 matrix multiplication tensor, with all other constant coordinates zero. The explicit error satisfies `||S(t)-M3||_F <= 111 |t|` for complex `0 < |t| <= 1`.

**Lower bound.** An independently written Borel-subspace enumeration reconstructs the known lower bound 17: 184 charts, including 13 complex one-parameter charts, reduce to eight pair spaces. All 512 ordered triples are checked exactly and fail the required dimension-16 intersection condition. The maximum intersection dimension is 11. Polynomial Smith forms cover all exceptional parameter values; generic sampling is not used as a universal proof.

**Rank-17 extension.** Under the additional condition that the three pair spaces are identical cyclic coordinate copies, exactly four Borel-fixed pair spaces pass the pair and (111) tests. Three occur only at the exceptional Cartan parameter `t = -1`. This symmetry restriction is not known to be without loss of generality, and the four survivors are not verified border decompositions. The report states precisely what is and is not classified.

No claim of publication-level novelty is made for these computations. The numerical bounds and upper construction are established literature; sources and attributions are in `SOURCES.md` and the report.

## Reproduce the exact checks

Python 3.10 or later is required. Tested here with Python 3.13.5 and SymPy 1.14.0.

```bash
python -m pip install -r requirements.txt
python code/verify_all.py
```

The scripts locate the package relative to their own paths, so they can also be invoked from another working directory. Do not run Python with `-O`: the combined verifier rejects that mode because assertions are essential checks.

The recorded run passed all three verification stages and nine consistency tests. Its complete output is `results/verification_run.log`; its machine-readable summary is `results/run_summary.json`. The run time in that file is only the executable verifier's duration, not the duration of the research or writing.

To check only the length-20 degeneration, without SymPy:

```bash
python code/verify_upper.py
```

## Important files

| File | Purpose |
|---|---|
| `data/smirnov20.json` | All original Laurent coefficients, with the output matrix transposed into the trace convention |
| `results/upper_verification.json` | Exact coefficient counts and error-norm polynomial |
| `results/upper_residual.json` | Every nonzero coefficient of `S(t)-M3` |
| `results/lower_verification.json` | All rank-16 chart tests and the eight surviving pair spaces |
| `results/lower_parameter_smith.json` | Universal one-parameter rank analysis for the lower bound |
| `results/lower_triples.csv` | All 512 ordered triples and their exact intersection dimensions |
| `results/cyclic17_verification.json` | The four restricted rank-17 candidates |
| `results/cyclic17_pair_bases.json` | Explicit rational bases for those candidates |
| `results/cyclic17_*_parameter_smith.json` | Pair and cyclic-intersection polynomial certificates |
| `code/test_verifiers.py` | Coordinate, Borel-action, rank, and corruption-detection tests |
| `experiments/` | Optional, non-certifying numerical searches; not used in any proof |
| `RESEARCH_LOG.md` | Completed work, discarded transcription, search outcomes, and proof boundaries |
| `NEXT_MATHEMATICAL_STEP.md` | Exact missing obligations for a genuine solution |

## Build the report

With a standard LaTeX installation that includes Latin Modern, AMS packages, `microtype`, and `hyperref`:

```bash
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

This produces `report.pdf`; the included reviewed copy is `AC03_report.pdf`.

## Audit notes

These are reproducible computer-assisted certificates, not a proof-assistant formalization. The mathematical reduction and completeness argument are written out in the report. The package contains no downloaded font files or full copies of the cited papers. The source coefficient data are attributed to Smirnov, and the lower-bound method and result to their authors.

`MANIFEST.sha256` records the files as packaged. Rerunning scripts regenerates result files and can change timing records, so a later manifest mismatch in those regenerated files is expected.
