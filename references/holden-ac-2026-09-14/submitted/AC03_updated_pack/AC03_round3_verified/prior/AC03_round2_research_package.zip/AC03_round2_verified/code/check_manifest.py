#!/usr/bin/env python3
"""Check every file hash in the delivered manifest using the standard library."""
from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parents[1]
def main():
    manifest=ROOT/'MANIFEST.sha256'
    if not manifest.is_file():raise FileNotFoundError(manifest)
    count=0
    for line in manifest.read_text().splitlines():
        if not line.strip():continue
        digest,rel=line.split('  ',1)
        path=(ROOT/rel).resolve()
        if not path.is_relative_to(ROOT.resolve()):raise ValueError('Unsafe manifest path')
        actual=hashlib.sha256(path.read_bytes()).hexdigest()
        if actual!=digest:raise RuntimeError('Hash mismatch: '+rel)
        count+=1
    print(f'PASS: {count} manifest hashes match.')
if __name__=='__main__':main()
