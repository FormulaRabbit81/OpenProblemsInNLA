"""Nonzero modular minors certify independent first jets over characteristic zero.

The points are integer affine coordinates; reduction modulo p is used ONLY to
prove a displayed integer determinant is nonzero. It is not a finite-field
exhaustiveness argument.
"""
from itertools import combinations_with_replacement,product
from pathlib import Path
import json,random,time
import numpy as np

def monomials(degrees):
    spaces=[list(combinations_with_replacement(range(9),d)) for d in degrees]
    return list(product(*spaces))

def evaluate_jets(points,degrees,p):
    mons=monomials(degrees);cols=[]
    for mon in mons:
        col=[]
        for point in points:
            val=1
            for f,indices in enumerate(mon):
                for i in indices:val=val*point[f][i]%p
            col.append(val)
            for f in range(len(degrees)):
                for i in range(1,9):
                    if i not in mon[f]:col.append(0);continue
                    v=mon[f].count(i)
                    for g,indices in enumerate(mon):
                        use=list(indices)
                        if g==f:use.remove(i)
                        for j in use:v=v*point[g][j]%p
                    col.append(v)
        cols.append(col)
    return np.asarray(cols,dtype=np.int64).T,mons

def pivot_columns(M,p):
    a=M.copy()%p;row=0;pivs=[];det=1
    for col in range(a.shape[1]):
        rr=np.flatnonzero(a[row:,col])
        if len(rr)==0:continue
        q=row+int(rr[0])
        if q!=row:a[[row,q]]=a[[q,row]];det=-det%p
        v=int(a[row,col]);det=det*v%p
        a[row]=a[row]*pow(v,-1,p)%p
        if row+1<len(a):a[row+1:]=(a[row+1:]-a[row+1:,col,None]*a[row:row+1])%p
        pivs.append(col);row+=1
        if row==len(a):break
    return pivs,det%p

def determinant(M,p):
    assert M.shape[0]==M.shape[1]
    pp,d=pivot_columns(M,p)
    return d if len(pp)==len(M) else 0

def build():
    root=Path(__file__).resolve().parents[1];rng=random.Random(170289);p=101
    records=[]
    for degrees in [(2,2),(1,1,1)]:
        pts=[[[1]+[rng.randrange(p) for _ in range(8)] for f in degrees] for s in range(17)]
        M,mons=evaluate_jets(pts,degrees,p);pivs,d=pivot_columns(M,p)
        assert len(pivs)==len(M) and d
        assert determinant(M[:,pivs],p)==d
        record={'r':17,'factor_dimensions':[9]*len(degrees),'degrees':list(degrees),'prime':p,'points':pts,'number_of_jet_rows':len(M),'ambient_columns':len(mons),'pivot_columns':pivs,'determinant_mod_prime':d}
        records.append(record)
        print('degrees',degrees,'rows',len(M),'cols',len(mons),'det_mod_p',d,flush=True)
    (root/'certificates/independent_first_jets.json').write_text(json.dumps(records,indent=2)+'\n')
    return records

def verify(path=None):
    root=Path(__file__).resolve().parents[1]
    data=json.loads((path or root/'certificates/independent_first_jets.json').read_text())
    assert [rec['degrees'] for rec in data]==[[2,2],[1,1,1]]
    for rec in data:
        assert rec['prime']==101
        assert rec['r']==17 and all(v==9 for v in rec['factor_dimensions'])
        assert all(len(q)==9 and q[0]==1 for pt in rec['points'] for q in pt)
        M,mons=evaluate_jets(rec['points'],rec['degrees'],rec['prime'])
        assert len(M)==rec['number_of_jet_rows']==17*(1+8*len(rec['degrees']))
        assert len(rec['pivot_columns'])==len(M)
        det=determinant(M[:,rec['pivot_columns']],rec['prime'])
        assert det==rec['determinant_mod_prime']!=0
    return {'status':'VERIFIED','ranks':[d['number_of_jet_rows'] for d in data], 'field_of_conclusion':'Q and C, certified by integer minors nonzero modulo 101'}

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--build',action='store_true');args=ap.parse_args()
    if args.build:build()
    print(json.dumps(verify(),indent=2))
