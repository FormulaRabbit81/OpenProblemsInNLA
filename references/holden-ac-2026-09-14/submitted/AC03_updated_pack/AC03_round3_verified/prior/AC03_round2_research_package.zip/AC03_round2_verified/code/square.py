"""Exact partial (220) square test, dual wedge-wedge formulation.

For E of dimension r in A tensor B, dim A=dim B=9,
 codim <I_110^2> = 81*r - rank(f_E) - binomial(r,2), I_110=E^perp.
Necessary condition for limits of ideals of r general points: codim >=17*r.
This is a necessary test, not a component-membership certificate.
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import product
from borel import pair_columns, echelon
from triples import reduce_vector

def ww(v, x, y):
    out={}
    for (a,b),c in v.items():
        if a==x or b==y: continue
        key=(min(a,x),max(a,x),min(b,y),max(b,y))
        out[key]=out.get(key,0)+(1 if (a<x)==(b<y) else -1)*c
    return {k:v for k,v in out.items() if v}

def square_columns(E):
    return [ww(v,x,y) for v in E for x,y in product(range(9),repeat=2)]

def square_test(conf,par=F(3)):
    E=pair_columns(conf,par)
    r=len(E)
    rr=len(echelon(square_columns(E)))
    kernel=81*r-rr
    return {'rank':rr,'kernel':kernel,'codimension':kernel-r*(r-1)//2,
            'threshold':17*r, 'passes':kernel-r*(r-1)//2>=17*r}

def square_symbolic(conf):
    import sympy as sp
    from sympy.matrices.normalforms import smith_normal_form
    from sympy.polys.domains import QQ
    t=sp.Symbol('t')
    cc0=square_columns(pair_columns(conf,F(0)))
    cc1=square_columns(pair_columns(conf,F(1)))
    const=[v for v,w in zip(cc0,cc1) if v==w]
    var=[(v,w) for v,w in zip(cc0,cc1) if v!=w]
    piv=echelon(const)
    var=[(reduce_vector(v,piv),reduce_vector(w,piv)) for v,w in var]
    rows=sorted(set().union(*(set(v)|set(w) for v,w in var)))
    m=sp.Matrix([[sp.Rational(v.get(i,0))+t*sp.Rational(w.get(i,0)-v.get(i,0)) for v,w in var] for i in rows])
    diag=[]
    if m.rows:
        snf=smith_normal_form(m,domain=QQ.poly_ring(t))
        diag=[sp.factor(snf[i,i]) for i in range(min(snf.shape)) if snf[i,i]!=0]
    r=len(cc0)//81
    return {'config':list(conf), 'fixed_rank':len(piv), 'shape':list(m.shape),
      'smith_diagonal':[str(d) for d in diag],
      'generic_codimension':81*r-len(piv)-len(diag)-r*(r-1)//2,
      'threshold':17*r,
      'nonconstant_factors':sorted(set(str(f) for d in diag for f,e in sp.factor_list(d)[1]))}

