"""Independent verification of the common 17-plane and its elementary obstructions."""
from __future__ import annotations
from fractions import Fraction as F
from itertools import product
from borel import pair_columns,echelon
from triples import reduce_vector

SUPPORTS=((3,6),(3,4,6,7),(6,7))
M3={(3*i+j,3*j+k,3*k+i):F(1) for i,j,k in product(range(3),repeat=3)}
BLOCK=list(product(*SUPPORTS))

def common_basis():
    return [dict(M3)]+[{abc:F(1)} for abc in BLOCK]

def block_intersection_rank(configs):
    """Rank of [X,-Y,0; X,0,-Z], independently of quotient projections."""
    cols=[]
    for mode,conf in enumerate(configs):
        for v in pair_columns(conf):
            for z in range(9):
                out={}
                for (a,b),val in v.items():
                    if mode==0:
                        out[0,a,b,z]=val;out[1,a,b,z]=val
                    elif mode==1:out[0,z,a,b]=-val
                    else:out[1,b,z,a]=-val
                cols.append(out)
    rr=len(echelon(cols))
    return len(cols)-rr,rr

def verify_common(configs):
    basis=common_basis()
    assert len(basis)==len(echelon(basis))==17
    assert not(set(BLOCK)&set(M3))
    for mode,conf in enumerate(configs):
        piv=echelon(pair_columns(conf))
        for tensor in basis:
            for z in range(9):
                if mode==0:col={(a,b):v for (a,b,c),v in tensor.items() if c==z}
                elif mode==1:col={(b,c):v for (a,b,c),v in tensor.items() if a==z}
                else:col={(c,a):v for (a,b,c),v in tensor.items() if b==z}
                assert not reduce_vector(col,piv)
    d,rr=block_intersection_rank(configs)
    assert d==17 and rr==442
    return {'intersection_dimension':d,'block_matrix_rank':rr,'common_basis_verified':True}

def geometry():
    projected={abc:v for abc,v in M3.items() if abc[0] not in SUPPORTS[0]}
    slices=[{(b,c):v for (a,b,c),v in projected.items() if a==i} for i in range(9)]
    rank=len(echelon(slices));assert rank==7
    pi={abc:v for abc,v in M3.items() if all(abc[i] not in SUPPORTS[i] for i in range(3))}
    expected={(0,0,0):F(1),(0,1,3):F(1),(7,5,8):F(1),(8,8,8):F(1)}
    assert pi==expected
    return {'one_factor_quotient_flattening_rank':rank,
            'three_factor_quotient_coordinates':[list(abc)+[int(v)] for abc,v in pi.items()],
            'normalized_pole_order_at_most_two_excluded':True}

def serial_basis():
    return [[list(k)+[v.numerator,v.denominator] for k,v in sorted(t.items())] for t in common_basis()]
