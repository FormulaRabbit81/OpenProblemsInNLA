# The exact remaining target

The main report proves a computer-assisted equivalence, not a border-rank value.
All vector-space bases below use the trace-pairing convention of that report.

Let

    M = sum_{i,j,k=1}^3 x_ij tensor y_jk tensor z_ki,
    A' = span(x21,x31),
    B' = span(y21,y22,y31,y32),
    C' = span(z31,z32),
    L  = A' tensor B' tensor C',
    S  = span(M) direct-sum L.

Then S has dimension 17. Let X be the Segre variety of decomposable tensors in
P(A tensor B tensor C), and let G17(X) be the closure of the 17-dimensional
linear spans of 17 points of X. The remaining assertion is exactly

    S in G17(X).

Together with the retained lower bound, a positive answer gives border-rank(M)=17.
A negative answer, using the complete reduction in the report, gives the new
lower bound 18, not the exact value by itself.

## Equivalent explicit tensor target

Take a 17-dimensional space D with basis d0 and d_abc indexed by the 16
coordinate triples in L. Define the four-factor tensor

    Q = d0 tensor M + sum_{(a,b,c) in block} d_abc tensor a tensor b tensor c.

It has 43 nonzero unit coordinates in D tensor A tensor B tensor C and is concise
in D. Membership of S in G17(X) is equivalent to four-way border-rank(Q)=17.
The factor count matters: grouping factors and passing a three-way necessary
rank test is not the same assertion.

## Established constraints on a positive construction

Every limiting point of a 17-point span construction of S lies in
Seg(P(A') x P(B') x P(C')). This set spans L rather than S. The missing M direction
must therefore come from cancellation among moving points, not from a set of 17
rank-one points already inside S.

In local holomorphic representatives with nonzero factor limits and a chosen
uniformizer, coefficient poles of order at most two cannot produce M. Indeed,
projection to (A/A') tensor (B/B') tensor (C/C') kills each factor to first order,
while the projection of M is the nonzero tensor

    x11 y11 z11 + x11 y12 z21 + x32 y23 z33 + x33 y33 z33.

Here products abbreviate tensor products of the quotient classes. This excludes
only that low-pole normalization. No universal upper bound on pole order is
known from this package, and higher-order degenerations remain admissible.

## Certification standard

A positive certificate should give an explicit algebraic or Laurent family of
17 decomposable tensors with limiting span S, or a rigorous membership argument
for the indicated closure. An explicit sum converging to M is also sufficient,
with all unwanted coefficients proved to cancel. Numerical residuals alone do
not suffice.

A negative certificate must exclude the full indicated closure. It must allow
all limiting supports in the smaller Segre, arbitrary admissible collisions and
orders, and nonsaturated multigraded limits. Failure of the grid search, failure
of low-order jets, or an obstruction for the saturated support alone is not such
a certificate.

The 87 surviving ordered triples are necessary low-degree data; they are not
87 known degenerations, and they do not prove component membership.
