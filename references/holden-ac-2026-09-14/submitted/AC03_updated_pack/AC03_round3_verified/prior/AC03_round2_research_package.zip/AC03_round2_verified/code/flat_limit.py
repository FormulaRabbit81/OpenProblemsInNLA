"""Exact Grassmann limits of independent polynomial columns at t=0.
Uses constant column operations and removal of a common power of t.
This certifies the limit of the fixed input curves, not all possible curves.
"""
from fractions import Fraction as F
from itertools import product
from borel import echelon
from triples import reduce_vector

def normalized_columns(terms):
    out=[]
    for term in terms:
        v={}
        for aa,bb,cc in product(term['a'],term['b'],term['c']):
            key=(aa[0]+bb[0]+cc[0],3*(aa[2]-1)+aa[3]-1,3*(bb[2]-1)+bb[3]-1,3*(cc[2]-1)+cc[3]-1)
            v[key]=v.get(key,0)+aa[1]*bb[1]*cc[1]
        v={k:F(x) for k,x in v.items() if x};d=min(k[0] for k in v)
        out.append({(k[0]-d,*k[1:]):x for k,x in v.items()})
    return out

def flat_limit(cols,cap=10000):
    piv={};ops=[];nops=0
    for j,col in enumerate(cols):
        v=dict(col);shifts=0;sub=0
        while v:
            nops+=1
            if nops>cap:raise RuntimeError('Termination limit exceeded; possible dependent columns.')
            d=min(k[0] for k in v)
            if d:
                v={(k[0]-d,*k[1:]):x for k,x in v.items()};shifts+=d
            lead={k[1:]:x for k,x in v.items() if k[0]==0}
            p=min(lead)
            if p not in piv:
                c=lead[p];piv[p]={k:x/c for k,x in v.items()}
                ops.append({'column':j,'powers_removed':shifts,'subtractions':sub,'pivot':list(p)})
                break
            c=lead[p];sub+=1
            for k,x in piv[p].items():
                val=v.get(k,0)-c*x
                if val:v[k]=val
                else:v.pop(k,None)
        if not v:ops.append({'column':j,'dependent':True})
    leads=[{k[1:]:x for k,x in v.items() if k[0]==0} for v in piv.values()]
    assert len(echelon(leads))==len(leads)
    return leads,ops

if __name__=='__main__':
    from pathlib import Path
    import json,time
    root=Path(__file__).resolve().parents[1]
    ts=json.loads((root/'certificates/smirnov20.json').read_text())['rank_one_terms'];cols=normalized_columns(ts)
    M={(3*i+j,3*j+k,3*k+i):F(1) for i,j,k in product(range(3),repeat=3)}
    report=[];st=time.time()
    for omit in [None]+list(range(20)):
        cc=[c for i,c in enumerate(cols) if i!=omit]
        leads,ops=flat_limit(cc)
        rem=reduce_vector(M,echelon(leads))
        d={'omitted_summand':None if omit is None else omit+1,'dimension':len(leads),'contains_M3':not rem,'residual_coordinates':len(rem),'operations':ops}
        report.append(d)
        print('omit',omit,'dim',len(leads),'contains',not rem,'residue',len(rem),'seconds',time.time()-st,flush=True)
    (root/'results/smirnov_deletion_test.json').write_text(json.dumps(report,indent=2))
