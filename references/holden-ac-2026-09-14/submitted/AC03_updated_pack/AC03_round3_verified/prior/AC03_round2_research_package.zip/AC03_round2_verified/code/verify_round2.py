#!/usr/bin/env python3
"""Recompute the rank-17 reduction, not a full solution of AC-03.

Usage: python code/verify_round2.py
Outputs are written to results/recomputed/. The supplied certificate tables are
compared to newly computed data; they are not accepted on trust.
"""
from __future__ import annotations
import sys
if not __debug__:
    raise RuntimeError('Run without -O: assertions are part of verification.')
from pathlib import Path
from itertools import product
from fractions import Fraction as F
from collections import Counter
import csv,json,time,random,platform
import sympy as sp
import numpy as np
from borel import enumerate_configs,pair_columns,pair_tests,echelon
from triples import triple_test,reduce_vector
from parameter import symbolic_test
from square import square_test,square_symbolic
from direct_square import direct_square
from span_certificate import verify_common,geometry,serial_basis,M3
from jet_certificate import verify as verify_jets
from flat_limit import normalized_columns,flat_limit

ROOT=Path(__file__).resolve().parents[1]
CERT=ROOT/'certificates';OUT=ROOT/'results/recomputed'
OUT.mkdir(parents=True,exist_ok=True)

def read(name):return json.loads((CERT/name).read_text())
def write(name,data):
    (OUT/name).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
def equal(a,b):return json.loads(json.dumps(a))==json.loads(json.dumps(b))

def consistency():
    rng=random.Random(17087)
    for rows,cols in [(7,12),(12,7),(20,25),(25,20),(14,14)]:
        for _ in range(3):
            a=[[rng.randrange(-2,3) if rng.random()<.35 else 0 for _ in range(cols)] for _ in range(rows)]
            vectors=[{i:F(a[i][j]) for i in range(rows) if a[i][j]} for j in range(cols)]
            assert len(echelon(vectors))==sp.Matrix(a).rank()
    return {'independent_SymPy_rank_comparisons':15}

def enumerate_pairs():
    allconfs=list(enumerate_configs(8));assert len(allconfs)==343
    pointcharts=sum('Fgen' not in c for c in allconfs);assert pointcharts==314
    pairrows=[];symbolic=[];passed=[];squarefamilies=[];sur=[];direct=[]
    for ident,conf in enumerate(allconfs):
        kernels=pair_tests(conf)
        pairrows.append({'id':ident,'config':conf,'pair_kernels':kernels})
        if 'Fgen' in conf:
            row={'id':ident,'config':conf,'tests':[symbolic_test(conf,f) for f in (0,1)]}
            for test in row['tests']:
                assert all(f in ('t - 2','2*t - 1') for f in test['nonconstant_factors'])
            assert kernels==tuple(test['generic_kernel'] for test in row['tests'])
            symbolic.append(row)
        if min(kernels)<17:continue
        sq=square_test(conf)
        rec={'id':ident,'config':conf,'pair_kernels':kernels,'square':sq};passed.append(rec)
        if 'Fgen' in conf:
            ps=square_symbolic(conf)
            assert all(f in ('t - 2','2*t - 1') for f in ps['nonconstant_factors'])
            assert ps['generic_codimension']==sq['codimension']<289
            squarefamilies.append(ps)
        if sq['passes']:
            assert 'Fgen' not in conf
            sur.append(rec)
            dd=direct_square(conf);assert dd['codimension']==sq['codimension']
            direct.append({'id':ident,**dd})
    assert len(symbolic)==29 and len(passed)==137 and len(squarefamilies)==11 and len(sur)==55
    assert equal(passed,read('square17_all.json'))
    assert equal(squarefamilies,read('square17_symbolic.json'))
    assert equal(sur,read('square17_survivors.json'))
    write('all_pair_charts.json',pairrows);write('pair_parameter_smith.json',symbolic)
    write('square_parameter_smith.json',squarefamilies);write('direct_square_checks.json',direct)
    print('Pair classification: 343 charts -> 137 pair-test charts -> 55 fixed square survivors.',flush=True)
    return sur

def old_four():
    candidates=[(('N','R','0','L','E','0','0','0','0'),F(3)),
                (('Fgen','E','0','L','E','0','0','0','0'),F(-1)),
                (('Fgen','R','0','E','E','0','0','0','0'),F(-1)),
                (('Fgen','R','0','L','0','0','0','0','0'),F(-1))]
    out=[]
    for i,(conf,t) in enumerate(candidates):
        a=square_test(conf,t);b=direct_square(conf,t)
        assert a['codimension']==b['codimension']==[278,276,276,276][i]<289
        out.append({'old_candidate':i,'parameter':str(t),'config':conf,'dual':a,'direct':b})
    write('old_four_exclusions.json',out)
    print('All four old cyclic candidates excluded by two independent square formulations.',flush=True)
    return out

def triples(sur):
    cs=[tuple(s['config']) for s in sur];n=len(cs);seen=set();hist=Counter();rows=[];survivors=[]
    for i in range(n):
        for j in range(i,n):
            for k in range(i,n):
                if j==i and k!=i:continue
                rotations={(i,j,k),(j,k,i),(k,i,j)}
                assert not(seen & rotations);seen.update(rotations)
                d=triple_test(cs[i],cs[j],cs[k]);mult=len(rotations);hist[d]+=mult
                ids=[sur[l]['id'] for l in (i,j,k)];rows.append([*ids,d,mult])
                if d>=17:survivors.append({'ids':ids,'indices':[i,j,k],'intersection':d,'orbit_size':mult})
        if i%10==0:print('Triple orbit scan',i,'of',n,'ordered triples covered',len(seen),flush=True)
    assert len(seen)==n**3==166375 and len(survivors)==29
    assert sum(s['orbit_size'] for s in survivors)==87 and max(hist)==17
    assert equal(survivors,read('square17_triple_survivors.json'))
    with (CERT/'square17_triples.csv').open(newline='') as f:
        expected=list(csv.reader(f));assert expected[0]==['a','b','c','intersection','orbit_size']
        assert rows==[[int(x) for x in row] for row in expected[1:]]
    assert hist==Counter({int(k):v for k,v in read('square17_triple_summary.json')['histogram'].items()})
    checks=[]
    for row in survivors:
        configs=[cs[i] for i in row['indices']]
        checks.append({'ids':row['ids'],**verify_common(configs)})
    assert all(row['ids'][:2]==[11,29] for row in survivors)
    write('common_span_checks.json',checks);write('common_span_basis.json',serial_basis())
    write('geometric_obstruction.json',geometry())
    summary={'ordered_triples':len(seen),'cyclic_orbits_checked':len(rows),'histogram':dict(hist),
             'surviving_orbits':29,'surviving_ordered_triples':87,'survivor_dimension':17}
    write('triple_summary.json',summary)
    print('All 166375 ordered triples covered; 87 pass, with one common plane up to rotation.',flush=True)
    return summary

def deletion():
    terms=read('smirnov20.json')['rank_one_terms'];columns=normalized_columns(terms)
    reports=[];first=None;full=None
    for omit in [None]+list(range(20)):
        cols=[v for i,v in enumerate(columns) if i!=omit]
        leads,ops=flat_limit(cols);piv=echelon(leads)
        contains=not reduce_vector(M3,piv)
        assert len(leads)==20-(omit is not None)
        assert contains==(omit is None)
        if omit is None:full=piv
        else:
            if first is None:first=piv
            assert all(not reduce_vector(v,first) for v in leads)
            assert all(not (set(v)&set(M3)) for v in leads)
            assert all(not reduce_vector(v,full) for v in leads)
        reports.append({'omitted_summand':None if omit is None else omit+1,
                        'dimension':len(leads),'contains_M3':contains,'operations':ops})
    assert len(echelon([*first.values(),M3]))==20
    write('deletion_certificate.json',{'all_19_limits_equal':True,'all_19_limits_disjoint_from_M3_support':True,
          'uniform_separating_coordinate':[0,0,0],
          'common_19_basis':[[list(k)+[v.numerator,v.denominator] for k,v in sorted(col.items())] for col in first.values()],
          'runs':reports})
    print('Smirnov deletion: all 20 nineteen-curve limits are the same M3-excluding plane.',flush=True)
    return {'tested_deletions':20,'all_excluded':True,'common_19_plane':True}

def main():
    start=time.time();summary={'status':'VERIFIED PARTIAL RESULTS; AC-03 NOT SOLVED',
                            'Python':platform.python_version(),'SymPy':sp.__version__,'NumPy':np.__version__}
    summary['consistency']=consistency()
    summary['first_jets']=verify_jets(CERT/'independent_first_jets.json')
    sur=enumerate_pairs();old_four();summary['triples']=triples(sur);summary['deletion']=deletion()
    summary['elapsed_seconds']=round(time.time()-start,3)
    write('run_summary.json',summary)
    print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__':main()
