"""Universal one-parameter pair tests using Smith form over Q[t]."""
from borel import *
from triples import reduce_vector
import sympy as sp
from sympy.matrices.normalforms import smith_normal_form
from sympy.polys.domains import QQ

t=sp.Symbol('t')

def wedge(v,z,factor):
    out={}
    for(a,b),c in v.items():
        w=(a,b)[factor];other=(b,a)[factor]
        if z!=w:out[(min(z,w),max(z,w),other)]=(1 if z<w else -1)*c
    return out

def symbolic_test(conf,factor):
    cc0=pair_columns(conf,F(0));cc1=pair_columns(conf,F(1))
    const=[];variable=[]
    for v0,v1 in zip(cc0,cc1):
        if v0==v1:
            const.extend(wedge(v0,z,factor)for z in range(9))
        else:
            variable.extend((wedge(v0,z,factor),wedge(v1,z,factor))for z in range(9))
    piv=echelon(const);R=len(piv)
    variable=[(reduce_vector(v0,piv),reduce_vector(v1,piv))for v0,v1 in variable]
    rows=sorted(set().union(*(set(v0)|set(v1)for v0,v1 in variable)))
    mat=sp.Matrix([[sp.Rational(v0.get(row,0))+t*sp.Rational(v1.get(row,0)-v0.get(row,0))for v0,v1 in variable]for row in rows])
    if mat.rows:
        snf=smith_normal_form(mat,domain=QQ.poly_ring(t))
        diag=[sp.factor(snf[i,i])for i in range(min(snf.shape))if snf[i,i]!=0]
    else:diag=[]
    return {'fixed_rank':R,'shape':list(mat.shape),'smith_diagonal':[str(d)for d in diag],
      'generic_kernel':9*len(cc0)-R-len(diag),'nonconstant_factors':sorted(set(str(f)for d in diag for f,e in sp.factor_list(d)[1]))}



def full_intersection_matrix_columns(conf,par):
    E=pair_columns(conf,par);out=[]
    for mode in range(3):
        for v in E:
            for z in range(9):
                d={}
                for (a,b),val in v.items():
                    if mode==0:
                        d[0,a,b,z]=val;d[1,a,b,z]=val
                    elif mode==1:
                        d[0,z,a,b]=-val
                    else:
                        d[1,b,z,a]=-val
                out.append(d)
    return out

def cyclic_symbolic(conf):
    cc0=full_intersection_matrix_columns(conf,F(0))
    cc1=full_intersection_matrix_columns(conf,F(1))
    const=[v0 for v0,v1 in zip(cc0,cc1)if v0==v1]
    variable=[(v0,v1)for v0,v1 in zip(cc0,cc1)if v0!=v1]
    piv=echelon(const)
    variable=[(reduce_vector(v0,piv),reduce_vector(v1,piv))for v0,v1 in variable]
    rows=sorted(set().union(*(set(v0)|set(v1)for v0,v1 in variable)))
    mat=sp.Matrix([[sp.Rational(v0.get(row,0))+t*sp.Rational(v1.get(row,0)-v0.get(row,0))for v0,v1 in variable]for row in rows])
    if mat.rows:
        snf=smith_normal_form(mat,domain=QQ.poly_ring(t))
        diag=[sp.factor(snf[i,i])for i in range(min(snf.shape))if snf[i,i]!=0]
    else:diag=[]
    return {'config':conf,'fixed_rank':len(piv),'shape':list(mat.shape),
        'smith_diagonal':[str(d)for d in diag], 'generic_intersection':len(cc0)-len(piv)-len(diag),
        'nonconstant_factors':sorted(set(str(f)for d in diag for f,e in sp.factor_list(d)[1]))}

