"""Independent direct polynomial multiplication for the partial square test.

Unlike square.py, this module does not construct a wedge-wedge matrix.
It first computes I = E^perp, then multiplies its polynomial generators.
All coefficients and row reductions are exact fractions.
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import product
from borel import echelon, pair_columns
from triples import reduce_vector

def annihilator(E, ambient):
    piv=echelon(E)
    for p in sorted(piv,reverse=True):
        for q in sorted(piv):
            if q>=p:break
            d=piv[q].get(p,0)
            if d:
                for k,a in piv[p].items():
                    v=piv[q].get(k,0)-d*a
                    if v:piv[q][k]=v
                    else:piv[q].pop(k,None)
    out=[{k:F(1),**{p:-v[k] for p,v in piv.items() if v.get(k)}}
         for k in ambient if k not in piv]
    assert all(sum(q.get(k,0)*a for k,a in v.items())==0 for q in out for v in E)
    assert len(out)+len(E)==len(ambient)
    return out

def direct_square(conf,par=F(3)):
    E=pair_columns(conf,par)
    I=annihilator(E,list(product(range(9),repeat=2)))
    monomials=set();nonmonomials=[];n=0
    for i,f in enumerate(I):
        for g in I[i:]:
            v={}
            for (a,b),x in f.items():
                for (c,d),y in g.items():
                    k=(min(a,c),max(a,c),min(b,d),max(b,d))
                    v[k]=v.get(k,0)+x*y
            v={k:x for k,x in v.items() if x}
            if len(v)==1:monomials.update(v)
            elif v:nonmonomials.append(v)
            n+=1
    reduced=[{k:x for k,x in v.items() if k not in monomials} for v in nonmonomials]
    remaining=len(echelon(reduced))
    rank=len(monomials)+remaining
    return {'products':n,'monomial_rank':len(monomials),'remaining_rank':remaining,
            'rank':rank,'ambient':2025,'codimension':2025-rank}
