# AC-03 — Verified round-two research extension

**Status: PARTIAL. The exact complex border rank is not determined.**
The verified interval remains **17 ≤ border-rank(M3) ≤ 20**. This package does
not contain a complete solution or an improved numerical bound.

Read **report.pdf** for the 17-page mathematical argument and explicit audit
boundaries. Its editable source is **report.tex**, with three generated table
files alongside it.

## Main results added to the previous package

The four previous Borel-fixed candidates under cyclic equality all fail the
stronger necessary square test: their codimensions are 278, 276, 276, 276,
whereas 289 is required.

Without cyclic equality, exhaustive characteristic-zero parameter treatment
leaves 55 fixed pair spaces and no continuous families. All 166,375 ordered
triples are covered; precisely 87 triples in 29 cyclic orbits pass the
three-factor intersection test. Every surviving intersection is 17-dimensional.

Up to cyclic rotation, every surviving intersection is the same explicit space:

    S = span(M3) ⊕ A' ⊗ B' ⊗ C'
    A' = span(x21, x31)
    B' = span(y21, y22, y31, y32)
    C' = span(z31, z32)

The report proves the computer-assisted equivalence:

    border-rank(M3) = 17
    ⇔ S is a limit of 17-dimensional spans of 17 decomposable tensors.

This equivalence reduces the question to one explicit span-limit membership
problem. **It does not decide that membership problem.**

Any normalized completion through that plane must have at least one coefficient
with pole order at least three. This is not a universal exclusion of higher-order
degenerations.

Separately, all twenty single deletions from the fixed Smirnov summand curves
have the same 19-dimensional limiting span, which excludes M3. Arbitrary
reweighting of any one fixed 19-subset cannot repair this. Other 19-term curves
are not excluded.

## Reproduce the checks

Run from the extracted package directory with Python 3.10 or newer:

```bash
python -m pip install -r requirements.txt
python code/verify_all.py
```

This safely unpacks the retained previous archive into a temporary directory,
runs its exact lower/upper verifiers and nine consistency tests, then runs the
new verifier. The recorded environment was Python 3.13.5, SymPy 1.14.0, and
NumPy 2.3.5. No internet access is used during verification.

To run only this round's checks:

```bash
python code/verify_round2.py
```

Do not use Python's `-O` mode; the verifiers intentionally refuse it. Outputs go
to `results/recomputed/`; fixed tables under `certificates/` are not overwritten.

The final recorded results are in `results/full_run_summary.json`, with detailed
logs in `results/prior_full_run.log` and `results/round2_full_run.log`.
A clean-copy rerun is also recorded in `results/clean_copy_validation.json`.

To compile the report:

```bash
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

## Audit and package map

`code/` contains exact enumeration, parameter Smith forms, the wedge square
map, a separate direct polynomial multiplication check, span certificates,
integer first-jet minors, and polynomial-column Grassmann limits.

`certificates/` contains the original new-result tables, all 55,495 cyclic
orbit records covering 166,375 ordered triples, the Smirnov coefficients, and
the two explicit integer first-jet minors.

`results/` contains recomputed certificates and verification logs. All 29
surviving intersection dimensions are also checked with an independent block
matrix, and 15 small rational rank calculations are checked against SymPy.

`prior/AC03_research_package.zip` is the unchanged previous user-provided
research package. It retains the earlier known-bound verifications.

`research/` contains the research notes and an explicitly exploratory snapshot.
Finite-field enumerations and failed searches in that snapshot are **not**
part of the exhaustive complex proof. Some scripts are exploratory drivers;
use the main verifier above for the supported proof workflow.

`MANIFEST.sha256` hashes all delivered files other than itself.
`code/check_manifest.py` verifies it without external dependencies. Run this
integrity check before rerunning the computations: a rerun intentionally rewrites
result files and timings, so their original delivery hashes will then change.

## Scope and status

The report is computer-assisted mathematics, not a proof-assistant
formalization or independent peer review. The finite classifications and
exclusions are deductions of this package; publication-level novelty has not
been independently established. No repository was edited.

A valid 17-term degeneration with limiting span S would finish the problem at
17. Excluding S from the indicated closure would establish the stronger lower
bound 18, but would not alone determine the exact value. Neither missing step
is supplied here.
