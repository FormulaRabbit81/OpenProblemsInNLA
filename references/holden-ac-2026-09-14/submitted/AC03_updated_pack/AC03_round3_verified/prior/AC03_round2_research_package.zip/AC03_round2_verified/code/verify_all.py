#!/usr/bin/env python3
"""Verify the retained prior package and this round's exact certificates."""
from __future__ import annotations
import sys
if not __debug__:
    raise RuntimeError('Run without -O: assertions are verification checks.')
from pathlib import Path
import tempfile,zipfile,subprocess,time,json,hashlib
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]

def safe_extract(archive:Path,destination:Path)->None:
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:raise RuntimeError('Prior archive failed CRC validation.')
        for item in z.infolist():
            target=(destination/item.filename).resolve()
            if not target.is_relative_to(destination.resolve()):
                raise RuntimeError('Unsafe archive path: '+item.filename)
        z.extractall(destination)

def execute(script:Path,cwd:Path,log:Path)->None:
    with log.open('w') as stream:
        result=subprocess.run([sys.executable,'-u',str(script)],cwd=cwd,stdout=stream,stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f'{script.name} failed. See {log}.')

def main()->None:
    start=time.time();results=ROOT/'results';results.mkdir(exist_ok=True)
    archive=ROOT/'prior/AC03_research_package.zip'
    with tempfile.TemporaryDirectory(prefix='ac03_prior_') as temp:
        directory=Path(temp);safe_extract(archive,directory)
        prior=directory/'AC03_verified_research'
        if not (prior/'code/verify_all.py').is_file():raise RuntimeError('Prior verifier not found in retained archive.')
        print('Verifying retained lower/upper certificates and original consistency tests.',flush=True)
        execute(prior/'code/verify_all.py',prior,results/'prior_full_run.log')
        (results/'prior_run_summary.json').write_text((prior/'results/run_summary.json').read_text())
    print('Verifying all new rank-17 reductions and deletion certificates.',flush=True)
    execute(ROOT/'code/verify_round2.py',ROOT,results/'round2_full_run.log')
    summary={'status':'PASS: VERIFIED PARTIAL RESULTS, NOT A SOLUTION OF AC-03',
             'finished_utc':datetime.now(timezone.utc).isoformat(),
             'elapsed_seconds':round(time.time()-start,3),
             'prior_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
             'prior':json.loads((results/'prior_run_summary.json').read_text()),
             'round2':json.loads((results/'recomputed/run_summary.json').read_text())}
    (results/'full_run_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(summary['status'],flush=True)
if __name__=='__main__':main()
