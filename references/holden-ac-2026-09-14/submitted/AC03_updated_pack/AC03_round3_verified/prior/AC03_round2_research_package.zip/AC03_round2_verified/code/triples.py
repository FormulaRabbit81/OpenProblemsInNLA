"""Exact (111) intersection tests for cyclic coordinate copies of pair spaces."""
from borel import *
from functools import lru_cache

def reduce_vector(v,pivots):
    v={i:F(a) for i,a in v.items() if a}
    # Traverse all pivots, not merely while min(v) is pivot: nonpivots survive.
    for p,vc in sorted(pivots.items()):
        d=v.get(p,0)
        if d:
            for i,a in vc.items():
                w=v.get(i,0)-d*a
                if w:v[i]=w
                elif i in v:del v[i]
    return v

@lru_cache(None)
def projection(config,t=F(3)):
    piv=echelon(pair_columns(config,t))
    return {(a,b):reduce_vector({(a,b):F(1)},piv)for a,b in product(range(9),repeat=2)}

@lru_cache(None)
def triple_projection(source,dest,kind,source_t=F(3),dest_t=F(3)):
    # source E_AB tensor C. Reduce slices against E_BC (kind0) or E_CA (kind1).
    proj=projection(dest,dest_t)
    cols=[]
    for v in pair_columns(source,source_t):
        for c in range(9):
            out=defaultdict(F)
            for (a,b),coef in v.items():
                for (u,w),d in proj[(b,c)if kind==0 else(c,a)].items():
                    out[(kind,a if kind==0 else b,u,w)]+=coef*d
            cols.append({k:v for k,v in out.items()if v})
    return tuple(cols)

def triple_test(ca,cb,cc,ta=F(3),tb=F(3),tc=F(3)):
    b=triple_projection(ca,cb,0,ta,tb)
    c=triple_projection(ca,cc,1,ta,tc)
    assert len(b)==len(c)
    return len(b)-rank([{**x,**y}for x,y in zip(b,c)])

