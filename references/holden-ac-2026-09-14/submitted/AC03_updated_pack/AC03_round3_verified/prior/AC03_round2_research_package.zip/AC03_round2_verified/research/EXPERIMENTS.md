# Additional calculations and their limits

These are research results and failed tests, not a complete solution of AC-03.
The supported main proof workflow is `../code/verify_all.py`. The separate
`exploratory_snapshot.zip` preserves the development drivers and their recorded
outputs. The two kinds of material must not be conflated: exact arithmetic on a
finite set of examples does not make that set exhaustive over the complex numbers.

## 1. Tests beyond the pair-square classification

**Cubes of pair ideals.** `higher_pair_power.py` directly multiplies the
annihilating bilinear forms. At both of the two mandatory pair spaces E11 and E29,
the degree-(3,3) quotient by the span of triple products has dimension 3550.
At 17 points of P8 x P8, second-jet conditions number at most
17 * binomial(18,2) = 2601. Even complete independence of those conditions would
therefore not rule out these pair spaces with this particular test. The recorded
values for E285 and E342 are 3756 and 3880, respectively.

**Products with the common triple ideal.** `ab_abc_product.py` independently
forms the annihilator of the explicit 17-plane S, then computes
I110 * I111 and its cyclic counterparts. There are 31 checks: E11 in AB,
E29 in BC, and all 29 possible CA pair spaces. Their degree-(2,2,1), or cyclic,
quotient dimensions range from 588 to 670. They exceed the 425 first-jet
conditions supplied by the integer certificate in the main package. Thus this
test does not eliminate any surviving triple. It is not an additional exclusion.

**Products of all three pair ideals.** `three_pair_product.py` forms
I110 * I011 * I101 in degree (2,2,2). Across the 29 canonical triples the exact
quotient dimensions range from 7691 to 8070, in an ambient space of dimension
45^3 = 91125. The number of second-jet conditions at 17 points of P8 x P8 x P8
is at most 17 * binomial(26,2) = 5525. The test cannot exclude these triples even
at that maximal threshold. Independence of those 5525 second jets has NOT been
certified here, and is not needed for this negative conclusion about the test.

**The square of I111.** `triple_square.py` gives quotient dimension 1110 in
degree (2,2,2). This is above the 425 first-jet threshold. The calculation
therefore supplies no exclusion of S from the required span-limit closure.

## 2. Koszul and related rank tests

`koszul.py` computes exact Koszul ranks of pair-space inclusion tensors. For
E11, exterior degree two gives ranks 468 and 458 in the two orientations,
against the rank-17 threshold 17 * 28 = 476. For E29 the orientations reverse.
The other recorded cases also do not violate a rank-17 threshold.

`span_tensor_koszul.py` tests three-factor groupings of the four-factor tensor
Q defined in Section 6.1 of the report. With A or C as the singleton factor,
exterior degree 15 in the 17-dimensional factor has rank 272, exactly the
threshold 17 * 16. Equality in a necessary rank inequality is not a border-rank
upper certificate. No grouping tested here proves border rank greater than 17.

`kk_capacity.py` computes weight-block capacity bounds for a particular
Kronecker-Koszul construction. The applicable capacity is already below the
rank-17 rejection threshold, so this specific construction cannot provide the
missing exclusion. This is not a negative statement about every possible
nonlinear or Kronecker-Koszul method.

The `koszul_projected.log` file is an **incomplete** exploratory run. Its driver
was stopped before all intended cases completed; there is no completed JSON
certificate for that run. Its observed ranks are not an exhaustive result.

## 3. Pure quadratic pieces and coupled square conditions

`pure_borel_explore.py` enumerates candidate Borel-stable 17-dimensional spaces
in Sym^2(C9) over finite fields. It requires one of two particular necessary
nine-dimensional cores extracted from the pair prolongations. It found 2138
candidates over F5 and 3082 over F7. These counts are finite-field counts, not
counts of complex candidates. The same issue applies to the 700 pure-A
candidates over F5 from `pureA_explore.py`.

The recorded rational lifts are checked for Lie-generator stability before
being used in additional rational computations. This protects against accepting
a lift that is stable only in the sampled characteristic, but does not turn the
finite sample into a complete complex parameter analysis.

For the F5-derived B candidates, `pure_tests.py` records pure cubic tests and
a stronger degree-(1,2,1) product test. Some choices pass; none of them is claimed
to complete an apolar ideal or to belong to the component of reduced-point
limits. The file `pure5_full_mixed_285.json` contains the recorded results for
one fixed CA candidate, not all 29 CA candidates simultaneously.

`joint_square_explore.py` tests the full degree-(2,2,0) square condition including
I200 * I020. A seeded sample of 3000 rational A/B choices contains 1074 passing
records. Sampling can repeat a choice, so this is not asserted to be 1074 distinct
points or components. These pairs have not been completed consistently through
all three factors and all required degrees. In particular, the sample is not
evidence sufficient to claim border rank 17.

`prolong.py` and `tangent.py` supply supporting exploratory linear algebra.
The tangent dimensions in `tangent_explore.log` concern a truncated incidence
problem, not the tangent space to the full reduced-point component. They cannot
establish smoothability or component membership.

## 4. A restricted third-order construction search

The base configuration consists of the 16 coordinate points of a 2 x 4 x 2
product grid and their product-of-sums point. This gives a dependent set in L,
the 16-dimensional block in the report's S. The driver `grid_cubic_search.py`
examines a restricted family of first normal jets satisfying certain
second-normal compatibility conditions.

The recorded search consists of 10,000 seeded trials over F101. The normal-image
dimension histogram is:

    dimension 0: 9146 trials
    dimension 1:  812 trials
    dimension 2:   42 trials

No trial realizes the four-coordinate normal component of M3 displayed in
Section 7 of the report. The finite sample is not exhaustive, the restricted jet
parametrization is not exhaustive, and the choice of grid-plus-sum base points
has not been justified without loss of generality. In particular, neither a
general third-order obstruction nor a higher-order obstruction is proved by
this search.

## 5. What was retained as proof

The report promotes only results with a stated mathematical reduction and
complete relevant computation: the strengthened pair classification, all
ordered triples, the common-plane equivalence, the elementary quotient
obstructions, and the fixed-Smirnov-curve deletion certificate. The main verifier
also reruns the earlier published-bound certificates.

The supplementary calculations above are preserved to prevent repeating failed
approaches and to identify the precise extent of the searches. None supplies the
missing membership or nonmembership assertion S in G17(X).
