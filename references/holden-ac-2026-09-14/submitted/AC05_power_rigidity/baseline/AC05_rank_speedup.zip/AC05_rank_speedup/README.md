# AC-05: Uniform bounds from rank-one completion

**Status: partial results, not a full solution of AC-05.**

The new report proves the following over the complex numbers, with corresponding tensor factors grouped:

- Every tensor in C^3 ⊗ C^3 ⊗ C^3 has asymptotic rank strictly below **4.64429449**.
- Every tensor in that space of border rank at most four has asymptotic rank strictly below **3.92304**.
- The rank-five/rank-one scalar recursion developed in the report admits the feasible value four for every seed power and every number of squaring rounds. That is a limitation of these particular scalar inequalities, not an asymptotic-rank lower bound or a counterexample.

Neither upper-bound theorem assumes tightness. Neither establishes the value three required by AC-05 for concise tight tensors. No proof of the universal all-dimension target is claimed.

## Start here

Read `report/AC05_rank_speedup.pdf` (16 pages). Editable LaTeX is beside it. `STATUS.md` states the exact remaining gap and the evidence boundary. `SOURCES.md` records the primary sources and inherited reports.

The key new finite certificate is a nonzero 27-by-27 Jacobian minor, determinant -3380083200, proving that a rank-one-completion family is dominant in the full 27-dimensional tensor space. The package also contains a completely specified 26-term rational seed pencil and exact rational certificates for both asymptotic constants.

The proof uses established spectral duality and the full/isolated-slice speedup framework. No priority, external peer-review, or proof-assistant verification claim is made. The complete geometric and asymptotic arguments are in the report; passing the finite tests is not a substitute for them.

## Reproduce the finite certificates

Python 3.10 or later is needed. The recorded run used Python 3.13.5.

The independent replay requires only the Python standard library:

```bash
python code/replay_certificates.py
```

To regenerate the certificates using the tested SymPy version:

```bash
python -m pip install -r requirements.txt
python code/generate_certificates.py
python code/replay_certificates.py
```

To rerun the original inherited archive:

```bash
python code/audit_baseline.py
```

The recorded results are **36 generator check groups, 42 replay check groups, and 123 original-archive checks passed**. The replay separately reconstructs the Jacobian and the grouped-square tensor. It checks every rational-power enclosure by integer powers, rather than trusting numerical roots. Four negative tests confirm rejection of corrupted data.

The later 21-page continuation's full test suite was not rerun; only its report was retrieved and read. The new main bounds do not depend on its dimension-three component classification.

## Package layout

`report/` contains the PDF and LaTeX. `code/` contains certificate generation, standard-library replay, and the original-archive audit. `certificates/` contains exact rational, integer and symbolic witnesses. `results/` contains recorded outputs. `baseline/` preserves the original ZIP byte for byte and the later continuation PDF.

The certificate replay checks finite premises. It is not an algorithm that outputs a rank-(4.64429449)^m decomposition of every tensor power. The asymptotic upper bounds use spectral duality and closure transfer, as explicitly proved or attributed in the report. No effective threshold for all tensor powers, numerical-stability result, or practical running-time benchmark is claimed.

## Rebuild the report

A pdfLaTeX installation with the packages declared in the source is required:

```bash
bash build_report.sh
```

The script removes intermediate build files and retains the final build log. `MANIFEST.sha256` records hashes of the delivered files; regenerate it after intentional changes. The original baseline archive has SHA-256:

```text
6d6780cc6a8a7a6594b01eb0e25bf28fda65f4433c2c1b0bac7cd3d3469739c9
```

No repository content or status was changed.
