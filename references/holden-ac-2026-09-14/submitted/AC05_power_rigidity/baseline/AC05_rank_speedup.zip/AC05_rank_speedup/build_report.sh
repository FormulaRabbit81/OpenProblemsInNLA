#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p results
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
for pass in 1 2 3; do
  if ! pdflatex -interaction=nonstopmode -halt-on-error -output-directory="$work" report/AC05_rank_speedup.tex >"$work/pass.log"; then
    tail -60 "$work/pass.log" >&2
    cp "$work/pass.log" results/latex_build_failure.log
    exit 1
  fi
done
cp "$work/AC05_rank_speedup.pdf" report/AC05_rank_speedup.pdf
cp "$work/AC05_rank_speedup.log" results/latex_build.log
printf 'Created report/AC05_rank_speedup.pdf\n'
