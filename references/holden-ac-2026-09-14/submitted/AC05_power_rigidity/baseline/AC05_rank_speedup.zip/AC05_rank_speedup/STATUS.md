# Status and exact claim boundary

## Exact target not established

AC-05 asks whether every concise tight complex tensor in (C^d)^(tensor 3) has asymptotic rank d. The product is the grouped/corresponding-factor tensor product. This package supplies neither a universal affirmative proof nor a counterexample.

For the dimension-three hard tensors retained from the later continuation,

```text
U = e002 + e021 + e111 + e120 + e201 + e210
F_lambda = e012 + e021 + e102 + e111 + e120 + e201 + lambda e210,
```

the new bounds are:

```text
3 <= asymptotic_rank(U) < 3.92304
3 <= asymptotic_rank(F_1) < 3.92304
3 <= asymptotic_rank(F_lambda) < 4.64429449  (lambda != 0).
```

Neither `asymptotic_rank(U) = 3` nor `asymptotic_rank(F_tau) = 3` for a transcendental tau is proved here. The inherited report's dimension-three completion criterion remains a reduction, not a resolution. No advance to the equality in arbitrary dimensions is claimed beyond the special cases already proved in the inherited packages.

## What is proved in the new report

Theorem 1.1 gives two uniform upper bounds, including the whole 3-by-3-by-3 tensor space. Proposition 3.1 gives a dominant explicit rank-one-completion family. Lemma 4.1 gives the full/isolated extraction with rational maps. Theorem 5.1 proves the repeated-squaring recurrence. Sections 7 and 8 turn it into exact certified constants. Theorem 10.1 proves the all-seed/all-round feasible-value-four obstruction for the rank-five/rank-one scalar relaxation.

The obstruction does not construct a spectral point, give a lower bound of four for any tensor, or rule out different seed constructions or additional relations. In particular it does not refute AC-05.

## Dependencies and checks

The asymptotic spectrum duality theorem and its behavior on matrix slices are established inputs, cited to Alman–Li's presentation of Strassen's theory. The report explicitly distinguishes the matrix-multiplication asymptotic-subrank input from flattening lower bounds. The closure-transfer argument is included with a proof and a reference to the closed-sublevel theorem.

The Jacobian minor is checked by two implementations. The degree-two seed pencil is checked at every core coefficient and in every cancellation block. The two constants have rational certificates with no floating-point acceptance criteria. The bound on border-rank-four tensors covers all spectral parameters in [2/3,1] using 17 exact intervals; it does not assume that a numerical maximum occurs at 2/3.

All recorded new finite checks and the original archive's 123 checks pass. Only the later continuation PDF was retrieved; its full test suite was not rerun. The main new bounds are independent of that report's component classification.

There has been no independent external mathematical audit and no proof-assistant kernel check. Separate checker implementation is not independent authorship. Repository status was not modified. The combined package supports a partial-results submission, not `SOLUTION CLAIMED`, `SOLVED`, or `LEAN VERIFIED`.
