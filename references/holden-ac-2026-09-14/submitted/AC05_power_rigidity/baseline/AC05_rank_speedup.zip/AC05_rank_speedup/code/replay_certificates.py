#!/usr/bin/env python3
"""Independently replay finite AC-05 certificates using the standard library.

This program does not import the generator, SymPy, NumPy, or an interval package.
It reconstructs the Jacobian and the seed tensor, checks determinants and the
Laurent cancellation blocks, and verifies every root enclosure by integer powers.
It also rejects deliberately corrupted matrix, root, and coverage certificates.
The geometric and asymptotic arguments remain mathematical proofs in the report.
"""
from __future__ import annotations
import copy
import json
import platform
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations, product
from pathlib import Path
from time import perf_counter

ROOT = Path(__file__).resolve().parents[1]
CERTS = ROOT / "certificates"

class Checker:
    def __init__(self, record: bool = True) -> None:
        self.record = record
        self.checks: list[dict[str, object]] = []
    def require(self, name: str, truth: bool) -> None:
        if not truth:
            raise AssertionError(name)
        if self.record:
            self.checks.append({"name": name, "passed": True})


def load(name: str) -> dict:
    return json.loads((CERTS / name).read_text())

def matrix(rows: list[list[str | int]]) -> list[list[F]]:
    if not rows or len({len(row) for row in rows}) != 1:
        raise ValueError("A nonempty rectangular matrix is required")
    return [[F(v) for v in row] for row in rows]

def tr(M): return [list(row) for row in zip(*M)]
def mm(A,B):
    if len(A[0]) != len(B): raise ValueError("Matrix dimensions disagree")
    return [[sum((a*b for a,b in zip(row,col)),F(0)) for col in zip(*B)] for row in A]
def diag(xs): return [[F(v) if i==j else F(0) for j in range(len(xs))] for i,v in enumerate(xs)]
def zeros(n,m): return [[F(0)]*m for _ in range(n)]
def columns(M,cols): return [[row[j] for j in cols] for row in M]
def plus(A,B): return [[a+b for a,b in zip(ar,br)] for ar,br in zip(A,B)]
def kron(A,B):
    return [[a*b for a in ar for b in br] for ar in A for br in B]

def determinant(M):
    if len(M) != len(M[0]): raise ValueError("A square matrix is required")
    A = [row[:] for row in M]
    answer=F(1)
    for k in range(len(A)):
        p=next((p for p in range(k,len(A)) if A[p][k]),None)
        if p is None:return F(0)
        if p!=k:A[p],A[k]=A[k],A[p];answer=-answer
        pivot=A[k][k];answer*=pivot
        for i in range(k+1,len(A)):
            ratio=A[i][k]/pivot
            for j in range(k+1,len(A)):A[i][j]-=ratio*A[k][j]
            A[i][k]=F(0)
    return answer

def rank(M):
    A=[row[:] for row in M];r=0
    for j in range(len(A[0])):
        p=next((p for p in range(r,len(A)) if A[p][j]),None)
        if p is None:continue
        A[r],A[p]=A[p],A[r]
        for i in range(r+1,len(A)):
            q=A[i][j]/A[r][j]
            for k in range(j,len(A[0])):A[i][k]-=q*A[r][k]
        r+=1
        if r==len(A):break
    return r

def tensor(A,B,C):
    return [sum((A[i][h]*B[j][h]*C[k][h] for h in range(len(A[0]))),F(0))
            for i in range(len(A)) for j in range(len(B)) for k in range(len(C))]

def dominance(cert,check):
    X,C=matrix(cert["X"]),matrix(cert["C"])
    A6=[row+x for row,x in zip(diag([1]*3),X)]
    B6=[[-x for x in row]+unit for row,unit in zip(tr(X),diag([1]*3))]
    A,B=columns(A6,range(5)),columns(B6,range(5))
    T=tensor(A,B,C)
    check.require("dominance: factor reconstruction",A==matrix(cert["A"]) and B==matrix(cert["B"]))
    check.require("dominance: tensor reconstruction",T==list(map(F,cert["tensor_lexicographic"])))
    Jcols=[];labels=[]
    for p,q in product(range(3),repeat=2):
        # Direct product rule, without using symbolic differentiation.
        col=[]
        for i,j,k in product(range(3),repeat=3):
            v=F(0)
            if q<2 and i==p:v+=B[j][3+q]*C[k][3+q]
            if j==q:v-=A[i][p]*C[k][p]
            col.append(v)
        Jcols.append(col);labels.append(["X",p,q])
    for p,q in product(range(3),range(5)):
        Jcols.append([A[i][q]*B[j][q] if k==p else F(0) for i,j,k in product(range(3),repeat=3)])
        labels.append(["C",p,q])
    for p,q in product(range(3),repeat=2):
        Jcols.append([T[9*q+3*j+k] if i==p else F(0) for i,j,k in product(range(3),repeat=3)])
        labels.append(["P",p,q])
    J=tr(Jcols)
    check.require("dominance: all Jacobian entries reconstructed",J==matrix(cert["jacobian"]) and labels==cert["column_labels"])
    ids=cert["selected_columns"]
    check.require("dominance: stated minor columns",ids==list(range(23))+[25,26,27,29])
    d=determinant(columns(J,ids))
    check.require("dominance: independent rational determinant",d==F(-3380083200)==F(cert["minor_determinant"]))
    check.require("dominance: six-column cancellation",mm(A6,tr(B6))==zeros(3,3))
    M=mm(A,tr(B))
    check.require("dominance: nonzero rank-one residual",M==matrix(cert["rank_one_sum"]) and rank(M)==1)
    return A,B,C,T

def pencil(cert,dom,check):
    A,B,C,T=dom
    M=mm(A,tr(B));u=[[row[2]] for row in M];v=[[F(0)],[F(0)],[F(1)]]
    Ah=[r+s for r,s in zip(kron(A,A),kron(u,u))]
    Bh=[r+s for r,s in zip(kron(B,B),kron(v,v))]
    Ch=[r+[F(0)] for r in kron(C,C)]
    check.require("pencil: core maps reconstructed from grouped products",
                  Ah==matrix(cert["A_core"]) and Bh==matrix(cert["B_core"]) and Ch==matrix(cert["C_core"]))
    check.require("pencil: source and exponents fixed",cert["source_signs"]==[1]*25+[-1]
                  and cert["third_aux_functional"]==[1]*26
                  and cert["factor_powers"]=={"A_core":0,"A_aux":1,"B_core":0,"B_aux":1,"C_core":0,"C_aux":-2})
    H=diag(cert["source_signs"]);P,Q=matrix(cert["A_aux"]),matrix(cert["B_aux"])
    check.require("pencil: auxiliary dimension eight",len(P)==len(Q)==8 and len(P[0])==len(Q[0])==26)
    check.require("pencil: coefficient of power -2 is zero",mm(mm(Ah,H),tr(Bh))==zeros(9,9))
    check.require("pencil: both power -1 blocks are zero",mm(mm(P,H),tr(Bh))==zeros(8,9)
                  and mm(mm(Ah,H),tr(Q))==zeros(9,8))
    check.require("pencil: isolated auxiliary is the identity",mm(mm(P,H),tr(Q))==diag([1]*8))
    image=tensor(mm(Ah,H),Bh,Ch)
    expected=[]
    for i,j,k in product(range(9),repeat=3):
        i0,i1=divmod(i,3);j0,j1=divmod(j,3);k0,k1=divmod(k,3)
        expected.append(T[9*i0+3*j0+k0]*T[9*i1+3*j1+k1])
    check.require("pencil: entire constant core is the grouped square",image==expected)
    check.require("pencil: full contraction and concise core maps",rank(Ah)==rank(Bh)==9 and determinant(H)==-1)

def rank_four(cert,check):
    fac=[matrix(z) for z in cert["factors"]]
    for pair in cert["pairs"]:
        i,j=pair["factors"];A,B=fac[i],fac[j]
        coefficients=[]
        for missing in range(4):
            cols=[h for h in range(4) if h!=missing]
            coefficients.append(determinant(columns(A,cols))*determinant(columns(B,cols)))
        weights=list(map(F,pair["weights"]))
        check.require(f"rank-four {i}{j}: full-spark coefficients",coefficients==list(map(F,pair["coefficients_by_missing_index"])) and all(coefficients))
        check.require(f"rank-four {i}{j}: nonzero weights",all(weights))
        M=mm(mm(A,diag(weights)),tr(B))
        check.require(f"rank-four {i}{j}: independent rank-two verification",M==matrix(pair["matrix"]) and rank(M)==2)

def scalar(cert,check,name):
    fixed = {"all_three":(5,1,2,3,F(464429449,100000000)),
             "border_four":(4,2,3,2,F(49038,12500))}[name]
    R,S,k,j,x=fixed
    check.require(f"{name}: claimed parameters fixed",(cert["base_rank"],cert["base_slice_rank"],cert["seed_power"],cert["rounds"],F(cert["threshold"]))==fixed)
    r,n,s=R**k,3**k,S**k;D,t,L=n,r+s-2*n,r+s
    ds,ts,ls=[D],[t],[L]
    for _ in range(j):
        D,t,L=D*D+2*D*t,t*t+2*D*D,L*L
        ds.append(D);ts.append(t);ls.append(L)
    check.require(f"{name}: exact dimension recurrence",ds==cert["D"] and ts==cert["t"] and ls==cert["L"]
                  and all(2*d+t==L for d,t,L in zip(ds,ts,ls)))
    roots={}
    for row in cert["root_enclosures"]:
        b=row["base"];e=F(row["exponent"]);lo=F(row["lower"]);hi=F(row["upper"])
        p,q=e.numerator,e.denominator
        if not (b>=1 and F(2,3)<=e<=1 and 0<lo<=hi):raise AssertionError("invalid root parameters")
        exact=pow(b,p)
        if not (pow(lo.numerator,q)<=exact*pow(lo.denominator,q)
                and pow(hi.numerator,q)>=exact*pow(hi.denominator,q)):
            raise AssertionError("invalid rational power enclosure")
        roots[b,e]=(lo,hi)
    check.require(f"{name}: all rational-power enclosures verified by integer powers",len(roots)==len(cert["root_enclosures"]))
    last=F(2,3)
    for interval in cert["intervals"]:
        a,b=F(interval["lower_theta"]),F(interval["upper_theta"])
        if not (last==a<b<=1):raise AssertionError("gap or overlap in theta coverage")
        y=x**k
        for t in ts[:-1]:y=y*y+2*roots[t,a][0]*y
        left=y+roots[ts[-1],a][0]
        right=(r+roots[s,b][1])**(2**j)
        if not (left==F(interval["left_lower"]) and right==F(interval["right_upper"]) and (left-right)/right > (F(1,10**8) if name=="all_three" else F(1,2000000))):
            raise AssertionError("invalid strict scalar inequality")
        if (left-right)/right != F(interval["relative_margin"]):raise AssertionError("invalid margin")
        last=b
    check.require(f"{name}: complete interval cover and every strict inequality",last==1 and len(cert["intervals"])>0)
    return len(cert["intervals"]),len(roots)

# Exact Gaussian rational arithmetic, used only to replay the small named tensors.
def gparse(s):
    s=str(s)
    if "I" not in s:return F(s),F(0)
    if s in ("I","-I"):return F(0),F(1 if s=="I" else -1)
    if s.startswith("-I/"):return F(0),-F(1,int(s[3:]))
    if s.startswith("I/"):return F(0),F(1,int(s[2:]))
    if s.endswith("*I"):return F(0),F(s[:-2])
    raise ValueError("Unsupported exact Gaussian rational")
def ga(x,y):return x[0]+y[0],x[1]+y[1]
def gm(x,y):return x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0]
def gmatrix(A):return [[gparse(x) for x in row] for row in A]
def gtensor(A,B,C):
    answer=[]
    for i,j,k in product(range(3),repeat=3):
        z=(F(0),F(0))
        for h in range(len(A[0])):z=ga(z,gm(gm(A[i][h],B[j][h]),C[k][h]))
        answer.append(z)
    return answer

def padd(a,b):
    out=[F(0)]*max(len(a),len(b))
    for i,x in enumerate(a):out[i]+=x
    for i,x in enumerate(b):out[i]+=x
    while len(out)>1 and out[-1]==0:out.pop()
    return tuple(out)
def pmul(a,b):
    out=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):out[i+j]+=x*y
    while len(out)>1 and out[-1]==0:out.pop()
    return tuple(out)
def pneg(a):return tuple(-v for v in a)
def pdet(M):
    @lru_cache(None)
    def recurse(row,cols):
        if not cols:return (F(1),)
        out=(F(0),)
        for pos,col in enumerate(cols):
            if all(x==0 for x in M[row][col]):continue
            rest=cols[:pos]+cols[pos+1:]
            term=pmul(M[row][col],recurse(row+1,rest))
            out=padd(out,term if pos%2==0 else pneg(term))
        return out
    return recurse(0,tuple(range(len(M))))

def targets(cert,check):
    fac=[gmatrix(z) for z in cert["U_factors"]]
    us=set(map(tuple,cert["U_support"]))
    check.require("targets: U four-term decomposition over Gaussian rationals",gtensor(*fac)==[(F(z in us),F(0)) for z in product(range(3),repeat=3)])
    V=gmatrix(cert["F1_vectors"])
    C=[[gm(x,(F(1,4) if j<2 else F(-1,4),F(0))) for j,x in enumerate(row)] for row in V]
    fs={(0,1,2),(0,2,1),(1,0,2),(1,1,1),(1,2,0),(2,0,1),(2,1,0)}
    check.require("targets: F1 four-term decomposition over Gaussian rationals",gtensor(V,V,C)==[(F(z in fs),F(0)) for z in product(range(3),repeat=3)])
    A=[row+[gparse(int(i==2))] for i,row in enumerate(V)]
    B=[row+[gparse(int(i==1))] for i,row in enumerate(V)]
    weights=list(map(gparse,cert["F_lambda_rank_one_weights"]))
    M=[]
    for i in range(3):
        row=[]
        for j in range(3):
            z=(F(0),F(0))
            for h in range(5):z=ga(z,gm(gm(A[i][h],weights[h]),B[j][h]))
            row.append(z)
        M.append(row)
    check.require("targets: F_lambda full-coefficient rank-one relation",M==gmatrix(cert["F_lambda_rank_one_matrix"]) and all(z!=(0,0) for z in weights))
    K=[[(F(0),) for _ in range(9)] for _ in range(9)];pairs=[(0,1),(0,2),(1,2)]
    for i,j,k in fs:
        val=(F(0),F(1)) if (i,j,k)==(2,1,0) else (F(1),)
        for p in range(3):
            if i==p:continue
            rr=3*pairs.index(tuple(sorted((i,p))))+k;cc=3*p+j
            K[rr][cc]=padd(K[rr][cc],val if i<p else pneg(val))
    def parse_poly(s):
        if s=="lambda":return (F(0),F(1))
        if s=="-lambda":return (F(0),F(-1))
        return (F(s),)
    stored=[[parse_poly(x) for x in row] for row in cert["F_lambda_Koszul"]]
    check.require("targets: Koszul matrix rebuilt from seven entries",K==stored)
    check.require("targets: full symbolic determinant by polynomial arithmetic",pdet(K)==(F(0),F(1),F(-1)))

def expect_rejection(name,callback,check):
    try:callback()
    except (AssertionError,ValueError,KeyError):check.require(name,True)
    else:raise AssertionError("Corrupted certificate was accepted: "+name)


def main():
    start=perf_counter();c=Checker()
    d=load("dominance.json");dom=dominance(d,c)
    pencil(load("seed_pencil.json"),dom,c)
    rank_four(load("rank_four.json"),c)
    all3=load("bound_all_three.json");four=load("bound_border_four.json")
    cover_counts={"all_three":scalar(all3,c,"all_three"),"border_four":scalar(four,c,"border_four")}
    targets(load("targets.json"),c)
    obstruction=load("scalar_obstruction.json")
    c.require("obstruction: exact anchors for all-k/all-round induction",obstruction["assignment_x"]==4 and obstruction["theta"]=="2/3" and F(20,26)<F(4,5)
              and F(4,5)**3+F(1,5)<F(4,5) and 26**2*4**3>25**3
              and F(4,6)<F(4,5) and 18**2<9**3 and F(25,36)<F(4,5))
    bad=copy.deepcopy(d);bad["jacobian"][0][0]=str(F(bad["jacobian"][0][0])+1)
    expect_rejection("negative test: corrupted Jacobian rejected",lambda:dominance(bad,Checker(False)),c)
    badroot=copy.deepcopy(all3)
    badroot["root_enclosures"][1]["lower"]=str(F(badroot["root_enclosures"][1]["lower"])+1)
    expect_rejection("negative test: incorrect power enclosure rejected",lambda:scalar(badroot,Checker(False),"all_three"),c)
    badcover=copy.deepcopy(four);badcover["intervals"].pop(1)
    expect_rejection("negative test: missing theta interval rejected",lambda:scalar(badcover,Checker(False),"border_four"),c)
    badpencil=load("seed_pencil.json");badpencil["A_aux"][0][0]=str(F(badpencil["A_aux"][0][0])+1)
    expect_rejection("negative test: corrupted degeneration map rejected",lambda:pencil(badpencil,dom,Checker(False)),c)
    result={"status":"PASS","checks_passed":len(c.checks),"checks":c.checks,"python":platform.python_version(),
            "coverage_counts_intervals_and_enclosures":cover_counts,"elapsed_seconds":round(perf_counter()-start,3),
            "scope":"Independent standard-library implementation of exact finite checks, not independent authorship, peer review, or a proof of AC-05."}
    (ROOT/"results"/"replay.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k!="checks"},indent=2))

if __name__=="__main__":main()
