#!/usr/bin/env python3
"""Generate exact certificates for the AC-05 rank-speedup continuation.

Requires SymPy. No floating-point calculation is used. The separate
replay_certificates.py reads the stored certificates using only Python's
standard library, reconstructing the finite algebraic witnesses independently.
Neither program is a proof-assistant verification of the quantified theorems.
"""
from __future__ import annotations
import json
import platform
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, product
from pathlib import Path
from time import perf_counter
import sympy as sp

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "certificates"
Q = 10**14
CHECKS: list[dict[str, object]] = []


def check(name: str, condition: bool) -> None:
    if not bool(condition):
        raise AssertionError(name)
    CHECKS.append({"name": name, "passed": True})


def rational(x: object) -> str:
    return str(x)


def mat(M: sp.Matrix) -> list[list[str]]:
    return [[str(M[i, j]) for j in range(M.cols)] for i in range(M.rows)]


def save(name: str, data: object) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / name).write_text(json.dumps(data, indent=2) + "\n")


def tensor(A: sp.Matrix, B: sp.Matrix, C: sp.Matrix) -> list[sp.Expr]:
    assert A.cols == B.cols == C.cols
    return [sum(A[i, h] * B[j, h] * C[k, h] for h in range(A.cols))
            for i in range(A.rows) for j in range(B.rows) for k in range(C.rows)]


def dominance() -> tuple[sp.Matrix, sp.Matrix, sp.Matrix, list[sp.Expr]]:
    X = sp.Matrix([[1, 2, 3], [2, 1, 4], [3, 5, 2]])
    C = sp.Matrix([[1, 0, 0, 1, 2], [0, 1, 0, 2, 3], [0, 0, 1, 4, 1]])
    A6 = sp.eye(3).row_join(X)
    B6 = (-X.T).row_join(sp.eye(3))
    A, B = A6[:, :5], B6[:, :5]
    T = tensor(A, B, C)
    columns, labels = [], []
    # Derivatives of Phi(P,X,C)=(P tensor I tensor I) sum_{h<5} a_h b_h c_h.
    for p, q in product(range(3), repeat=2):
        dA6, dB6 = sp.zeros(3, 6), sp.zeros(3, 6)
        dA6[p, 3 + q], dB6[q, p] = 1, -1
        columns.append(sp.Matrix(tensor(dA6[:, :5], B, C)) +
                       sp.Matrix(tensor(A, dB6[:, :5], C)))
        labels.append(["X", p, q])
    for p, q in product(range(3), range(5)):
        dC = sp.zeros(3, 5)
        dC[p, q] = 1
        columns.append(sp.Matrix(tensor(A, B, dC)))
        labels.append(["C", p, q])
    for p, q in product(range(3), repeat=2):
        col = sp.zeros(27, 1)
        for j, k in product(range(3), repeat=2):
            col[9*p + 3*j + k] = T[9*q + 3*j + k]
        columns.append(col)
        labels.append(["P", p, q])
    J = sp.Matrix.hstack(*columns)
    selected = list(range(23)) + [25, 26, 27, 29]
    det = J[:, selected].det(method="domain-ge")
    check("dominance: specified 27-column minor", det == -3380083200)
    check("dominance: full six-column relation", A6 * B6.T == sp.zeros(3))
    check("dominance: five-column rank-one relation",
          A * B.T == -X[:, 2] * sp.Matrix([[0, 0, 1]]))
    check("dominance: nonzero completion", (A * B.T).rank() == 1)
    check("dominance: coefficient factor has full row rank", C.rank() == 3)
    save("dominance.json", {
        "description": "Dominant 33-parameter family; all indices are zero based.",
        "X": mat(X), "C": mat(C), "A": mat(A), "B": mat(B),
        "tensor_lexicographic": [str(x) for x in T],
        "column_labels": labels, "jacobian": mat(J),
        "selected_columns": selected, "minor_determinant": str(det),
        "rank_one_sum": mat(A * B.T),
    })
    return A, B, C, T


def seed_pencil(A: sp.Matrix, B: sp.Matrix, C: sp.Matrix, T: list[sp.Expr]) -> None:
    # The witness M=-X_3 e_2^T is u v^T. Its square has a rank-one factorization.
    u = (A * B.T)[:, 2]
    v = sp.Matrix([0, 0, 1])
    Ap, Bp, Cp = (sp.kronecker_product(Z, Z) for Z in (A, B, C))
    Ah = Ap.row_join(sp.kronecker_product(u, u))
    Bh = Bp.row_join(sp.kronecker_product(v, v))
    Ch = Cp.row_join(sp.zeros(9, 1))
    H = sp.diag(*([1] * 25 + [-1]))
    check("seed: mutually orthogonal core row spaces", Ah * H * Bh.T == sp.zeros(9))
    check("seed: nondegenerate full source contraction", H.det() == -1)
    L = sp.Matrix.vstack(*[w.T for w in (Bh * H).nullspace()])
    R = sp.Matrix.vstack(*[w.T for w in (Ah * H).nullspace()])
    pairing = L * H * R.T
    row_ids = list(pairing.T.rref()[1])
    col_ids = list(pairing[row_ids, :].rref()[1])
    P = L[row_ids, :]
    Q0 = R[col_ids, :]
    K = P * H * Q0.T
    Qm = K.inv().T * Q0
    check("seed: residual pairing has exact rank eight", len(row_ids) == len(col_ids) == 8)
    check("seed: left mixed auxiliary block vanishes", P * H * Bh.T == sp.zeros(8, 9))
    check("seed: right mixed auxiliary block vanishes", Ah * H * Qm.T == sp.zeros(9, 8))
    check("seed: auxiliary block is identity", P * H * Qm.T == sp.eye(8))
    image = tensor(Ah * H, Bh, Ch)
    expected = []
    for i, j, k in product(range(9), repeat=3):
        i0, i1 = divmod(i, 3)
        j0, j1 = divmod(j, 3)
        k0, k1 = divmod(k, 3)
        expected.append(T[9*i0 + 3*j0 + k0] * T[9*i1 + 3*j1 + k1])
    check("seed: core tensor equals the grouped square at all 729 entries", image == expected)
    check("seed: first and second core maps have rank nine", Ah.rank() == Bh.rank() == 9)
    save("seed_pencil.json", {
        "description": "26-term Laurent factorization with polynomial tensor image; constant term T^2 direct-sum M_8.",
        "core_dimensions": [9, 9, 9], "auxiliary_dimensions": [8, 8, 1],
        "A_core": mat(Ah), "B_core": mat(Bh), "C_core": mat(Ch),
        "A_aux": mat(P), "B_aux": mat(Qm), "source_signs": [1]*25 + [-1],
        "third_aux_functional": [1]*26,
        "factor_powers": {"A_core": 0, "A_aux": 1, "B_core": 0,
                          "B_aux": 1, "C_core": 0, "C_aux": -2},
        "nonzero_tensor_powers": [0, 1, 2],
    })


def rank_four() -> None:
    values = [[1, 2, 3, 4], [2, 3, 5, 7], [1, 3, 4, 6]]
    factors = [sp.Matrix([[1]*4, xs, [x*x for x in xs]]) for xs in values]
    records = []
    mus = sp.symbols("m0:4")
    for first, second in [(0, 1), (1, 2), (2, 0)]:
        A, B = factors[first], factors[second]
        coeffs = []
        p = 0
        for missing in range(4):
            I = [z for z in range(4) if z != missing]
            c = A[:, I].det() * B[:, I].det()
            coeffs.append(c)
            p += c * sp.prod(mus[z] for z in I)
        check(f"rank-four pair {first}{second}: all minors nonzero", all(c != 0 for c in coeffs))
        check(f"rank-four pair {first}{second}: Cauchy--Binet identity",
              sp.expand((A * sp.diag(*mus) * B.T).det() - p) == 0)
        # mu_0=mu_1=mu_2=1; constant coefficient is coefficient missing index 3.
        weights = [sp.Integer(1)]*3 + [-coeffs[3] / sum(coeffs[:3])]
        M = A * sp.diag(*weights) * B.T
        check(f"rank-four pair {first}{second}: full-coefficient rank-two witness",
              all(z != 0 for z in weights) and M.rank() == 2)
        records.append({"factors": [first, second],
                        "coefficients_by_missing_index": [str(z) for z in coeffs],
                        "weights": [str(z) for z in weights], "matrix": mat(M)})
    save("rank_four.json", {"factors": [mat(A) for A in factors], "pairs": records})


@lru_cache(None)
def enclosure(base: int, exponent: Fraction) -> tuple[Fraction, Fraction]:
    p, q = exponent.numerator, exponent.denominator
    if base == 1:
        return Fraction(1), Fraction(1)
    value = pow(base, p) * pow(Q, q)
    floor, is_exact = sp.integer_nthroot(value, q)
    return Fraction(int(floor), Q), Fraction(int(floor if is_exact else floor + 1), Q)


def recurrence(r: int, n: int, s: int, rounds: int) -> tuple[list[int], list[int], list[int]]:
    D, t, L = n, r+s-2*n, r+s
    ds, ts, ls = [D], [t], [L]
    for _ in range(rounds):
        D, t, L = D*D + 2*D*t, t*t + 2*D*D, L*L
        ds.append(D); ts.append(t); ls.append(L)
    check(f"recurrence r={r},n={n},s={s}: dimension invariant", all(L == 2*D+t for D,t,L in zip(ds,ts,ls)))
    return ds, ts, ls


def lower_value(x: Fraction, theta: Fraction, ts: list[int], k: int) -> Fraction:
    y = x**k
    for t in ts[:-1]:
        y = y*y + 2*enclosure(t, theta)[0]*y
    return y + enclosure(ts[-1], theta)[0]


def scalar_bound(R: int, S: int, k: int, rounds: int, x: Fraction, filename: str) -> None:
    r, n, s = R**k, 3**k, S**k
    ds, ts, ls = recurrence(r, n, s, rounds)
    todo = [(Fraction(2,3), Fraction(1))]
    intervals = []
    roots: dict[tuple[int, Fraction], dict[str, str | int]] = {}
    while todo:
        lo, hi = todo.pop()
        left = lower_value(x, lo, ts, k)
        right = (r + enclosure(s, hi)[1])**(2**rounds)
        if left > right:
            uses = [(t, lo) for t in ts] + [(s, hi)]
            for base, exp in uses:
                lower, upper = enclosure(base, exp)
                roots[base, exp] = {"base": base, "exponent": str(exp),
                                    "lower": str(lower), "upper": str(upper)}
            intervals.append({"lower_theta": str(lo), "upper_theta": str(hi),
                              "left_lower": str(left), "right_upper": str(right),
                              "relative_margin": str((left-right)/right)})
        else:
            if hi-lo < Fraction(1, 3*2**20):
                raise ArithmeticError("Unable to certify the proposed threshold")
            midpoint = (lo+hi)/2
            todo.extend([(midpoint,hi), (lo,midpoint)])
    intervals.sort(key=lambda z: Fraction(z["lower_theta"]))
    check(f"bound {filename}: exact interval cover",
          Fraction(intervals[0]["lower_theta"]) == Fraction(2,3)
          and Fraction(intervals[-1]["upper_theta"]) == 1
          and all(a["upper_theta"] == b["lower_theta"] for a,b in zip(intervals, intervals[1:])))
    check(f"bound {filename}: positive exact gap on every interval",
          all(Fraction(z["relative_margin"]) > (Fraction(1,10**8) if R == 5 else Fraction(1,2000000)) for z in intervals))
    save(filename, {"base_rank": R, "base_slice_rank": S, "seed_power": k,
                    "rounds": rounds, "threshold": str(x), "r": r, "n": n, "s": s,
                    "D": ds, "t": ts, "L": ls, "root_grid_denominator": Q,
                    "root_enclosures": sorted(roots.values(), key=lambda z: (z["base"], Fraction(z["exponent"]))),
                    "intervals": intervals})


def target_checks() -> None:
    I = sp.I
    U_support = [(0,0,2),(0,2,1),(1,1,1),(1,2,0),(2,0,1),(2,1,0)]
    A = sp.Matrix([[1,1,0,0],[0,0,1,1],[0,1,I,-I]])
    B = A.copy()
    C = sp.Matrix([[0,0,-I/2,I/2],[-1,1,sp.Rational(1,2),sp.Rational(1,2)],[1,0,0,0]])
    expected = [sp.Integer((i,j,k) in U_support) for i,j,k in product(range(3),repeat=3)]
    check("U: inherited four-term identity reconstructed", list(map(sp.expand,tensor(A,B,C))) == expected)
    V = sp.Matrix([[1,-1,I,-I],[1,1,-1,-1],[1,-1,-I,I]])
    F1 = tensor(V,V,V*sp.diag(sp.Rational(1,4),sp.Rational(1,4),-sp.Rational(1,4),-sp.Rational(1,4)))
    Fs = [(0,1,2),(0,2,1),(1,0,2),(1,1,1),(1,2,0),(2,0,1),(2,1,0)]
    check("F1: inherited four-term identity reconstructed",
          list(map(sp.expand,F1)) == [sp.Integer(x in Fs) for x in product(range(3),repeat=3)])
    weights = [-I,I,-1,1,4*I]
    Aa = V.row_join(sp.Matrix([0,0,1]))
    Bb = V.row_join(sp.Matrix([0,1,0]))
    M = Aa*sp.diag(*weights)*Bb.T
    check("F_lambda: explicit full-weight rank-one contraction", sp.simplify(M) == sp.Matrix([[0,0,0],[0,0,-4*I],[0,0,0]]))
    lam = sp.symbols("lambda")
    F = {(0,1,2):1,(0,2,1):1,(1,0,2):1,(1,1,1):1,(1,2,0):1,(2,0,1):1,(2,1,0):lam}
    K = sp.zeros(9)
    pairs = [(0,1),(0,2),(1,2)]
    for (i,j,k),val in F.items():
        for p in range(3):
            if i==p: continue
            pair = tuple(sorted((i,p)))
            K[3*pairs.index(pair)+k, 3*p+j] += val*(1 if i<p else -1)
    check("F_lambda: symbolic Koszul determinant", sp.expand(K.det() - lam*(1-lam)) == 0)
    save("targets.json", {"U_support": U_support,"U_factors":[mat(A),mat(B),mat(C)],
                          "F1_vectors": mat(V), "F_lambda_rank_one_weights": [str(w) for w in weights],
                          "F_lambda_rank_one_matrix": mat(M), "F_lambda_Koszul": mat(K),
                          "Koszul_determinant": "lambda*(1-lambda)"})


def obstruction_checks() -> None:
    check("scalar obstruction: k=1 initial and first-step slack", Fraction(4,6) < Fraction(4,5) and 18**2 < 9**3 and Fraction(25,36) < Fraction(4,5))
    check("scalar obstruction: k=2 initial rational slack", Fraction(16+4,26) < Fraction(4,5))
    check("scalar obstruction: uniform k>=3 initial slack", Fraction(4,5)**3 + Fraction(1,5) < Fraction(4,5))
    check("scalar obstruction: invariant-step rational slack", 26**2 * 4**3 > 25**3)
    save("scalar_obstruction.json", {"assignment_x": 4, "theta": "2/3", "slack_fraction": "4/5",
         "scope": "All rank-five/rank-one scalar recursions in the report, seed powers k>=1 and all squaring rounds. This is not a spectral-point construction.",
         "step_integer_comparison": [26**2 * 4**3, 25**3]})


def main() -> None:
    started = perf_counter()
    A,B,C,T = dominance()
    seed_pencil(A,B,C,T)
    rank_four()
    scalar_bound(5,1,2,3,Fraction(464429449,100000000),"bound_all_three.json")
    scalar_bound(4,2,3,2,Fraction(49038,12500),"bound_border_four.json") # 3.92304
    target_checks()
    obstruction_checks()
    result = {"status": "PASS", "checks_passed": len(CHECKS), "checks": CHECKS,
              "python": platform.python_version(), "sympy": sp.__version__,
              "elapsed_seconds": round(perf_counter()-started,3),
              "scope": "Exact finite premises only; not a proof of AC-05 or formal verification of the report."}
    (ROOT/"results").mkdir(exist_ok=True)
    (ROOT/"results"/"generation.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k!="checks"},indent=2))


if __name__ == "__main__":
    main()
