#!/usr/bin/env python3
"""Rerun the original 123-check archive without modifying it."""
from __future__ import annotations
import hashlib,json,subprocess,sys,tempfile,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
archive=ROOT/'baseline'/'AC05_partial_results.zip'
with tempfile.TemporaryDirectory(prefix='ac05_baseline_') as tmp:
    with zipfile.ZipFile(archive) as z:
        for entry in z.infolist():
            target=(Path(tmp)/entry.filename).resolve()
            if not target.is_relative_to(Path(tmp).resolve()):
                raise ValueError('Unsafe archive path')
        z.extractall(tmp)
    working=Path(tmp)/'AC05_partial_results'
    output=working/'results'/'audit_rerun.json'
    proc=subprocess.run([sys.executable,'code/verify.py','--output',str(output)],cwd=working,
                        text=True,capture_output=True,check=False)
    (ROOT/'results'/'baseline_audit.log').write_text(proc.stdout+proc.stderr)
    if proc.returncode:raise RuntimeError('Inherited checker failed; inspect baseline_audit.log')
    data=json.loads(output.read_text())
    (ROOT/'results'/'baseline_verification.json').write_text(json.dumps(data,indent=2)+'\n')
    summary={'status':'PASS','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
             'checker_returncode':proc.returncode,
             'scope':'Original archive tests rerun. Only the later 21-page continuation report was retrieved; its full test suite was not rerun.'}
    (ROOT/'results'/'baseline_audit.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))
