# Sources and provenance

## Primary public sources

1. **OpenProblemsInNLA, AC-05: Strassen's asymptotic rank conjecture for tight tensors.** Accessed 14 September 2026. Used for the exact quantifiers, field, tightness condition and corresponding-factor convention.
   https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/arithmetic-and-complexity/AC-05/README.md

2. **OpenProblemsInNLA, root README, problem-status definitions.** Accessed 14 September 2026. Used to distinguish partial cases from a complete resolution claim and a solved exact target.
   https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/README.md

3. **Josh Alman and Baitian Li, Asymptotic Rank Speedup Theorems, Revisited.** arXiv:2605.21738v1, 20 May 2026. Theorem 4.1 and Propositions 4.1–4.2 provide the spectral facts used here; Sections 5.2–5.3 and Theorems 6.1–6.2 supply the established full/isolated-slice speedup framework. The report gives the relevant linear algebra and induction explicitly. No priority claim is made for this machinery.
   https://arxiv.org/abs/2605.21738v1
   https://arxiv.org/html/2605.21738v1

4. **Matthias Christandl, Koen Hoeberechts, Harold Nieuwboer, Péter Vrana and Jeroen Zuiddam, Asymptotic tensor rank is characterized by polynomials.** arXiv:2411.15789v2, 7 June 2026. Theorem 1.2 establishes Zariski-closed asymptotic-rank sublevels. A proof of the needed closure-transfer statement is included in Section 2 of the new report.
   https://arxiv.org/abs/2411.15789v2

## Supplied prior work

5. **AC-05: Constructive partial results.** The original 13-page report and archive supplied in the conversation. The ZIP is preserved unchanged in `baseline/AC05_partial_results.zip`. Its SHA-256 appears in README.md; its 123 exact checks were rerun in a temporary directory.

6. **AC-05: Explicit decompositions and a dimension-three reduction.** The supplied later 21-page continuation, retrieved from the file Library. Its report is preserved at `baseline/AC05_continuation.pdf`. All report text was read, including its two-target completion criterion and its explicit limitations. Its full code suite was not retrieved or rerun. The new main bounds do not depend on its component classification.

The new package includes no full copy of an external research paper. The public primary sources were read through the web, without a GitHub plugin. The new derivations, certificates and the exact remaining gap are distinguished from the established inputs in the report.
