#!/usr/bin/env python3
"""Read-only package preflight. No Lean, network, Git mutation, or candidate writes.

Invokes only the trusted metadata validator and pure configuration/selection
functions from the copied, Git-object-authenticated shared infrastructure.
Does not invoke the harness verifier, bootstrap, snapshot writer or controls.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path,PurePosixPath
import json,hashlib,re,difflib,importlib.util,contextlib,io,importlib.metadata,datetime
O=Path(__file__).resolve().parent;S=O/'core-01';P=S/'candidate';I=S/'infrastructure';checks=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def js(p):return json.loads(Path(p).read_text())
def ck(v,label):
 if not v:raise AssertionError(label)
 checks.append(label)
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
snap=js(S/'SNAPSHOT.json')
for b in snap['bindings']:ck(sha(O/b['copy'])==b['sha256'],'Captured core payload '+b['copy'])
for c in snap['commands']:ck(c['exit_code']==0 and sha(O/c['output'])==c['output_sha256'],'Actual read-only Git-object capture '+c['output'])
pm=js(P/'PACKAGE-MANIFEST.json');files={str(p.relative_to(P)):p for p in P.rglob('*') if p.is_file()};ck(set(pm['files'])==set(files)-{'PACKAGE-MANIFEST.json'},'Exact complete package inventory')
for f,h in pm['files'].items():ck(sha(P/f)==h,'Package manifest '+f)
ck(not any(p.is_symlink() for p in P.rglob('*')),'No symlinks');ck(not any('.lake' in p.parts or p.suffix in {'.olean','.ilean','.o','.so','.a'} for p in files.values()),'No tracked build artifacts');ck(not list(P.rglob('*.py')),'All historical Python payloads inactive')
email=[]
for f,p in files.items():
 if re.search(rb'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}',p.read_bytes()):email.append(f)
ck(not email,'No email pattern in complete package')
old=js(S/'prior-cleanup/AUDIT.json');old_sources={('Solution.lean' if x['module']=='IE02Solution' else x['module'].replace('.','/')+'.lean'):x['source_sha256'] for x in old['actual_success_origins']};active=js(P/'ACTIVE-SOURCE-MANIFEST.json');complete=js(P/'verification/LOCAL-COMPLETE.json');ck(active['source_sha256']==complete['sources']==old_sources,'Entire actual123 source mapping unchanged')
for f,h in old_sources.items():ck(sha(P/f)==h,'Actual123 proof source '+f)
leanfiles={str(p.relative_to(P)) for p in P.rglob('*.lean')};ck(leanfiles==set(old_sources)|{'Challenge.lean'} and len(leanfiles)==56,'Exactly fifty-five active closure files and independent Challenge')
freeze=js(P/'STATEMENT-FREEZE.json');ck(len(freeze['frozen_files'])==13,'Thirteen frozen original inputs');exceptions=[]
for f,h in freeze['frozen_files'].items():
 if sha(P/f)!=h:exceptions.append(f)
ck(exceptions==['lakefile.toml'],'Only operational Lake registration exception')
oldlake=P/'statement-history/pre-publication/lakefile.toml';ck(sha(oldlake)==freeze['frozen_files']['lakefile.toml'],'Exact original frozen Lakefile retained');before=oldlake.read_text();after=(P/'lakefile.toml').read_text();expected=before.replace('defaultTargets = ["Challenge"]','defaultTargets = ["Solution"]')+'\n[[lean_lib]]\nname = "Solution"\n';ck(after==expected,'Exact two allowed Lake changes');patch=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='statement-history/pre-publication/lakefile.toml',tofile='lakefile.toml'));ck(patch==(P/'verification/packaging/LAKE-REGISTRATION.patch').read_text(),'Correct retained Lake diff');transition=js(P/'verification/packaging/TRANSITION.json');ck(transition['active_lake_sha256']==sha(P/'lakefile.toml') and transition['frozen_files']==freeze['frozen_files'],'Truthful operational exception record')
config=js(P/'comparator.json');names=config['theorem_names'];headers=js(P/'STATEMENT-HEADERS.json')['headers'];ck(len(names)==50 and [h['name'] for h in headers]==names,'Fifty exact frozen contract names');ck(config['definition_names']==[] and set(config['permitted_axioms'])=={'propext','Classical.choice','Quot.sound'},'No replaceable definitions or extra allowed axiom');ck(config['challenge_module']=='Challenge' and config['solution_module']=='Solution','Correct distinct canonical module names')
metadata=js(P/'formalization.yaml');results=metadata['status']['main_results'];mapping=js(P/'IMPLEMENTATION-MAP.json')['results'];ck(results==mapping and len(results)==50,'Manifest and implementation map identical fifty results');byname={x['name']:x for x in old['contracts_checked']}
for r in results:
 c=byname[r['declaration']];ck(r['file']==c['source'] and r['line']==c['line'] and r['file_sha256']==c['source_sha256']==sha(P/r['file']),'Exact advertised declaration location/hash '+r['declaration'])
ck([r['declaration'] for r in results]==names,'Advertised order matches exact Comparator order');ck(metadata['status']['whole_problem_verified'] is False,'Whole target correctly unaccepted before Linux');ck(metadata['status']['sorry_count']==metadata['status']['sorry_in_definitions']==0 and '50 intentional independent specification' in metadata['status']['source_scan_note'],'Implementation/Challenge hole scopes distinguished')
ck(metadata['project']['authors']==['George Stepaniants'],'Correct author');affil=metadata['project']['affiliations']['George Stepaniants'];ck('Department of Computing and Mathematical Sciences, California Institute of Technology' in affil,'Correct authorized department/university');ck('Substantial OpenAI Codex assistance' in (P/'README.md').read_text(),'AI assistance disclosed')
for f in old_sources:ck('Department of Computing and Mathematical Sciences, California Institute of Technology.' in (P/f).read_text(),'Source attribution retained '+f)
retained=js(P/'verification/RETAINED-PATHS.json');reviewmap=js(P/'reviews/final/COPY-MAP.json')['copies'];paths=[]
for r in retained:
 ck(sha(P/r['path'])==r['sha256'],'Exact retained payload '+r['path']);paths.append(r['path'])
 if Path(r['original_path']).suffix in {'.py','.lean'} and r['path'] not in leanfiles:ck(r['path'].endswith('.txt'),'Historical inactive suffix '+r['path'])
for r in reviewmap:
 ck(sha(P/r['package'])==r['sha256'],'Exact archived review payload '+r['package']);paths.append(r['package'])
 if Path(r['original']).suffix in {'.py','.lean'}:ck(r['package'].endswith('.txt'),'Review source/code inactive '+r['package'])
ck(len(paths)==len(set(paths)),'No conflicting retained path aliases')
ck(sha(P/'statement-history/pre-publication/formalization.yaml')==sha(P/'reviews/final/referee-2/baseline/snapshot/project/formalization.yaml'),'Exact original source YAML preserved')
index=js(P/'reviews/final/INDEX.json');ck(sha(P/'reviews/final/INDEX.json')=='baa3b6b245740a99fa060ab0361e56ca602cafefc943dc5a2673ee5a877c9e6e','Root final review index exact');ck(index['current_sources']==old_sources,'Review index bound to actual current sources');ck(index['actual_local_receipt_sha256']==complete['receipt_sha256']=='c810a0613b1e919e9fc3700a26428ebe1eae927bfedfe07878a2681e3cf4edec','Local receipt consistent');ck(len(index['reviews'])==2 and len({r['reviewer'] for r in index['reviews']})==2,'Two distinct named reviewers');ck(not index['Linux_Comparator_run'] and not index['official_TauCeti_or_human_review'] and index['count_change']==0,'Review scope honest')
for row in index['reviews']:
 ck((P/'reviews/final'/row['baseline']).is_file() and (P/'reviews/final'/row['continuation']).is_file(),'Baseline and cleanup review links resolve')
 ck(sha((P/'reviews/final'/row['continuation']).parent/'MANIFEST.json')==row['manifest_sha256'],'Exact continuation manifest link')
 ck(row['overall']=='approve','Index final status is cleanup approval')
ck(index['reviews'][1]['manifest_sha256']==sha(S/'prior-cleanup/MANIFEST.json'),'Own independent cleanup approval actually bound')
state=js(P/'STATE.json');ck(state['local_Lean_passed'] is True and state['GitHub_Comparator_run'] is False and state['independent_full_proof_reviews']==2 and state['count_change']==0,'Current metadata distinguishes local/full source review and pending Linux')
# Check public-facing package links without executing archived scripts.
links=re.findall(r'\[[^\]]*\]\(([^)]+)\)',(P/'README.md').read_text());broken=[]
for link in links:
 if '://' in link or link.startswith('#'):continue
 if link=='../../../tools/lean/HARNESS.md':ck((I/'tools/lean/HARNESS.md').is_file(),'Shared repository harness link canonical depth');continue
 if not (P/link.split('#')[0]).exists():broken.append(link)
ck(not broken,'README package links resolve')
# Actual existing validation APIs; these perform only reads and schema validation.
validator=load('nla_package_manifest_validator',I/'tools/lean/validate_manifest.py');schema=js(I/'docs/lean/schema/v0.4.schema.json');ck(sha(I/'docs/lean/schema/v0.4.schema.json')==sha(P/'sources/standards/v0.4.schema.json'),'Real pinned schema identical to retained reference');output=io.StringIO()
with contextlib.redirect_stdout(output):validator.validate(P,schema)
ck(output.getvalue().strip()=='Manifest schema and comparator coverage: PASS (50 declarations)','Actual shared v0.4 validator passed')
harness=load('nla_package_harness',I/'tools/lean/harness.py');ck(harness.validate_project(P)==config,'Actual harness pure configuration gate passed');lock=harness.load_lock();ck((P/'lean-toolchain').read_text().strip()==lock['lean_toolchain']=='leanprover/lean4:v4.33.1','Package and real harness toolchain agree');ck(lock['commit']=='8d1b0c0545a77b40245e84705aa7d273e6c81e62' and len(lock['files'])==58,'Exact shared Forsythe-adapted checker lock')
# Recreate complete-checkout discovery from actual pinned Git-tree captures.
selector=load('nla_package_selector',I/'tools/lean/projects.py');registry=js(S/'evidence/problem_ids-base.json');seed_registry=js(S/'evidence/problem_ids-seed.json');basepaths=(S/'evidence/git-tree-base.txt').read_text().splitlines();seedpaths=(S/'evidence/git-tree-seed.txt').read_text().splitlines();ck(basepaths==seedpaths and registry==seed_registry and not (S/'evidence/base-seed-diff.txt').read_text(),'Seed has exactly the upstream base tree');ck('[skip ci]' in (S/'evidence/seed-message.txt').read_text(),'Empty seed carries explicit skip-ci message');entries=selector.registered_projects(registry);base_projects=[x for x in entries if any(p==x['project'] or p.startswith(x['project']+'/') for p in basepaths)];raw=[p for p in basepaths if p.endswith('/comparator.json')];ck(len(base_projects)==44 and len(raw)==154 and sum(p.endswith('/lean/comparator.json') for p in raw)==62,'Full base checkout has44 canonical projects,62 lean/comparator suffix paths and154 arbitrary-depth comparator paths');canonical=str(PurePosixPath(registry['IE-02']).parent/'lean');ck(canonical=='linear-systems-and-elimination/IE-02/lean','Permanent canonical project path');afterpaths=basepaths+[canonical+'/'+f for f in files];projects=[x for x in entries if any(p==x['project'] or p.startswith(x['project']+'/') for p in afterpaths)];ck(len(projects)==45,'Candidate adds exactly one canonical registered Lean project');selector.require_retained_projects(projects,base_projects);selected=selector.select(projects,[canonical+'/'+f for f in files]);ck(selected==[{'id':'IE-02','project':canonical}],'Normal proof-only push/PR selects exactly IE02');ck(selector.select(base_projects,[])==[],'Empty seed diff selects no project');ck(len(selector.select(projects,['tools/lean/harness.py']))==45,'Shared-tool change would correctly select all45');tools_changed=any(p.startswith(('tools/lean/','docs/lean/ci-toolchain/')) or p=='.github/workflows/lean-verification.yml' for p in [canonical+'/'+f for f in files]);ck(tools_changed is False,'Proof-only change does not spuriously select separate tools job')
workflow=(I/'.github/workflows/lean-verification.yml').read_text();driver=(I/'tools/lean/harness.py').read_text();ck('fetch-depth: 0' in workflow and 'sparse-checkout' not in workflow,'Workflow uses full checkout, not sparse local visibility');ck('"$BASE_REF" = "0000000000000000000000000000000000000000"' in workflow and 'projects.py --all' in workflow,'All-zero before/manual-dispatch all-project case explicitly retained');ck('run_controls(tool_dir, logdir, env)' in driver[driver.index('def verify('):] and 'systemd(["lake", "env", env["COMPARATOR_BIN"], "comparator.json"]' in driver,'Per-project real controls and Comparator invocation remain active');ck('"Lean default kernel accepts the solution", "Your solution is okay!"' in driver,'Actual required success markers retained')
print(json.dumps({'result':'PASS','checks':len(checks),'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Independent operational preflight; no Lean/Comparator execution or mathematical rereview','package_manifest_sha256':sha(P/'PACKAGE-MANIFEST.json'),'active_proof_sources':55,'active_Challenge_sources':1,'contracts':50,'frozen_inputs_unchanged':12,'sole_frozen_exception':'lakefile.toml: default Solution target and Solution library registration','retained_paths':len(retained),'archived_review_paths':len(reviewmap),'all_package_files':len(files),'email_pattern_hits':0,'schema_validator_output':output.getvalue().strip(),'versions':{'python':sys.version,'PyYAML':importlib.metadata.version('PyYAML'),'jsonschema':importlib.metadata.version('jsonschema')},'actual_pure_harness_gate':'PASS','selection':{'upstream_base':snap['base'],'empty_seed':snap['seed'],'base_registered':44,'base_paths_ending_lean_comparator':62,'base_all_depth_comparator_paths':154,'after_candidate_registered':45,'normal_proof_push_or_PR':selected,'tools_changed':False,'zero_before_or_manual_dispatch':'Selects all registered projects by explicit workflow logic; empty skip-ci seed avoids relying on that case for normal subsequent proof push.','GitHub_zero_seed_runs':'Parent-reported; not independently queried because this task uses no network.'},'commands_not_run':['lake build','Lean compiler','bootstrap.sh','Comparator','kernel replay','sandbox controls','GitHub workflow'], 'approval_scope':'Core packaging and final mathematical-review metadata approved; append this operational report and reseal package inventory, then perform real Linux controls before whole-target acceptance.'},indent=2))
