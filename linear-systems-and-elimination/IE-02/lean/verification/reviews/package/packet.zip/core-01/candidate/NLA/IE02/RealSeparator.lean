/-
Copyright (c) 2026 George Stepaniants. Released under Apache 2.0 license.
Department of Computing and Mathematical Sciences, California Institute of Technology.
Substantial OpenAI Codex assistance. Original attribution is retained in
Definitions.lean and SourceCorrespondence.md. Mathlib's Euclidean projections,
real-linear maps and complex real/imaginary identities are reused directly.
-/
import NLA.IE02.Definitions
import Mathlib.Data.Complex.BigOperators
import LeanCert.Tactic

set_option autoImplicit false
set_option leancert.trust "kernel"

namespace NLA.IE02
noncomputable section
open scoped BigOperators

theorem real_separator_complex_form {k : ℕ} (ell : H k →L[ℝ] ℝ) :
    ∀ z : H k, ell z = (∑ j, separatorCoefficients ell j * z j).re := by
  classical
  intro z
  have hz : z = ∑ j : Fin k,
      ((z j).re • basisVector j + (z j).im • (Complex.I • basisVector j)) := by
    apply PiLp.ext
    intro i
    have hs : (∑ j : Fin k,
        ((z j).re • basisVector j + (z j).im • (Complex.I • basisVector j))) i =
        ∑ j : Fin k,
          ((z j).re • basisVector j + (z j).im • (Complex.I • basisVector j)) i :=
      map_sum (PiLp.projₗ (𝕜 := ℝ) 2 (fun _ : Fin k => ℂ) i) _ _
    rw [hs]
    simp [PiLp.add_apply, PiLp.smul_apply, basisVector,
      Complex.real_smul, mul_ite, Finset.sum_add_distrib]
  calc
    ell z = ell (∑ j : Fin k,
        ((z j).re • basisVector j + (z j).im • (Complex.I • basisVector j))) :=
      congrArg ell hz
    _ = ∑ j : Fin k,
        ((z j).re * ell (basisVector j) +
          (z j).im * ell (Complex.I • basisVector j)) := by
      rw [map_sum]
      simp only [map_add, map_smul, smul_eq_mul]
    _ = (∑ j, separatorCoefficients ell j * z j).re := by
      rw [Complex.re_sum]
      apply Finset.sum_congr rfl
      intro j _hj
      simp only [separatorCoefficients, Complex.mul_re, Complex.sub_re,
        Complex.sub_im, Complex.mul_im, Complex.ofReal_re, Complex.ofReal_im,
        Complex.I_re, Complex.I_im]
      ring

#print axioms real_separator_complex_form
#assert_trust kernel real_separator_complex_form

end
end NLA.IE02
