"""Read-only public Git object audit, with sealed prior package bytes; no Git CLI."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

R = Path(__file__).resolve().parent
B = Path('/private/tmp/nla-lean-next-20260915')
PREFLIGHT = B / 'reviews/IE02-package-referee-20260917'
GH = '/tmp/nla-submission-tools/gh_2.100.0_macOS_arm64/bin/gh'
REPO = 'sgstepaniants/OpenProblemsInNLA'
COMMIT = '9dc46f23457fed8396ad9f6a77677efe30c87df4'
SEED = '91e59797d7427eade2a36f3f656d1c9b518bc831'
BASE = '849003686970b372e1b2128ba072f86168f81d38'
PROJECT = 'linear-systems-and-elimination/IE-02/lean'
out = R / 'public-source'
out.mkdir(exist_ok=True)
calls = []

def sha(data): return hashlib.sha256(data).hexdigest()
def git_blob(data): return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
def save(rel, data):
    p = out / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists(): assert p.read_bytes() == data, p
    else: p.write_bytes(data)
    return p
def api(endpoint, rel):
    argv = [GH, 'api', '--allow-escape-sequences', f'repos/{REPO}/{endpoint}']
    start = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(argv, capture_output=True, check=False)
    save(rel, result.stdout)
    save(rel + '.stderr', result.stderr)
    calls.append({'argv': argv, 'start_utc': start, 'end_utc': datetime.now(timezone.utc).isoformat(),
                  'exit_code': result.returncode, 'snapshot': 'public-source/' + rel,
                  'sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr)})
    assert result.returncode == 0, result.stderr.decode()
    return json.loads(result.stdout)
head = api('git/commits/' + COMMIT, 'head-commit.json')
seed = api('git/commits/' + SEED, 'seed-commit.json')
assert head['sha'] == COMMIT and [p['sha'] for p in head['parents']] == [SEED]
assert seed['sha'] == SEED and [p['sha'] for p in seed['parents']] == [BASE]
assert head['author']['email'] == head['committer']['email'] == ''
trees = {}
def tree(oid):
    if oid not in trees:
        data = api('git/trees/' + oid, 'trees/' + oid + '.json')
        assert data['sha'] == oid and not data.get('truncated')
        trees[oid] = {x['path']: x for x in data['tree']}
    return trees[oid]
def locate(root, path):
    current = root
    pieces = path.split('/')
    for i, part in enumerate(pieces):
        entry = tree(current)[part]
        if i < len(pieces) - 1: assert entry['type'] == 'tree'
        current = entry['sha']
    return entry
def without(entries, excluded): return {k: (v['mode'], v['type'], v['sha']) for k, v in entries.items() if k != excluded}
head_root, seed_root = head['tree']['sha'], seed['tree']['sha']
hr, sr = tree(head_root), tree(seed_root)
category = 'linear-systems-and-elimination'
assert without(hr, category) == without(sr, category)
hc, sc = tree(hr[category]['sha']), tree(sr[category]['sha'])
assert without(hc, 'IE-02') == without(sc, 'IE-02')
hp, sp = tree(hc['IE-02']['sha']), tree(sc['IE-02']['sha'])
assert without(hp, 'lean') == without(sp, 'lean') and 'lean' not in sp
assert hp['lean']['type'] == 'tree'
project_tree = api('git/trees/' + hp['lean']['sha'] + '?recursive=1', 'project-tree.json')
assert not project_tree.get('truncated') and project_tree['sha'] == hp['lean']['sha']
public_files = {x['path']: x for x in project_tree['tree'] if x['type'] == 'blob'}
assert all(x['type'] in {'blob', 'tree'} for x in project_tree['tree'])
assert all(x['mode'] in {'100644', '100755'} for x in public_files.values())

assert sha((PREFLIGHT / 'MANIFEST.json').read_bytes()) == '7dd5268cb2935ae95fcfa5cb678625ff25306adffbda9a9ba60e59d1e8f57d7b'
source_map = {}
preflight_bindings = json.loads((PREFLIGHT / 'core-01/SNAPSHOT.json').read_text())['bindings']
for f in preflight_bindings:
    if f['copy'].startswith('core-01/candidate/'):
        rel = f['copy'][len('core-01/candidate/'):]
        source_map[rel] = {'path': rel, 'snapshot': f['copy'], 'sha256': f['sha256']}
assert set(public_files) == set(source_map) and len(source_map) == 1953
source_bindings = {}
zip_path = out / 'reviewed-package.zip'
assert not zip_path.exists()
with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for rel, record in sorted(source_map.items()):
        data = (PREFLIGHT / record['snapshot']).read_bytes()
        assert sha(data) == record['sha256']
        oid = git_blob(data)
        assert oid == public_files[rel]['sha'], rel
        z.writestr(rel, data)
        source_bindings[rel] = {'sha256': sha(data), 'git_blob_sha1': oid, 'mode': public_files[rel]['mode']}

repo_bindings = []
for record in preflight_bindings:
    if not record['copy'].startswith('core-01/infrastructure/'): continue
    rel = record['copy'][len('core-01/infrastructure/'):]
    record['snapshot'] = record['copy']
    entry = locate(head_root, rel)
    data = (PREFLIGHT / record['snapshot']).read_bytes()
    assert entry['type'] == 'blob' and entry['sha'] == git_blob(data), rel
    assert sha(data) == record['sha256']
    dest = 'repository/' + rel
    if rel.endswith('.py'): dest += '.txt'
    save(dest, data)
    repo_bindings.append({'path': rel, 'snapshot': 'public-source/' + dest,
                          'sha256': sha(data), 'git_blob_sha1': entry['sha']})
save('SOURCE-BINDINGS.json', (json.dumps({'project': PROJECT, 'commit': COMMIT,
    'files': source_bindings, 'repository_files': repo_bindings}, indent=2) + '\n').encode())
receipt = {'scope': 'Independent read-only GitHub Git-object/source-byte audit; no local Git/Lean/Lake/Comparator invocation.',
    'repository': REPO, 'commit': COMMIT, 'seed': SEED, 'base': BASE,
    'head_tree': head_root, 'seed_tree': seed_root, 'project_tree': hp['lean']['sha'],
    'only_added_tree': PROJECT, 'canonical_parent_files_and_all_other_paths_unchanged': True,
    'bound_package_files': len(source_bindings), 'bound_repository_files': len(repo_bindings),
    'reviewed_package_manifest_sha256': source_bindings['PACKAGE-MANIFEST.json']['sha256'],
    'reviewed_package_zip_sha256': sha(zip_path.read_bytes()),
    'prior_preflight_manifest_sha256': sha((PREFLIGHT / 'MANIFEST.json').read_bytes()), 'api_calls': calls}
save('RECEIPT.json', (json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps({k: v for k, v in receipt.items() if k != 'api_calls'}, indent=2))
