"""Read-only public Git object audit, with sealed prior package bytes; no Git CLI."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

R = Path(__file__).resolve().parent
B = Path('/private/tmp/nla-lean-next-20260915')
PREFLIGHT = B / 'reviews/SP15-package-referee-20260917'
GH = '/tmp/nla-submission-tools/gh_2.100.0_macOS_arm64/bin/gh'
REPO = 'sgstepaniants/OpenProblemsInNLA'
COMMIT = '69938fe5ac20768f7c23c0bead00b6add2516200'
SEED = '836b6e206ac07aa3b95c11017b8d974d3b1d0798'
BASE = '849003686970b372e1b2128ba072f86168f81d38'
PROJECT = 'eigenvalues-and-inverse-problems/SP-15/lean'
out = R / 'public-source'
out.mkdir(exist_ok=True)
calls = []

def sha(data): return hashlib.sha256(data).hexdigest()
def git_blob(data): return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
def save(rel, data):
    p = out / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists(): assert p.read_bytes() == data, p
    else: p.write_bytes(data)
    return p
def api(endpoint, rel):
    argv = [GH, 'api', '--allow-escape-sequences', f'repos/{REPO}/{endpoint}']
    start = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(argv, capture_output=True, check=False)
    save(rel, result.stdout)
    save(rel + '.stderr', result.stderr)
    calls.append({'argv': argv, 'start_utc': start, 'end_utc': datetime.now(timezone.utc).isoformat(),
                  'exit_code': result.returncode, 'snapshot': 'public-source/' + rel,
                  'sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr)})
    assert result.returncode == 0, result.stderr.decode()
    return json.loads(result.stdout)
head = api('git/commits/' + COMMIT, 'head-commit.json')
seed = api('git/commits/' + SEED, 'seed-commit.json')
assert head['sha'] == COMMIT and [p['sha'] for p in head['parents']] == [SEED]
assert seed['sha'] == SEED and [p['sha'] for p in seed['parents']] == [BASE]
assert head['author']['email'] == head['committer']['email'] == ''
trees = {}
def tree(oid):
    if oid not in trees:
        data = api('git/trees/' + oid, 'trees/' + oid + '.json')
        assert data['sha'] == oid and not data.get('truncated')
        trees[oid] = {x['path']: x for x in data['tree']}
    return trees[oid]
def locate(root, path):
    current = root
    pieces = path.split('/')
    for i, part in enumerate(pieces):
        entry = tree(current)[part]
        if i < len(pieces) - 1: assert entry['type'] == 'tree'
        current = entry['sha']
    return entry
def without(entries, excluded): return {k: (v['mode'], v['type'], v['sha']) for k, v in entries.items() if k != excluded}
head_root, seed_root = head['tree']['sha'], seed['tree']['sha']
hr, sr = tree(head_root), tree(seed_root)
category = 'eigenvalues-and-inverse-problems'
assert without(hr, category) == without(sr, category)
hc, sc = tree(hr[category]['sha']), tree(sr[category]['sha'])
assert without(hc, 'SP-15') == without(sc, 'SP-15')
hp, sp = tree(hc['SP-15']['sha']), tree(sc['SP-15']['sha'])
assert without(hp, 'lean') == without(sp, 'lean') and 'lean' not in sp
assert hp['lean']['type'] == 'tree'
project_tree = api('git/trees/' + hp['lean']['sha'] + '?recursive=1', 'project-tree.json')
assert not project_tree.get('truncated') and project_tree['sha'] == hp['lean']['sha']
public_files = {x['path']: x for x in project_tree['tree'] if x['type'] == 'blob'}
assert all(x['type'] in {'blob', 'tree'} for x in project_tree['tree'])
assert all(x['mode'] in {'100644', '100755'} for x in public_files.values())

assert sha((PREFLIGHT / 'MANIFEST.json').read_bytes()) == 'ed964e3352b5a0feada88bb583911123daac08b7b497ffddd4a9f7bb633feaeb'
source_map = {}
for name in ['SOURCE-SNAPSHOT.json', 'METADATA-REPAIR-SNAPSHOT.json', 'FINAL-ASSEMBLY-SNAPSHOT.json']:
    for f in json.loads((PREFLIGHT / name).read_text())['files']:
        source_map[f['path']] = f
assert set(public_files) == set(source_map) and len(source_map) == 2237
source_bindings = {}
zip_path = out / 'reviewed-package.zip'
assert not zip_path.exists()
with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for rel, record in sorted(source_map.items()):
        data = (PREFLIGHT / record['snapshot']).read_bytes()
        assert sha(data) == record['sha256']
        oid = git_blob(data)
        assert oid == public_files[rel]['sha'], rel
        z.writestr(rel, data)
        source_bindings[rel] = {'sha256': sha(data), 'git_blob_sha1': oid, 'mode': public_files[rel]['mode']}

repo_bindings = []
for record in json.loads((PREFLIGHT / 'EXTERNAL-BINDINGS.json').read_text())['files']:
    rel = record.get('path')
    if rel is None: continue
    entry = locate(head_root, rel)
    data = (PREFLIGHT / record['snapshot']).read_bytes()
    assert entry['type'] == 'blob' and entry['sha'] == git_blob(data), rel
    assert sha(data) == record['sha256']
    dest = 'repository/' + rel
    if rel.endswith('.py'): dest += '.txt'
    save(dest, data)
    repo_bindings.append({'path': rel, 'snapshot': 'public-source/' + dest,
                          'sha256': sha(data), 'git_blob_sha1': entry['sha']})
save('SOURCE-BINDINGS.json', (json.dumps({'project': PROJECT, 'commit': COMMIT,
    'files': source_bindings, 'repository_files': repo_bindings}, indent=2) + '\n').encode())
receipt = {'scope': 'Independent read-only GitHub Git-object/source-byte audit; no local Git/Lean/Lake/Comparator invocation.',
    'repository': REPO, 'commit': COMMIT, 'seed': SEED, 'base': BASE,
    'head_tree': head_root, 'seed_tree': seed_root, 'project_tree': hp['lean']['sha'],
    'only_added_tree': PROJECT, 'canonical_parent_files_and_all_other_paths_unchanged': True,
    'bound_package_files': len(source_bindings), 'bound_repository_files': len(repo_bindings),
    'reviewed_package_manifest_sha256': source_bindings['PACKAGE-MANIFEST.json']['sha256'],
    'reviewed_package_zip_sha256': sha(zip_path.read_bytes()),
    'prior_preflight_manifest_sha256': sha((PREFLIGHT / 'MANIFEST.json').read_bytes()), 'api_calls': calls}
save('RECEIPT.json', (json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps({k: v for k, v in receipt.items() if k != 'api_calls'}, indent=2))
