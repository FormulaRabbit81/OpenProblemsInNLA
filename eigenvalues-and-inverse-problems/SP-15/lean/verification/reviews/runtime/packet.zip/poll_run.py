"""Read-only GitHub run observation; no mutation or success inference."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess

R = Path(__file__).resolve().parent
GH = '/tmp/nla-submission-tools/gh_2.100.0_macOS_arm64/bin/gh'
REPO = 'sgstepaniants/OpenProblemsInNLA'
COMMIT = '69938fe5ac20768f7c23c0bead00b6add2516200'
stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
out = R / 'observations' / stamp
out.mkdir(parents=True)
paths = {
    'run.json': 'actions/runs/35229660506',
    'jobs.json': 'actions/runs/35229660506/jobs?per_page=100',
    'ids-run.json': 'actions/runs/35229660530',
}
def fetch(item):
    name, path = item
    argv = [GH, 'api', '--allow-escape-sequences', 'repos/' + REPO + '/' + path]
    result = subprocess.run(argv, capture_output=True, check=False)
    (out / name).write_bytes(result.stdout)
    (out / (name + '.stderr')).write_bytes(result.stderr)
    return name, {'argv': argv, 'exit_code': result.returncode,
                  'sha256': hashlib.sha256(result.stdout).hexdigest(),
                  'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()}
with ThreadPoolExecutor(max_workers=3) as pool:
    calls = dict(pool.map(fetch, paths.items()))
(out / 'RECEIPT.json').write_text(json.dumps({'observed_utc': stamp, 'calls': calls}, indent=2) + '\n')
assert all(c['exit_code'] == 0 for c in calls.values()), calls
run = json.loads((out / 'run.json').read_text())
jobs = json.loads((out / 'jobs.json').read_text())['jobs']
ids = json.loads((out / 'ids-run.json').read_text())
assert run['id'] == 35229660506 and run['head_sha'] == COMMIT
assert ids['id'] == 35229660530 and ids['head_sha'] == COMMIT
print(json.dumps({'observation': str(out), 'commit': COMMIT,
    'run': {k: run[k] for k in ['id', 'status', 'conclusion', 'run_attempt', 'html_url']},
    'jobs': [{k: j[k] for k in ['id', 'name', 'status', 'conclusion']} for j in jobs],
    'ids_run': {k: ids[k] for k in ['id', 'status', 'conclusion', 'html_url']},
    'scope': 'Observed GitHub status only; completed artifacts and logs still require audit.'}, indent=2))
