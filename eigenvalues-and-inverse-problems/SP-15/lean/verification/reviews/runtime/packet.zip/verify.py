"""Offline, read-only evidence audit. Never invokes Lean, Git, a shell, or network.

This verifies the captured run and source bindings; it is not another execution
of Comparator or a review of the informal mathematics. Only the stdlib is used.
"""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import shlex
import zipfile

R = Path(__file__).resolve().parent
checks = 0


def check(value, label):
    global checks
    checks += 1
    if not value:
        raise AssertionError(label)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git_object(kind, data):
    return hashlib.sha1(kind.encode() + b' ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        check(key not in result, 'duplicate JSON key ' + key)
        result[key] = value
    return result


def obj(path):
    return json.loads((R / path).read_text(), object_pairs_hook=unique)


def safe(path):
    p = PurePosixPath(path)
    check(not p.is_absolute() and '..' not in p.parts and str(p) == path,
          'unsafe relative path: ' + path)
    return p


def zip_contents(path):
    data = {}
    with zipfile.ZipFile(path) as z:
        for entry in z.infolist():
            safe(entry.filename.rstrip('/'))
            check((entry.external_attr >> 16) & 0o170000 != 0o120000, 'ZIP symlink')
            if entry.is_dir():
                continue
            check(entry.filename not in data, 'duplicate ZIP entry')
            data[entry.filename] = z.read(entry)
    return data


def without(entries, excluded):
    return {k: (v['mode'], v['type'], v['sha']) for k, v in entries.items() if k != excluded}


def strip_timestamp(line):
    return re.sub(r'^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z ', '', line)


def markers(text, values, label):
    for value in values:
        check(value in text, label + ': ' + value)


params = obj('PARAMETERS.json')
problem, project, commit = params['problem'], params['project'], params['commit']
source = obj('public-source/SOURCE-BINDINGS.json')
receipt = obj('public-source/RECEIPT.json')
check(source['commit'] == receipt['commit'] == commit, 'public source commit')
check(source['project'] == receipt['only_added_tree'] == project, 'canonical path')
check(receipt['seed'] == params['seed'] and receipt['base'] == params['base'], 'base/seed')
check(sha((R / 'package-preflight/MANIFEST.json').read_bytes()) ==
      receipt['prior_preflight_manifest_sha256'] == params['preflight_manifest_sha256'], 'prior sealed review')

head, seed = obj('public-source/head-commit.json'), obj('public-source/seed-commit.json')
base = obj('public-source/base-commit.json')
base_receipt = obj('public-source/BASE-COMMIT-RECEIPT.json')
check(sha((R / 'public-source/base-commit.json').read_bytes()) == base_receipt['stdout_sha256'] and
      base_receipt['exit_code'] == 0, 'base commit API capture')
check(base['sha'] == params['base'] and base['tree']['sha'] == seed['tree']['sha'], 'empty seed exactly preserves published base tree')
check(head['sha'] == commit and [p['sha'] for p in head['parents']] == [params['seed']], 'head identity/parent')
check(seed['sha'] == params['seed'] and [p['sha'] for p in seed['parents']] == [params['base']], 'seed parent')
check(head['author']['email'] == head['committer']['email'] == '', 'no published contributor email')
trees = {}
for path in sorted((R / 'public-source/trees').glob('*.json')):
    t = obj(path.relative_to(R))
    check(not t.get('truncated'), 'complete nonrecursive tree')
    entries = sorted(t['tree'], key=lambda x: (x['path'] + ('/' if x['type'] == 'tree' else '')).encode())
    raw = b''.join((x['mode'].lstrip('0') + ' ' + x['path']).encode() + b'\0' + bytes.fromhex(x['sha']) for x in entries)
    check(git_object('tree', raw) == t['sha'] == path.stem, 'Git tree object hash')
    trees[t['sha']] = {x['path']: x for x in entries}


def locate(root, path):
    current = root
    for part in path.split('/'):
        entry = trees[current][part]
        current = entry['sha']
    return entry


category, pid, leaf = project.split('/')
check(leaf == 'lean' and pid == problem, 'canonical problem path')
hr, sr = trees[head['tree']['sha']], trees[seed['tree']['sha']]
check(without(hr, category) == without(sr, category), 'all other root subtrees unchanged')
hc, sc = trees[hr[category]['sha']], trees[sr[category]['sha']]
check(without(hc, pid) == without(sc, pid), 'all other category subtrees unchanged')
hp, sp = trees[hc[pid]['sha']], trees[sc[pid]['sha']]
check(without(hp, 'lean') == without(sp, 'lean') and 'lean' not in sp,
      'original canonical pages unchanged; only new lean subtree')
ptree = obj('public-source/project-tree.json')
check(not ptree.get('truncated') and ptree['sha'] == hp['lean']['sha'], 'complete public project tree')
blobs = {x['path']: x for x in ptree['tree'] if x['type'] == 'blob'}
check(all(x['type'] in {'blob', 'tree'} for x in ptree['tree']), 'ordinary project tree')
package_zip = R / 'public-source/reviewed-package.zip'
package = zip_contents(package_zip)
check(sha(package_zip.read_bytes()) == receipt['reviewed_package_zip_sha256'], 'package archive identity')
check(set(package) == set(blobs) == set(source['files']), 'all committed package paths')
check(len(package) == params['package_files'], 'package file count')
for rel, data in package.items():
    entry = source['files'][rel]
    check(sha(data) == entry['sha256'], 'reviewed source SHA256 ' + rel)
    check(git_object('blob', data) == entry['git_blob_sha1'] == blobs[rel]['sha'], 'public Git blob ' + rel)
    check(blobs[rel]['mode'] == entry['mode'] and entry['mode'] in {'100644', '100755'}, 'ordinary file ' + rel)
check(sha(package['PACKAGE-MANIFEST.json']) == params['package_manifest_sha256'] ==
      receipt['reviewed_package_manifest_sha256'], 'approved package manifest')
preflight_manifest = obj('package-preflight/MANIFEST.json')
prior_package = {}
if problem == 'SP-15':
    for index in ['SOURCE-SNAPSHOT.json','METADATA-REPAIR-SNAPSHOT.json','FINAL-ASSEMBLY-SNAPSHOT.json']:
        check(sha((R / 'package-preflight' / index).read_bytes()) == preflight_manifest['files'][index], 'sealed preflight index ' + index)
        for entry in obj('package-preflight/' + index)['files']:
            check(entry['sha256'] == preflight_manifest['files'][entry['snapshot']], 'original sealed snapshot ' + entry['path'])
            prior_package[entry['path']] = entry['sha256']
else:
    for path, digest in preflight_manifest['files'].items():
        if path.startswith('core-01/candidate/'):
            prior_package[path[len('core-01/candidate/'):]] = digest
check(prior_package == {k:sha(v) for k,v in package.items()}, 'all public package files equal prior sealed reviewer snapshots')
for entry in source['repository_files']:
    data = (R / entry['snapshot']).read_bytes()
    check(sha(data) == entry['sha256'], 'repository source SHA256 ' + entry['path'])
    check(git_object('blob', data) == entry['git_blob_sha1'] ==
          locate(head['tree']['sha'], entry['path'])['sha'], 'public infrastructure blob ' + entry['path'])
for call in receipt['api_calls']:
    check(call['exit_code'] == 0 and sha((R / call['snapshot']).read_bytes()) == call['sha256'], 'source API evidence')

run = obj('final-run/run.json')
check(run['id'] == params['run'] and run['head_sha'] == commit and run['run_attempt'] == 1, 'actual final run identity')
check(run['status'] == 'completed' and run['conclusion'] == 'success' and run['event'] == 'push', 'completed normal push run')
check(run['repository']['full_name'] == params['repository'], 'GitHub repository')
jobs_obj = obj('final-run/jobs.json')
jobs = jobs_obj['jobs']
check(jobs_obj['total_count'] == len(jobs) == 3, 'complete job matrix')
selected = [j for j in jobs if j['name'].startswith('verify (')]
check(len(selected) == 1 and selected[0]['name'] == f'verify ({problem}, {project})', 'sole actual selected project')
job = selected[0]
for j in jobs:
    expected = 'skipped' if j['name'] == 'checker-controls' else 'success'
    check(j['status'] == 'completed' and j['conclusion'] == expected, 'actual job outcome')
    check(j['head_sha'] == commit and j['run_id'] == run['id'], 'job source/run binding')
    check(all(s['conclusion'] in {'success', 'skipped'} for s in j['steps']), 'job step outcomes')
select = next(j for j in jobs if j['name'] == 'select')
select_raw = (R / f"final-run/job-{select['id']}.log").read_text()
actual_matrix = [json.loads(strip_timestamp(x)) for x in select_raw.splitlines()
                 if strip_timestamp(x).startswith('{"include":')]
check(actual_matrix == [{'include': [{'id': problem, 'project': project}]}], 'actual selector output')
markers(select_raw, ['BASE_REF: ' + params['seed'], 'EVENT_NAME: push', 'Ran 30 tests', 'Ran 12 tests'], 'actual selection gates')

arts_obj = obj('final-run/artifacts.json')
check(arts_obj['total_count'] == len(arts_obj['artifacts']) == 1, 'sole immutable artifact')
artifact = arts_obj['artifacts'][0]
archive = R / ('final-run/lean-' + problem + '.zip')
check(artifact['id'] == params['artifact'] and artifact['name'] == 'lean-' + problem, 'artifact identity')
check(not artifact['expired'] and artifact['workflow_run']['id'] == run['id'] and
      artifact['workflow_run']['head_sha'] == commit, 'artifact workflow binding')
check(artifact['digest'] == 'sha256:' + sha(archive.read_bytes()) == 'sha256:' + params['artifact_sha256'], 'GitHub artifact digest')
payload = zip_contents(archive)
artifact_root = R / 'final-run/artifacts' / ('lean-' + problem)
check(set(payload) == {p.relative_to(artifact_root).as_posix() for p in artifact_root.rglob('*') if p.is_file()}, 'complete extracted artifact')
for rel, data in payload.items():
    check((artifact_root / rel).read_bytes() == data, 'unmodified artifact payload ' + rel)
results = list(artifact_root.glob('verify-*/result.json'))
check(len(results) == 1, 'one actual verification result')
result_path = results[0]
result = obj(result_path.relative_to(R))
check(result['repository_commit'] == commit and result['project'] == project and
      result['result'] == 'comparator-accepted', 'actual exact source acceptance')
check(result['semantic_review'] == 'not-performed-by-this-command', 'honest semantic scope')
check(result['input_sha256'] == {k: sha(v) for k, v in package.items()}, 'all actual inputs match public approved package')
config = json.loads(package['comparator.json'], object_pairs_hook=unique)
check(result['config'] == config, 'literal Comparator config')
names = config['theorem_names']
standard = {'propext', 'Quot.sound', 'Classical.choice'}
check(len(names) == len(set(names)) == params['contracts'], 'exact contract count')
check(config['definition_names'] == [] and config['challenge_module'] == 'Challenge' and
      config['solution_module'] == 'Solution', 'no definition holes and distinct modules')
check(len(config['permitted_axioms']) == 3 and set(config['permitted_axioms']) == standard, 'standard axiom set, order immaterial')

repo_files = {x['path']: R / x['snapshot'] for x in source['repository_files']}
lock_bytes = repo_files['tools/lean/source-lock.json'].read_bytes()
lock = json.loads(lock_bytes, object_pairs_hook=unique)
tool = result['tool_receipt']
check(sha(lock_bytes) == result['source_lock_sha256'] == tool['source_lock_sha256'] ==
      'b3833b07916e5db77579b9cc53ca582282f6a841f36d6a60d693e5b02d342b6b', 'unchanged checker source lock')
check(lock['commit'] == tool['forsythe_commit'] == '8d1b0c0545a77b40245e84705aa7d273e6c81e62', 'checker source pin')
check(len(lock['files']) == 58, 'locked checker source count')
check(tool['lean_toolchain'] == lock['lean_toolchain'] == package['lean-toolchain'].decode().strip() ==
      'leanprover/lean4:v4.33.1', 'Lean toolchain identity')
check(tool['platform'].startswith('Linux-') and 'x86_64-unknown-linux-gnu' in tool['lean_version'], 'real Linux platform')
check(tool['go_version'] == 'go version go1.27.1 linux/amd64', 'pinned Go version')
check(tool['executables'] == params['executables'], 'recorded freshly built/revalidated executable hashes')
check(tool['ci_sandbox_probe_sha256'] == '31057195baf238807cacbb4126c5b07f02cec55a4e4437de5f3a755b3fada803', 'reviewed CI probe adaptation hash')

evidence = result_path.parent
logs = {p.name: p.read_text() for p in evidence.glob('*.log')}
check(set(logs) == {'comparator.log','kernel-controls.log','comparator-controls.log','sandbox.log',
      'negative-native.log','negative-sorry.log','user-service.log','dependencies.log','mathlib-cache.log'}, 'all actual phases')
for name, text in logs.items():
    status = 1 if name in {'negative-native.log', 'negative-sorry.log'} else 0
    check(text.rstrip().endswith('EXIT_STATUS=' + str(status)), 'actual process exit ' + name)
comp = logs['comparator.log']
for module in ['Challenge', 'Solution']:
    exports = [line for line in comp.splitlines() if line.startswith('Exporting #[') and line.endswith(' from ' + module)]
    check(len(exports) == 1, 'one export from ' + module)
    check(re.findall(r'\bNLA\.[A-Za-z0-9_.]+', exports[0]) == names, 'literal export order ' + module)
aggregate = re.findall(r"info: Solution\.lean:\d+:\d+: '([^']+)' depends on axioms: \[([^\]]*)\]", comp)
check([name for name, _ in aggregate] == names, 'all aggregate axiom records in exact order')
all_axioms = re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", comp)
for name, ax in all_axioms:
    check(set(ax.split(', ')) <= standard, 'observed permitted axioms ' + name)
check(comp.index('Building Challenge') < comp.index('Building Solution') < comp.index('Running Lean default kernel on solution.'), 'fresh build/export/kernel phase order')
check(comp.count('declaration uses `sorry`') == len(names) and
      'declaration uses `sorry`' not in comp[comp.index('Building Solution'):], 'only intentional Challenge sorry warnings')
check(all(s not in comp for s in ['sorryAx', 'Illegal axiom', 'error:', 'uncaught exception']), 'no solution rejection or hole')
check(comp.count('Lean default kernel accepts the solution') == comp.count('Your solution is okay!') == 1, 'single actual default kernel and Comparator acceptance')
args = shlex.split(comp.splitlines()[0][2:])
check(args[:6] == ['systemd-run','--user','--quiet','--wait','--pipe','--collect'], 'actual non-root systemd route')
markers(comp.splitlines()[0], ['RestrictAddressFamilies=~AF_UNIX','/usr/bin/env -i', 'COMPARATOR_LANDRUN=',
        '/scripts/strict_landrun.py', 'nla-fresh-proof-', 'lake env ', '/bin/comparator comparator.json'], 'actual strict Comparator command')
check(not any('fake' in a.lower() for a in args), 'no fake sandbox argument')
active = [n for n in package if n.endswith('.lean')]
check(len(active) == params['active_lean_files'], 'active Lean source count')
modules = {n[:-5].replace('/', '.') for n in active}
built = set(re.findall(r'Built ([A-Za-z0-9_.]+) \(', comp))
check(modules <= built, 'freshly built all active project modules including Challenge')
numeric = package['NLA/' + problem.replace('-', '') + '/Numerical.lean'].decode()
markers(numeric, ['set_option leancert.trust "kernel"','interval_decide (trust := kernel)', '#assert_trust kernel'], 'published numerical kernel mode')
for marker in ['RETURN honest_with_inductives_and_quotients: accepted', 'RETURN invalid_raw_proof: rejected:',
               'RETURN quotient_postcheck_mismatch: rejected: Quotient constant mismatch on: Quot.lift',
               'PASS: all three actual Comparator.runBuiltinKernel cases behaved as required']:
    check(marker in logs['kernel-controls.log'], 'kernel control ' + marker)
for fixture, expected, marker in [
    ('simple_match',0,'Your solution is okay!'),
    ('simple_mismatch',1,"Challenge and solution constant kind don't match: 'comm'"),
    ('simple_axiom_issue',1,"Illegal axiom detected: 'helper'"),
    ('simple_kind_mismatch',1,"Illegal axiom detected: 'helper'"),
    ('type_mismatch',1,"Challenge and solution theorem statement do not match: 'checked'")]:
    check(f'PASS {fixture}: exit {expected}, expected {expected}; required phase: {marker}' in logs['comparator-controls.log'], 'actual regression outcome ' + fixture)
check('PASS: all five Comparator regressions' in logs['comparator-controls.log'], 'regression complete')
check("Illegal axiom detected: 'sorryAx'" in logs['negative-sorry.log'], 'actual sorry rejection')
check("Illegal axiom detected: 'checked._native.native_decide.ax_1_1'" in logs['negative-native.log'], 'actual native rejection')
sandbox = logs['sandbox.log']
uids = [int(n) for n in re.findall(r'Sandbox UID: (\d+)', sandbox)]
check(len(uids) == 2 and all(n > 0 for n in uids), 'non-root build and export UIDs')
shared_markers = ['outside .lake write-open: denied','outside .lake truncate: denied',
    'outside .lake read-only truncate-open: denied','symlink from .lake to outside write: denied',
    'outside .lake creation: denied','host parent: absent from private /proc','host parent signal lookup: denied',
    'host loopback listener: unreachable','AF_UNIX socket creation: denied','effective capabilities: none',
    'no_new_privs: set','nested namespace write attempt: rejected exit=1']
shared_markers += [n + ' namespace: private' for n in ['user','pid','mnt','net','ipc','uts']]
for mode in ['build','export']:
    section = sandbox.split('MODE ' + mode + ': exit=0\n',1)[1].split('Finished with result:',1)[0]
    markers(section, ['PASS ' + m for m in shared_markers], 'actual sandbox ' + mode)
markers(sandbox, ['PASS build .lake write: allowed','PASS export .lake write-open: denied',
        'PASS export .lake truncate: denied','Outer and export fixture contents unchanged; only designated build fixture written.'], 'writable boundary')
for case in ['unknown option','unexpected --rw','unexpected --rwx','relative --rwx']:
    check('NEGATIVE ' + case + ': exit=2' in sandbox, 'sandbox argument rejection ' + case)
deps = json.loads(package['lake-manifest.json'])['packages']
for dep in deps:
    check("checking out revision '" + dep['rev'] + "'" in logs['dependencies.log'], 'actual exact dependency ' + dep['name'])
check('Decompressed 8690 file(s)' in logs['mathlib-cache.log'], 'actual pinned Mathlib cache completed')
for p in sorted((artifact_root / 'bootstrap').glob('*.log')):
    check(p.read_text().rstrip().endswith('EXIT_STATUS=0'), 'actual fresh tool build ' + p.name)

raw_path = R / f"final-run/job-{job['id']}.log"
raw = raw_path.read_text()
raw_lines = [strip_timestamp(x) for x in raw.splitlines()]
check(re.search(r'git log -1 --format=%H\n[^\n]*' + commit + r'\n', raw) is not None, 'actual checked-out commit')
markers(raw, [f'Manifest schema and comparator coverage: PASS ({len(names)} declarations)',
             'auto-config: false','build: false','use-github-cache: false','use-mathlib-cache: false',
             'PASS: fresh Comparator run and all controls.'], 'actual workflow gates')
markers(raw, ['SHA256 digest of uploaded artifact zip is ' + params['artifact_sha256'],
              'Artifact ID ' + str(params['artifact'])], 'raw upload identity corroborates GitHub API')
for name, text in logs.items():
    # Each nonblank payload line must appear in order in the raw GitHub job stream.
    # $ command and EXIT_STATUS are the artifact logger's own framing.
    start = 0
    for line in text.splitlines()[1:]:
        if not line or line.startswith('EXIT_STATUS='):
            continue
        try:
            start = raw_lines.index(line, start) + 1
        except ValueError:
            raise AssertionError('artifact/raw-job mismatch in ' + name + ': ' + line)
        check(True, 'raw job corroborates artifact line')

ids = obj('ids-run/run.json')
id_jobs = obj('ids-run/jobs.json')['jobs']
check(ids['id'] == params['ids_run'] and ids['head_sha'] == commit and
      ids['status'] == 'completed' and ids['conclusion'] == 'success', 'actual permanent-ID workflow')
check(len(id_jobs) == 1 and id_jobs[0]['conclusion'] == 'success', 'actual permanent-ID job')
id_raw = (R / f"ids-run/job-{id_jobs[0]['id']}.log").read_text()
markers(id_raw, ['Ran 17 tests','Validated 217 permanent problem IDs'], 'actual permanent-ID checks')
core_checks = checks
sealed = (R / 'MANIFEST.json').exists()
if sealed:
    manifest = obj('MANIFEST.json')
    # Nested historical MANIFEST.json files are payloads too.
    files = {p.relative_to(R).as_posix(): p for p in R.rglob('*') if p.is_file() and p != R / 'MANIFEST.json'}
    check(set(files) == set(manifest['files']), 'complete final review packet inventory')
    for name, digest in manifest['files'].items():
        safe(name)
        check(not files[name].is_symlink() and sha(files[name].read_bytes()) == digest, 'sealed review payload ' + name)

print(json.dumps({'result':'PASS','reviewer':'/root/sp15_full_referee1','problem':problem,
    'commit':commit,'run':run['id'],'job':job['id'],'artifact':artifact['id'],
    'artifact_sha256':sha(archive.read_bytes()),'package_files':len(package),'contracts':len(names),
    'active_lean_files':len(active),'actual_matrix':actual_matrix[0], 'nonroot_uids':uids,
    'permitted_axioms':sorted(standard),'observed_aggregate_axioms':{name:ax.split(', ') for name,ax in aggregate},
    'executables':tool['executables'],'tool_source_lock_sha256':sha(lock_bytes),
    'raw_job_sha256':sha(raw_path.read_bytes()),'result_sha256':sha(result_path.read_bytes()),
    'raw_logs_sha256':{p.name:sha(p.read_bytes()) for p in sorted(evidence.glob('*.log'))},
    'actual_ids_run':ids['id'],'core_checks':core_checks,'checks':checks,'sealed_packet':sealed,
    'local_Lean_or_Comparator_execution':False,
    'scope':'Offline verification of captured authentic GitHub execution evidence; not another mathematical review or rerun.'},indent=2))
